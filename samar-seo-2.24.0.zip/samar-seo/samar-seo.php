<?php
/**
 * Plugin Name: SEO Suite
 * Plugin URI:
 * Description: AI-powered SEO toolkit — bulk meta descriptions, image ALT tags, title optimizer, H1 checker, redirect manager, schema markup, llms.txt, broken link scanner, thin content detector, and Open Graph tags. Supports OpenAI, Azure OpenAI, and Anthropic Claude models.
 * Version: 2.24.0
 * Update URI: https://api.egiig.com/wp-plugin
 * Author: SEO Suite
 * Author URI:
 * License: GPL v2 or later
 * Text Domain: samar-seo
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SSEO_VERSION', '2.24.0' );
define( 'SSEO_DIR', plugin_dir_path( __FILE__ ) );
define( 'SSEO_URL', plugin_dir_url( __FILE__ ) );
define( 'SSEO_BASENAME', plugin_basename( __FILE__ ) );

/**
 * White-label product name. Agencies override it site-wide in wp-config.php with:
 *     define( 'SEO_SUITE_NAME', 'Acme SEO' );
 * or per-site via the sseo_whitelabel_name option. Falls back to the neutral default.
 */
if ( ! function_exists( 'sseo_product_name' ) ) {
    function sseo_product_name() {
        if ( defined( 'SEO_SUITE_NAME' ) && SEO_SUITE_NAME ) return SEO_SUITE_NAME;
        $n = get_option( 'sseo_whitelabel_name', '' );
        return $n !== '' ? $n : 'SEO Suite';
    }
}

/**
 * Stealth mode. When on, the SEO Suite tool menu (Meta, ALT Tags, Redirects, …) is not shown in
 * wp-admin and direct ?page=sseo* URLs are bounced, so the client never sees the list of what the
 * plugin does. The REST endpoints the agency platform calls are untouched, so every job still runs.
 * The Plugins row stays (WordPress requires it) with the white-label name set below.
 * Turn on with wp-config `define( 'SEO_SUITE_STEALTH', true );`, the sseo_stealth option, or from the
 * agency platform at connect time / via the /brand endpoint.
 * The agency operator can still open the hidden tools for one browser session by visiting any plugin
 * page with ?sseo_op=<the site's connect secret>; the client never has that secret.
 */
if ( ! function_exists( 'sseo_stealth' ) ) {
    function sseo_stealth() {
        if ( defined( 'SEO_SUITE_STEALTH' ) ) return (bool) SEO_SUITE_STEALTH;
        return (bool) get_option( 'sseo_stealth', 0 );
    }
    function sseo_stealth_operator() {
        if ( ! is_admin() || ! function_exists( 'sseo_connect_secret' ) ) return false;
        $secret = sseo_connect_secret();
        if ( $secret === '' ) return false;
        return isset( $_COOKIE['sseo_op'] ) && hash_equals( wp_hash( 'sseo_op|' . $secret ), (string) $_COOKIE['sseo_op'] );
    }
    function sseo_stealth_maybe_set_operator() {
        if ( empty( $_GET['sseo_op'] ) || ! current_user_can( 'manage_options' ) || ! function_exists( 'sseo_connect_secret' ) ) return;
        $secret = sseo_connect_secret();
        if ( $secret !== '' && hash_equals( $secret, (string) wp_unslash( $_GET['sseo_op'] ) ) ) {
            setcookie( 'sseo_op', wp_hash( 'sseo_op|' . $secret ), time() + 8 * HOUR_IN_SECONDS, defined( 'ADMIN_COOKIE_PATH' ) ? ADMIN_COOKIE_PATH : '/wp-admin/', defined( 'COOKIE_DOMAIN' ) ? COOKIE_DOMAIN : '', is_ssl(), true );
        }
    }
}

// Show the white-label name on the Plugins screen, and when overridden, hide upstream authorship.
add_filter( 'all_plugins', function ( $plugins ) {
    $base = defined( 'SSEO_BASENAME' ) ? SSEO_BASENAME : plugin_basename( __FILE__ );
    if ( isset( $plugins[ $base ] ) ) {
        $name = sseo_product_name();
        $plugins[ $base ]['Name']  = $name;
        $plugins[ $base ]['Title'] = $name;
        if ( ( defined( 'SEO_SUITE_NAME' ) && SEO_SUITE_NAME ) || get_option( 'sseo_whitelabel_name', '' ) !== '' ) {
            $plugins[ $base ]['Author']      = $name;
            $plugins[ $base ]['AuthorName']  = $name;
            $plugins[ $base ]['AuthorURI']   = '';
            $plugins[ $base ]['PluginURI']   = '';
            $plugins[ $base ]['Description'] = 'SEO optimization toolkit.';
        }
    }
    return $plugins;
} );

// Includes
require_once SSEO_DIR . 'includes/connect.php';
require_once SSEO_DIR . 'includes/sso.php';
require_once SSEO_DIR . 'includes/class-api-handler.php';
require_once SSEO_DIR . 'includes/class-seo-integration.php';
require_once SSEO_DIR . 'includes/class-meta-generator.php';
require_once SSEO_DIR . 'includes/class-alt-generator.php';
require_once SSEO_DIR . 'includes/class-title-optimizer.php';
require_once SSEO_DIR . 'includes/class-h1-checker.php';
require_once SSEO_DIR . 'includes/class-redirect-manager.php';
require_once SSEO_DIR . 'includes/class-schema-generator.php';
require_once SSEO_DIR . 'includes/class-llms-txt.php';
require_once SSEO_DIR . 'includes/class-broken-links.php';
require_once SSEO_DIR . 'includes/class-thin-content.php';
require_once SSEO_DIR . 'includes/class-open-graph.php';
require_once SSEO_DIR . 'includes/class-image-optimizer.php';
require_once SSEO_DIR . 'includes/class-robots-txt.php';
require_once SSEO_DIR . 'includes/class-orphan-pages.php';
require_once SSEO_DIR . 'includes/class-crawl-depth.php';
require_once SSEO_DIR . 'includes/class-anchor-text.php';
require_once SSEO_DIR . 'includes/class-internal-linker.php';
require_once SSEO_DIR . 'includes/class-redirect-chains.php';
require_once SSEO_DIR . 'includes/class-seo-audit.php';
require_once SSEO_DIR . 'includes/class-local-audit.php';
require_once SSEO_DIR . 'includes/class-ai-audit.php';
require_once SSEO_DIR . 'includes/class-report-generator.php';
require_once SSEO_DIR . 'includes/class-content-generator.php';
require_once SSEO_DIR . 'includes/class-page-templates.php';
require_once SSEO_DIR . 'includes/class-template-engine.php';
require_once SSEO_DIR . 'includes/class-testimonials.php';
require_once SSEO_DIR . 'includes/class-admin.php';
require_once SSEO_DIR . 'includes/class-ajax-handler.php';
require_once SSEO_DIR . 'includes/class-rest-api.php';
// Updates from the agency platform, like any other plugin (Plugins screen, auto-updates, the agency's update tool). [tracking-v28]
require_once SSEO_DIR . 'includes/class-updater.php';
// Site management API for the agency and its AI tools (egsm/v1). [site-manager v1]
require_once SSEO_DIR . 'site-manager/bootstrap.php';

final class Samar_SEO {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action( 'plugins_loaded', [ $this, 'init' ] );
        register_activation_hook( __FILE__, [ $this, 'activate' ] );
        // Deactivating revokes the agency's site-management key. [site-manager v1]
        register_deactivation_hook( __FILE__, function () { if ( class_exists( 'EGSM_Auth' ) ) { EGSM_Auth::revoke(); } } );

        // [site-manager v1] The Google/Bing sitemap ping endpoints were retired by both engines; new/updated URLs are
        // now sent via IndexNow (site-manager/includes/class-egsm-indexnow.php) and Google reads the sitemap.

    }

    public function init() {
        // [site-manager v1] Fix: register the standalone <title>/meta-description output early. It used to be
        // registered lazily from inside wp_head (by the schema/OG classes), after the title had already printed,
        // so titles and descriptions set in SEO Suite never reached the page when no other SEO plugin was active.
        if ( ! is_admin() ) {
            new SSEO_SEO_Integration();
        }
        new SSEO_Admin();
        new SSEO_Ajax_Handler();
        new SSEO_Rest_Api();
        new SSEO_Image_Optimizer();
        new SSEO_Report_Generator();
        new SSEO_Schema_Generator();
        new SSEO_Open_Graph();
        new SSEO_Redirect_Manager();
        new SSEO_LLMS_Txt();
        new SSEO_Testimonials();

        // Archive/Blog page intro — safe JS injection, works with any theme/builder
        add_action( 'wp_footer', function() {
            if ( is_admin() ) return;

            $intro = '';
            $page_id = 0;

            if ( is_home() ) {
                $page_id = (int) get_option('page_for_posts');
            } elseif ( is_category() || is_tag() ) {
                $term = get_queried_object();
                if ( $term ) $intro = get_term_meta( $term->term_id, '_sseo_archive_intro', true );
            }

            if ( $page_id && ! $intro ) {
                $intro = get_post_meta( $page_id, '_sseo_archive_intro', true );
            }

            if ( ! $intro ) return;

            // Encode for safe JS injection
            $safe = wp_json_encode( $intro );
            ?>
            <script>
            (function(){
                var intro = <?php echo $safe; ?>;
                if(!intro) return;
                var wrap = document.createElement('div');
                wrap.className = 'sseo-archive-intro';
                wrap.innerHTML = intro;

                // Strategy 1: Before first article/post element
                var targets = [
                    'article',
                    '.post',
                    '.hentry',
                    '.elementor-posts-container',
                    '.elementor-post',
                    '.blog-posts',
                    '.posts-container',
                    '[data-elementor-type="archive"]',
                    '.archive-posts'
                ];
                for(var i=0;i<targets.length;i++){
                    var el = document.querySelector(targets[i]);
                    if(el){
                        el.parentNode.insertBefore(wrap, el);
                        return;
                    }
                }

                // Strategy 2: After page title heading
                var headings = document.querySelectorAll('h1');
                for(var j=0;j<headings.length;j++){
                    var h = headings[j];
                    var text = h.textContent.trim().toLowerCase();
                    if(text === 'blog' || text === 'news' || text === 'articles' || text === 'posts'){
                        h.parentNode.insertBefore(wrap, h.nextSibling);
                        return;
                    }
                }

                // Strategy 3: After header or before main content
                var main = document.querySelector('main, [role="main"], #content, #primary, .site-content');
                if(main && main.firstChild){
                    main.insertBefore(wrap, main.firstChild);
                    return;
                }
            })();
            </script>
            <?php
        }, 99 );

        // Footer injection for Service Areas links
        add_action( 'wp_footer', function() {
            $parent = get_page_by_path('service-areas');
            if ( ! $parent || $parent->post_status !== 'publish' ) return;

            // Get all child pages of service-areas
            $children = get_pages(['parent' => $parent->ID, 'post_status' => 'publish', 'sort_column' => 'menu_order,post_title']);
            if ( empty($children) ) return;

            $links = [];
            foreach ($children as $child) {
                // Extract clean city name from slug: "baltimore-county-md" → "Baltimore County"
                $city = $child->post_name;
                $city = preg_replace('/-m[doa]$|-maryland$/i', '', $city); // strip state suffix
                $city = ucwords(str_replace('-', ' ', $city));
                $links[] = '<a href="' . get_permalink($child->ID) . '" style="color:rgba(255,255,255,.8);text-decoration:none;font-size:13px;transition:color .2s">' . esc_html($city) . '</a>';
            }

            echo '<div class="sseo-areas-footer" style="text-align:center;padding:16px 20px 8px;background:#1e293b">';
            echo '<div style="font-size:11px;font-weight:600;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:8px">Service Areas</div>';
            echo '<div style="display:flex;flex-wrap:wrap;justify-content:center;gap:8px 16px">';
            echo implode('', $links);
            echo '</div></div>';
        }, 98 );

        // Footer injection for Privacy Policy & Terms links
        add_action( 'wp_footer', function() {
            $privacy = get_page_by_path('privacy-policy');
            $terms   = get_page_by_path('terms-of-service');
            if ( ! $privacy && ! $terms ) return;
            $links = [];
            if ( $privacy && $privacy->post_status === 'publish' ) {
                $links[] = '<a href="' . get_permalink($privacy->ID) . '" style="color:inherit;text-decoration:underline">Privacy Policy</a>';
            }
            if ( $terms && $terms->post_status === 'publish' ) {
                $links[] = '<a href="' . get_permalink($terms->ID) . '" style="color:inherit;text-decoration:underline">Terms of Service</a>';
            }
            if ( empty($links) ) return;
            echo '<div class="sseo-legal-footer" style="text-align:center;padding:12px 20px;font-size:13px;color:#64748b;border-top:1px solid #e2e8f0;margin-top:8px">';
            echo implode( ' &nbsp;|&nbsp; ', $links );
            echo '</div>';
        }, 99 );

        // One-time: restore original March 20 baseline (score 15) from report data
        if (get_option('sseo_baseline_restored_v204') !== '1') {
            $baseline = get_option('sseo_baseline_snapshot');
            // Only restore if current baseline is NOT the original (score 15)
            if (!$baseline || ($baseline['score'] ?? 0) != 15) {
                $restored = [
                    'label'=>'before','date'=>'2026-03-20 15:26:17','score'=>15,
                    'meta_total'=>88,'meta_missing'=>88,'meta_data'=>[],
                    'title_issues_count'=>65,'title_data'=>[],
                    'h1_issues_count'=>89,'h1_data'=>[],
                    'alt_missing'=>480,'alt_samples'=>[],
                    'imgtitle_generic'=>0,'alt_changes'=>[],'imgtitle_changes'=>[],
                    'thin_stats'=>['thin'=>58,'strong'=>0],'thin_pages'=>[],
                    'redirect_count'=>3,'redirects_list'=>[],
                    'broken_links'=>[],
                    'schema_on'=>true,'og_on'=>true,'llms_exists'=>false,
                    'enhance_log'=>[],
                    'site_name'=>'Wall to Wall Construction, LLC','site_url'=>home_url('/'),
                    'brand'=>get_option('sseo_brand_name',''),'location'=>get_option('sseo_target_location',''),
                ];
                update_option('sseo_baseline_snapshot', $restored, false);
                update_option('sseo_baseline_date', '2026-03-20 15:26:17');
            }
            update_option('sseo_baseline_restored_v204', '1');
        }
    }

    public function activate() {
        $defaults = [
            'provider'          => 'openai',
            'openai_api_key'    => '',
            'openai_model'      => 'gpt-4o-mini',
            'azure_api_key'     => '',
            'azure_endpoint'    => '',
            'azure_deployment'  => '',
            'azure_api_version' => '2024-02-01',
            'anthropic_api_key' => '',
            'anthropic_model'   => 'claude-sonnet-4-20250514',
            'default_tone'      => 'professional',
            'brand_name'        => get_bloginfo( 'name' ),
            'target_location'   => '',
            'business_type'     => '',
            'business_phone'    => '',
            'business_address'  => '',
            'post_types'        => [ 'post', 'page' ],
            'seo_plugin'        => 'auto',
            'batch_size'        => 5,
            'rate_limit_delay'  => 2,
            'schema_enabled'    => 1,
            'og_enabled'        => 1,
            'llms_txt_content'  => '',
        ];
        foreach ( $defaults as $k => $v ) {
            if ( false === get_option( 'sseo_' . $k ) ) update_option( 'sseo_' . $k, $v );
        }

        // Redirects table
        global $wpdb;
        $table = $wpdb->prefix . 'sseo_redirects';
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( "CREATE TABLE IF NOT EXISTS {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            source_url varchar(500) NOT NULL,
            target_url varchar(500) NOT NULL,
            type int NOT NULL DEFAULT 301,
            hits int unsigned DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY source_url (source_url(191))
        ) {$charset};" );

        // Log table
        $log = $wpdb->prefix . 'sseo_log';
        dbDelta( "CREATE TABLE IF NOT EXISTS {$log} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            post_id bigint(20) unsigned NOT NULL,
            type varchar(20) NOT NULL,
            old_value text,
            new_value text,
            tokens_used int unsigned DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY post_id (post_id)
        ) {$charset};" );

        // Flush rewrite rules for llms.txt
        flush_rewrite_rules();
    }
}

Samar_SEO::instance();
