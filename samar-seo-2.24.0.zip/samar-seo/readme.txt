=== Samar SEO ===
Contributors: egiigautomation
Tags: seo, meta description, alt tags, openai, claude, ai, schema, redirects, broken links
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 2.24.0
License: GPLv2 or later

AI-powered SEO toolkit — bulk meta descriptions, image ALT tags, title optimizer, H1 checker, redirect manager, schema markup, broken link scanner, thin content detector, llms.txt, and Open Graph tags.

== Description ==

Samar SEO is a comprehensive, AI-powered SEO plugin that fixes the most common SEO audit issues automatically. It supports OpenAI, Azure OpenAI, and Anthropic Claude as AI providers.

**AI-Powered Tools:**

* **Bulk Meta Descriptions** — AI generates personalized meta descriptions for all posts/pages. Search, filter by missing, auto-apply in bulk.
* **Bulk Image ALT Tags** — Finds all images missing ALT text across your media library. AI generates descriptive, SEO-optimized alternatives.
* **Title Optimizer** — Scans for titles that are too long (>60 chars), too short, or missing. AI generates optimized replacements.
* **H1 Checker** — Detects pages with missing or duplicate H1 headings. AI suggests keyword-rich H1 tags.

**Technical SEO Tools:**

* **301 Redirect Manager** — Create and manage redirects for broken URLs and 404s. Tracks hit counts.
* **Broken Link Scanner** — Crawls all internal links and identifies dead URLs. One-click redirect creation.
* **Thin Content Detector** — Identifies pages with low word count, sorted by severity (critical/warning/notice).
* **Schema Markup** — Auto-injects LocalBusiness, Article, FAQ, and Breadcrumb JSON-LD structured data.
* **Open Graph Tags** — Auto-generates og: and twitter: meta tags for social sharing.
* **llms.txt Generator** — Creates and serves the llms.txt file for AI model compatibility. AI can generate it for you.

**Dashboard:**

* Live SEO Health Score (0-100) that updates as you fix issues
* Audit issue tracker showing open/fixed status for each problem category
* Integrates with Yoast SEO, Rank Math, All in One SEO, and The SEO Framework

**AI Provider Support:**

* OpenAI (gpt-4o-mini, gpt-4o, gpt-4-turbo, gpt-4.1-mini, gpt-4.1, o4-mini)
* Azure OpenAI (any deployed model)
* Anthropic Claude (Claude Sonnet 4, Claude Opus 4, Claude Haiku 4.5)

== Installation ==

1. Upload `samar-seo` folder to `/wp-content/plugins/`
2. Activate through Plugins menu
3. Go to **Samar SEO > Settings** — enter your API key and configure business details
4. Visit the **Dashboard** to see your SEO health score and start fixing issues

== Changelog ==

= 2.22.0 =
* Ad conversion tracking: the connected agency platform can add its tracking tag to every page <head> (egsm/v1/tracking/tag). Shown, and removable, under Settings > Agency site access.
* Updates now come from the agency platform like any other plugin update (Plugins screen, auto-updates).

= 1.0.0 =
* Initial release
