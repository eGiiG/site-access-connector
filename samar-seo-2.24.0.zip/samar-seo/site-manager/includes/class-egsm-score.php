<?php
/**
 * SEO score (0–100) per page/post, like Yoast / Rank Math: focus-keyword placement, basic on-page SEO,
 * readability and technical checks. Works for drafts and published content and for every builder
 * (the text comes from the builder-aware HTML).
 *
 * Stored in post meta: _egsm_score (int), _egsm_score_data (checks), _egsm_score_at (time).
 * Recalculated after every save (batched at shutdown) and backfilled for existing content in the background.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Score {

	private static $queue = array();

	public static function init() {
		add_action( 'save_post', array( __CLASS__, 'on_save' ), 100, 2 );
		add_action( 'shutdown', array( __CLASS__, 'flush_queue' ) );
		add_action( 'egsm_score_backfill', array( __CLASS__, 'backfill_batch' ) );
		add_action( 'admin_init', array( __CLASS__, 'kick' ) );
	}

	/**
	 * Keep the background scoring moving even where WP-Cron doesn't run (cron disabled, loopback blocked,
	 * low traffic): any wp-admin page load or API list/audit request scores the next batch, at most once
	 * a minute. Cheap no-op once everything is scored.
	 */
	public static function kick( $limit = 25 ) {
		if ( wp_doing_ajax() || (int) get_option( 'egsm_score_cursor', -1 ) < 0 || get_transient( 'egsm_score_kick' ) ) {
			return null;
		}
		set_transient( 'egsm_score_kick', 1, MINUTE_IN_SECONDS );
		return self::backfill_batch( is_int( $limit ) ? $limit : 25 );
	}

	public static function types() {
		$t = get_post_types( array( 'public' => true ), 'names' );
		unset( $t['attachment'] );
		return array_values( $t );
	}

	public static function on_save( $id, $post ) {
		if ( wp_is_post_revision( $id ) || wp_is_post_autosave( $id ) || ! in_array( $post->post_type, self::types(), true ) || 'auto-draft' === $post->post_status || 'trash' === $post->post_status ) {
			return;
		}
		self::queue( $id );
	}

	public static function queue( $id ) {
		self::$queue[ (int) $id ] = true;
	}

	public static function flush_queue() {
		$ids         = array_keys( self::$queue );
		self::$queue = array();
		foreach ( $ids as $id ) {
			try {
				self::store( $id );
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
			}
		}
	}

	public static function store( $id ) {
		$post = get_post( $id );
		if ( ! $post || ! in_array( $post->post_type, self::types(), true ) ) {
			return null;
		}
		return self::save( $id, self::analyze( $post ) );
	}

	/** Store an analysis result (also used by the audit so scores exist as soon as a site is audited). */
	public static function save( $id, $r ) {
		update_post_meta( $id, '_egsm_score', (int) $r['score'] );
		update_post_meta(
			$id,
			'_egsm_score_data',
			array(
				'grade'  => $r['grade'],
				'counts' => $r['counts'],
				'top'    => array_slice( array_values( array_filter( $r['checks'], function ( $c ) {
					return 'bad' === $c['status'];
				} ) ), 0, 5 ),
			)
		);
		update_post_meta( $id, '_egsm_score_at', time() );
		return $r;
	}

	public static function grade( $score ) {
		return $score >= 80 ? 'good' : ( $score >= 50 ? 'ok' : 'bad' );
	}

	/** meta_query clause for a score filter: good | ok | bad | nokw | noindex | unscored (null if unknown). */
	public static function filter_clause( $f ) {
		switch ( $f ) {
			case 'good':
				return array( 'key' => '_egsm_score', 'value' => 80, 'compare' => '>=', 'type' => 'NUMERIC' );
			case 'ok':
				return array( 'key' => '_egsm_score', 'value' => array( 50, 79 ), 'compare' => 'BETWEEN', 'type' => 'NUMERIC' );
			case 'bad':
				return array( 'key' => '_egsm_score', 'value' => 50, 'compare' => '<', 'type' => 'NUMERIC' );
			case 'nokw':
				return array( 'key' => '_egsm_focus_kw', 'compare' => 'NOT EXISTS' );
			case 'noindex':
				return array( 'key' => '_egsm_noindex', 'value' => '1' );
			case 'unscored':
				return array( 'key' => '_egsm_score', 'compare' => 'NOT EXISTS' );
		}
		return null;
	}

	/* ---------- backfill for existing content ---------- */

	public static function start_backfill() {
		update_option( 'egsm_score_cursor', 0, false );
		update_option( 'egsm_score_backfill_started', time(), false );
		wp_clear_scheduled_hook( 'egsm_score_backfill' );
		wp_schedule_single_event( time() + 30, 'egsm_score_backfill' );
	}

	/** Score the next batch (by ID). @return array { done, remaining, scored } */
	public static function backfill_batch( $limit = 40 ) {
		global $wpdb;
		$cursor = (int) get_option( 'egsm_score_cursor', 0 );
		if ( $cursor < 0 ) {
			return array( 'done' => true, 'remaining' => 0, 'scored' => 0 );
		}
		$types = self::types();
		$in    = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE ID > %d AND post_type IN ($in) AND post_status IN ('publish','draft','pending','future','private') ORDER BY ID ASC LIMIT %d", array_merge( array( $cursor ), $types, array( (int) $limit ) ) ) ); // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders
		$t0 = microtime( true );
		$n  = 0;
		foreach ( $ids as $id ) {
			try {
				self::sync_flat_meta( (int) $id );
				self::store( (int) $id );
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
			}
			$cursor = (int) $id;
			$n++;
			if ( microtime( true ) - $t0 > 8 ) {
				break; // stay well inside request time limits; the rest continues next batch
			}
		}
		$ids = array_slice( $ids, 0, $n );
		$remaining = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE ID > %d AND post_type IN ($in) AND post_status IN ('publish','draft','pending','future','private')", array_merge( array( $cursor ), $types ) ) ); // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders
		if ( $remaining > 0 ) {
			update_option( 'egsm_score_cursor', $cursor, false );
			if ( ! wp_next_scheduled( 'egsm_score_backfill' ) ) {
				wp_schedule_single_event( time() + 60, 'egsm_score_backfill' );
			}
		} else {
			update_option( 'egsm_score_cursor', -1, false );
		}
		return array(
			'done'      => 0 === $remaining,
			'remaining' => $remaining,
			'scored'    => count( $ids ),
		);
	}

	/** Flat, queryable copies of noindex + focus keyword (sitemaps, list filters, duplicate-keyword check). */
	public static function sync_flat_meta( $id ) {
		$seo = EGSM_SEO::get( $id );
		if ( $seo['noindex'] ) {
			update_post_meta( $id, '_egsm_noindex', '1' );
		} else {
			delete_post_meta( $id, '_egsm_noindex' );
		}
		$kw = mb_strtolower( trim( (string) $seo['focus_keyword'] ) );
		if ( '' !== $kw ) {
			update_post_meta( $id, '_egsm_focus_kw', $kw );
		} else {
			delete_post_meta( $id, '_egsm_focus_kw' );
		}
	}

	/* ---------- the analysis ---------- */

	private static function check( &$checks, $id, $group, $weight, $status, $msg ) {
		$checks[] = array(
			'id'      => $id,
			'group'   => $group,
			'weight'  => $weight,
			'status'  => $status, // good | ok | bad | info
			'message' => $msg,
		);
	}

	/**
	 * @param WP_Post $post
	 * @param array   $o  live overrides from the editor: post_title, content, slug, seo_title, description, keyword
	 */
	public static function analyze( $post, $o = array() ) {
		$builder = EGSM_Builders::detect( $post );
		if ( isset( $o['content'] ) && in_array( $builder, array( 'gutenberg', 'classic' ), true ) ) {
			$html = has_blocks( $o['content'] ) ? $o['content'] : wpautop( $o['content'] );
		} else {
			$html = EGSM_Builders::get_html( $post );
		}
		$seo        = EGSM_SEO::get( $post->ID );
		$post_title = isset( $o['post_title'] ) ? (string) $o['post_title'] : $post->post_title;
		$kw         = trim( isset( $o['keyword'] ) ? (string) $o['keyword'] : (string) $seo['focus_keyword'] );
		$custom_t   = isset( $o['seo_title'] ) ? (string) $o['seo_title'] : (string) $seo['title'];
		$title      = '' !== trim( $custom_t ) ? EGSM_SEO::effective_title( $post->ID, $custom_t ) : trim( $post_title . ' - ' . get_bloginfo( 'name' ), ' -' );
		if ( '' !== trim( $custom_t ) && isset( $o['post_title'] ) ) {
			$title = str_replace( $post->post_title, $post_title, $title );
		}
		$desc = isset( $o['description'] ) ? trim( (string) $o['description'] ) : trim( (string) $seo['effective_description'] );
		$slug = isset( $o['slug'] ) && '' !== $o['slug'] ? (string) $o['slug'] : ( $post->post_name ? $post->post_name : sanitize_title( $post_title ) );
		$slug = urldecode( $slug );

		$text   = EGSM_Util::text_from_html( $html );
		$words  = EGSM_Util::word_count( $text );
		$heads  = EGSM_Util::headings( $html );
		$links  = EGSM_Util::links( $html );
		$images = EGSM_Util::images( $html );
		$is_post = 'post' === $post->post_type;
		$checks  = array();

		/* ---- focus keyword ---- */
		if ( '' === $kw ) {
			self::check( $checks, 'kw_set', 'keyword', 10, 'bad', 'No focus keyword set. Add the main search phrase this page should rank for.' );
		} else {
			$kl  = mb_strtolower( $kw );
			$has = function ( $hay ) use ( $kl ) {
				return false !== mb_stripos( (string) $hay, $kl );
			};
			self::check( $checks, 'kw_title', 'keyword', 8, $has( $title ) ? 'good' : 'bad', $has( $title ) ? 'Focus keyword is in the SEO title.' : 'Add the focus keyword to the SEO title.' );
			$pos = mb_stripos( $title, $kl );
			self::check( $checks, 'kw_title_start', 'keyword', 3, false !== $pos && $pos <= max( 10, (int) ( mb_strlen( $title ) / 3 ) ) ? 'good' : 'ok', false !== $pos && $pos <= max( 10, (int) ( mb_strlen( $title ) / 3 ) ) ? 'Focus keyword is near the start of the title.' : 'Move the focus keyword closer to the start of the title.' );
			self::check( $checks, 'kw_desc', 'keyword', 5, $has( $desc ) ? 'good' : 'bad', $has( $desc ) ? 'Focus keyword is in the meta description.' : 'Use the focus keyword in the meta description.' );
			$kslug = sanitize_title( $kw );
			$in_slug = false !== strpos( $slug, $kslug ) || count( array_intersect( explode( '-', $kslug ), explode( '-', $slug ) ) ) >= max( 1, (int) ceil( count( explode( '-', $kslug ) ) * 0.7 ) );
			self::check( $checks, 'kw_slug', 'keyword', 4, $in_slug ? 'good' : 'ok', $in_slug ? 'Focus keyword is in the URL.' : 'Include the focus keyword in the URL slug (a 301 is added automatically when a live URL changes).' );
			$intro = EGSM_Util::first_words( $text, max( 100, (int) ( $words * 0.1 ) ) );
			self::check( $checks, 'kw_intro', 'keyword', 5, $has( $intro ) ? 'good' : 'bad', $has( $intro ) ? 'Focus keyword appears in the introduction.' : 'Use the focus keyword in the first paragraph.' );
			$sub = array_filter( $heads, function ( $h ) use ( $kl ) {
				return $h['level'] >= 2 && $h['level'] <= 3 && false !== mb_stripos( $h['text'], $kl );
			} );
			self::check( $checks, 'kw_subheadings', 'keyword', 4, $sub ? 'good' : ( $words < 300 ? 'ok' : 'bad' ), $sub ? 'Focus keyword is in a subheading.' : 'Use the focus keyword (or a close variation) in an H2 or H3.' );
			$occ     = EGSM_Util::count_phrase( $text, $kw );
			$kwords  = max( 1, count( preg_split( '/\s+/', $kw ) ) );
			$density = $words ? round( 100 * $occ * $kwords / $words, 2 ) : 0;
			$dstat   = $density >= 0.5 && $density <= 2.5 ? 'good' : ( $density > 3 || 0 === $occ ? 'bad' : 'ok' );
			self::check( $checks, 'kw_density', 'keyword', 5, $dstat, sprintf( 'Keyword density %s%% (%d times). %s', $density, $occ, 'good' === $dstat ? 'Good.' : ( $density > 3 ? 'Too high — reads as stuffing; use variations.' : 'Aim for 0.5–2.5%.' ) ) );
			if ( $images ) {
				$alt_kw = array_filter( $images, function ( $i ) use ( $kl ) {
					return null !== $i['alt'] && false !== mb_stripos( $i['alt'], $kl );
				} );
				self::check( $checks, 'kw_img_alt', 'keyword', 3, $alt_kw ? 'good' : 'ok', $alt_kw ? 'Focus keyword is in an image alt text.' : 'Describe one image with the focus keyword in its alt text.' );
			}
			$len = mb_strlen( $kw );
			self::check( $checks, 'kw_length', 'keyword', 2, $kwords <= 5 && $len <= 60 ? 'good' : 'ok', $kwords <= 5 ? 'Focus keyword length is fine.' : 'Focus keyword is long; pick the core phrase (up to 4–5 words).' );
			$dupes = self::keyword_used_elsewhere( $post->ID, $kl );
			self::check( $checks, 'kw_unique', 'keyword', 4, $dupes ? 'bad' : 'good', $dupes ? 'This focus keyword is already used on: ' . implode( ', ', array_map( 'get_the_title', array_slice( $dupes, 0, 3 ) ) ) . '. Pages compete with each other — give each its own keyword.' : 'Focus keyword is not used by another page.' );
		}

		/* ---- basic SEO ---- */
		$tl = mb_strlen( $title );
		self::check( $checks, 'title_len', 'basic', 5, $tl >= 30 && $tl <= 60 ? 'good' : ( $tl > 60 && $tl <= 70 ? 'ok' : 'bad' ), "SEO title is {$tl} characters" . ( $tl > 60 ? ' — Google cuts titles around 60.' : ( $tl < 30 ? ' — too short; use the space.' : '.' ) ) );
		$dl = mb_strlen( $desc );
		self::check( $checks, 'desc_len', 'basic', 5, 0 === $dl ? 'bad' : ( $dl >= 120 && $dl <= 160 ? 'good' : 'ok' ), 0 === $dl ? 'No meta description — Google will pick random text.' : "Meta description is {$dl} characters" . ( $dl > 160 ? ' — shorten to about 155.' : ( $dl < 120 ? ' — aim for 120–160.' : '.' ) ) );
		$min_good = $is_post ? 600 : 300;
		$min_ok   = $is_post ? 300 : 150;
		self::check( $checks, 'content_len', 'basic', 8, $words >= $min_good ? 'good' : ( $words >= $min_ok ? 'ok' : 'bad' ), "{$words} words" . ( $words >= $min_good ? '.' : " — aim for {$min_good}+ to cover the topic properly." ) );
		self::check( $checks, 'slug_len', 'basic', 2, mb_strlen( $slug ) <= 75 ? 'good' : 'ok', mb_strlen( $slug ) <= 75 ? 'URL is a good length.' : 'URL is long; shorten the slug.' );
		$h1 = count( array_filter( $heads, function ( $h ) {
			return 1 === $h['level'];
		} ) );
		$builder_h1 = in_array( $builder, array( 'elementor', 'divi', 'bricks', 'beaver', 'oxygen', 'breakdance' ), true );
		if ( $h1 > 1 ) {
			self::check( $checks, 'h1', 'basic', 3, 'bad', "{$h1} H1 headings in the content — keep one main heading." );
		} elseif ( 0 === $h1 && $builder_h1 ) {
			self::check( $checks, 'h1', 'basic', 3, 'ok', 'No H1 found in the page builder layout — check the main heading uses H1.' );
		} else {
			self::check( $checks, 'h1', 'basic', 3, 'good', 'One main heading.' );
		}
		$subs = count( array_filter( $heads, function ( $h ) {
			return $h['level'] >= 2;
		} ) );
		self::check( $checks, 'subheadings', 'basic', 3, $words < 300 || $subs >= max( 1, (int) floor( $words / 350 ) ) ? 'good' : ( $subs ? 'ok' : 'bad' ), $subs ? "{$subs} subheadings." : 'No subheadings — break the text up with H2s.' );
		$internal = array_filter( $links, function ( $l ) {
			return $l['internal'] && 0 !== strpos( $l['href'], '#' );
		} );
		$external = array_filter( $links, function ( $l ) {
			return ! $l['internal'];
		} );
		self::check( $checks, 'internal_links', 'basic', 5, count( $internal ) >= 2 ? 'good' : ( $internal ? 'ok' : 'bad' ), count( $internal ) . ' internal link(s)' . ( $internal ? '.' : ' — link to related pages on this site.' ) );
		self::check( $checks, 'external_links', 'basic', 2, $external ? 'good' : 'ok', $external ? count( $external ) . ' outbound link(s).' : 'No outbound links — cite a trustworthy source where it helps.' );
		if ( $images ) {
			$no_alt = array_filter( $images, function ( $i ) {
				return null === $i['alt'] || '' === trim( $i['alt'] );
			} );
			self::check( $checks, 'img_alt', 'basic', 4, $no_alt ? 'bad' : 'good', $no_alt ? count( $no_alt ) . ' image(s) without alt text.' : 'All images have alt text.' );
		} else {
			self::check( $checks, 'images', 'basic', 3, $words > 300 ? 'bad' : 'ok', 'No images in the content — add at least one relevant image.' );
		}
		if ( $is_post ) {
			$thumb = get_post_thumbnail_id( $post );
			self::check( $checks, 'featured', 'basic', 2, $thumb ? 'good' : 'ok', $thumb ? 'Featured image set.' : 'Set a featured image (used in shares and Discover).' );
		}

		/* ---- readability ---- */
		$flesch = EGSM_Util::flesch( $text );
		if ( null !== $flesch ) {
			self::check( $checks, 'flesch', 'readability', 4, $flesch >= 60 ? 'good' : ( $flesch >= 30 ? 'ok' : 'bad' ), "Reading ease {$flesch}" . ( $flesch >= 60 ? ' — easy to read.' : ' — use shorter sentences and simpler words.' ) );
		}
		$sent = EGSM_Util::sentences( $text );
		if ( count( $sent ) >= 5 ) {
			$long = count( array_filter( $sent, function ( $s ) {
				return EGSM_Util::word_count( $s ) > 20;
			} ) );
			$pct  = (int) round( 100 * $long / count( $sent ) );
			self::check( $checks, 'long_sentences', 'readability', 3, $pct <= 25 ? 'good' : ( $pct <= 40 ? 'ok' : 'bad' ), "{$pct}% of sentences are over 20 words" . ( $pct <= 25 ? '.' : ' — split some of them.' ) );
		}
		$long_p = 0;
		if ( preg_match_all( '#<p\b[^>]*>(.*?)</p>#is', $html, $pm ) ) {
			foreach ( $pm[1] as $p ) {
				if ( EGSM_Util::word_count( EGSM_Util::text_from_html( $p ) ) > 150 ) {
					$long_p++;
				}
			}
		}
		self::check( $checks, 'paragraphs', 'readability', 2, $long_p ? 'ok' : 'good', $long_p ? "{$long_p} paragraph(s) over 150 words — break them up." : 'Paragraph length is fine.' );

		/* ---- technical ---- */
		if ( $seo['noindex'] ) {
			self::check( $checks, 'noindex', 'technical', 0, 'info', 'This page is set to noindex — search engines will not show it.' );
		}
		if ( '' !== (string) $seo['canonical'] && EGSM_Redirects::site_path( $seo['canonical'] ) !== EGSM_Redirects::site_path( get_permalink( $post ) ) ) {
			self::check( $checks, 'canonical', 'technical', 2, 'bad', 'Canonical points to another URL, so this page will not rank on its own.' );
		}
		$schema = EGSM_AISEO::get_post_schema( $post->ID );
		$has_schema = (bool) $schema || ( EGSM_SSEO::on() && ( $is_post || get_post_meta( $post->ID, '_sseo_local_schema', true ) ) );
		self::check( $checks, 'schema', 'technical', 2, $has_schema ? 'good' : 'ok', $has_schema ? 'Structured data present.' : 'No structured data on this page (FAQ, Service, Article…).' );

		$earned = 0;
		$max    = 0;
		$counts = array( 'good' => 0, 'ok' => 0, 'bad' => 0 );
		foreach ( $checks as $c ) {
			if ( 'info' === $c['status'] ) {
				continue;
			}
			$max    += $c['weight'];
			$earned += 'good' === $c['status'] ? $c['weight'] : ( 'ok' === $c['status'] ? $c['weight'] / 2 : 0 );
			$counts[ $c['status'] ]++;
		}
		$score = $max ? (int) round( 100 * $earned / $max ) : 0;
		usort( $checks, function ( $a, $b ) {
			$rank = array( 'bad' => 0, 'ok' => 1, 'info' => 2, 'good' => 3 );
			return $rank[ $a['status'] ] - $rank[ $b['status'] ] ?: $b['weight'] - $a['weight'];
		} );
		return array(
			'score'   => $score,
			'grade'   => self::grade( $score ),
			'counts'  => $counts,
			'keyword' => $kw,
			'title'   => $title,
			'description' => $desc,
			'words'   => $words,
			'checks'  => $checks,
		);
	}

	private static function keyword_used_elsewhere( $id, $kl ) {
		$q = new WP_Query(
			array(
				'post_type'      => self::types(),
				'post_status'    => array( 'publish', 'future', 'draft', 'pending', 'private' ),
				'posts_per_page' => 5,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'post__not_in'   => array( (int) $id ),
				'meta_query'     => array(
					array(
						'key'   => '_egsm_focus_kw',
						'value' => $kl,
					),
				),
			)
		);
		return $q->posts;
	}
}
