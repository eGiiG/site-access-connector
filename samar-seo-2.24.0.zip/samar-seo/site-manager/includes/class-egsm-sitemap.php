<?php
/**
 * WordPress core sitemaps (/wp-sitemap.xml) tuned for SEO: noindexed pages, terms and archives are left out,
 * excluded post types/taxonomies are removed, and every post/page URL gets a lastmod date.
 * Only active when this plugin (or SEO Suite) is the site's SEO plugin — Yoast/Rank Math use their own sitemaps.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Sitemap {

	public static function init() {
		add_filter( 'wp_sitemaps_posts_query_args', array( __CLASS__, 'posts_args' ), 10, 2 );
		add_filter( 'wp_sitemaps_taxonomies_query_args', array( __CLASS__, 'terms_args' ), 10, 2 );
		add_filter( 'wp_sitemaps_post_types', array( __CLASS__, 'post_types' ) );
		add_filter( 'wp_sitemaps_taxonomies', array( __CLASS__, 'taxonomies' ) );
		add_filter( 'wp_sitemaps_add_provider', array( __CLASS__, 'providers' ), 10, 2 );
		add_filter( 'wp_sitemaps_posts_entry', array( __CLASS__, 'post_entry' ), 10, 2 );
	}

	private static function on() {
		return EGSM_SEO_Settings::we_are_seo_plugin();
	}

	public static function posts_args( $args, $post_type ) {
		if ( ! self::on() ) {
			return $args;
		}
		$mq   = isset( $args['meta_query'] ) && is_array( $args['meta_query'] ) ? $args['meta_query'] : array();
		$mq[] = array(
			'relation' => 'OR',
			array(
				'key'     => '_egsm_noindex',
				'compare' => 'NOT EXISTS',
			),
			array(
				'key'     => '_egsm_noindex',
				'value'   => '1',
				'compare' => '!=',
			),
		);
		$args['meta_query'] = $mq;
		// The blog page (if set) is covered by the posts; keep it only when indexable.
		return $args;
	}

	public static function terms_args( $args, $taxonomy ) {
		if ( ! self::on() ) {
			return $args;
		}
		$mq   = isset( $args['meta_query'] ) && is_array( $args['meta_query'] ) ? $args['meta_query'] : array();
		$mq[] = array(
			'key'     => '_egsm_noindex',
			'compare' => 'NOT EXISTS',
		);
		$args['meta_query'] = $mq;
		return $args;
	}

	public static function post_types( $types ) {
		if ( ! self::on() ) {
			return $types;
		}
		foreach ( (array) EGSM_SEO_Settings::get( 'sitemap_exclude_types' ) as $t ) {
			unset( $types[ $t ] );
		}
		return $types;
	}

	public static function taxonomies( $taxes ) {
		if ( ! self::on() ) {
			return $taxes;
		}
		$drop = array_merge( (array) EGSM_SEO_Settings::get( 'sitemap_exclude_tax' ), array_keys( (array) EGSM_SEO_Settings::get( 'noindex_tax' ) ) );
		foreach ( $drop as $t ) {
			unset( $taxes[ $t ] );
		}
		return $taxes;
	}

	public static function providers( $provider, $name ) {
		if ( self::on() && 'users' === $name && EGSM_SEO_Settings::get( 'noindex_author' ) ) {
			return false;
		}
		return $provider;
	}

	public static function post_entry( $entry, $post ) {
		if ( self::on() && $post && ! empty( $post->post_modified_gmt ) && '0000-00-00 00:00:00' !== $post->post_modified_gmt ) {
			$entry['lastmod'] = mysql_to_rfc3339( $post->post_modified_gmt );
		}
		return $entry;
	}
}
