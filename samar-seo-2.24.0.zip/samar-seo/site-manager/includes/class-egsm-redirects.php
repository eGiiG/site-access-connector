<?php
/**
 * 301/302/410 redirects (with automatic redirects when URLs change) and a 404 log.
 *
 * Sources are stored as site-relative paths without a trailing slash ("/old-page").
 * Targets may be a URL, a path, or "post:123" (follows the post if its URL changes later).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Redirects {

	const INDEX_OPTION = 'egsm_redirect_index';

	public static function init_frontend() {
		add_action( 'template_redirect', array( __CLASS__, 'maybe_redirect' ), 0 );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_log_404' ), 99 );
	}

	/** Path relative to the WordPress home (subdirectory installs aware). */
	public static function site_path( $url ) {
		$path = EGSM_Util::normalize_path( $url );
		$base = untrailingslashit( (string) wp_parse_url( home_url(), PHP_URL_PATH ) );
		if ( '' !== $base && 0 === strpos( $path, $base ) ) {
			$path = substr( $path, strlen( $base ) );
			$path = '' === $path ? '/' : $path;
		}
		return $path;
	}

	private static function rebuild_index() {
		global $wpdb;
		$t    = EGSM_DB::table( 'redirects' );
		$rows = $wpdb->get_results( "SELECT id, source FROM {$t}", ARRAY_A );
		$idx  = array();
		foreach ( $rows as $r ) {
			$idx[ $r['source'] ] = (int) $r['id'];
		}
		update_option( self::INDEX_OPTION, $idx, count( $idx ) < 3000 );
		return $idx;
	}

	private static function index() {
		$idx = get_option( self::INDEX_OPTION, null );
		return is_array( $idx ) ? $idx : self::rebuild_index();
	}

	public static function resolve_target( $target ) {
		if ( preg_match( '/^post:(\d+)$/', (string) $target, $m ) ) {
			$url = get_permalink( (int) $m[1] );
			return $url ? $url : '';
		}
		return EGSM_Util::absolute_url( $target );
	}

	public static function maybe_redirect() {
		if ( is_admin() || ! isset( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		$uri = wp_unslash( $_SERVER['REQUEST_URI'] );
		$idx = self::index();
		$path = self::site_path( $uri );
		if ( ! isset( $idx[ $path ] ) ) {
			// SEO Suite matches the raw REQUEST_URI, so its rules miss URLs carrying ?utm=… and similar.
			// Serve those here (query string kept); plain URLs are left to SEO Suite.
			if ( EGSM_SSEO::on() && false !== strpos( $uri, '?' ) && EGSM_SSEO::redirect_table() ) {
				global $wpdb;
				$t   = EGSM_SSEO::redirect_table();
				$src = EGSM_SSEO::source_path( $path );
				$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE source_url IN (%s, %s) LIMIT 1", $src, trailingslashit( $src ) ), ARRAY_A );
				if ( $row && '' !== (string) $row['target_url'] ) {
					$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET hits = hits + 1 WHERE id = %d", $row['id'] ) );
					$to = (string) $row['target_url'];
					$qs = (string) wp_parse_url( $uri, PHP_URL_QUERY );
					if ( '' !== $qs && false === strpos( $to, '?' ) ) {
						$to .= '?' . $qs;
					}
					$code = (int) $row['type'];
					wp_redirect( $to, in_array( $code, array( 301, 302, 307, 308 ), true ) ? $code : 301, 'egsm' ); // phpcs:ignore WordPress.Security.SafeRedirect
					exit;
				}
			}
			return;
		}
		global $wpdb;
		$t   = EGSM_DB::table( 'redirects' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $idx[ $path ] ), ARRAY_A );
		if ( ! $row ) {
			return;
		}
		$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET hits = hits + 1, last_hit = %s WHERE id = %d", EGSM_Util::now(), $row['id'] ) );
		$code = (int) $row['code'];
		if ( 410 === $code ) {
			global $wp_query;
			$wp_query->set_404();
			status_header( 410 );
			nocache_headers();
			return;
		}
		$to = self::resolve_target( $row['target'] );
		if ( '' === $to || self::site_path( $to ) === $path ) {
			return;
		}
		$qs = (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_QUERY );
		if ( '' !== $qs && false === strpos( $to, '?' ) ) {
			$to .= '?' . $qs;
		}
		wp_redirect( $to, in_array( $code, array( 301, 302, 307, 308 ), true ) ? $code : 301, 'egsm' ); // phpcs:ignore WordPress.Security.SafeRedirect
		exit;
	}

	/* ---------- CRUD ---------- */

	public static function all( $args = array() ) {
		global $wpdb;
		$t     = EGSM_DB::table( 'redirects' );
		$limit = max( 1, min( 1000, (int) ( isset( $args['limit'] ) ? $args['limit'] : 200 ) ) );
		$rows  = $wpdb->get_results( "SELECT * FROM {$t} ORDER BY id DESC LIMIT {$limit}", ARRAY_A );
		foreach ( $rows as &$r ) {
			$r['id']          = (int) $r['id'];
			$r['code']        = (int) $r['code'];
			$r['hits']        = (int) $r['hits'];
			$r['resolved_to'] = 410 === $r['code'] ? null : self::resolve_target( $r['target'] );
			$r['store']       = 'egsm';
		}
		unset( $r );
		if ( EGSM_SSEO::on() ) {
			foreach ( EGSM_SSEO::redirect_rows() as $x ) {
				$rows[] = array(
					'id'          => (int) $x['id'],
					'source'      => $x['source_url'],
					'target'      => $x['target_url'],
					'code'        => (int) $x['type'],
					'hits'        => (int) $x['hits'],
					'created_at'  => $x['created_at'],
					'resolved_to' => $x['target_url'],
					'store'       => 'seo-suite',
				);
			}
		}
		return $rows;
	}

	/** @return array|WP_Error created row */
	public static function add( $source, $target, $code = 301, $note = '', $log = true ) {
		global $wpdb;
		$code = (int) $code;
		if ( ! in_array( $code, array( 301, 302, 307, 308, 410 ), true ) ) {
			return new WP_Error( 'egsm_bad_request', 'code must be 301, 302, 307, 308 or 410.', array( 'status' => 400 ) );
		}
		$src = self::site_path( $source );
		if ( '/' === $src ) {
			return new WP_Error( 'egsm_bad_request', 'Refusing to redirect the home page.', array( 'status' => 400 ) );
		}
		if ( 410 !== $code ) {
			if ( is_numeric( $target ) ) {
				$target = 'post:' . (int) $target;
			}
			$to = self::resolve_target( $target );
			if ( '' === $to ) {
				return new WP_Error( 'egsm_bad_request', 'Redirect target not found.', array( 'status' => 422 ) );
			}
			if ( EGSM_Util::is_internal( $to ) && self::site_path( $to ) === $src ) {
				return new WP_Error( 'egsm_bad_request', 'Redirect target equals the source (loop).', array( 'status' => 422 ) );
			}
		} else {
			$target = '';
		}
		if ( 410 !== $code && EGSM_SSEO::on() && EGSM_SSEO::redirect_table() ) {
			// SEO Suite's table, so its Redirects screen shows the rule. Targets are stored as URLs.
			list( $row, $before ) = EGSM_SSEO::redirect_upsert( $src, $to, $code );
			$wpdb->delete( EGSM_DB::table( 'redirects' ), array( 'source' => $src ) ); // never two rules for one URL
			self::rebuild_index();
			if ( $log ) {
				$row['change_id'] = EGSM_Log::record( 'redirect_add', 'sseo_redirect', (int) $row['id'], $before, $row, "Redirect $src → $to" );
			}
			$row['store'] = 'seo-suite';
			return $row;
		}
		$t        = EGSM_DB::table( 'redirects' );
		$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE source = %s", $src ), ARRAY_A );
		if ( $existing ) {
			$wpdb->update(
				$t,
				array(
					'target' => $target,
					'code'   => $code,
					'note'   => substr( $note, 0, 191 ),
				),
				array( 'id' => $existing['id'] )
			);
			$id = (int) $existing['id'];
		} else {
			$wpdb->insert(
				$t,
				array(
					'source'     => $src,
					'target'     => $target,
					'code'       => $code,
					'note'       => substr( $note, 0, 191 ),
					'created_at' => EGSM_Util::now(),
				)
			);
			$id = (int) $wpdb->insert_id;
		}
		// Collapse chains: anything that pointed at this source now points at the final target.
		if ( 410 !== $code && ! preg_match( '/^post:/', $target ) ) {
			$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET target = %s WHERE target IN (%s, %s) AND id <> %d", $target, $src, home_url( $src ), $id ) );
		}
		self::rebuild_index();
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ), ARRAY_A );
		if ( $log ) {
			$row['change_id'] = EGSM_Log::record( 'redirect_add', 'redirect', $id, $existing ? $existing : null, $row, "Redirect $src → " . ( $target ? $target : '410 Gone' ) );
		}
		return $row;
	}

	public static function delete( $id, $store = '' ) {
		global $wpdb;
		if ( '' === $store ) {
			$store = EGSM_SSEO::on() ? 'seo-suite' : 'egsm';
		}
		if ( 'seo-suite' === $store ) {
			$row = EGSM_SSEO::redirect_get( (int) $id );
			if ( ! $row ) {
				return new WP_Error( 'egsm_not_found', 'Redirect not found in SEO Suite\'s list (pass store=egsm for 410 rules).', array( 'status' => 404 ) );
			}
			EGSM_SSEO::redirect_delete( (int) $id );
			return array(
				'deleted'   => (int) $id,
				'store'     => 'seo-suite',
				'change_id' => EGSM_Log::record( 'redirect_delete', 'sseo_redirect', (int) $id, $row, null, 'Deleted redirect ' . $row['source_url'] ),
			);
		}
		$t   = EGSM_DB::table( 'redirects' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ), ARRAY_A );
		if ( ! $row ) {
			return new WP_Error( 'egsm_not_found', 'Redirect not found.', array( 'status' => 404 ) );
		}
		$wpdb->delete( $t, array( 'id' => $id ) );
		self::rebuild_index();
		return array(
			'deleted'   => (int) $id,
			'change_id' => EGSM_Log::record( 'redirect_delete', 'redirect', $id, $row, null, 'Deleted redirect ' . $row['source'] ),
		);
	}

	public static function revert_row( $id, $before, $after ) {
		global $wpdb;
		$t = EGSM_DB::table( 'redirects' );
		if ( null === $before ) {
			$wpdb->delete( $t, array( 'id' => $id ) );
		} else {
			$row = array_intersect_key( $before, array_flip( array( 'id', 'source', 'target', 'code', 'hits', 'last_hit', 'note', 'created_at' ) ) );
			$wpdb->replace( $t, $row );
		}
		self::rebuild_index();
		return true;
	}

	/** Given old/new URL maps (post id => url), add 301s where URLs changed. */
	public static function create_for_moves( $old, $new ) {
		$made = array();
		foreach ( $old as $pid => $old_url ) {
			if ( ! isset( $new[ $pid ] ) || ! $old_url ) {
				continue;
			}
			if ( self::site_path( $old_url ) === self::site_path( $new[ $pid ] ) ) {
				continue;
			}
			$r = self::add( $old_url, 'post:' . $pid, 301, 'URL changed for #' . $pid );
			if ( ! is_wp_error( $r ) ) {
				$made[] = array(
					'from'      => self::site_path( $old_url ),
					'to'        => $new[ $pid ],
					'change_id' => $r['change_id'],
				);
			}
		}
		return $made;
	}

	/* ---------- 404 log ---------- */

	public static function maybe_log_404() {
		if ( ! is_404() || ! EGSM_Settings::get( 'log_404' ) || ! isset( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		$path = self::site_path( wp_unslash( $_SERVER['REQUEST_URI'] ) );
		if ( preg_match( '#(\.php|/\.env|/\.git|/wp-admin|/wp-login|xmlrpc|/cgi-bin|\.(bak|sql|zip|tar|gz|ini|log)$)#i', $path ) || strlen( $path ) > 250 ) {
			return;
		}
		global $wpdb;
		$t   = EGSM_DB::table( '404' );
		$now = EGSM_Util::now();
		$ref = isset( $_SERVER['HTTP_REFERER'] ) ? substr( esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ), 0, 250 ) : '';
		$id  = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE path = %s", $path ) );
		if ( $id ) {
			$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET hits = hits + 1, last_seen = %s" . ( $ref ? ', referrer = %s' : '' ) . ' WHERE id = %d', $ref ? array( $now, $ref, $id ) : array( $now, $id ) ) );
		} else {
			$wpdb->insert(
				$t,
				array(
					'path'       => $path,
					'referrer'   => $ref,
					'first_seen' => $now,
					'last_seen'  => $now,
				)
			);
			if ( 1 === wp_rand( 1, 50 ) ) {
				$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t}" );
				if ( $count > 2000 ) {
					$wpdb->query( "DELETE FROM {$t} ORDER BY last_seen ASC LIMIT " . ( $count - 2000 ) );
				}
			}
		}
	}

	public static function list_404( $limit = 100 ) {
		global $wpdb;
		$t     = EGSM_DB::table( '404' );
		$limit = max( 1, min( 1000, (int) $limit ) );
		$rows  = $wpdb->get_results( "SELECT path, hits, referrer, first_seen, last_seen FROM {$t} ORDER BY hits DESC, last_seen DESC LIMIT {$limit}", ARRAY_A );
		$idx   = self::index();
		$sseo  = array();
		foreach ( EGSM_SSEO::on() ? EGSM_SSEO::redirect_rows() : array() as $x ) {
			$sseo[ self::site_path( $x['source_url'] ) ] = true;
		}
		foreach ( $rows as &$r ) {
			$r['hits']       = (int) $r['hits'];
			$r['redirected'] = isset( $idx[ $r['path'] ] ) || ( isset( $sseo[ $r['path'] ] ) );
		}
		return $rows;
	}

	public static function clear_404() {
		global $wpdb;
		$wpdb->query( 'DELETE FROM ' . EGSM_DB::table( '404' ) );
		return array( 'cleared' => true );
	}
}
