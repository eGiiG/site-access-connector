<?php
/**
 * Request authentication.
 *
 * Two ways in:
 *  1. Signed requests from the agency platform (HMAC-SHA256 with a per-site secret).
 *     Headers: X-Egsm-Kid, X-Egsm-Ts, X-Egsm-Nonce, X-Egsm-Sig
 *     String to sign (newline-joined):
 *       METHOD, route (e.g. /egsm/v1/content/12), canonical query, unix ts, nonce, sha256(raw body)
 *     Canonical query = GET params minus rest_route, keys sorted recursively,
 *     http_build_query(..., '', '&', PHP_QUERY_RFC3986).
 *  2. A logged-in administrator (Application Password or cookie + REST nonce), if the
 *     site owner allows it. Keeps existing app-password connections working.
 *
 * Signed auth hooks determine_current_user, so the request is a normal logged-in
 * request as far as security plugins that block anonymous REST access are concerned.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Auth {

	const CLOCK_SKEW = 300;

	/** @var string none|ok|error */
	private static $state = 'none';
	private static $error = '';
	private static $kid   = '';

	public static function is_egsm_request() {
		$prefix = '/' . trim( rest_get_url_prefix(), '/' ) . '/' . EGSM_NS;
		if ( isset( $_GET['rest_route'] ) ) {
			$route = (string) wp_unslash( $_GET['rest_route'] );
			return 0 === strpos( $route, '/' . EGSM_NS );
		}
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		return false !== strpos( $uri, $prefix );
	}

	public static function current_route() {
		if ( isset( $_GET['rest_route'] ) ) {
			return rawurldecode( (string) wp_unslash( $_GET['rest_route'] ) );
		}
		$uri    = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$path   = (string) wp_parse_url( $uri, PHP_URL_PATH );
		$marker = '/' . trim( rest_get_url_prefix(), '/' ) . '/';
		$pos    = strpos( $path, $marker );
		if ( false === $pos ) {
			return '';
		}
		return '/' . rawurldecode( substr( $path, $pos + strlen( $marker ) ) );
	}

	public static function canonical_query( $params ) {
		unset( $params['rest_route'] );
		self::ksort_recursive( $params );
		return http_build_query( $params, '', '&', PHP_QUERY_RFC3986 );
	}

	private static function ksort_recursive( &$arr ) {
		if ( ! is_array( $arr ) ) {
			return;
		}
		ksort( $arr );
		foreach ( $arr as &$v ) {
			if ( is_array( $v ) ) {
				self::ksort_recursive( $v );
			}
		}
	}

	private static function header( $name ) {
		$key = 'HTTP_' . strtoupper( str_replace( '-', '_', $name ) );
		return isset( $_SERVER[ $key ] ) ? trim( (string) wp_unslash( $_SERVER[ $key ] ) ) : '';
	}

	/** determine_current_user filter. */
	public static function determine_current_user( $user_id ) {
		static $done = false;
		if ( $done ) {
			return 'ok' === self::$state ? EGSM_Settings::service_user_id() : $user_id;
		}
		$sig = self::header( 'X-Egsm-Sig' );
		if ( '' === $sig || ! self::is_egsm_request() ) {
			return $user_id;
		}
		$done = true;

		$result = self::verify(
			isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) : 'GET',
			self::current_route(),
			self::canonical_query( wp_unslash( $_GET ) ),
			self::header( 'X-Egsm-Kid' ),
			self::header( 'X-Egsm-Ts' ),
			self::header( 'X-Egsm-Nonce' ),
			$sig,
			(string) file_get_contents( 'php://input' )
		);

		if ( true !== $result ) {
			self::$state = 'error';
			self::$error = $result;
			return $user_id;
		}
		$uid = EGSM_Settings::service_user_id();
		if ( ! $uid ) {
			self::$state = 'error';
			self::$error = 'No administrator account is available to act as.';
			return $user_id;
		}
		self::$state = 'ok';
		return $uid;
	}

	/** @return true|string true or an error reason. */
	public static function verify( $method, $route, $query, $kid, $ts, $nonce, $sig, $body ) {
		$stored_kid = (string) get_option( 'egsm_kid', '' );
		$secret     = (string) get_option( 'egsm_secret', '' );
		if ( '' === $stored_kid || '' === $secret ) {
			return 'This site is not connected. Generate a connection key in the plugin settings.';
		}
		if ( ! hash_equals( $stored_kid, $kid ) ) {
			return 'Unknown key id — the connection key was regenerated or revoked on the site.';
		}
		if ( ! ctype_digit( $ts ) || abs( time() - (int) $ts ) > self::CLOCK_SKEW ) {
			return 'Request timestamp is outside the allowed window (check server clocks).';
		}
		if ( strlen( $nonce ) < 16 || strlen( $nonce ) > 64 ) {
			return 'Invalid nonce.';
		}
		$payload  = implode( "\n", array( $method, $route, $query, $ts, $nonce, hash( 'sha256', $body ) ) );
		$expected = hash_hmac( 'sha256', $payload, $secret );
		if ( ! hash_equals( $expected, strtolower( $sig ) ) ) {
			return 'Signature mismatch.';
		}
		$nonce_key = 'egsm_n_' . md5( $kid . '|' . $nonce );
		if ( get_transient( $nonce_key ) ) {
			return 'Replay detected (nonce already used).';
		}
		set_transient( $nonce_key, 1, self::CLOCK_SKEW * 2 );

		$limit  = (int) apply_filters( 'egsm_rate_limit_per_minute', 240 );
		$rl_key = 'egsm_rl_' . md5( $kid ) . '_' . (int) floor( time() / 60 );
		$count  = (int) get_transient( $rl_key );
		if ( $count >= $limit ) {
			return 'rate_limited';
		}
		set_transient( $rl_key, $count + 1, 120 );

		self::$kid = $kid;
		update_option( 'egsm_last_seen', time(), false );
		return true;
	}

	public static function via_signature() {
		return 'ok' === self::$state;
	}

	/**
	 * REST permission check.
	 *
	 * @param string $level read|draft|publish|full
	 * @return true|WP_Error
	 */
	public static function check( $level ) {
		if ( 'error' === self::$state ) {
			if ( 'rate_limited' === self::$error ) {
				return new WP_Error( 'egsm_rate_limited', 'Too many requests for this site. Retry in a minute.', array( 'status' => 429 ) );
			}
			return new WP_Error( 'egsm_auth', self::$error, array( 'status' => 401 ) );
		}
		$ok = 'ok' === self::$state;
		if ( ! $ok && is_user_logged_in() && current_user_can( 'manage_options' ) && EGSM_Settings::get( 'app_password_auth' ) ) {
			$ok = true;
		}
		if ( ! $ok ) {
			return new WP_Error( 'egsm_auth', 'Authentication required (signed request or an administrator Application Password).', array( 'status' => 401 ) );
		}
		if ( ! EGSM_Settings::level_allows( $level ) ) {
			return new WP_Error(
				'egsm_level',
				sprintf( "The site owner set this connection to '%s' access. This action needs '%s' access — they can raise it in the plugin settings.", EGSM_Settings::level(), $level ),
				array(
					'status'         => 403,
					'site_level'     => EGSM_Settings::level(),
					'required_level' => $level,
				)
			);
		}
		return true;
	}

	/** Who is making the change, for the audit log. */
	public static function actor() {
		if ( 'ok' === self::$state ) {
			return 'agency:' . self::$kid;
		}
		$u = wp_get_current_user();
		return $u && $u->ID ? 'user:' . $u->user_login : 'system';
	}

	/* ----- Connection keys ----- */

	/** Creates a new key pair and returns the connection key string (shown once). */
	public static function generate_key() {
		$kid    = bin2hex( random_bytes( 8 ) );
		$secret = bin2hex( random_bytes( 32 ) );
		update_option( 'egsm_kid', $kid, false );
		update_option( 'egsm_secret', $secret, false );
		update_option( 'egsm_key_created', time(), false );
		if ( current_user_can( 'manage_options' ) ) {
			update_option( 'egsm_service_user', get_current_user_id(), false );
		}
		return self::encode_key( $kid, $secret );
	}

	public static function encode_key( $kid, $secret ) {
		$json = wp_json_encode(
			array(
				'v'      => 1,
				'url'    => home_url( '/' ),
				'rest'   => rest_url( EGSM_NS . '/' ),
				'kid'    => $kid,
				'secret' => $secret,
			)
		);
		return 'egsm1.' . rtrim( strtr( base64_encode( $json ), '+/', '-_' ), '=' );
	}

	public static function revoke() {
		delete_option( 'egsm_kid' );
		delete_option( 'egsm_secret' );
		delete_option( 'egsm_key_created' );
		delete_option( 'egsm_paired' );
	}

	public static function is_connected() {
		return '' !== (string) get_option( 'egsm_kid', '' );
	}
}
