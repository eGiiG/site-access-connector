<?php
/**
 * Page-builder detection, builder-aware HTML/text extraction and text replacement.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Builders {

	/** Builders we can build/restructure pages with (not just edit text). */
	const FULL_SUPPORT = array( 'gutenberg', 'classic', 'elementor' );

	public static function detect( $post ) {
		$post = get_post( $post );
		if ( ! $post ) {
			return 'unknown';
		}
		$id = $post->ID;
		if ( 'builder' === get_post_meta( $id, '_elementor_edit_mode', true ) && get_post_meta( $id, '_elementor_data', true ) ) {
			return 'elementor';
		}
		if ( get_post_meta( $id, '_bricks_page_content_2', true ) ) {
			return 'bricks';
		}
		if ( get_post_meta( $id, '_fl_builder_enabled', true ) ) {
			return 'beaver';
		}
		if ( get_post_meta( $id, '_breakdance_data', true ) ) {
			return 'breakdance';
		}
		if ( get_post_meta( $id, 'ct_builder_shortcodes', true ) || get_post_meta( $id, 'ct_builder_json', true ) || get_post_meta( $id, '_oxygen_data', true ) ) {
			return 'oxygen';
		}
		if ( 'on' === get_post_meta( $id, '_et_pb_use_builder', true ) ) {
			return 'divi';
		}
		if ( self::is_thrive( $id ) ) {
			return 'thrive'; // [thrive-support v1]
		}
		if ( false !== strpos( $post->post_content, '[vc_row' ) ) {
			return 'wpbakery';
		}
		if ( has_blocks( $post->post_content ) ) {
			return 'gutenberg';
		}
		return '' === trim( $post->post_content ) ? self::default_editor( $post->post_type ) : 'classic';
	}

	/** What a brand-new post of this type should be written as. */
	public static function default_editor( $post_type ) {
		if ( class_exists( 'Classic_Editor' ) && 'block' !== get_option( 'classic-editor-replace', 'classic' ) ) {
			return 'classic';
		}
		return use_block_editor_for_post_type( $post_type ) ? 'gutenberg' : 'classic';
	}

	public static function site_builders() {
		$b = array();
		if ( defined( 'ELEMENTOR_VERSION' ) ) {
			$b['elementor'] = ELEMENTOR_VERSION . ( defined( 'ELEMENTOR_PRO_VERSION' ) ? ' (Pro ' . ELEMENTOR_PRO_VERSION . ')' : '' );
		}
		if ( defined( 'ET_BUILDER_VERSION' ) ) {
			$b['divi'] = ET_BUILDER_VERSION;
		}
		if ( defined( 'FL_BUILDER_VERSION' ) ) {
			$b['beaver'] = FL_BUILDER_VERSION;
		}
		if ( defined( 'BRICKS_VERSION' ) ) {
			$b['bricks'] = BRICKS_VERSION;
		}
		if ( defined( 'WPB_VC_VERSION' ) ) {
			$b['wpbakery'] = WPB_VC_VERSION;
		}
		if ( defined( 'CT_VERSION' ) ) {
			$b['oxygen'] = CT_VERSION;
		}
		if ( defined( '__BREAKDANCE_VERSION' ) ) {
			$b['breakdance'] = __BREAKDANCE_VERSION;
		}
		if ( defined( 'TVE_VERSION' ) ) {
			$b['thrive'] = TVE_VERSION; // [thrive-support v1]
		}
		$b['default_editor'] = self::default_editor( 'page' );
		return $b;
	}

	/** Builder-aware HTML used for analysis (headings, links, images, text). */
	public static function get_html( $post ) {
		$post = get_post( $post );
		if ( ! $post ) {
			return '';
		}
		switch ( self::detect( $post ) ) {
			case 'elementor':
				return EGSM_Elementor::to_html( EGSM_Elementor::get_data( $post->ID ), $post );
			case 'divi':
			case 'wpbakery':
				return self::shortcode_html( $post->post_content );
			case 'bricks':
				return self::walk_html( get_post_meta( $post->ID, '_bricks_page_content_2', true ) );
			case 'beaver':
				return self::walk_html( get_post_meta( $post->ID, '_fl_builder_data', true ) );
			case 'breakdance':
				$d = get_post_meta( $post->ID, '_breakdance_data', true );
				return self::walk_html( is_string( $d ) ? json_decode( $d, true ) : $d );
			case 'oxygen':
				$sc = get_post_meta( $post->ID, 'ct_builder_shortcodes', true );
				if ( $sc ) {
					return self::shortcode_html( $sc );
				}
				$j = get_post_meta( $post->ID, 'ct_builder_json', true );
				if ( ! $j ) {
					$j = get_post_meta( $post->ID, '_oxygen_data', true );
				}
				return self::walk_html( is_string( $j ) ? json_decode( $j, true ) : $j );
			case 'thrive':
				return self::thrive_clean( self::thrive_source( $post->ID ) );
			case 'classic':
				return wpautop( $post->post_content );
			default:
				return $post->post_content;
		}
	}

	public static function get_text( $post ) {
		return EGSM_Util::text_from_html( self::get_html( $post ) );
	}

	/** Shortcode builders: keep inner content, surface text attributes. */
	private static function shortcode_html( $content ) {
		$content = preg_replace_callback(
			'/\[(?!\/)[a-zA-Z0-9_\-]+([^\]]*)\]/',
			function ( $m ) {
				$out = '';
				if ( preg_match_all( '/\b(title|heading|header|button_text|text)\s*=\s*"([^"]*)"/i', $m[1], $attrs, PREG_SET_ORDER ) ) {
					foreach ( $attrs as $a ) {
						$val = trim( rawurldecode( str_replace( array( '%22', '%91', '%93' ), array( '"', '[', ']' ), $a[2] ) ) );
						if ( '' !== $val && ! preg_match( '#^(https?:|\#|\d+$|on$|off$)#i', $val ) ) {
							$out .= '<p>' . esc_html( $val ) . '</p>';
						}
					}
				}
				return $out;
			},
			(string) $content
		);
		$content = preg_replace( '/\[\/[a-zA-Z0-9_\-]+\]/', '', $content );
		return wpautop( $content );
	}

	/** Generic walk over builder arrays/objects, emitting headings and text. */
	private static function walk_html( $data ) {
		$html = '';
		self::walk( $data, $html );
		return $html;
	}

	private static function walk( $node, &$html, $key = '' ) {
		if ( is_object( $node ) ) {
			$node = get_object_vars( $node );
		}
		if ( is_array( $node ) ) {
			$tag = '';
			foreach ( array( 'tag', 'heading_tag', 'html_tag' ) as $t ) {
				if ( isset( $node[ $t ] ) && is_string( $node[ $t ] ) && preg_match( '/^h[1-6]$/', $node[ $t ] ) ) {
					$tag = $node[ $t ];
				}
			}
			if ( isset( $node['settings'] ) && ( is_array( $node['settings'] ) || is_object( $node['settings'] ) ) ) {
				$s = (array) $node['settings'];
				foreach ( array( 'tag', 'heading_tag', 'html_tag' ) as $t ) {
					if ( isset( $s[ $t ] ) && is_string( $s[ $t ] ) && preg_match( '/^h[1-6]$/', $s[ $t ] ) ) {
						$tag = $s[ $t ];
					}
				}
				$name = isset( $node['name'] ) ? $node['name'] : ( isset( $s['type'] ) ? $s['type'] : '' );
				if ( '' === $tag && is_string( $name ) && 'heading' === $name ) {
					$tag = 'h2';
				}
				foreach ( array( 'text', 'heading', 'title', 'content', 'html', 'description' ) as $f ) {
					if ( isset( $s[ $f ] ) && is_string( $s[ $f ] ) && '' !== trim( $s[ $f ] ) ) {
						$v     = $s[ $f ];
						$html .= $tag && in_array( $f, array( 'text', 'heading', 'title' ), true ) ? "<{$tag}>" . esc_html( wp_strip_all_tags( $v ) ) . "</{$tag}>" : ( preg_match( '/<[a-z][\s\S]*>/i', $v ) ? $v : '<p>' . esc_html( $v ) . '</p>' );
					}
				}
				unset( $node['settings'] );
			}
			foreach ( $node as $k => $v ) {
				if ( is_array( $v ) || is_object( $v ) ) {
					self::walk( $v, $html, (string) $k );
				}
			}
		}
	}

	/* ---------- [thrive-support v1] Thrive Architect ---------- */

	/*
	 * Thrive Architect keeps the live content in post meta, not post_content:
	 *   tve_updated_post{_lp}        the content Thrive renders and its editor loads (source of truth)
	 *   tve_content_before_more{_lp}  a copy used for excerpts / "more" splits (identical unless a more tag is used)
	 *   post_content                  a stripped search mirror (styles removed, <script> stored as [tcb-script])
	 * {_lp} is "_" + the tve_landing_page value when the page uses a Thrive landing-page template, else empty.
	 * Every write goes to all three so the page, the editor and search stay in step; Thrive's next save keeps it.
	 */

	public static function thrive_suffix( $id ) {
		$lp = get_post_meta( $id, 'tve_landing_page', true );
		return is_string( $lp ) && '' !== $lp ? '_' . $lp : '';
	}

	public static function thrive_source( $id ) {
		$v = get_post_meta( $id, 'tve_updated_post' . self::thrive_suffix( $id ), true );
		return is_string( $v ) ? $v : '';
	}

	public static function is_thrive( $id ) {
		if ( ! get_post_meta( $id, 'tcb_editor_enabled', true ) ) {
			return false;
		}
		return '' !== trim( self::thrive_source( $id ) );
	}

	/** Thrive HTML for analysis: drop styles, [tcb-script] blocks and document-head tags pasted into Custom HTML. */
	public static function thrive_clean( $html ) {
		$html = preg_replace( '#\[tcb-script\b[^\]]*\].*?\[/tcb-script\]#is', ' ', (string) $html );
		$html = preg_replace( '#<(style|script|noscript|title)\b[^>]*>.*?</\1>#is', ' ', $html );
		$html = preg_replace( '#<(meta|link)\b[^>]*>#i', ' ', $html );
		return $html;
	}

	/* [thrive-set v1] Whole-layout replacement for Thrive pages built from a Custom HTML element. */

	/** Convert <script> tags to Thrive's stored form so Thrive renders them (and its editor keeps them). */
	public static function thrive_to_source( $html ) {
		return (string) preg_replace_callback(
			'#<script\b([^>]*)>(.*?)</script>#is',
			function ( $m ) {
				$attrs = trim( $m[1] );
				return '<code class="tve_js_placeholder">[tcb-script' . ( '' !== $attrs ? ' ' . $attrs : '' ) . ']' . $m[2] . '[/tcb-script]</code>';
			},
			(string) $html
		);
	}

	/** Replace the Thrive source, its "before more" copy and the search mirror. @return true|WP_Error */
	public static function thrive_set_content( $id, $html ) {
		$html = (string) $html;
		if ( '' === trim( wp_strip_all_tags( self::thrive_clean( $html ) ) ) ) {
			return new WP_Error( 'egsm_empty', 'content_html has no visible content.', array( 'status' => 400 ) );
		}
		$suf = self::thrive_suffix( $id );
		$src = self::thrive_to_source( $html );
		EGSM_Util::set_meta( $id, 'tve_updated_post' . $suf, $src );
		EGSM_Util::set_meta( $id, 'tve_content_before_more' . $suf, $src );
		$mirror = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( self::thrive_clean( $src ) ) ) );
		$r      = wp_update_post(
			array(
				'ID'           => $id,
				'post_content' => wp_slash( $mirror ),
			),
			true
		);
		return is_wp_error( $r ) ? $r : true;
	}

	/**
	 * Run a transform over the Thrive source and its two copies, and save them together.
	 * $fn( string $html, int &$count ) returns the new html. Returns the number of changes in the source.
	 */
	public static function thrive_apply( $id, $fn ) {
		$suf      = self::thrive_suffix( $id );
		$src_key  = 'tve_updated_post' . $suf;
		$more_key = 'tve_content_before_more' . $suf;
		$src      = self::thrive_source( $id );
		$count    = 0;
		$new      = $fn( $src, $count );
		if ( ! $count || $new === $src ) {
			return 0;
		}
		$post  = get_post( $id );
		$dummy = 0;
		$mirror = $fn( (string) $post->post_content, $dummy );
		if ( $mirror !== $post->post_content ) {
			wp_update_post(
				array(
					'ID'           => $id,
					'post_content' => wp_slash( $mirror ),
				)
			);
		}
		EGSM_Util::set_meta( $id, $src_key, $new );
		$more = get_post_meta( $id, $more_key, true );
		if ( is_string( $more ) && '' !== $more ) {
			$dummy = 0;
			EGSM_Util::set_meta( $id, $more_key, $more === $src ? $new : $fn( $more, $dummy ) );
		}
		return $count;
	}

	/** replace_text for Thrive pages: all-or-nothing, matched against the source Thrive renders. */
	private static function thrive_replace_text( $id, $pairs, $ci ) {
		$src     = self::thrive_source( $id );
		$results = array();
		$missing = array();
		$check   = $src;
		foreach ( $pairs as $i => $p ) {
			$find = isset( $p['find'] ) ? (string) $p['find'] : '';
			if ( '' === $find ) {
				return new WP_Error( 'egsm_bad_request', "replace_text[$i].find is empty.", array( 'status' => 400 ) );
			}
			$n     = 0;
			$check = self::replace_in_string( $check, $find, isset( $p['replace'] ) ? (string) $p['replace'] : '', $ci, ! empty( $p['all'] ) ? -1 : 1, $n );
			$results[] = array(
				'find'    => $find,
				'matches' => $n,
			);
			if ( 0 === $n && empty( $p['optional'] ) ) {
				$missing[] = $find;
			}
		}
		if ( $missing ) {
			return new WP_Error(
				'egsm_text_not_found',
				'Some text to replace was not found in the Thrive content (nothing was changed). Read the page with include=raw and copy the exact text.',
				array(
					'status'    => 422,
					'not_found' => $missing,
				)
			);
		}
		self::thrive_apply(
			$id,
			function ( $html, &$count ) use ( $pairs, $ci ) {
				foreach ( $pairs as $p ) {
					$html = self::replace_in_string( $html, (string) $p['find'], isset( $p['replace'] ) ? (string) $p['replace'] : '', $ci, ! empty( $p['all'] ) ? -1 : 1, $count );
				}
				return $html;
			}
		);
		return $results;
	}

	/* ---------- universal text replace ---------- */

	/**
	 * Replace text across wherever this builder stores content.
	 *
	 * @param int   $id
	 * @param array $pairs [ ['find'=>..,'replace'=>..,'all'=>bool], ... ]
	 * @return array|WP_Error per-pair counts
	 */
	public static function replace_text( $id, $pairs, $case_insensitive = false ) {
		$post    = get_post( $id );
		$builder = self::detect( $post );
		if ( 'thrive' === $builder ) {
			return self::thrive_replace_text( $id, $pairs, $case_insensitive );
		}
		$content = $post->post_content;

		$meta_keys = array();
		if ( 'elementor' === $builder ) {
			$meta_keys = array( '_elementor_data' );
		} elseif ( 'bricks' === $builder ) {
			$meta_keys = array( '_bricks_page_content_2' );
		} elseif ( 'beaver' === $builder ) {
			$meta_keys = array( '_fl_builder_data', '_fl_builder_draft' );
		} elseif ( 'breakdance' === $builder ) {
			$meta_keys = array( '_breakdance_data' );
		} elseif ( 'oxygen' === $builder ) {
			$meta_keys = array( 'ct_builder_shortcodes', 'ct_builder_json', '_oxygen_data' );
		}

		$meta_vals = array();
		foreach ( $meta_keys as $k ) {
			$raw = get_post_meta( $id, $k, true );
			if ( '' === $raw || null === $raw ) {
				continue;
			}
			$json = false;
			if ( is_string( $raw ) ) {
				$decoded = json_decode( $raw, true );
				if ( is_array( $decoded ) ) {
					$raw  = $decoded;
					$json = true;
				}
			}
			$meta_vals[ $k ] = array(
				'value' => $raw,
				'json'  => $json,
			);
		}

		$results = array();
		$missing = array();
		foreach ( $pairs as $i => $p ) {
			$find    = isset( $p['find'] ) ? (string) $p['find'] : '';
			$replace = isset( $p['replace'] ) ? (string) $p['replace'] : '';
			$all     = ! empty( $p['all'] );
			if ( '' === $find ) {
				return new WP_Error( 'egsm_bad_request', "replace_text[$i].find is empty.", array( 'status' => 400 ) );
			}
			$count   = 0;
			$limit   = $all ? -1 : 1;
			$content = self::replace_in_string( $content, $find, $replace, $case_insensitive, $limit, $count );
			foreach ( $meta_vals as $k => $mv ) {
				$remaining = $all ? -1 : max( 0, 1 - $count );
				if ( 0 === $remaining && ! $all && 'elementor' !== $builder ) {
					break;
				}
				// Elementor keeps post_content as a plain-text mirror; the data is the source of truth.
				$local = 0;
				$val   = $mv['value'];
				self::replace_deep( $val, $find, $replace, $case_insensitive, $all ? -1 : 1, $local );
				$meta_vals[ $k ]['value'] = $val;
				$count                   += $local;
			}
			$results[] = array(
				'find'    => $find,
				'matches' => $count,
			);
			if ( 0 === $count && empty( $p['optional'] ) ) {
				$missing[] = $find;
			}
		}
		if ( $missing ) {
			return new WP_Error(
				'egsm_text_not_found',
				'Some text to replace was not found (nothing was changed). Read the page first and copy the exact text.',
				array(
					'status'    => 422,
					'not_found' => $missing,
				)
			);
		}

		if ( $content !== $post->post_content ) {
			wp_update_post(
				array(
					'ID'           => $id,
					'post_content' => wp_slash( $content ),
				)
			);
		}
		foreach ( $meta_vals as $k => $mv ) {
			EGSM_Util::set_meta( $id, $k, $mv['json'] ? wp_json_encode( $mv['value'] ) : $mv['value'] );
		}
		if ( 'elementor' === $builder ) {
			EGSM_Elementor::clear_css( $id );
		}
		return $results;
	}

	public static function replace_in_string( $subject, $find, $replace, $ci, $limit, &$count ) {
		$pattern = '/' . preg_quote( $find, '/' ) . '/' . ( $ci ? 'iu' : 'u' );
		$n       = 0;
		$out     = preg_replace_callback(
			$pattern,
			function () use ( $replace ) {
				return $replace;
			},
			(string) $subject,
			$limit,
			$n
		);
		$count += $n;
		return null === $out ? $subject : $out;
	}

	public static function replace_deep( &$value, $find, $replace, $ci, $limit, &$count ) {
		if ( 0 === $limit ) {
			return;
		}
		if ( is_string( $value ) ) {
			$before = $count;
			$value  = self::replace_in_string( $value, $find, $replace, $ci, $limit, $count );
			return;
		}
		if ( is_array( $value ) ) {
			foreach ( $value as $k => &$v ) {
				if ( $limit > 0 && $count >= $limit ) {
					return;
				}
				// Never touch ids / widget types / structural keys.
				if ( in_array( (string) $k, array( 'id', 'elType', 'widgetType', 'name', 'type', 'parent', 'node' ), true ) ) {
					continue;
				}
				self::replace_deep( $v, $find, $replace, $ci, $limit > 0 ? $limit - $count : -1, $count );
			}
			return;
		}
		if ( is_object( $value ) ) {
			foreach ( get_object_vars( $value ) as $k => $v ) {
				if ( in_array( (string) $k, array( 'id', 'node', 'parent', 'type' ), true ) ) {
					continue;
				}
				self::replace_deep( $v, $find, $replace, $ci, $limit > 0 ? $limit - $count : -1, $count );
				$value->$k = $v;
			}
		}
	}
}
