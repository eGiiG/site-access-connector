<?php
/**
 * Block editor (Gutenberg): convert HTML to valid core blocks, replace sections, append.
 *
 * Markup mirrors core's save() output (WordPress 6.5+) so pages open in the editor
 * without "unexpected or invalid content" warnings.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Gutenberg {

	const INLINE = array( 'a', 'abbr', 'b', 'bdi', 'bdo', 'cite', 'code', 'data', 'dfn', 'em', 'i', 'kbd', 'mark', 'q', 's', 'samp', 'small', 'span', 'strong', 'sub', 'sup', 'time', 'u', 'var', 'del', 'ins' );

	/** HTML (as an AI would write it) → serialized block markup. */
	public static function html_to_blocks( $html ) {
		$html = trim( (string) $html );
		if ( '' === $html ) {
			return '';
		}
		if ( has_blocks( $html ) ) {
			return $html; // Already block markup.
		}
		$root = self::load( $html );
		if ( ! $root ) {
			return self::serialize( array( self::html_block( $html ) ) );
		}
		$blocks = self::convert_children( $root );
		return self::serialize( $blocks );
	}

	public static function serialize( $blocks ) {
		$parts = array();
		foreach ( $blocks as $b ) {
			$parts[] = serialize_block( $b );
		}
		return implode( "\n\n", $parts );
	}

	private static function load( $html ) {
		if ( ! class_exists( 'DOMDocument' ) ) {
			return null;
		}
		$doc  = new DOMDocument();
		$prev = libxml_use_internal_errors( true );
		$ok   = $doc->loadHTML( '<?xml encoding="utf-8"?><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body><div id="egsm-root">' . $html . '</div></body></html>' );
		libxml_clear_errors();
		libxml_use_internal_errors( $prev );
		if ( ! $ok ) {
			return null;
		}
		return $doc->getElementById( 'egsm-root' );
	}

	private static function inner_html( DOMNode $node ) {
		$out = '';
		foreach ( $node->childNodes as $c ) {
			$out .= $node->ownerDocument->saveHTML( $c );
		}
		return trim( $out );
	}

	private static function outer_html( DOMNode $node ) {
		return trim( $node->ownerDocument->saveHTML( $node ) );
	}

	private static function block( $name, $attrs, $html, $inner = array(), $inner_content = null ) {
		return array(
			'blockName'    => $name,
			'attrs'        => $attrs,
			'innerBlocks'  => $inner,
			'innerHTML'    => $html,
			'innerContent' => null === $inner_content ? array( "\n" . $html . "\n" ) : $inner_content,
		);
	}

	private static function html_block( $html ) {
		return self::block( 'core/html', array(), $html );
	}

	private static function paragraph( $inner ) {
		return self::block( 'core/paragraph', array(), '<p>' . $inner . '</p>' );
	}

	/** Wrap inner blocks in a container: open + children + close, the way core serializes. */
	private static function container( $name, $attrs, $open, $close, $children ) {
		$content = array( "\n" . $open );
		$html    = "\n" . $open;
		foreach ( $children as $i => $c ) {
			$content[] = null;
			if ( $i < count( $children ) - 1 ) {
				$content[] = "\n\n";
				$html     .= "\n\n";
			}
		}
		$content[] = $close . "\n";
		$html     .= $close . "\n";
		return array(
			'blockName'    => $name,
			'attrs'        => $attrs,
			'innerBlocks'  => $children,
			'innerHTML'    => $html,
			'innerContent' => $content,
		);
	}

	private static function is_inline( DOMNode $n ) {
		if ( XML_TEXT_NODE === $n->nodeType ) {
			return true;
		}
		if ( XML_ELEMENT_NODE !== $n->nodeType ) {
			return false;
		}
		$tag = strtolower( $n->nodeName );
		if ( 'img' === $tag ) {
			return false;
		}
		if ( in_array( $tag, self::INLINE, true ) ) {
			// An inline wrapper around an image (a > img) is treated as a block image.
			foreach ( $n->childNodes as $c ) {
				if ( XML_ELEMENT_NODE === $c->nodeType && 'img' === strtolower( $c->nodeName ) ) {
					return false;
				}
			}
			return true;
		}
		return 'br' === $tag;
	}

	private static function has_block_children( DOMNode $n ) {
		foreach ( $n->childNodes as $c ) {
			if ( XML_ELEMENT_NODE === $c->nodeType && ! self::is_inline( $c ) ) {
				return true;
			}
		}
		return false;
	}

	private static function convert_children( DOMNode $parent ) {
		$blocks = array();
		$buffer = '';
		$flush  = function () use ( &$buffer, &$blocks ) {
			$t = trim( $buffer );
			$t = preg_replace( '#^(<br\s*/?>\s*)+|(\s*<br\s*/?>)+$#i', '', $t );
			if ( '' !== trim( wp_strip_all_tags( $t ) ) || false !== strpos( $t, '<img' ) ) {
				$blocks[] = self::paragraph( $t );
			}
			$buffer = '';
		};
		foreach ( $parent->childNodes as $n ) {
			if ( XML_COMMENT_NODE === $n->nodeType ) {
				continue;
			}
			if ( self::is_inline( $n ) ) {
				if ( XML_ELEMENT_NODE === $n->nodeType && 'br' === strtolower( $n->nodeName ) && preg_match( '#<br\s*/?>\s*$#i', trim( $buffer ) ) ) {
					$flush();
					continue;
				}
				$buffer .= XML_TEXT_NODE === $n->nodeType ? esc_html( $n->nodeValue ) : $n->ownerDocument->saveHTML( $n );
				continue;
			}
			$flush();
			foreach ( self::convert_element( $n ) as $b ) {
				$blocks[] = $b;
			}
		}
		$flush();
		return $blocks;
	}

	private static function convert_element( DOMElement $el ) {
		$tag = strtolower( $el->nodeName );
		switch ( $tag ) {
			case 'h1':
			case 'h2':
			case 'h3':
			case 'h4':
			case 'h5':
			case 'h6':
				$level = (int) $tag[1];
				$attrs = 2 === $level ? array() : array( 'level' => $level );
				$id    = $el->getAttribute( 'id' );
				$open  = '<' . $tag . ' class="wp-block-heading"' . ( $id ? ' id="' . esc_attr( $id ) . '"' : '' ) . '>';
				return array( self::block( 'core/heading', $attrs, $open . self::inner_html( $el ) . '</' . $tag . '>' ) );

			case 'p':
				if ( self::only_image( $el ) ) {
					return array( self::image_block( $el ) );
				}
				$inner = self::inner_html( $el );
				return '' === trim( wp_strip_all_tags( $inner ) ) ? array() : array( self::paragraph( $inner ) );

			case 'ul':
			case 'ol':
				return array( self::list_block( $el ) );

			case 'blockquote':
				$cite     = '';
				$children = array();
				foreach ( $el->childNodes as $c ) {
					if ( XML_ELEMENT_NODE === $c->nodeType && in_array( strtolower( $c->nodeName ), array( 'cite', 'footer' ), true ) ) {
						$cite = self::inner_html( $c );
						continue;
					}
				}
				$tmp = $el->cloneNode( true );
				foreach ( iterator_to_array( $tmp->childNodes ) as $c ) {
					if ( XML_ELEMENT_NODE === $c->nodeType && in_array( strtolower( $c->nodeName ), array( 'cite', 'footer' ), true ) ) {
						$tmp->removeChild( $c );
					}
				}
				$children = self::convert_children( $tmp );
				if ( ! $children ) {
					$children = array( self::paragraph( '' ) );
				}
				return array( self::container( 'core/quote', array(), '<blockquote class="wp-block-quote">', ( '' !== $cite ? '<cite>' . $cite . '</cite>' : '' ) . '</blockquote>', $children ) );

			case 'hr':
				return array( self::block( 'core/separator', array(), '<hr class="wp-block-separator has-alpha-channel-opacity"/>' ) );

			case 'img':
			case 'figure':
				if ( 'figure' === $tag && $el->getElementsByTagName( 'table' )->length ) {
					return array( self::table_block( $el->getElementsByTagName( 'table' )->item( 0 ) ) );
				}
				if ( 'img' === $tag || $el->getElementsByTagName( 'img' )->length ) {
					return array( self::image_block( $el ) );
				}
				return array( self::html_block( self::outer_html( $el ) ) );

			case 'table':
				return array( self::table_block( $el ) );

			case 'details':
				$summary = '';
				$tmp     = $el->cloneNode( true );
				foreach ( iterator_to_array( $tmp->childNodes ) as $c ) {
					if ( XML_ELEMENT_NODE === $c->nodeType && 'summary' === strtolower( $c->nodeName ) ) {
						$summary = self::inner_html( $c );
						$tmp->removeChild( $c );
					}
				}
				$children = self::convert_children( $tmp );
				if ( ! $children ) {
					$children = array( self::paragraph( '' ) );
				}
				return array( self::container( 'core/details', array(), '<details class="wp-block-details"><summary>' . $summary . '</summary>', '</details>', $children ) );

			case 'div':
			case 'section':
			case 'article':
			case 'main':
			case 'header':
			case 'footer':
			case 'aside':
				// Styled wrappers are kept verbatim so custom boxes/CTAs keep their look.
				if ( $el->getAttribute( 'style' ) || $el->getAttribute( 'class' ) ) {
					return array( self::html_block( self::outer_html( $el ) ) );
				}
				if ( self::has_block_children( $el ) ) {
					return self::convert_children( $el );
				}
				$inner = self::inner_html( $el );
				return '' === trim( wp_strip_all_tags( $inner ) ) ? array() : array( self::paragraph( $inner ) );

			default:
				return array( self::html_block( self::outer_html( $el ) ) );
		}
	}

	private static function only_image( DOMElement $el ) {
		$imgs = $el->getElementsByTagName( 'img' );
		if ( 1 !== $imgs->length ) {
			return false;
		}
		return '' === trim( $el->textContent );
	}

	private static function image_block( DOMElement $el ) {
		$img = 'img' === strtolower( $el->nodeName ) ? $el : $el->getElementsByTagName( 'img' )->item( 0 );
		$src = $img->getAttribute( 'src' );
		$alt = $img->getAttribute( 'alt' );
		$id  = 0;
		if ( preg_match( '/wp-image-(\d+)/', (string) $img->getAttribute( 'class' ), $m ) ) {
			$id = (int) $m[1];
		} elseif ( $src ) {
			$id = (int) attachment_url_to_postid( $src );
		}
		$href = '';
		$a    = $img->parentNode;
		if ( $a && 'a' === strtolower( $a->nodeName ) ) {
			$href = $a->getAttribute( 'href' );
		}
		$caption = '';
		$fc      = $el->getElementsByTagName( 'figcaption' );
		if ( $fc->length ) {
			$caption = self::inner_html( $fc->item( 0 ) );
		}
		$attrs = array();
		if ( $id ) {
			$attrs['id'] = $id;
		}
		$attrs['sizeSlug']        = 'full';
		$attrs['linkDestination'] = $href ? 'custom' : 'none';

		$img_html = '<img src="' . esc_url( $src ) . '" alt="' . esc_attr( $alt ) . '"' . ( $id ? ' class="wp-image-' . $id . '"' : '' ) . '/>';
		if ( $href ) {
			$img_html = '<a href="' . esc_url( $href ) . '">' . $img_html . '</a>';
		}
		$html = '<figure class="wp-block-image size-full">' . $img_html . ( '' !== $caption ? '<figcaption class="wp-element-caption">' . $caption . '</figcaption>' : '' ) . '</figure>';
		return self::block( 'core/image', $attrs, $html );
	}

	private static function list_block( DOMElement $el ) {
		$ordered = 'ol' === strtolower( $el->nodeName );
		$items   = array();
		foreach ( $el->childNodes as $li ) {
			if ( XML_ELEMENT_NODE !== $li->nodeType || 'li' !== strtolower( $li->nodeName ) ) {
				continue;
			}
			$nested = array();
			$text   = '';
			foreach ( $li->childNodes as $c ) {
				if ( XML_ELEMENT_NODE === $c->nodeType && in_array( strtolower( $c->nodeName ), array( 'ul', 'ol' ), true ) ) {
					$nested[] = self::list_block( $c );
				} else {
					$text .= XML_TEXT_NODE === $c->nodeType ? esc_html( $c->nodeValue ) : $c->ownerDocument->saveHTML( $c );
				}
			}
			$text = trim( $text );
			if ( $nested ) {
				$content = array( "\n<li>" . $text );
				$inner   = "\n<li>" . $text;
				foreach ( $nested as $i => $n ) {
					$content[] = null;
				}
				$content[] = "</li>\n";
				$inner    .= "</li>\n";
				$items[]   = array(
					'blockName'    => 'core/list-item',
					'attrs'        => array(),
					'innerBlocks'  => $nested,
					'innerHTML'    => $inner,
					'innerContent' => $content,
				);
			} else {
				$items[] = self::block( 'core/list-item', array(), '<li>' . $text . '</li>' );
			}
		}
		$tag   = $ordered ? 'ol' : 'ul';
		$attrs = $ordered ? array( 'ordered' => true ) : array();
		return self::container( 'core/list', $attrs, '<' . $tag . ' class="wp-block-list">', '</' . $tag . '>', $items );
	}

	private static function table_block( DOMElement $table ) {
		$head = array();
		$body = array();
		foreach ( $table->getElementsByTagName( 'tr' ) as $tr ) {
			$cells   = array();
			$all_th  = true;
			$in_head = $tr->parentNode && 'thead' === strtolower( $tr->parentNode->nodeName );
			foreach ( $tr->childNodes as $c ) {
				if ( XML_ELEMENT_NODE !== $c->nodeType ) {
					continue;
				}
				$t = strtolower( $c->nodeName );
				if ( 'td' === $t ) {
					$all_th = false;
				}
				if ( 'td' === $t || 'th' === $t ) {
					$cells[] = self::inner_html( $c );
				}
			}
			if ( ! $cells ) {
				continue;
			}
			if ( $in_head || ( $all_th && ! $head && ! $body ) ) {
				$head[] = $cells;
			} else {
				$body[] = $cells;
			}
		}
		$h = '<figure class="wp-block-table"><table class="has-fixed-layout">';
		if ( $head ) {
			$h .= '<thead>';
			foreach ( $head as $row ) {
				$h .= '<tr><th>' . implode( '</th><th>', $row ) . '</th></tr>';
			}
			$h .= '</thead>';
		}
		$h .= '<tbody>';
		foreach ( $body as $row ) {
			$h .= '<tr><td>' . implode( '</td><td>', $row ) . '</td></tr>';
		}
		$h .= '</tbody></table></figure>';
		return self::block( 'core/table', array(), $h );
	}

	/* ---------- editing helpers ---------- */

	/** Plain-text of a heading block/element for matching. */
	private static function heading_text( $block ) {
		return trim( mb_strtolower( EGSM_Util::text_from_html( $block['innerHTML'] ) ) );
	}

	/**
	 * Replace the body under a heading (until the next heading of the same or higher level).
	 *
	 * @return string|WP_Error new content
	 */
	public static function replace_section( $content, $heading, $new_html, $include_heading = false ) {
		$target = trim( mb_strtolower( (string) $heading ) );
		if ( has_blocks( $content ) ) {
			$blocks = parse_blocks( $content );
			$start  = -1;
			$level  = 0;
			foreach ( $blocks as $i => $b ) {
				if ( 'core/heading' === $b['blockName'] && self::heading_text( $b ) === $target ) {
					$start = $i;
					$level = isset( $b['attrs']['level'] ) ? (int) $b['attrs']['level'] : 2;
					break;
				}
			}
			if ( $start < 0 ) {
				return new WP_Error( 'egsm_heading_not_found', 'Heading not found at the top level of the page: ' . $heading, array( 'status' => 422 ) );
			}
			$end = count( $blocks );
			for ( $j = $start + 1; $j < count( $blocks ); $j++ ) {
				$b = $blocks[ $j ];
				if ( 'core/heading' === $b['blockName'] ) {
					$l = isset( $b['attrs']['level'] ) ? (int) $b['attrs']['level'] : 2;
					if ( $l <= $level ) {
						$end = $j;
						break;
					}
				}
			}
			$new    = parse_blocks( self::html_to_blocks( $new_html ) );
			$new    = array_values(
				array_filter(
					$new,
					function ( $b ) {
						return null !== $b['blockName'];
					}
				)
			);
			$from   = $include_heading ? $start : $start + 1;
			$result = array_merge( array_slice( $blocks, 0, $from ), $new, array_slice( $blocks, $end ) );
			return self::serialize_parsed( $result );
		}
		// Classic HTML.
		if ( ! preg_match_all( '#<h([1-6])\b[^>]*>(.*?)</h\1>#is', $content, $m, PREG_OFFSET_CAPTURE | PREG_SET_ORDER ) ) {
			return new WP_Error( 'egsm_heading_not_found', 'No headings found on this page.', array( 'status' => 422 ) );
		}
		foreach ( $m as $idx => $h ) {
			if ( trim( mb_strtolower( EGSM_Util::text_from_html( $h[2][0] ) ) ) !== $target ) {
				continue;
			}
			$level     = (int) $h[1][0];
			$h_start   = $h[0][1];
			$h_end     = $h_start + strlen( $h[0][0] );
			$end       = strlen( $content );
			$remaining = count( $m );
			for ( $k = $idx + 1; $k < $remaining; $k++ ) {
				if ( (int) $m[ $k ][1][0] <= $level ) {
					$end = $m[ $k ][0][1];
					break;
				}
			}
			$from = $include_heading ? $h_start : $h_end;
			return substr( $content, 0, $from ) . "\n" . trim( $new_html ) . "\n\n" . substr( $content, $end );
		}
		return new WP_Error( 'egsm_heading_not_found', 'Heading not found: ' . $heading, array( 'status' => 422 ) );
	}

	/** serialize_blocks for parsed blocks, keeping blank lines between top-level blocks. */
	public static function serialize_parsed( $blocks ) {
		$out = array();
		foreach ( $blocks as $b ) {
			if ( null === $b['blockName'] ) {
				if ( '' === trim( $b['innerHTML'] ) ) {
					continue;
				}
			}
			$out[] = serialize_block( $b );
		}
		return implode( "\n\n", $out );
	}

	public static function append( $content, $html, $as_blocks ) {
		$add = $as_blocks ? self::html_to_blocks( $html ) : trim( $html );
		return rtrim( (string) $content ) . "\n\n" . $add . "\n";
	}

	public static function prepend( $content, $html, $as_blocks ) {
		$add = $as_blocks ? self::html_to_blocks( $html ) : trim( $html );
		return $add . "\n\n" . ltrim( (string) $content );
	}

	/** Visible FAQ section (H2 + H3 question + answer paragraphs) — good for answer engines. */
	public static function faq_html( $items, $title = 'Frequently Asked Questions' ) {
		$h = '' !== $title ? '<h2>' . esc_html( $title ) . '</h2>' : '';
		foreach ( $items as $it ) {
			$h .= '<h3>' . esc_html( $it['question'] ) . '</h3>';
			$a  = trim( (string) $it['answer'] );
			$h .= preg_match( '#^<(p|ul|ol|table)\b#i', $a ) ? $a : '<p>' . $a . '</p>';
		}
		return $h;
	}
}
