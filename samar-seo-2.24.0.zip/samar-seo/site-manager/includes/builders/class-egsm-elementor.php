<?php
/**
 * Elementor: read/write the widget tree (_elementor_data), slot-based text filling,
 * structural ops (remove, duplicate, insert), CSS cache invalidation.
 *
 * Slot paths:  {elementId}.{setting}             e.g. 3f2a9c1.title
 *              {elementId}.{repeater}.{i}.{field} e.g. 7bc12d0.tabs.2.tab_content
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Elementor {

	const TEXT_KEY = '/^(title|text|editor|description|content|caption|heading|sub_?title|sub_?heading|label|html|before_text|highlighted_text|after_text|rotating_text|testimonial_content|testimonial_name|testimonial_job|title_text|description_text|tab_title|tab_content|item_title|item_content|button_text|prefix|suffix|inner_text|blockquote_content|author_name|alert_title|alert_description|price|period|feature_text|question|answer|name|job|excerpt|link_text|ribbon_title|heading_text|sub_heading|sub_title|cta_text)$/';
	const SKIP_VAL = '/^(#[0-9a-f]{3,8}|yes|no|none|default|left|right|center|full|custom|h[1-6]|[0-9.]+(px|em|%|vh|vw)?)$/i';

	public static function get_data( $id ) {
		$raw = get_post_meta( $id, '_elementor_data', true );
		if ( is_array( $raw ) ) {
			return $raw;
		}
		$data = json_decode( (string) $raw, true );
		return is_array( $data ) ? $data : array();
	}

	public static function save_data( $id, $data ) {
		EGSM_Util::set_meta( $id, '_elementor_data', wp_json_encode( array_values( $data ) ) );
		update_post_meta( $id, '_elementor_edit_mode', 'builder' );
		// Keep post_content as a readable mirror (search, RSS, SEO plugins' analysis).
		wp_update_post(
			array(
				'ID'           => $id,
				'post_content' => wp_slash( self::plain_content( $data ) ),
			)
		);
		self::clear_css( $id );
	}

	public static function clear_css( $id ) {
		delete_post_meta( $id, '_elementor_css' );
		delete_post_meta( $id, '_elementor_element_cache' );
		delete_post_meta( $id, '_elementor_page_assets' );
		$up = wp_upload_dir();
		foreach ( array( 'post-' . $id . '.css' ) as $f ) {
			$path = trailingslashit( $up['basedir'] ) . 'elementor/css/' . $f;
			if ( file_exists( $path ) ) {
				wp_delete_file( $path );
			}
		}
		if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
			try {
				$css = \Elementor\Core\Files\CSS\Post::create( $id );
				if ( method_exists( $css, 'delete' ) ) {
					$css->delete();
				}
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
			}
		}
	}

	/* ---------- reading ---------- */

	private static function is_text_value( $key, $val ) {
		return is_string( $val ) && '' !== trim( $val ) && preg_match( self::TEXT_KEY, $key ) && ! preg_match( self::SKIP_VAL, trim( $val ) ) && ! preg_match( '#^https?://\S+$#', trim( $val ) );
	}

	/** Every editable text/image/link slot in the page, in document order. */
	public static function slots( $data ) {
		$out = array();
		self::walk_slots( $data, $out );
		return $out;
	}

	private static function walk_slots( $elements, &$out ) {
		foreach ( (array) $elements as $el ) {
			if ( ! is_array( $el ) || empty( $el['id'] ) ) {
				continue;
			}
			$eid    = $el['id'];
			$widget = isset( $el['widgetType'] ) ? $el['widgetType'] : $el['elType'];
			$s      = isset( $el['settings'] ) && is_array( $el['settings'] ) ? $el['settings'] : array();
			foreach ( $s as $key => $val ) {
				if ( self::is_text_value( $key, $val ) ) {
					$slot = array(
						'path'   => $eid . '.' . $key,
						'widget' => $widget,
						'type'   => preg_match( '/<[a-z][\s\S]*>/i', $val ) || in_array( $key, array( 'editor', 'html' ), true ) ? 'html' : 'text',
						'value'  => $val,
					);
					if ( 'heading' === $widget && 'title' === $key ) {
						$slot['tag'] = isset( $s['header_size'] ) ? $s['header_size'] : 'h2';
					}
					$out[] = $slot;
				} elseif ( is_array( $val ) && isset( $val['url'] ) && in_array( $key, array( 'image', 'link', 'button_link', 'website_link', 'image_link' ), true ) ) {
					$out[] = array(
						'path'   => $eid . '.' . $key,
						'widget' => $widget,
						'type'   => 'image' === $key ? 'image' : 'link',
						'value'  => 'image' === $key ? array(
							'url' => $val['url'],
							'id'  => isset( $val['id'] ) ? (int) $val['id'] : 0,
							'alt' => isset( $val['id'] ) && $val['id'] ? (string) get_post_meta( (int) $val['id'], '_wp_attachment_image_alt', true ) : '',
						) : $val['url'],
					);
				} elseif ( is_array( $val ) && isset( $val[0] ) && is_array( $val[0] ) ) {
					foreach ( $val as $i => $item ) {
						if ( ! is_array( $item ) ) {
							continue;
						}
						foreach ( $item as $ik => $iv ) {
							if ( self::is_text_value( $ik, $iv ) ) {
								$out[] = array(
									'path'   => $eid . '.' . $key . '.' . $i . '.' . $ik,
									'widget' => $widget,
									'type'   => preg_match( '/<[a-z][\s\S]*>/i', $iv ) ? 'html' : 'text',
									'value'  => $iv,
								);
							}
						}
					}
				}
			}
			if ( ! empty( $el['elements'] ) ) {
				self::walk_slots( $el['elements'], $out );
			}
		}
	}

	/** Compact outline of the page structure for an AI to reason about. */
	public static function outline( $data, $depth = 0 ) {
		$out = array();
		foreach ( (array) $data as $el ) {
			if ( ! is_array( $el ) || empty( $el['id'] ) ) {
				continue;
			}
			$node = array(
				'id'   => $el['id'],
				'type' => isset( $el['widgetType'] ) ? $el['widgetType'] : $el['elType'],
			);
			if ( ! empty( $el['elements'] ) && $depth < 12 ) {
				$node['children'] = self::outline( $el['elements'], $depth + 1 );
			}
			$out[] = $node;
		}
		return $out;
	}

	/** Render the widget tree to semantic HTML for analysis. */
	public static function to_html( $data, $post = null ) {
		$html = '';
		foreach ( (array) $data as $el ) {
			if ( ! is_array( $el ) ) {
				continue;
			}
			$s = isset( $el['settings'] ) && is_array( $el['settings'] ) ? $el['settings'] : array();
			$w = isset( $el['widgetType'] ) ? $el['widgetType'] : '';
			switch ( $w ) {
				case 'heading':
					$tag   = isset( $s['header_size'] ) && preg_match( '/^h[1-6]$/', $s['header_size'] ) ? $s['header_size'] : 'h2';
					$title = isset( $s['title'] ) ? $s['title'] : '';
					if ( ! empty( $s['link']['url'] ) ) {
						$title = '<a href="' . esc_url( $s['link']['url'] ) . '">' . $title . '</a>';
					}
					$html .= "<{$tag}>{$title}</{$tag}>";
					break;
				case 'theme-post-title':
				case 'post-title':
					$tag   = isset( $s['header_size'] ) && preg_match( '/^h[1-6]$/', $s['header_size'] ) ? $s['header_size'] : 'h1';
					$html .= "<{$tag}>" . esc_html( $post ? get_the_title( $post ) : '' ) . "</{$tag}>";
					break;
				case 'text-editor':
					$html .= isset( $s['editor'] ) ? wpautop( $s['editor'] ) : '';
					break;
				case 'html':
					$html .= isset( $s['html'] ) ? $s['html'] : '';
					break;
				case 'button':
					$url   = isset( $s['link']['url'] ) ? $s['link']['url'] : '';
					$html .= '<p><a href="' . esc_url( $url ) . '">' . esc_html( isset( $s['text'] ) ? $s['text'] : '' ) . '</a></p>';
					break;
				case 'image':
					if ( ! empty( $s['image']['url'] ) ) {
						$aid   = isset( $s['image']['id'] ) ? (int) $s['image']['id'] : 0;
						$alt   = $aid ? (string) get_post_meta( $aid, '_wp_attachment_image_alt', true ) : '';
						$img   = '<img src="' . esc_url( $s['image']['url'] ) . '" alt="' . esc_attr( $alt ) . '"' . ( $aid ? ' class="wp-image-' . $aid . '"' : '' ) . '>';
						$html .= ! empty( $s['link']['url'] ) ? '<a href="' . esc_url( $s['link']['url'] ) . '">' . $img . '</a>' : $img;
					}
					break;
				case 'icon-box':
				case 'image-box':
					$tag = isset( $s['title_size'] ) && preg_match( '/^h[1-6]$/', $s['title_size'] ) ? $s['title_size'] : 'h3';
					if ( 'image-box' === $w && ! empty( $s['image']['url'] ) ) {
						$aid   = isset( $s['image']['id'] ) ? (int) $s['image']['id'] : 0;
						$html .= '<img src="' . esc_url( $s['image']['url'] ) . '" alt="' . esc_attr( $aid ? (string) get_post_meta( $aid, '_wp_attachment_image_alt', true ) : '' ) . '"' . ( $aid ? ' class="wp-image-' . $aid . '"' : '' ) . '>';
					}
					if ( ! empty( $s['title_text'] ) ) {
						$html .= "<{$tag}>" . $s['title_text'] . "</{$tag}>";
					}
					if ( ! empty( $s['description_text'] ) ) {
						$html .= '<p>' . $s['description_text'] . '</p>';
					}
					break;
				case 'icon-list':
					if ( ! empty( $s['icon_list'] ) && is_array( $s['icon_list'] ) ) {
						$html .= '<ul>';
						foreach ( $s['icon_list'] as $it ) {
							$t     = isset( $it['text'] ) ? $it['text'] : '';
							$html .= '<li>' . ( ! empty( $it['link']['url'] ) ? '<a href="' . esc_url( $it['link']['url'] ) . '">' . $t . '</a>' : $t ) . '</li>';
						}
						$html .= '</ul>';
					}
					break;
				case 'accordion':
				case 'toggle':
				case 'tabs':
					if ( ! empty( $s['tabs'] ) && is_array( $s['tabs'] ) ) {
						foreach ( $s['tabs'] as $it ) {
							$html .= '<h3>' . ( isset( $it['tab_title'] ) ? $it['tab_title'] : '' ) . '</h3>' . wpautop( isset( $it['tab_content'] ) ? $it['tab_content'] : '' );
						}
					}
					break;
				case 'nested-accordion':
				case 'nested-tabs':
					if ( ! empty( $s['items'] ) && is_array( $s['items'] ) ) {
						foreach ( $s['items'] as $i => $it ) {
							$html .= '<h3>' . ( isset( $it['item_title'] ) ? $it['item_title'] : '' ) . '</h3>';
							if ( isset( $el['elements'][ $i ] ) ) {
								$html .= self::to_html( array( $el['elements'][ $i ] ), $post );
							}
						}
						$el['elements'] = array();
					}
					break;
				case 'testimonial':
					$html .= '<blockquote><p>' . ( isset( $s['testimonial_content'] ) ? $s['testimonial_content'] : '' ) . '</p><cite>' . ( isset( $s['testimonial_name'] ) ? $s['testimonial_name'] : '' ) . '</cite></blockquote>';
					break;
				case '':
					break;
				default:
					foreach ( $s as $k => $v ) {
						if ( self::is_text_value( $k, $v ) ) {
							$html .= preg_match( '/<[a-z][\s\S]*>/i', $v ) ? $v : '<p>' . esc_html( $v ) . '</p>';
						}
					}
			}
			if ( ! empty( $el['elements'] ) ) {
				$html .= self::to_html( $el['elements'], $post );
			}
		}
		return $html;
	}

	public static function plain_content( $data ) {
		$html = self::to_html( $data );
		$html = preg_replace( '#<img\b[^>]*>#i', '', $html );
		return trim( $html );
	}

	/* ---------- writing ---------- */

	private static function &find( &$elements, $id ) {
		$null = null;
		foreach ( $elements as &$el ) {
			if ( isset( $el['id'] ) && $el['id'] === $id ) {
				return $el;
			}
			if ( ! empty( $el['elements'] ) ) {
				$found = &self::find( $el['elements'], $id );
				if ( null !== $found ) {
					return $found;
				}
			}
		}
		return $null;
	}

	/** Set one slot. @return true|WP_Error */
	public static function set_slot( &$data, $path, $value ) {
		$parts = explode( '.', (string) $path );
		if ( count( $parts ) < 2 ) {
			return new WP_Error( 'egsm_bad_slot', 'Invalid slot path: ' . $path, array( 'status' => 400 ) );
		}
		$eid = array_shift( $parts );
		$el  = &self::find( $data, $eid );
		if ( null === $el ) {
			return new WP_Error( 'egsm_bad_slot', 'Element not found for slot: ' . $path, array( 'status' => 422 ) );
		}
		if ( ! isset( $el['settings'] ) || ! is_array( $el['settings'] ) ) {
			$el['settings'] = array();
		}
		$key = $parts[0];
		if ( 1 === count( $parts ) ) {
			if ( 'image' === $key || ( isset( $el['settings'][ $key ]['url'] ) && isset( $el['settings'][ $key ]['id'] ) ) ) {
				$aid = is_array( $value ) ? (int) ( isset( $value['id'] ) ? $value['id'] : 0 ) : (int) $value;
				if ( ! $aid || 'attachment' !== get_post_type( $aid ) ) {
					return new WP_Error( 'egsm_bad_slot', 'Image slots take an attachment id (upload the image first): ' . $path, array( 'status' => 422 ) );
				}
				$el['settings'][ $key ] = array(
					'url'    => wp_get_attachment_url( $aid ),
					'id'     => $aid,
					'size'   => '',
					'alt'    => (string) get_post_meta( $aid, '_wp_attachment_image_alt', true ),
					'source' => 'library',
				);
				return true;
			}
			if ( is_array( $el['settings'][ $key ] ?? null ) && array_key_exists( 'url', $el['settings'][ $key ] ) ) {
				$el['settings'][ $key ]['url'] = esc_url_raw( is_array( $value ) ? $value['url'] : $value );
				return true;
			}
			$el['settings'][ $key ] = (string) $value;
			return true;
		}
		if ( 3 === count( $parts ) ) {
			list( $rep, $i, $field ) = $parts;
			if ( ! isset( $el['settings'][ $rep ][ (int) $i ] ) || ! is_array( $el['settings'][ $rep ][ (int) $i ] ) ) {
				return new WP_Error( 'egsm_bad_slot', 'Repeater item not found: ' . $path, array( 'status' => 422 ) );
			}
			$el['settings'][ $rep ][ (int) $i ][ $field ] = (string) $value;
			return true;
		}
		return new WP_Error( 'egsm_bad_slot', 'Invalid slot path: ' . $path, array( 'status' => 400 ) );
	}

	public static function new_id() {
		return substr( bin2hex( random_bytes( 4 ) ), 0, 7 );
	}

	private static function reid( $el, &$map ) {
		$new               = self::new_id();
		$map[ $el['id'] ]  = $new;
		$el['id']          = $new;
		if ( ! empty( $el['elements'] ) ) {
			foreach ( $el['elements'] as $k => $child ) {
				$el['elements'][ $k ] = self::reid( $child, $map );
			}
		}
		return $el;
	}

	/** Insert $new after the element with $after_id (same parent). */
	private static function insert_after( &$elements, $after_id, $new ) {
		foreach ( $elements as $i => &$el ) {
			if ( isset( $el['id'] ) && $el['id'] === $after_id ) {
				array_splice( $elements, $i + 1, 0, array( $new ) );
				return true;
			}
			if ( ! empty( $el['elements'] ) && self::insert_after( $el['elements'], $after_id, $new ) ) {
				return true;
			}
		}
		return false;
	}

	private static function remove( &$elements, $id ) {
		foreach ( $elements as $i => &$el ) {
			if ( isset( $el['id'] ) && $el['id'] === $id ) {
				array_splice( $elements, $i, 1 );
				return true;
			}
			if ( ! empty( $el['elements'] ) && self::remove( $el['elements'], $id ) ) {
				return true;
			}
		}
		return false;
	}

	/** Last widget-bearing column/container, for appending content at the end of the page. */
	private static function last_widget_id( $elements ) {
		$last = null;
		foreach ( (array) $elements as $el ) {
			if ( isset( $el['elType'] ) && 'widget' === $el['elType'] ) {
				$last = $el['id'];
			}
			if ( ! empty( $el['elements'] ) ) {
				$l = self::last_widget_id( $el['elements'] );
				if ( $l ) {
					$last = $l;
				}
			}
		}
		return $last;
	}

	private static function widget( $type, $settings ) {
		return array(
			'id'         => self::new_id(),
			'elType'     => 'widget',
			'settings'   => $settings,
			'elements'   => array(),
			'widgetType' => $type,
		);
	}

	/**
	 * Structural operations.
	 * [ {op:remove,id} | {op:duplicate,id,fill:{field:value}} | {op:insert_html,after,html}
	 *   | {op:insert_heading,after,text,tag} | {op:append_html,html} | {op:set,path,value} ]
	 *
	 * @return array|WP_Error id map of duplicated/inserted elements
	 */
	public static function apply_ops( &$data, $ops ) {
		$created = array();
		foreach ( (array) $ops as $n => $op ) {
			$type = isset( $op['op'] ) ? $op['op'] : '';
			switch ( $type ) {
				case 'set':
					$r = self::set_slot( $data, $op['path'], $op['value'] );
					if ( is_wp_error( $r ) ) {
						return $r;
					}
					break;
				case 'remove':
					if ( ! self::remove( $data, (string) $op['id'] ) ) {
						return new WP_Error( 'egsm_bad_op', "ops[$n]: element not found: " . $op['id'], array( 'status' => 422 ) );
					}
					break;
				case 'duplicate':
					$src = &self::find( $data, (string) $op['id'] );
					if ( null === $src ) {
						return new WP_Error( 'egsm_bad_op', "ops[$n]: element not found: " . $op['id'], array( 'status' => 422 ) );
					}
					$map  = array();
					$copy = self::reid( $src, $map );
					unset( $src );
					$after = isset( $op['after'] ) ? (string) $op['after'] : (string) $op['id'];
					self::insert_after( $data, $after, $copy );
					$created[] = array(
						'op'     => 'duplicate',
						'source' => $op['id'],
						'new_id' => $copy['id'],
						'id_map' => $map,
					);
					if ( ! empty( $op['fill'] ) && is_array( $op['fill'] ) ) {
						foreach ( $op['fill'] as $path => $val ) {
							// Paths in fill may use the ORIGINAL ids; translate them.
							$parts = explode( '.', $path, 2 );
							if ( isset( $map[ $parts[0] ] ) ) {
								$path = $map[ $parts[0] ] . ( isset( $parts[1] ) ? '.' . $parts[1] : '' );
							}
							$r = self::set_slot( $data, $path, $val );
							if ( is_wp_error( $r ) ) {
								return $r;
							}
						}
					}
					break;
				case 'insert_html':
				case 'insert_heading':
				case 'append_html':
					if ( 'insert_heading' === $type ) {
						$tag = isset( $op['tag'] ) && preg_match( '/^h[1-6]$/', $op['tag'] ) ? $op['tag'] : 'h2';
						$w   = self::widget(
							'heading',
							array(
								'title'       => (string) $op['text'],
								'header_size' => $tag,
							)
						);
					} else {
						$w = self::widget( 'text-editor', array( 'editor' => (string) $op['html'] ) );
					}
					$after = 'append_html' === $type ? self::last_widget_id( $data ) : ( isset( $op['after'] ) ? (string) $op['after'] : '' );
					if ( ! $after || ! self::insert_after( $data, $after, $w ) ) {
						return new WP_Error( 'egsm_bad_op', "ops[$n]: anchor element not found.", array( 'status' => 422 ) );
					}
					$created[] = array(
						'op'     => $type,
						'new_id' => $w['id'],
					);
					break;
				default:
					return new WP_Error( 'egsm_bad_op', "ops[$n]: unknown op '$type'.", array( 'status' => 400 ) );
			}
		}
		return $created;
	}

	/** Meta keys copied when cloning an Elementor page as a template. */
	public static function clone_meta_keys() {
		return array( '_elementor_data', '_elementor_edit_mode', '_elementor_template_type', '_elementor_version', '_elementor_pro_version', '_elementor_page_settings', '_wp_page_template' );
	}
}
