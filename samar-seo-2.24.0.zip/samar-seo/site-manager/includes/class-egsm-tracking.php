<?php
/**
 * Ad conversion tracking tag. [tracking-v28]
 *
 * The agency platform puts its tracking tag (one async <script>) in every front-end page's <head>, so the site's
 * form fills and call clicks from ads are counted and ad click ids reach the booking page. Nothing is shown on
 * the page and no personal data is stored by the plugin.
 *
 *   GET    /egsm/v1/tracking/tag   { installed, src, pixel_id, at }
 *   PUT    /egsm/v1/tracking/tag   { src, pixel_id }   publish access; only the platform's own tag is accepted
 *   DELETE /egsm/v1/tracking/tag
 *
 * Every change is in the change log, so the site owner (Settings, Agency site access) can undo it or remove the
 * tag there at any time.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Tracking {

	const OPTION = 'egsm_tracking_tag';

	public static function init() {
		add_action( 'wp_head', array( __CLASS__, 'output' ), 1 );
		add_action( 'admin_post_egsm_tracking_remove', array( __CLASS__, 'handle_remove' ) );
	}

	/** @return array{src:string,pixel_id:string,at:string}|null */
	public static function current() {
		$t = get_option( self::OPTION, array() );
		return ( is_array( $t ) && ! empty( $t['src'] ) && self::valid_src( (string) $t['src'] ) ) ? $t : null;
	}

	/**
	 * Only the platform's tag: https://<host>/api/t/e.js?pid=<uuid>. The host may be the agency's own (white-label)
	 * platform domain, so it is not pinned; the path and the id are.
	 */
	public static function valid_src( $src ) {
		return (bool) preg_match( '#^https://[a-z0-9]([a-z0-9.-]*[a-z0-9])?(:\d{2,5})?/api/t/e\.js\?pid=[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$#i', (string) $src );
	}

	public static function output() {
		if ( is_admin() || is_feed() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}
		$t = self::current();
		if ( ! $t ) {
			return;
		}
		echo "\n<script async src=\"" . esc_url( $t['src'] ) . "\"></script>\n";
	}

	/* ---------- REST ---------- */

	public static function get() {
		$t = self::current();
		return array(
			'installed' => (bool) $t,
			'src'       => $t ? $t['src'] : null,
			'pixel_id'  => $t ? $t['pixel_id'] : null,
			'at'        => $t ? $t['at'] : null,
		);
	}

	public static function put( WP_REST_Request $req ) {
		$b   = $req->get_json_params();
		$b   = is_array( $b ) ? $b : $req->get_body_params();
		$src = isset( $b['src'] ) ? trim( (string) $b['src'] ) : '';
		$pid = isset( $b['pixel_id'] ) ? strtolower( trim( (string) $b['pixel_id'] ) ) : '';
		if ( ! self::valid_src( $src ) || ! preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/', $pid ) || false === stripos( $src, 'pid=' . $pid ) ) {
			return new WP_Error( 'egsm_bad_tag', 'That is not a tracking tag from the connected agency platform.', array( 'status' => 422 ) );
		}
		$cur = self::current();
		if ( $cur && $cur['src'] === $src ) {
			return array_merge( self::get(), array( 'changed' => false ) );
		}
		$before = EGSM_Log::option_state( array( self::OPTION ) );
		update_option( self::OPTION, array( 'src' => $src, 'pixel_id' => $pid, 'at' => gmdate( 'c' ) ), true );
		$cid = EGSM_Log::record( 'tracking_tag', 'option', 0, $before, EGSM_Log::option_state( array( self::OPTION ) ), $cur ? 'Updated the ad conversion tracking tag' : 'Added the ad conversion tracking tag' );
		EGSM_Cache::purge_all();
		return array_merge( self::get(), array( 'changed' => true, 'change_id' => $cid ) );
	}

	public static function delete() {
		if ( ! self::current() && false === get_option( self::OPTION, false ) ) {
			return array_merge( self::get(), array( 'changed' => false ) );
		}
		return array_merge( self::remove( 'Removed the ad conversion tracking tag' ), array( 'changed' => true ) );
	}

	private static function remove( $summary ) {
		$before = EGSM_Log::option_state( array( self::OPTION ) );
		delete_option( self::OPTION );
		$cid = EGSM_Log::record( 'tracking_tag', 'option', 0, $before, EGSM_Log::option_state( array( self::OPTION ) ), $summary );
		EGSM_Cache::purge_all();
		return array_merge( self::get(), array( 'change_id' => $cid ) );
	}

	/* ---------- site owner ---------- */

	public static function handle_remove() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'egsm_tracking_remove' ) ) {
			wp_die( 'Not allowed.' );
		}
		self::remove( 'Site owner removed the ad conversion tracking tag' );
		wp_safe_redirect( add_query_arg( array( 'egsm' => 'saved' ), admin_url( 'admin.php?page=' . EGSM_Admin::SLUG ) ) );
		exit;
	}
}
