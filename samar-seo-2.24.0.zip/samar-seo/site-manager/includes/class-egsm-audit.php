<?php
/**
 * SEO + AEO audit from inside WordPress (no crawling): site-level checks and
 * per-page issues with severity, plus an optional rendered check of one page.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Audit {

	const UTILITY_SLUGS = '/(contact|privacy|terms|cookie|thank|cart|checkout|account|login|register|disclaimer|accessibility|sitemap|404)/i';

	private static function issue( $code, $severity, $message, $fix = '', $extra = array() ) {
		return array_merge(
			array(
				'code'     => $code,
				'severity' => $severity,
				'message'  => $message,
				'fix'      => $fix,
			),
			$extra
		);
	}

	/* ---------- site ---------- */

	public static function site() {
		$issues = array();
		if ( '0' === (string) get_option( 'blog_public' ) ) {
			$issues[] = self::issue( 'search_engines_discouraged', 'critical', 'WordPress is set to "Discourage search engines" — the whole site is noindexed.', 'PUT /settings/site {"blog_public":1}' );
		}
		if ( '' === (string) get_option( 'permalink_structure' ) ) {
			$issues[] = self::issue( 'plain_permalinks', 'warning', 'Plain permalinks (?p=123) are in use.', 'Set a permalink structure in Settings → Permalinks (not automated: it changes every URL).' );
		}
		if ( 'https' !== wp_parse_url( home_url(), PHP_URL_SCHEME ) ) {
			$issues[] = self::issue( 'no_https', 'warning', 'Site URL is not HTTPS.', 'Install SSL and update the site URL.' );
		}
		$tag = get_bloginfo( 'description' );
		if ( '' === trim( $tag ) || false !== stripos( $tag, 'Just another WordPress site' ) ) {
			$issues[] = self::issue( 'default_tagline', 'notice', 'Site tagline is empty or the WordPress default.', 'PUT /settings/site {"blogdescription": "..."}' );
		}
		if ( ! get_option( 'site_icon' ) ) {
			$issues[] = self::issue( 'no_site_icon', 'notice', 'No site icon (favicon) set — shown in Google results.', 'Upload an icon and PUT /settings/site {"site_icon": attachment_id}' );
		}

		$bots = EGSM_AISEO::bots_status();
		foreach ( $bots['search_bots'] as $bot => $allowed ) {
			if ( ! $allowed ) {
				$issues[] = self::issue( 'search_bot_blocked', 'critical', "robots.txt blocks $bot from the site.", 'Fix robots.txt rules.' );
			}
		}
		$blocked_search = array();
		foreach ( $bots['ai_bots'] as $b ) {
			if ( ! $b['allowed'] && in_array( $b['purpose'], array( 'ai_search', 'user_fetch' ), true ) ) {
				$blocked_search[] = $b['bot'];
			}
		}
		if ( $blocked_search ) {
			$issues[] = self::issue( 'ai_search_bots_blocked', 'warning', 'AI answer engines are blocked: ' . implode( ', ', $blocked_search ) . '. The site cannot be cited in those AI answers.', 'PUT /aiseo/bots to allow them.' );
		}
		$llms = EGSM_AISEO::llms_settings();
		if ( ! $llms['enabled'] && ! file_exists( ABSPATH . 'llms.txt' ) ) {
			$issues[] = self::issue( 'no_llms_txt', 'notice', 'No llms.txt — a curated map of the site for AI assistants.', 'PUT /aiseo/llms {"enabled":true}' );
		}
		$schema_types = array();
		foreach ( EGSM_AISEO::get_site_schema() as $o ) {
			if ( isset( $o['@type'] ) ) {
				$schema_types = array_merge( $schema_types, (array) $o['@type'] );
			}
		}
		$seo_plugin = EGSM_SEO::active_plugin();
		if ( EGSM_SSEO::on() && EGSM_SSEO::has_business_profile() ) {
			$schema_types[] = 'LocalBusiness';
		}
		if ( ! array_intersect( $schema_types, array( 'Organization', 'LocalBusiness', 'HomeAndConstructionBusiness', 'ProfessionalService', 'MedicalBusiness', 'Plumber', 'HousePainter', 'GeneralContractor', 'Dentist', 'LegalService', 'Store', 'Restaurant' ) ) && in_array( $seo_plugin, array( 'native', 'sseo' ), true ) ) {
			$issues[] = self::issue( 'no_business_schema', 'warning', 'No Organization/LocalBusiness schema — AI engines use it to identify the business (name, address, phone, service area).', 'PUT /schema/site with LocalBusiness JSON-LD.' );
		} elseif ( ! $schema_types ) {
			$issues[] = self::issue( 'check_business_schema', 'notice', "No site-wide schema from this plugin; $seo_plugin may output Organization only. For local businesses add LocalBusiness with address, phone, hours and areaServed.", 'PUT /schema/site' );
		}
		if ( 'native' === $seo_plugin ) {
			$issues[] = self::issue( 'no_seo_plugin', 'notice', 'No SEO plugin active — this plugin outputs titles, descriptions, canonicals and robots itself for pages you set.', '' );
		}
		$sitemap = '';
		if ( 'yoast' === $seo_plugin || 'rankmath' === $seo_plugin ) {
			$sitemap = home_url( '/sitemap_index.xml' );
		} elseif ( 'aioseo' === $seo_plugin ) {
			$sitemap = home_url( '/sitemap.xml' );
		} elseif ( function_exists( 'wp_sitemaps_get_server' ) && wp_sitemaps_get_server()->sitemaps_enabled() ) {
			$sitemap = home_url( '/wp-sitemap.xml' );
		}
		$sitemap_source = '' !== $sitemap ? ( in_array( $seo_plugin, array( 'yoast', 'rankmath', 'aioseo' ), true ) ? $seo_plugin : 'wordpress' ) : '';
		if ( '' === $sitemap ) {
			// WordPress's own sitemap is off: look for one served by another plugin (checked once a day).
			$found = get_transient( 'egsm_ext_sitemap' );
			if ( false === $found ) {
				$found = '';
				foreach ( array( '/sitemap.xml', '/sitemap_index.xml' ) as $p ) {
					$r = wp_remote_get( home_url( $p ), array( 'timeout' => 6, 'redirection' => 2, 'limit_response_size' => 4096 ) );
					$b = is_wp_error( $r ) ? '' : (string) wp_remote_retrieve_body( $r );
					if ( ! is_wp_error( $r ) && 200 === (int) wp_remote_retrieve_response_code( $r ) && ( false !== stripos( $b, '<urlset' ) || false !== stripos( $b, '<sitemapindex' ) ) ) {
						$found = home_url( $p );
						break;
					}
				}
				set_transient( 'egsm_ext_sitemap', $found, DAY_IN_SECONDS );
			}
			if ( '' !== $found ) {
				$sitemap        = $found;
				$sitemap_source = 'another plugin';
				$issues[]       = self::issue( 'external_sitemap', 'notice', "The XML sitemap ($found) comes from another plugin, not WordPress. Pages set to noindex here are not removed from it automatically — exclude them in that plugin, or switch it off so WordPress's sitemap (which respects noindex) is used.", '' );
			} elseif ( in_array( $seo_plugin, array( 'native', 'sseo' ), true ) ) {
				$issues[] = self::issue( 'no_sitemap', 'warning', 'No XML sitemap detected — WordPress\'s built-in sitemap is switched off and no other sitemap was found.', '' );
			}
		}

		global $wpdb;
		$n404 = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . EGSM_DB::table( '404' ) . ' WHERE hits >= 3' );
		if ( $n404 ) {
			$issues[] = self::issue( 'recurring_404s', 'warning', "$n404 URLs keep returning 404.", 'GET /404s, then add redirects.' );
		}
		$updates = EGSM_Maintenance::updates( false );
		if ( $updates['plugins'] ) {
			$issues[] = self::issue( 'plugin_updates', 'notice', count( $updates['plugins'] ) . ' plugin update(s) available.', 'POST /updates/plugins (needs full access).' );
		}
		if ( version_compare( PHP_VERSION, '8.1', '<' ) ) {
			$issues[] = self::issue( 'old_php', 'notice', 'PHP ' . PHP_VERSION . ' is out of support; performance and security suffer.', 'Ask the host to upgrade PHP.' );
		}
		return array(
			'issues'     => $issues,
			'seo_plugin' => $seo_plugin,
			'sitemap'    => $sitemap,
			'sitemap_source' => $sitemap_source,
			'robots'     => array(
				'source'  => $bots['robots_source'],
				'ai_bots' => $bots['ai_bots'],
			),
		);
	}

	/* ---------- pages ---------- */

	public static function page( $post, $ctx = array() ) {
		$issues  = array();
		$seo     = EGSM_SEO::get( $post->ID );
		$html    = EGSM_Builders::get_html( $post );
		$text    = EGSM_Util::text_from_html( $html );
		$words   = EGSM_Util::word_count( $text );
		$heads   = EGSM_Util::headings( $html );
		$links   = EGSM_Util::links( $html );
		$images  = EGSM_Util::images( $html );
		$builder = EGSM_Builders::detect( $post );
		$utility = preg_match( self::UTILITY_SLUGS, $post->post_name );
		$is_home = (int) get_option( 'page_on_front' ) === $post->ID;

		// Title.
		$title = $seo['effective_title'];
		$tlen  = mb_strlen( $title );
		if ( '' === trim( $seo['title'] ) ) {
			$issues[] = self::issue( 'seo_title_default', 'notice', 'No custom SEO title (the template default is used: "' . $title . '").', 'seo.title' );
		}
		if ( $tlen > 60 ) {
			$issues[] = self::issue( 'title_too_long', 'warning', "SEO title is $tlen characters (aim for 50–60; Google truncates around 60).", 'seo.title' );
		} elseif ( $tlen < 25 ) {
			$issues[] = self::issue( 'title_too_short', 'warning', "SEO title is only $tlen characters.", 'seo.title' );
		}
		if ( isset( $ctx['dup_titles'][ mb_strtolower( $title ) ] ) && count( $ctx['dup_titles'][ mb_strtolower( $title ) ] ) > 1 ) {
			$issues[] = self::issue( 'duplicate_title', 'warning', 'Same SEO title as: ' . implode( ', ', array_diff( $ctx['dup_titles'][ mb_strtolower( $title ) ], array( $post->ID ) ) ), 'seo.title', array( 'duplicates' => array_values( array_diff( $ctx['dup_titles'][ mb_strtolower( $title ) ], array( $post->ID ) ) ) ) );
		}

		// Description.
		$desc = $seo['effective_description'];
		$dlen = mb_strlen( $desc );
		if ( '' === $desc ) {
			$issues[] = self::issue( 'meta_description_missing', $utility ? 'notice' : 'warning', 'No meta description — Google will pick random text.', 'seo.description' );
		} elseif ( $dlen > 160 ) {
			$issues[] = self::issue( 'meta_description_too_long', 'notice', "Meta description is $dlen characters (aim for 120–155).", 'seo.description' );
		} elseif ( $dlen < 70 ) {
			$issues[] = self::issue( 'meta_description_too_short', 'notice', "Meta description is only $dlen characters.", 'seo.description' );
		}
		if ( '' !== $desc && isset( $ctx['dup_desc'][ mb_strtolower( $desc ) ] ) && count( $ctx['dup_desc'][ mb_strtolower( $desc ) ] ) > 1 ) {
			$issues[] = self::issue( 'duplicate_description', 'warning', 'Same meta description as other pages.', 'seo.description', array( 'duplicates' => array_values( array_diff( $ctx['dup_desc'][ mb_strtolower( $desc ) ], array( $post->ID ) ) ) ) );
		}

		// Indexing.
		if ( $seo['noindex'] ) {
			$in_menu = isset( $ctx['menu_ids'][ $post->ID ] );
			$issues[] = self::issue( 'noindex', $is_home || $in_menu ? 'critical' : 'notice', 'Page is set to noindex' . ( $in_menu ? ' but it is in the site menu' : '' ) . '.', 'seo.noindex=false if it should rank' );
		}
		if ( '' !== $seo['canonical'] && EGSM_Redirects::site_path( $seo['canonical'] ) !== EGSM_Redirects::site_path( get_permalink( $post ) ) ) {
			$issues[] = self::issue( 'canonical_elsewhere', 'warning', 'Canonical points to another URL: ' . $seo['canonical'], 'seo.canonical' );
		}

		// Headings.
		$h1 = count(
			array_filter(
				$heads,
				function ( $h ) {
					return 1 === $h['level'];
				}
			)
		);
		$tpl = (string) get_page_template_slug( $post );
		if ( $h1 > 1 ) {
			$issues[] = self::issue( 'multiple_h1', 'warning', "The content has $h1 H1 headings (the theme usually adds the page title as H1 too).", 'Change extra H1s to H2.' );
		} elseif ( 0 === $h1 && in_array( $builder, array( 'elementor', 'divi', 'bricks', 'beaver', 'oxygen', 'breakdance' ), true ) ) {
			$issues[] = self::issue( 'no_h1_builder', 'warning', 'No H1 found in the ' . $builder . ' layout' . ( preg_match( '/canvas|full|blank/i', $tpl ) ? ' and the template hides the theme title' : '' ) . '. Verify with render=1.', 'Set the main heading tag to H1.' );
		}
		$prev = 0;
		foreach ( $heads as $h ) {
			if ( $prev && $h['level'] > $prev + 1 ) {
				$issues[] = self::issue( 'heading_skip', 'notice', "Heading level jumps from H$prev to H{$h['level']} (\"{$h['text']}\").", '' );
				break;
			}
			$prev = $h['level'];
		}
		if ( ! $utility && $words >= 300 && count( $heads ) < 2 ) {
			$issues[] = self::issue( 'few_subheadings', 'notice', 'Long content with almost no subheadings.', 'Add H2 sections.' );
		}

		// Content depth.
		if ( ! $utility ) {
			if ( $words < 150 ) {
				$issues[] = self::issue( 'thin_content', 'warning', "Only $words words of content.", 'Expand to cover the topic fully (service pages ~600+, articles ~1000+).' );
			} elseif ( $words < 400 ) {
				$issues[] = self::issue( 'light_content', 'notice', "Only $words words of content.", 'Expand the page.' );
			}
		}

		// Images.
		$no_alt = array_filter(
			$images,
			function ( $i ) {
				return null === $i['alt'] || '' === trim( $i['alt'] );
			}
		);
		if ( $no_alt ) {
			$issues[] = self::issue( 'images_missing_alt', 'warning', count( $no_alt ) . ' image(s) have no alt text.', 'PATCH /media/{id} {"alt": "..."} (updates content too).', array( 'images' => array_values( array_slice( $no_alt, 0, 20 ) ) ) );
		}
		if ( 'post' === $post->post_type && ! get_post_thumbnail_id( $post ) ) {
			$issues[] = self::issue( 'no_featured_image', 'notice', 'No featured image (used in social shares and Discover).', 'featured_media' );
		}

		// Links.
		$internal = array_filter(
			$links,
			function ( $l ) {
				return $l['internal'] && 0 !== strpos( $l['href'], '#' );
			}
		);
		if ( ! $utility && ! $internal ) {
			$issues[] = self::issue( 'no_internal_links', 'warning', 'No internal links from this page to other pages.', 'POST /links/insert' );
		}
		if ( isset( $ctx['graph']['nodes'][ $post->ID ] ) ) {
			$g = $ctx['graph']['nodes'][ $post->ID ];
			if ( 0 === $g['in_internal'] && ! $g['in_menu'] && ! $is_home ) {
				$issues[] = self::issue( 'orphan_page', 'warning', 'Orphan page: no other page or menu links here.', 'Link to it from related pages (POST /links/insert).' );
			}
		}
		if ( isset( $ctx['unresolved'][ $post->ID ] ) ) {
			$issues[] = self::issue( 'unresolved_internal_links', 'warning', count( $ctx['unresolved'][ $post->ID ] ) . ' internal link(s) do not match any page (possibly broken).', 'POST /links/replace', array( 'links' => array_slice( $ctx['unresolved'][ $post->ID ], 0, 20 ) ) );
		}

		// URL.
		$slug = urldecode( $post->post_name );
		if ( mb_strlen( $slug ) > 75 || substr_count( $slug, '-' ) > 7 ) {
			$issues[] = self::issue( 'long_slug', 'notice', 'Long URL slug: ' . $slug, 'Shorter slug (a 301 is added automatically).' );
		}

		// Keyword alignment.
		$kw = trim( (string) $seo['focus_keyword'] );
		$kw_checks = null;
		if ( '' === $kw ) {
			if ( ! $utility ) {
				$issues[] = self::issue( 'no_focus_keyword', 'notice', 'No target keyword mapped to this page.', 'PUT /keywords or seo.focus_keyword' );
			}
		} else {
			$first100  = EGSM_Util::first_words( $text, 100 );
			$h_text    = implode( ' ', wp_list_pluck( $heads, 'text' ) );
			$occ       = EGSM_Util::count_phrase( $text, $kw );
			$density   = $words ? round( 100 * $occ * max( 1, count( preg_split( '/\s+/', $kw ) ) ) / $words, 2 ) : 0;
			$kw_checks = array(
				'keyword'        => $kw,
				'in_title'       => false !== mb_stripos( $title, $kw ),
				'in_description' => false !== mb_stripos( $desc, $kw ),
				'in_headings'    => false !== mb_stripos( $h_text . ' ' . $post->post_title, $kw ),
				'in_first_100'   => false !== mb_stripos( $first100, $kw ),
				'in_slug'        => false !== strpos( $slug, sanitize_title( $kw ) ),
				'occurrences'    => $occ,
				'density_pct'    => $density,
			);
			foreach ( array( 'in_title' => 'SEO title', 'in_description' => 'meta description', 'in_headings' => 'headings', 'in_first_100' => 'first 100 words' ) as $k => $label ) {
				if ( ! $kw_checks[ $k ] ) {
					$issues[] = self::issue( 'keyword_missing_' . str_replace( 'in_', '', $k ), 'in_title' === $k ? 'warning' : 'notice', "Target keyword \"$kw\" is not in the $label.", '' );
				}
			}
			if ( $density > 3 ) {
				$issues[] = self::issue( 'keyword_stuffing', 'warning', "Keyword density is {$density}% — reads as stuffing.", 'Use variations and synonyms.' );
			}
			if ( isset( $ctx['cannibal'][ mb_strtolower( $kw ) ] ) && count( $ctx['cannibal'][ mb_strtolower( $kw ) ] ) > 1 ) {
				$issues[] = self::issue( 'keyword_cannibalization', 'warning', 'Other pages target the same keyword: ' . implode( ', ', array_diff( $ctx['cannibal'][ mb_strtolower( $kw ) ], array( $post->ID ) ) ), 'Give each page a distinct primary keyword or merge them.' );
			}
		}

		// Freshness.
		$days = (int) floor( ( time() - strtotime( $post->post_modified_gmt . ' UTC' ) ) / DAY_IN_SECONDS );
		if ( 'post' === $post->post_type && $days > 540 ) {
			$issues[] = self::issue( 'stale_content', 'notice', "Not updated in $days days.", 'Refresh facts, dates and examples.' );
		}

		// AEO.
		$aeo = EGSM_AISEO::analyze( $post );
		if ( ! $utility && $aeo['score'] < 50 ) {
			$issues[] = self::issue( 'low_answer_readiness', 'warning', 'Low AI-answer readiness (' . $aeo['score'] . '/100).', implode( ' ', array_slice( $aeo['tips'], 0, 3 ) ) );
		}

		$scored = EGSM_Score::analyze( $post );
		if ( '' === get_post_meta( $post->ID, '_egsm_score', true ) ) {
			EGSM_Score::save( $post->ID, $scored );
		}
		$score  = $scored['score'];
		return array(
			'id'         => $post->ID,
			'type'       => $post->post_type,
			'title'      => $post->post_title,
			'url'        => get_permalink( $post ),
			'builder'    => $builder,
			'word_count' => $words,
			'seo_score'  => $score,
			'seo_grade'  => $scored['grade'],
			'aeo_score'  => $aeo['score'],
			'keyword'    => $kw_checks,
			'issues'     => $issues,
			'aeo_tips'   => $aeo['tips'],
		);
	}

	/** Shared lookups so duplicate/orphan/cannibalization checks see the whole site. */
	public static function context( $types ) {
		$ids = get_posts(
			array(
				'post_type'   => $types,
				'post_status' => 'publish',
				'numberposts' => 3000,
				'fields'      => 'ids',
			)
		);
		$dup_t = array();
		$dup_d = array();
		$kw    = array();
		foreach ( $ids as $id ) {
			$s                                               = EGSM_SEO::get( $id );
			$dup_t[ mb_strtolower( $s['effective_title'] ) ][] = $id;
			if ( '' !== $s['effective_description'] ) {
				$dup_d[ mb_strtolower( $s['effective_description'] ) ][] = $id;
			}
			if ( '' !== $s['focus_keyword'] ) {
				$kw[ mb_strtolower( trim( $s['focus_keyword'] ) ) ][] = $id;
			}
		}
		$graph      = EGSM_Structure::link_graph();
		$unresolved = array();
		foreach ( $graph['unresolved_links'] as $l ) {
			$unresolved[ $l['post_id'] ][] = $l;
		}
		return array(
			'ids'        => $ids,
			'dup_titles' => $dup_t,
			'dup_desc'   => $dup_d,
			'cannibal'   => $kw,
			'graph'      => $graph,
			'unresolved' => $unresolved,
			'menu_ids'   => EGSM_Structure::menu_object_ids(),
		);
	}

	public static function run( WP_REST_Request $req ) {
		$types  = $req->get_param( 'type' ) ? array_intersect( array_map( 'trim', explode( ',', $req->get_param( 'type' ) ) ), EGSM_Content::post_types() ) : array( 'page', 'post' );
		$types  = $types ? array_values( $types ) : array( 'page', 'post' );
		$limit  = max( 1, min( 300, (int) ( $req->get_param( 'limit' ) ? $req->get_param( 'limit' ) : 100 ) ) );
		$offset = max( 0, (int) $req->get_param( 'offset' ) );
		$ctx    = self::context( $types );
		$slice  = array_slice( $ctx['ids'], $offset, $limit );
		$pages  = array();
		$counts = array(
			'critical' => 0,
			'warning'  => 0,
			'notice'   => 0,
		);
		$by_code = array();
		foreach ( $slice as $id ) {
			$r = self::page( get_post( $id ), $ctx );
			foreach ( $r['issues'] as $i ) {
				$counts[ $i['severity'] ]++;
				$by_code[ $i['code'] ] = isset( $by_code[ $i['code'] ] ) ? $by_code[ $i['code'] ] + 1 : 1;
			}
			if ( EGSM_Util::bool( $req->get_param( 'issues_only' ) ) && ! $r['issues'] ) {
				continue;
			}
			$pages[] = $r;
		}
		arsort( $by_code );
		usort(
			$pages,
			function ( $a, $b ) {
				return $a['seo_score'] - $b['seo_score'];
			}
		);
		$site = null;
		if ( 0 === $offset ) {
			$site = self::site();
			foreach ( $site['issues'] as $i ) {
				$counts[ $i['severity'] ]++;
			}
		}
		$avg = $pages ? (int) round( array_sum( wp_list_pluck( $pages, 'seo_score' ) ) / count( $pages ) ) : null;
		$aeo = $pages ? (int) round( array_sum( wp_list_pluck( $pages, 'aeo_score' ) ) / count( $pages ) ) : null;
		return array(
			'site'            => $site,
			'summary'         => array(
				'pages_total'      => count( $ctx['ids'] ),
				'pages_in_batch'   => count( $slice ),
				'next_offset'      => $offset + $limit < count( $ctx['ids'] ) ? $offset + $limit : null,
				'avg_seo_score'    => $avg,
				'avg_aeo_score'    => $aeo,
				'issue_counts'     => $counts,
				'top_issue_codes'  => array_slice( $by_code, 0, 15, true ),
				'orphans'          => count( $ctx['graph']['orphans'] ),
				'cannibalized_keywords' => count(
					array_filter(
						$ctx['cannibal'],
						function ( $v ) {
							return count( $v ) > 1;
						}
					)
				),
			),
			'pages'           => $pages,
		);
	}

	/**
	 * Fetch the live page and read what search engines actually see.
	 * Loopback requests can be blocked on some hosts; failures are reported, not fatal.
	 */
	public static function rendered( $post ) {
		if ( 'publish' !== $post->post_status ) {
			return array( 'error' => 'Only published pages can be fetched.' );
		}
		$url = get_permalink( $post );
		$res = wp_remote_get(
			$url,
			array(
				'timeout'     => 20,
				'redirection' => 3,
				'sslverify'   => apply_filters( 'https_local_ssl_verify', false ),
				'user-agent'  => 'Mozilla/5.0 (compatible; egsm-audit/1.0; +' . home_url() . ')',
				'headers'     => array( 'Cache-Control' => 'no-cache' ),
			)
		);
		if ( is_wp_error( $res ) ) {
			return array( 'error' => 'Could not fetch the page from the server itself: ' . $res->get_error_message() );
		}
		$code = wp_remote_retrieve_response_code( $res );
		$html = wp_remote_retrieve_body( $res );
		$head = preg_match( '#<head\b[^>]*>(.*?)</head>#is', $html, $m ) ? $m[1] : $html;
		$out  = array(
			'status'          => $code,
			'bytes'           => strlen( $html ),
			'x_robots_tag'    => wp_remote_retrieve_header( $res, 'x-robots-tag' ),
			'title'           => preg_match( '#<title[^>]*>(.*?)</title>#is', $head, $t ) ? trim( html_entity_decode( wp_strip_all_tags( $t[1] ), ENT_QUOTES, 'UTF-8' ) ) : null,
			'meta_description' => null,
			'canonical'       => null,
			'robots'          => null,
			'h1'              => array(),
			'schema_types'    => array(),
			'og_image'        => null,
			'images_without_alt' => 0,
		);
		if ( preg_match_all( '#<meta\b[^>]*>#i', $head, $metas ) ) {
			foreach ( $metas[0] as $tag ) {
				$name = strtolower( (string) EGSM_Util::attr( $tag, 'name' ) );
				$prop = strtolower( (string) EGSM_Util::attr( $tag, 'property' ) );
				if ( 'description' === $name ) {
					$out['meta_description'] = EGSM_Util::attr( $tag, 'content' );
				} elseif ( 'robots' === $name ) {
					$out['robots'] = EGSM_Util::attr( $tag, 'content' );
				} elseif ( 'og:image' === $prop ) {
					$out['og_image'] = EGSM_Util::attr( $tag, 'content' );
				}
			}
		}
		if ( preg_match( '#<link\b[^>]*rel=["\']canonical["\'][^>]*>#i', $head, $c ) ) {
			$out['canonical'] = EGSM_Util::attr( $c[0], 'href' );
		}
		foreach ( EGSM_Util::headings( $html ) as $h ) {
			if ( 1 === $h['level'] ) {
				$out['h1'][] = $h['text'];
			}
		}
		if ( preg_match_all( '#<script[^>]+application/ld\+json[^>]*>(.*?)</script>#is', $html, $js ) ) {
			foreach ( $js[1] as $blob ) {
				$d = json_decode( trim( $blob ), true );
				if ( ! is_array( $d ) ) {
					continue;
				}
				$nodes = isset( $d['@graph'] ) ? $d['@graph'] : ( isset( $d['@type'] ) ? array( $d ) : $d );
				foreach ( (array) $nodes as $n ) {
					if ( is_array( $n ) && isset( $n['@type'] ) ) {
						$out['schema_types'] = array_merge( $out['schema_types'], (array) $n['@type'] );
					}
				}
			}
			$out['schema_types'] = array_values( array_unique( $out['schema_types'] ) );
		}
		foreach ( EGSM_Util::images( preg_replace( '#<head\b.*?</head>#is', '', $html ) ) as $i ) {
			if ( null === $i['alt'] || '' === trim( $i['alt'] ) ) {
				$out['images_without_alt']++;
			}
		}
		$issues = array();
		if ( 200 !== (int) $code ) {
			$issues[] = "HTTP $code";
		}
		if ( 1 !== count( $out['h1'] ) ) {
			$issues[] = count( $out['h1'] ) . ' H1 tags on the rendered page';
		}
		if ( ! $out['meta_description'] ) {
			$issues[] = 'No meta description in the rendered page';
		}
		if ( $out['robots'] && false !== stripos( $out['robots'], 'noindex' ) ) {
			$issues[] = 'Rendered page has meta robots noindex';
		}
		if ( $out['x_robots_tag'] && false !== stripos( (string) $out['x_robots_tag'], 'noindex' ) ) {
			$issues[] = 'X-Robots-Tag header says noindex';
		}
		$out['issues'] = $issues;
		return $out;
	}
}
