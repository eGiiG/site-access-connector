<?php
/**
 * REST API: egsm/v1/*
 *
 * Every route declares the minimum access level it needs (read < draft < publish < full).
 * The site owner sets the connection's level in the plugin settings.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_REST {

	/** route => [methods, level, callback, description] */
	private static function routes() {
		$id = '(?P<id>\d+)';
		return array(
			array( '/site', 'GET', 'read', array( 'EGSM_Maintenance', 'site_info' ), 'Site overview: WordPress/PHP/theme, builders, SEO plugin, cache plugins, content counts, access level.', false ),
			array( '/health', 'GET', 'read', array( __CLASS__, 'health' ), 'Connection check.', false ),
			array( '/connect/confirm', 'POST', 'read', array( 'EGSM_SSEO', 'confirm_key' ), 'Finish a connection made with a connection key: the platform sends the reporting token, agency branding and lock password (signed requests only).', true ),
			array( '/capabilities', 'GET', 'read', array( __CLASS__, 'capabilities' ), 'Machine-readable list of every endpoint, its access level and purpose.', false ),

			/* [EGSM-ACTIONS] plugin actions registered with the WordPress Abilities API */
			array( '/actions', 'GET', 'read', array( 'EGSM_Abilities', 'list_actions' ), 'Actions other plugins offer (e.g. events, forms): name, purpose, input schema, access level (category, search, include_core).', false ),
			array( '/actions/run', 'POST', 'read', array( 'EGSM_Abilities', 'run_action' ), 'Run a plugin action: {name, input}. Read-only actions need read, others publish, destructive ones full.', true ),

			array( '/settings/site', 'GET', 'read', array( 'EGSM_Maintenance', 'get_site_settings' ), 'Site title, tagline, search-engine visibility, site icon.', false ),
			array( '/settings/site', 'PUT', 'publish', array( __CLASS__, 'put_site_settings' ), 'Update blogname, blogdescription, blog_public, site_icon.', true ),

			array( '/content', 'GET', 'read', array( 'EGSM_Content', 'list_items' ), 'List pages/posts (type, status, search, parent, category, page, per_page, light).', false ),
			array( '/content', 'POST', 'draft', array( 'EGSM_Content', 'create' ), 'Create a page/post (content_html | content_blocks | clone_from + fill), with SEO, schema, FAQ, image, terms. Drafts need draft access; publishing needs publish.', true ),
			array( '/content/by-url', 'GET', 'read', array( __CLASS__, 'get_content_by_url' ), 'Resolve a URL or path on this site to its page and return the full page (url=...).', false ),
			array( '/content/' . $id, 'GET', 'read', array( __CLASS__, 'get_content' ), 'Full page: builder, editable slots, headings, links, images, text, SEO, schema, keywords. render=1 also fetches the live page.', false ),
			array( '/content/' . $id, 'PATCH,PUT', 'draft', array( 'EGSM_Content', 'update' ), 'Edit a page: fields, content_html, replace_section, append_html, replace_text, elementor_slots, elementor_ops, seo, schema, faq, keywords, featured_media. Auto-301 on URL change.', true ),
			array( '/content/' . $id, 'DELETE', 'publish', array( 'EGSM_Content', 'trash' ), 'Move to trash (optional redirect_to).', true ),

			array( '/seo/' . $id, 'GET', 'read', array( __CLASS__, 'get_seo' ), 'SEO fields for a page (via the active SEO plugin).', false ),
			array( '/seo/' . $id, 'PUT,PATCH', 'draft', array( __CLASS__, 'put_seo' ), 'Set title, description, focus_keyword, canonical, noindex, nofollow, og_*.', true ),
			array( '/seo/bulk', 'POST', 'draft', array( __CLASS__, 'bulk_seo' ), 'Set SEO fields on many pages: {items:[{id, seo:{...}}]}.', true ),

			array( '/score/(?P<id>\d+)', 'GET', 'read', array( __CLASS__, 'get_score' ), 'SEO score (0-100) with every check for a page/post; pass keyword/seo_title/description to preview changes.', false ),
			array( '/score/recalc', 'POST', 'draft', array( __CLASS__, 'post_score_recalc' ), 'Recalculate stored SEO scores: {ids:[...]} or {all:true} (runs in batches; call again while remaining > 0).', true ),
			array( '/seo/settings', 'GET', 'read', array( 'EGSM_SEO_Settings', 'for_api' ), 'Search settings: archive noindex, homepage title, sitemap exclusions, link rules, IndexNow.', false ),
			array( '/seo/settings', 'PUT', 'publish', array( __CLASS__, 'put_seo_settings' ), 'Update search settings (noindex_tax, noindex_author, noindex_date, home_title, home_description, sitemap_exclude_types, sitemap_exclude_tax, link_external_rel, link_external_newtab, link_rules, indexnow).', true ),
			array( '/audit', 'GET', 'read', array( 'EGSM_Audit', 'run' ), 'Site + page SEO/AEO audit (type, limit, offset, issues_only).', false ),
			array( '/audit/' . $id, 'GET', 'read', array( __CLASS__, 'audit_page' ), 'Audit one page; render=1 checks the live HTML.', false ),

			array( '/aiseo/bots', 'GET', 'read', array( 'EGSM_AISEO', 'bots_status' ), 'robots.txt and which AI crawlers / search bots can crawl the site.', false ),
			array( '/aiseo/bots', 'PUT', 'publish', array( __CLASS__, 'put_bots' ), 'Allow/block AI crawlers: {"GPTBot":"block","OAI-SearchBot":"allow","CCBot":"default"}.', true ),
			array( '/aiseo/robots', 'PUT', 'publish', array( __CLASS__, 'put_robots' ), 'Custom robots.txt lines appended to WordPress\'s virtual robots.txt: {text}.', true ),
			array( '/aiseo/llms', 'GET', 'read', array( __CLASS__, 'get_llms' ), 'llms.txt settings and preview.', false ),
			array( '/aiseo/llms', 'PUT', 'publish', array( __CLASS__, 'put_llms' ), 'Configure llms.txt: enabled, full, intro, include_posts, sections, custom_text.', true ),
			array( '/aiseo/analyze/' . $id, 'GET', 'read', array( __CLASS__, 'analyze' ), 'AI-answer readiness score, checks and concrete tips for a page.', false ),

			array( '/schema/site', 'GET', 'read', array( 'EGSM_AISEO', 'get_site_schema' ), 'Site-wide JSON-LD (Organization / LocalBusiness).', false ),
			array( '/schema/site', 'PUT', 'publish', array( __CLASS__, 'put_site_schema' ), 'Replace site-wide JSON-LD: {schema:[...]}.', true ),
			array( '/schema/' . $id, 'GET', 'read', array( __CLASS__, 'get_post_schema' ), 'Page JSON-LD added by this plugin.', false ),
			array( '/schema/' . $id, 'PUT', 'draft', array( __CLASS__, 'put_post_schema' ), 'Replace page JSON-LD: {schema:[...]} ([] clears).', true ),
			array( '/faq/' . $id, 'POST', 'draft', array( __CLASS__, 'post_faq' ), 'Add a visible FAQ section + FAQPage schema: {items:[{question,answer}], title?, content?, schema?}.', true ),

			array( '/keywords', 'GET', 'read', array( 'EGSM_AISEO', 'keyword_report' ), 'Keyword map per page, unmapped pages, cannibalization.', false ),
			array( '/keywords', 'PUT', 'draft', array( __CLASS__, 'put_keywords' ), 'Map keywords from GSC/SEMrush/Ubersuggest: {items:[{post_id|url, primary, secondary[], volume, difficulty, position, intent, source}], sync_focus?}.', true ),

			array( '/structure', 'GET', 'read', array( 'EGSM_Structure', 'tree' ), 'Page tree (silos), categories, menus, orphans, link counts.', false ),
			array( '/structure/move', 'POST', 'publish', array( __CLASS__, 'post_move' ), 'Re-parent / re-slug / re-order pages with automatic 301s: {moves:[{id,parent?,slug?,menu_order?}]}.', true ),
			array( '/links/graph', 'GET', 'read', array( __CLASS__, 'get_graph' ), 'Internal link graph: in/out counts, orphans, unresolved links (refresh=1).', false ),
			array( '/links/insert', 'POST', 'publish', array( __CLASS__, 'post_link_insert' ), 'Link anchor text in a page to another page: {post_id, anchor, target_id|url, max?}.', true ),
			array( '/links/replace', 'POST', 'publish', array( __CLASS__, 'post_link_replace' ), 'Replace a link URL in one page or site-wide: {old_url, new_url|new_target_id, post_id?}.', true ),
			array( '/links/rel', 'POST', 'publish', array( __CLASS__, 'post_link_rel' ), 'Set rel on existing links to a URL, one page or site-wide: {url, rel: "nofollow"|"sponsored"|"ugc"|"sponsored nofollow"|"follow"|"", post_id?}.', true ),

			array( '/menus', 'GET', 'read', array( 'EGSM_Structure', 'menus' ), 'Menus and items.', false ),
			array( '/menus/items', 'POST', 'publish', array( __CLASS__, 'post_menu_item' ), 'Add a menu item: {menu_id|location, object_id|url, title?, parent_item?, position?}.', true ),
			array( '/menus/items/' . $id, 'PATCH', 'publish', array( __CLASS__, 'patch_menu_item' ), 'Edit a menu item: {title?, url?, parent_item?, position?}.', true ),
			array( '/menus/items/' . $id, 'DELETE', 'publish', array( __CLASS__, 'delete_menu_item' ), 'Remove a menu item.', true ),

			array( '/redirects', 'GET', 'read', array( __CLASS__, 'get_redirects' ), 'Redirect rules.', false ),
			array( '/redirects', 'POST', 'publish', array( __CLASS__, 'post_redirect' ), 'Add a redirect: {source, target (url | path | post id), code: 301|302|307|308|410}.', true ),
			array( '/redirects/' . $id, 'DELETE', 'publish', array( __CLASS__, 'delete_redirect' ), 'Delete a redirect.', true ),
			array( '/404s', 'GET', 'read', array( __CLASS__, 'get_404s' ), 'Most-hit 404 URLs (limit).', false ),
			array( '/404s', 'DELETE', 'publish', array( 'EGSM_Redirects', 'clear_404' ), 'Clear the 404 log.', true ),

			array( '/media', 'GET', 'read', array( __CLASS__, 'get_media' ), 'Images (missing_alt=1, search, page, per_page).', false ),
			array( '/media', 'POST', 'draft', array( __CLASS__, 'post_media' ), 'Upload an image: {url|base64, filename, alt, title, caption, post_id?, set_featured?, webp?, max_width?}.', true ),
			array( '/media/' . $id, 'PATCH', 'publish', array( __CLASS__, 'patch_media' ), 'Update alt/title/caption; propagate (default) fixes alt on images already in content.', true ),
			array( '/media/bulk-alt', 'POST', 'publish', array( __CLASS__, 'bulk_alt' ), 'Set alt text on many images: {items:[{id, alt}]}.', true ),

			array( '/terms', 'GET', 'read', array( __CLASS__, 'get_terms' ), 'Categories/tags (taxonomy=category).', false ),
			array( '/terms', 'POST', 'publish', array( __CLASS__, 'post_term' ), 'Create a term: {taxonomy, name, slug?, parent?, description?}.', true ),
			array( '/terms/' . $id, 'PATCH', 'publish', array( __CLASS__, 'patch_term' ), 'Edit a term (name, slug, description, parent) with automatic 301.', true ),

			array( '/authors', 'GET', 'read', array( 'EGSM_AISEO', 'authors' ), 'Authors with bios (E-E-A-T).', false ),
			array( '/authors/' . $id, 'PATCH', 'publish', array( __CLASS__, 'patch_author' ), 'Update author bio, url, display_name.', true ),

			array( '/changes', 'GET', 'read', array( __CLASS__, 'get_changes' ), 'Change log (object_type, object_id, limit, offset).', false ),
			array( '/changes/' . $id, 'GET', 'read', array( __CLASS__, 'get_change' ), 'One change with before/after state.', false ),
			array( '/changes/' . $id . '/revert', 'POST', 'publish', array( __CLASS__, 'revert' ), 'Undo a change (force=true to overwrite newer edits).', true ),

			array( '/updates', 'GET', 'read', array( __CLASS__, 'get_updates' ), 'Available core/plugin/theme updates (refresh=1).', false ),
			array( '/updates/plugins', 'POST', 'full', array( __CLASS__, 'post_update_plugins' ), 'Update plugins: {plugins:["file.php"] | "all"}.', true ),
			array( '/updates/themes', 'POST', 'full', array( __CLASS__, 'post_update_themes' ), 'Update themes: {themes:["slug"] | "all"}.', true ),
			array( '/cache/purge', 'POST', 'publish', array( __CLASS__, 'purge' ), 'Purge page caches (post_id? or everything).', true ),

			array( '/branding', 'PUT', 'read', array( __CLASS__, 'put_branding' ), 'Agency branding shown in the site\'s admin (signed requests only).', true ),

			array( '/tracking/tag', 'GET', 'read', array( 'EGSM_Tracking', 'get' ), 'The ad conversion tracking tag in the site <head>, if any.', false ),
			array( '/tracking/tag', 'PUT', 'publish', array( 'EGSM_Tracking', 'put' ), 'Put the platform\'s ad conversion tracking tag in every page <head>: {src, pixel_id}. Only https://<platform>/api/t/e.js?pid=<uuid> is accepted.', true ),
			array( '/tracking/tag', 'DELETE', 'publish', array( 'EGSM_Tracking', 'delete' ), 'Remove the ad conversion tracking tag.', true ),
		);
	}

	public static function register_routes() {
		foreach ( self::routes() as $r ) {
			list( $path, $methods, $level, $cb ) = $r;
			register_rest_route(
				EGSM_NS,
				$path,
				array(
					'methods'             => $methods,
					'callback'            => function ( WP_REST_Request $req ) use ( $cb ) {
						$GLOBALS['egsm_warnings']               = array();
						$GLOBALS['egsm_last_elementor_created'] = null;
						$GLOBALS['egsm_last_replace']           = null;
						try {
							$res = call_user_func( $cb, $req );
						} catch ( \Throwable $e ) {
							return new WP_Error( 'egsm_exception', $e->getMessage(), array( 'status' => 500 ) );
						}
						if ( is_wp_error( $res ) ) {
							return $res;
						}
						$res = rest_ensure_response( $res );
						if ( ! empty( $GLOBALS['egsm_warnings'] ) ) {
							$data = $res->get_data();
							if ( is_array( $data ) ) {
								$data['warnings'] = $GLOBALS['egsm_warnings'];
								$res->set_data( $data );
							}
						}
						$res->header( 'Cache-Control', 'no-store' );
						return $res;
					},
					'permission_callback' => function () use ( $level ) {
						return EGSM_Auth::check( $level );
					},
				)
			);
		}
	}

	private static function body( WP_REST_Request $req ) {
		$b = $req->get_json_params();
		return is_array( $b ) ? $b : $req->get_body_params();
	}

	/** Route a partial edit through the main content updater so levels, logging and rollback apply. */
	private static function content_patch( $id, $payload ) {
		$r = new WP_REST_Request( 'PATCH', '/' . EGSM_NS . '/content/' . (int) $id );
		$r->set_url_params( array( 'id' => (int) $id ) );
		$r->set_header( 'content-type', 'application/json' );
		$r->set_body( wp_json_encode( $payload ) );
		return EGSM_Content::update( $r );
	}

	/* ---------- handlers ---------- */

	public static function health() {
		return array(
			'ok'             => true,
			'plugin_version' => EGSM_VERSION,
			'access_level'   => EGSM_Settings::level(),
			'auth'           => EGSM_Auth::via_signature() ? 'signature' : 'user',
			'site'           => home_url( '/' ),
			'time'           => time(),
		);
	}

	public static function capabilities() {
		$out = array();
		foreach ( self::routes() as $r ) {
			$out[] = array(
				'path'        => '/' . EGSM_NS . preg_replace( '/\(\?P<(\w+)>[^)]+\)/', '{$1}', $r[0] ),
				'methods'     => $r[1],
				'level'       => $r[2],
				'writes'      => $r[5],
				'description' => $r[4],
			);
		}
		return array(
			'plugin_version' => EGSM_VERSION,
			'access_level'   => EGSM_Settings::level(),
			'endpoints'      => $out,
		);
	}

	public static function put_site_settings( $req ) {
		return EGSM_Maintenance::set_site_settings( self::body( $req ) );
	}

	public static function get_content( $req ) {
		$post = EGSM_Content::get_post_or_error( $req['id'] );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$inc = $req->get_param( 'include' ) ? array_map( 'trim', explode( ',', $req->get_param( 'include' ) ) ) : array();
		$out = EGSM_Content::detail( $post, $inc );
		if ( EGSM_Util::bool( $req->get_param( 'render' ) ) ) {
			$out['rendered'] = EGSM_Audit::rendered( $post );
		}
		return $out;
	}

	public static function get_content_by_url( $req ) {
		$url = (string) $req->get_param( 'url' );
		$id  = $url ? url_to_postid( EGSM_Util::absolute_url( $url ) ) : 0;
		if ( ! $id && $url && EGSM_Redirects::site_path( $url ) === '/' && 'page' === get_option( 'show_on_front' ) ) {
			$id = (int) get_option( 'page_on_front' );
		}
		if ( ! $id ) {
			return new WP_Error( 'egsm_not_found', 'No page or post found at that URL.', array( 'status' => 404 ) );
		}
		$req->set_param( 'id', $id );
		$req->set_url_params( array( 'id' => $id ) );
		return self::get_content( $req );
	}

	public static function get_score( $req ) {
		$post = EGSM_Content::get_post_or_error( $req['id'] );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$o = array();
		foreach ( array( 'keyword', 'seo_title', 'description' ) as $k ) {
			if ( null !== $req->get_param( $k ) ) {
				$o[ $k ] = sanitize_text_field( (string) $req->get_param( $k ) );
			}
		}
		$r = EGSM_Score::analyze( $post, $o );
		if ( ! $o ) {
			EGSM_Score::store( $post->ID );
		}
		return array_merge( array( 'id' => $post->ID, 'url' => get_permalink( $post ) ), $r );
	}

	public static function post_score_recalc( $req ) {
		$b = self::body( $req );
		if ( ! empty( $b['all'] ) ) {
			if ( ! empty( $b['restart'] ) || -1 === (int) get_option( 'egsm_score_cursor', 0 ) ) {
				update_option( 'egsm_score_cursor', 0, false );
			}
			return EGSM_Score::backfill_batch( 50 );
		}
		$out = array();
		foreach ( array_slice( (array) ( isset( $b['ids'] ) ? $b['ids'] : array() ), 0, 100 ) as $id ) {
			$post = get_post( (int) $id );
			if ( $post ) {
				EGSM_Score::sync_flat_meta( $post->ID );
				$r     = EGSM_Score::store( $post->ID );
				$out[] = array( 'id' => $post->ID, 'score' => $r ? $r['score'] : null );
			}
		}
		return array( 'scored' => $out );
	}

	public static function put_seo_settings( $req ) {
		return EGSM_SEO_Settings::update( self::body( $req ) );
	}

	public static function get_seo( $req ) {
		$post = EGSM_Content::get_post_or_error( $req['id'] );
		return is_wp_error( $post ) ? $post : EGSM_SEO::get( $post->ID );
	}

	public static function put_seo( $req ) {
		$b   = self::body( $req );
		$seo = isset( $b['seo'] ) ? $b['seo'] : $b;
		$r   = self::content_patch( $req['id'], array( 'seo' => $seo, 'change_note' => 'Updated SEO fields' ) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return array(
			'id'        => (int) $req['id'],
			'seo'       => EGSM_SEO::get( (int) $req['id'] ),
			'change_id' => $r['change_id'],
		);
	}

	public static function bulk_seo( $req ) {
		$b     = self::body( $req );
		$out   = array();
		$items = isset( $b['items'] ) ? (array) $b['items'] : array();
		if ( count( $items ) > 200 ) {
			return new WP_Error( 'egsm_bad_request', 'Max 200 items per call.', array( 'status' => 400 ) );
		}
		foreach ( $items as $it ) {
			$id = isset( $it['id'] ) ? (int) $it['id'] : 0;
			$r  = self::content_patch( $id, array( 'seo' => isset( $it['seo'] ) ? $it['seo'] : array(), 'change_note' => 'Updated SEO fields (bulk)' ) );
			$out[] = is_wp_error( $r ) ? array(
				'id'    => $id,
				'error' => $r->get_error_message(),
			) : array(
				'id'        => $id,
				'change_id' => $r['change_id'],
			);
		}
		return array( 'results' => $out );
	}

	public static function audit_page( $req ) {
		$post = EGSM_Content::get_post_or_error( $req['id'] );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$ctx = EGSM_Audit::context( array( $post->post_type ) );
		$out = EGSM_Audit::page( $post, $ctx );
		if ( EGSM_Util::bool( $req->get_param( 'render' ) ) ) {
			$out['rendered'] = EGSM_Audit::rendered( $post );
		}
		return $out;
	}

	public static function put_bots( $req ) {
		$b = self::body( $req );
		return EGSM_AISEO::set_bots( isset( $b['bots'] ) ? $b['bots'] : $b );
	}

	public static function put_robots( $req ) {
		$b = self::body( $req );
		return EGSM_AISEO::set_robots_extra( isset( $b['text'] ) ? $b['text'] : '' );
	}

	public static function get_llms() {
		return array(
			'settings'               => EGSM_AISEO::llms_settings(),
			'url'                    => home_url( '/llms.txt' ),
			'preview'                => EGSM_AISEO::generate_llms(),
			'physical_file_conflict' => file_exists( ABSPATH . 'llms.txt' ),
		);
	}

	public static function put_llms( $req ) {
		return EGSM_AISEO::set_llms( self::body( $req ) );
	}

	public static function analyze( $req ) {
		$post = EGSM_Content::get_post_or_error( $req['id'] );
		return is_wp_error( $post ) ? $post : array_merge( array( 'id' => $post->ID, 'url' => get_permalink( $post ) ), EGSM_AISEO::analyze( $post ) );
	}

	public static function put_site_schema( $req ) {
		$b = self::body( $req );
		return EGSM_AISEO::set_site_schema( array_key_exists( 'schema', $b ) ? $b['schema'] : $b );
	}

	public static function get_post_schema( $req ) {
		$post = EGSM_Content::get_post_or_error( $req['id'] );
		return is_wp_error( $post ) ? $post : EGSM_AISEO::get_post_schema( $post->ID );
	}

	public static function put_post_schema( $req ) {
		$b = self::body( $req );
		$r = self::content_patch( $req['id'], array( 'schema' => array_key_exists( 'schema', $b ) ? $b['schema'] : $b, 'change_note' => 'Updated schema' ) );
		return is_wp_error( $r ) ? $r : array(
			'id'        => (int) $req['id'],
			'schema'    => EGSM_AISEO::get_post_schema( (int) $req['id'] ),
			'change_id' => $r['change_id'],
		);
	}

	public static function post_faq( $req ) {
		$r = self::content_patch( $req['id'], array( 'faq' => self::body( $req ), 'change_note' => 'Added FAQ' ) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return array(
			'id'        => (int) $req['id'],
			'change_id' => $r['change_id'],
			'schema'    => EGSM_AISEO::get_post_schema( (int) $req['id'] ),
		);
	}

	public static function put_keywords( $req ) {
		$b     = self::body( $req );
		$items = isset( $b['items'] ) ? (array) $b['items'] : array();
		$sync  = ! isset( $b['sync_focus'] ) || EGSM_Util::bool( $b['sync_focus'] );
		if ( count( $items ) > 500 ) {
			return new WP_Error( 'egsm_bad_request', 'Max 500 items per call.', array( 'status' => 400 ) );
		}
		$out = array();
		foreach ( $items as $it ) {
			$id = ! empty( $it['post_id'] ) ? (int) $it['post_id'] : ( ! empty( $it['url'] ) ? url_to_postid( EGSM_Util::absolute_url( $it['url'] ) ) : 0 );
			if ( ! $id ) {
				$out[] = array(
					'input' => isset( $it['url'] ) ? $it['url'] : null,
					'error' => 'No page found for this URL.',
				);
				continue;
			}
			$kw = $it;
			unset( $kw['post_id'], $kw['url'] );
			$payload = array(
				'keywords'    => $kw,
				'change_note' => 'Mapped keywords',
			);
			if ( ! $sync ) {
				$payload['keywords_no_sync'] = true;
			}
			$r     = $sync ? self::content_patch( $id, $payload ) : self::keywords_only( $id, $kw );
			$out[] = is_wp_error( $r ) ? array(
				'id'    => $id,
				'error' => $r->get_error_message(),
			) : array(
				'id'        => $id,
				'change_id' => isset( $r['change_id'] ) ? $r['change_id'] : 0,
			);
		}
		return array( 'results' => $out );
	}

	private static function keywords_only( $id, $kw ) {
		$before = EGSM_Log::snapshot_post( $id );
		EGSM_AISEO::set_keywords( $id, $kw, false );
		return array( 'change_id' => EGSM_Log::post_changed( 'keywords', $id, $before, 'Mapped keywords' ) );
	}

	public static function post_move( $req ) {
		$b = self::body( $req );
		return EGSM_Structure::move( isset( $b['moves'] ) ? $b['moves'] : array( $b ) );
	}

	public static function get_graph( $req ) {
		return EGSM_Structure::link_graph( EGSM_Util::bool( $req->get_param( 'refresh' ) ) );
	}

	public static function post_link_insert( $req ) {
		return EGSM_Structure::insert_link( self::body( $req ) );
	}

	public static function post_link_replace( $req ) {
		return EGSM_Structure::replace_link( self::body( $req ) );
	}

	public static function post_link_rel( $req ) {
		return EGSM_Structure::set_link_rel( self::body( $req ) );
	}

	public static function post_menu_item( $req ) {
		return EGSM_Structure::add_menu_item( self::body( $req ) );
	}

	public static function patch_menu_item( $req ) {
		return EGSM_Structure::update_menu_item( $req['id'], self::body( $req ) );
	}

	public static function delete_menu_item( $req ) {
		return EGSM_Structure::delete_menu_item( $req['id'] );
	}

	public static function get_redirects( $req ) {
		return EGSM_Redirects::all( array( 'limit' => $req->get_param( 'limit' ) ) );
	}

	public static function post_redirect( $req ) {
		$b = self::body( $req );
		return EGSM_Redirects::add( isset( $b['source'] ) ? $b['source'] : '', isset( $b['target'] ) ? $b['target'] : '', isset( $b['code'] ) ? $b['code'] : 301, isset( $b['note'] ) ? sanitize_text_field( $b['note'] ) : '' );
	}

	public static function delete_redirect( $req ) {
		return EGSM_Redirects::delete( (int) $req['id'], (string) $req->get_param( 'store' ) );
	}

	public static function get_404s( $req ) {
		return EGSM_Redirects::list_404( $req->get_param( 'limit' ) ? $req->get_param( 'limit' ) : 100 );
	}

	public static function get_media( $req ) {
		return EGSM_Media::list_items( $req->get_params() );
	}

	public static function post_media( $req ) {
		$b = self::body( $req );
		if ( ! empty( $b['set_featured'] ) && ! empty( $b['post_id'] ) && ! EGSM_Settings::level_allows( 'publish' ) && EGSM_Content::is_live_status( get_post_status( (int) $b['post_id'] ) ) ) {
			return new WP_Error( 'egsm_level', "Changing a live page's featured image needs 'publish' access.", array( 'status' => 403 ) );
		}
		return EGSM_Media::upload( $b );
	}

	public static function patch_media( $req ) {
		return EGSM_Media::update( $req['id'], self::body( $req ) );
	}

	public static function bulk_alt( $req ) {
		$b   = self::body( $req );
		$out = array();
		foreach ( (array) ( isset( $b['items'] ) ? $b['items'] : array() ) as $it ) {
			$r     = EGSM_Media::update( isset( $it['id'] ) ? $it['id'] : 0, array( 'alt' => isset( $it['alt'] ) ? $it['alt'] : '' ) );
			$out[] = is_wp_error( $r ) ? array(
				'id'    => isset( $it['id'] ) ? $it['id'] : null,
				'error' => $r->get_error_message(),
			) : $r;
		}
		return array( 'results' => $out );
	}

	public static function get_terms( $req ) {
		return EGSM_Maintenance::list_terms( $req->get_param( 'taxonomy' ) ? sanitize_key( $req->get_param( 'taxonomy' ) ) : 'category' );
	}

	public static function post_term( $req ) {
		return EGSM_Maintenance::create_term( self::body( $req ) );
	}

	public static function patch_term( $req ) {
		return EGSM_Maintenance::update_term( $req['id'], self::body( $req ) );
	}

	public static function patch_author( $req ) {
		return EGSM_AISEO::update_author( $req['id'], self::body( $req ) );
	}

	public static function get_changes( $req ) {
		return EGSM_Log::list_changes( $req->get_params() );
	}

	public static function get_change( $req ) {
		$row = EGSM_Log::get( (int) $req['id'] );
		if ( ! $row ) {
			return new WP_Error( 'egsm_not_found', 'Change not found.', array( 'status' => 404 ) );
		}
		$row['before_state'] = null === $row['before_state'] ? null : json_decode( $row['before_state'], true );
		$row['after_state']  = null === $row['after_state'] ? null : json_decode( $row['after_state'], true );
		return $row;
	}

	public static function revert( $req ) {
		$b = self::body( $req );
		return EGSM_Log::revert( (int) $req['id'], ! empty( $b['force'] ) || EGSM_Util::bool( $req->get_param( 'force' ) ) );
	}

	public static function get_updates( $req ) {
		return EGSM_Maintenance::updates( EGSM_Util::bool( $req->get_param( 'refresh' ) ) );
	}

	public static function post_update_plugins( $req ) {
		$b = self::body( $req );
		return EGSM_Maintenance::update_plugins( isset( $b['plugins'] ) ? $b['plugins'] : array() );
	}

	public static function post_update_themes( $req ) {
		$b = self::body( $req );
		return EGSM_Maintenance::update_themes( isset( $b['themes'] ) ? $b['themes'] : array() );
	}

	public static function purge( $req ) {
		$b = self::body( $req );
		if ( ! empty( $b['post_id'] ) ) {
			return array( 'purged' => EGSM_Cache::purge_post( (int) $b['post_id'] ) );
		}
		return array( 'purged' => EGSM_Cache::purge_all() );
	}

	public static function put_branding( $req ) {
		if ( ! EGSM_Auth::via_signature() ) {
			return new WP_Error( 'egsm_auth', 'Branding can only be set by the connected agency platform.', array( 'status' => 403 ) );
		}
		return EGSM_Maintenance::set_branding( self::body( $req ) );
	}
}
