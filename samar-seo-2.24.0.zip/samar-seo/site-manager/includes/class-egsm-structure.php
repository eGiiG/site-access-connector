<?php
/**
 * Site structure: page tree (silos), internal link graph, moves with 301s,
 * menus, and internal-link insertion/replacement.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Structure {

	/** Current URLs of a post and all its descendants: [id => url]. */
	public static function urls_of_tree( $id ) {
		$out  = array( (int) $id => get_permalink( $id ) );
		$post = get_post( $id );
		if ( $post && is_post_type_hierarchical( $post->post_type ) ) {
			$kids = get_posts(
				array(
					'post_type'   => $post->post_type,
					'post_status' => 'publish',
					'numberposts' => -1,
					'fields'      => 'ids',
					'post_parent' => $id,
				)
			);
			foreach ( $kids as $k ) {
				$out += self::urls_of_tree( $k );
			}
		}
		return $out;
	}

	/* ---------- link graph ---------- */

	public static function link_graph( $force = false ) {
		$cached = get_transient( 'egsm_link_graph' );
		if ( ! $force && is_array( $cached ) ) {
			return $cached;
		}
		$ids = get_posts(
			array(
				'post_type'   => EGSM_Content::post_types(),
				'post_status' => 'publish',
				'numberposts' => 3000,
				'fields'      => 'ids',
			)
		);
		$out      = array();
		$incoming = array_fill_keys( $ids, 0 );
		$sources  = array_fill_keys( $ids, array() );
		$broken   = array();
		foreach ( $ids as $id ) {
			$links    = EGSM_Util::links( EGSM_Builders::get_html( $id ) );
			$targets  = array();
			$ext      = 0;
			foreach ( $links as $l ) {
				if ( ! $l['internal'] ) {
					$ext++;
					continue;
				}
				$tid = isset( $l['target_id'] ) ? (int) $l['target_id'] : 0;
				if ( $tid && $tid !== $id ) {
					$targets[ $tid ] = true;
				} elseif ( ! $tid && 0 !== strpos( $l['href'], '#' ) ) {
					$path = EGSM_Redirects::site_path( $l['href'] );
					if ( '/' !== $path && ! preg_match( '#^/(wp-content|wp-includes|category|tag|author|feed|\?)#', $path ) && ! preg_match( '#\.(pdf|jpe?g|png|gif|webp|svg|docx?|xlsx?|zip|mp4)$#i', $path ) ) {
						$broken[] = array(
							'post_id' => $id,
							'href'    => $l['href'],
							'anchor'  => $l['anchor'],
						);
					}
				}
			}
			foreach ( array_keys( $targets ) as $tid ) {
				if ( isset( $incoming[ $tid ] ) ) {
					$incoming[ $tid ]++;
					$sources[ $tid ][] = $id;
				}
			}
			$out[ $id ] = array(
				'out_internal' => count( $targets ),
				'out_external' => $ext,
				'links_to'     => array_keys( $targets ),
			);
		}
		// Menu links count as incoming.
		$in_menu = self::menu_object_ids();
		foreach ( $out as $id => &$row ) {
			$row['in_internal'] = $incoming[ $id ];
			$row['linked_from'] = array_slice( $sources[ $id ], 0, 50 );
			$row['in_menu']     = isset( $in_menu[ $id ] );
		}
		unset( $row );
		$front = (int) get_option( 'page_on_front' );
		$orph  = array();
		foreach ( $out as $id => $row ) {
			if ( 0 === $row['in_internal'] && ! $row['in_menu'] && $id !== $front ) {
				$orph[] = $id;
			}
		}
		$graph = array(
			'nodes'            => $out,
			'orphans'          => $orph,
			'unresolved_links' => array_slice( $broken, 0, 500 ),
			'generated'        => gmdate( 'c' ),
		);
		set_transient( 'egsm_link_graph', $graph, 15 * MINUTE_IN_SECONDS );
		return $graph;
	}

	public static function flush_graph() {
		delete_transient( 'egsm_link_graph' );
	}

	public static function menu_object_ids() {
		$ids = array();
		foreach ( wp_get_nav_menus() as $menu ) {
			foreach ( (array) wp_get_nav_menu_items( $menu->term_id ) as $item ) {
				if ( 'post_type' === $item->type ) {
					$ids[ (int) $item->object_id ] = true;
				}
			}
		}
		return $ids;
	}

	/* ---------- tree ---------- */

	public static function tree() {
		$types = array_values( array_filter( EGSM_Content::post_types(), 'is_post_type_hierarchical' ) );
		$posts = get_posts(
			array(
				'post_type'   => $types,
				'post_status' => array( 'publish', 'draft', 'private', 'pending', 'future' ),
				'numberposts' => 3000,
				'orderby'     => 'menu_order title',
				'order'       => 'ASC',
			)
		);
		$graph   = self::link_graph();
		$nodes   = array();
		$by_par  = array();
		foreach ( $posts as $p ) {
			$g              = isset( $graph['nodes'][ $p->ID ] ) ? $graph['nodes'][ $p->ID ] : null;
			$nodes[ $p->ID ] = array(
				'id'          => $p->ID,
				'type'        => $p->post_type,
				'title'       => $p->post_title,
				'slug'        => $p->post_name,
				'url'         => get_permalink( $p ),
				'status'      => $p->post_status,
				'menu_order'  => (int) $p->menu_order,
				'in_links'    => $g ? $g['in_internal'] : 0,
				'out_links'   => $g ? $g['out_internal'] : 0,
				'in_menu'     => $g ? $g['in_menu'] : false,
				'children'    => array(),
			);
			$by_par[ (int) $p->post_parent ][] = $p->ID;
		}
		$build = function ( $pid ) use ( &$build, &$nodes, $by_par ) {
			$out = array();
			foreach ( isset( $by_par[ $pid ] ) ? $by_par[ $pid ] : array() as $cid ) {
				if ( ! isset( $nodes[ $cid ] ) ) {
					continue;
				}
				$n             = $nodes[ $cid ];
				$n['children'] = $build( $cid );
				$out[]         = $n;
			}
			return $out;
		};
		$cats = array();
		foreach ( get_categories( array( 'hide_empty' => false ) ) as $c ) {
			$cats[] = array(
				'id'     => $c->term_id,
				'name'   => $c->name,
				'slug'   => $c->slug,
				'parent' => $c->parent,
				'count'  => $c->count,
				'url'    => get_category_link( $c ),
				'description' => $c->description,
			);
		}
		return array(
			'front_page'  => (int) get_option( 'page_on_front' ),
			'posts_page'  => (int) get_option( 'page_for_posts' ),
			'pages'       => $build( 0 ),
			'categories'  => $cats,
			'menus'       => self::menus(),
			'orphans'     => $graph['orphans'],
			'permalinks'  => (string) get_option( 'permalink_structure' ),
		);
	}

	/* ---------- moves ---------- */

	/**
	 * Reorganize pages: [{id, parent?, slug?, menu_order?}, ...]. Creates 301s for every changed URL.
	 */
	public static function move( $moves ) {
		$results = array();
		foreach ( (array) $moves as $i => $m ) {
			$id   = isset( $m['id'] ) ? (int) $m['id'] : 0;
			$post = EGSM_Content::get_post_or_error( $id );
			if ( is_wp_error( $post ) ) {
				return $post;
			}
			if ( isset( $m['parent'] ) ) {
				$par = (int) $m['parent'];
				if ( $par === $id ) {
					return new WP_Error( 'egsm_bad_parent', "moves[$i]: a page cannot be its own parent.", array( 'status' => 400 ) );
				}
				if ( $par && in_array( $id, get_post_ancestors( $par ), true ) ) {
					return new WP_Error( 'egsm_bad_parent', "moves[$i]: cannot move a page under its own descendant.", array( 'status' => 400 ) );
				}
			}
			$before = EGSM_Log::snapshot_post( $id );
			$old    = self::urls_of_tree( $id );
			$fields = array( 'ID' => $id );
			if ( isset( $m['parent'] ) ) {
				$fields['post_parent'] = (int) $m['parent'];
			}
			if ( isset( $m['slug'] ) ) {
				$fields['post_name'] = sanitize_title( $m['slug'] );
			}
			if ( isset( $m['menu_order'] ) ) {
				$fields['menu_order'] = (int) $m['menu_order'];
			}
			$r = wp_update_post( wp_slash( $fields ), true );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			$redirects = 'publish' === $post->post_status ? EGSM_Redirects::create_for_moves( $old, self::urls_of_tree( $id ) ) : array();
			$results[] = array(
				'id'        => $id,
				'url'       => get_permalink( $id ),
				'redirects' => $redirects,
				'change_id' => EGSM_Log::post_changed( 'move', $id, $before, 'Moved/renamed "' . $post->post_title . '"' ),
			);
			EGSM_Cache::purge_post( $id );
		}
		self::flush_graph();
		return array( 'moved' => $results );
	}

	/* ---------- menus ---------- */

	public static function menus() {
		$locations = get_nav_menu_locations();
		$out       = array();
		foreach ( wp_get_nav_menus() as $menu ) {
			$items = array();
			foreach ( (array) wp_get_nav_menu_items( $menu->term_id ) as $it ) {
				$items[] = array(
					'item_id'   => $it->ID,
					'title'     => $it->title,
					'url'       => $it->url,
					'type'      => $it->type,
					'object'    => $it->object,
					'object_id' => (int) $it->object_id,
					'parent'    => (int) $it->menu_item_parent,
					'position'  => (int) $it->menu_order,
				);
			}
			$out[] = array(
				'id'        => $menu->term_id,
				'name'      => $menu->name,
				'locations' => array_keys( $locations, $menu->term_id, true ),
				'items'     => $items,
			);
		}
		return $out;
	}

	private static function resolve_menu( $p ) {
		if ( ! empty( $p['menu_id'] ) ) {
			$m = wp_get_nav_menu_object( (int) $p['menu_id'] );
			return $m ? $m->term_id : 0;
		}
		if ( ! empty( $p['location'] ) ) {
			$loc = get_nav_menu_locations();
			return isset( $loc[ $p['location'] ] ) ? (int) $loc[ $p['location'] ] : 0;
		}
		return 0;
	}

	public static function add_menu_item( $p ) {
		$menu = self::resolve_menu( $p );
		if ( ! $menu ) {
			return new WP_Error( 'egsm_not_found', 'Menu not found (give menu_id or a theme location).', array( 'status' => 404 ) );
		}
		$data = array(
			'menu-item-status'    => 'publish',
			'menu-item-parent-id' => isset( $p['parent_item'] ) ? (int) $p['parent_item'] : 0,
			'menu-item-position'  => isset( $p['position'] ) ? (int) $p['position'] : 0,
		);
		if ( ! empty( $p['object_id'] ) ) {
			$post = get_post( (int) $p['object_id'] );
			if ( ! $post ) {
				return new WP_Error( 'egsm_not_found', 'object_id not found.', array( 'status' => 404 ) );
			}
			$data['menu-item-object-id'] = $post->ID;
			$data['menu-item-object']    = $post->post_type;
			$data['menu-item-type']      = 'post_type';
			$data['menu-item-title']     = isset( $p['title'] ) ? sanitize_text_field( $p['title'] ) : '';
		} elseif ( ! empty( $p['url'] ) ) {
			$data['menu-item-type']  = 'custom';
			$data['menu-item-url']   = esc_url_raw( $p['url'] );
			$data['menu-item-title'] = sanitize_text_field( isset( $p['title'] ) ? $p['title'] : $p['url'] );
		} else {
			return new WP_Error( 'egsm_bad_request', 'Give object_id (page/post) or url.', array( 'status' => 400 ) );
		}
		$id = wp_update_nav_menu_item( $menu, 0, $data );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		self::flush_graph();
		return array(
			'item_id'   => $id,
			'change_id' => EGSM_Log::post_changed( 'menu_add', $id, null, 'Added menu item "' . get_the_title( $id ) . '"' ),
		);
	}

	public static function update_menu_item( $item_id, $p ) {
		$item = get_post( (int) $item_id );
		if ( ! $item || 'nav_menu_item' !== $item->post_type ) {
			return new WP_Error( 'egsm_not_found', 'Menu item not found.', array( 'status' => 404 ) );
		}
		$menus = wp_get_object_terms( $item->ID, 'nav_menu', array( 'fields' => 'ids' ) );
		$menu  = $menus ? (int) $menus[0] : 0;
		$setup = wp_setup_nav_menu_item( $item );
		$before = EGSM_Log::snapshot_post( $item->ID );
		$data  = array(
			'menu-item-db-id'     => $item->ID,
			'menu-item-object-id' => $setup->object_id,
			'menu-item-object'    => $setup->object,
			'menu-item-type'      => $setup->type,
			'menu-item-title'     => isset( $p['title'] ) ? sanitize_text_field( $p['title'] ) : $setup->title,
			'menu-item-url'       => isset( $p['url'] ) ? esc_url_raw( $p['url'] ) : $setup->url,
			'menu-item-parent-id' => isset( $p['parent_item'] ) ? (int) $p['parent_item'] : (int) $setup->menu_item_parent,
			'menu-item-position'  => isset( $p['position'] ) ? (int) $p['position'] : (int) $setup->menu_order,
			'menu-item-status'    => 'publish',
		);
		$r     = wp_update_nav_menu_item( $menu, $item->ID, $data );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return array(
			'item_id'   => $item->ID,
			'change_id' => EGSM_Log::post_changed( 'menu_update', $item->ID, $before, 'Updated menu item' ),
		);
	}

	public static function delete_menu_item( $item_id ) {
		$item = get_post( (int) $item_id );
		if ( ! $item || 'nav_menu_item' !== $item->post_type ) {
			return new WP_Error( 'egsm_not_found', 'Menu item not found.', array( 'status' => 404 ) );
		}
		$snap = EGSM_Log::snapshot_post( $item->ID );
		wp_delete_post( $item->ID, true );
		self::flush_graph();
		return array(
			'deleted'   => (int) $item_id,
			'change_id' => EGSM_Log::record( 'menu_delete', 'menu_item', $item_id, $snap, null, 'Deleted menu item "' . $item->post_title . '" (not auto-revertable; re-add it with add_menu_item)' ),
		);
	}

	/* ---------- internal links ---------- */

	/**
	 * Link the first unlinked occurrence of $anchor in $html to $url.
	 * Skips text inside <a>, headings, <script>, <style>, <code>, <button> and block comments.
	 */
	public static function link_in_html( $html, $anchor, $url, $ci, $max, &$count, $rel = '', $extra = '' ) {
		// [thrive-support v1] Thrive stores <script> as [tcb-script]…[/tcb-script]: never link inside those.
		$parts = preg_split( '/(<!--.*?-->|\[tcb-script\b.*?\[\/tcb-script\]|<[^>]+>)/s', (string) $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		$skip  = 0;
		$tags  = 'a|h1|h2|h3|h4|h5|h6|script|style|code|pre|button|figcaption|summary|title|textarea|select|option';
		$re    = '/(?<![\p{L}\p{N}])(' . preg_quote( $anchor, '/' ) . ')(?![\p{L}\p{N}])/u' . ( $ci ? 'i' : '' );
		foreach ( $parts as &$part ) {
			if ( '' === $part ) {
				continue;
			}
			if ( 0 === strpos( $part, '[tcb-script' ) ) {
				continue;
			}
			if ( '<' === $part[0] ) {
				if ( preg_match( '#^<(' . $tags . ')\b#i', $part ) && '/>' !== substr( $part, -2 ) ) {
					$skip++;
				} elseif ( preg_match( '#^</(' . $tags . ')\s*>#i', $part ) ) {
					$skip = max( 0, $skip - 1 );
				}
				continue;
			}
			if ( $skip > 0 || $count >= $max ) {
				continue;
			}
			$n    = 0;
			$part = preg_replace_callback(
				$re,
				function ( $m ) use ( $url, $rel, $extra ) {
					return '<a href="' . esc_url( $url ) . '"' . ( '' !== $rel ? ' rel="' . esc_attr( $rel ) . '"' : '' ) . $extra . '>' . $m[1] . '</a>';
				},
				$part,
				$max - $count,
				$n
			);
			$count += $n;
		}
		return implode( '', $parts );
	}

	/**
	 * Insert an internal link. p = {post_id, anchor, target_id|url, max=1, case_insensitive=true}
	 */
	public static function insert_link( $p ) {
		$post = EGSM_Content::get_post_or_error( isset( $p['post_id'] ) ? $p['post_id'] : 0 );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$anchor = trim( (string) ( isset( $p['anchor'] ) ? $p['anchor'] : '' ) );
		$url    = ! empty( $p['target_id'] ) ? get_permalink( (int) $p['target_id'] ) : ( isset( $p['url'] ) ? esc_url_raw( $p['url'] ) : '' );
		if ( '' === $anchor || ! $url ) {
			return new WP_Error( 'egsm_bad_request', 'anchor and target_id (or url) are required.', array( 'status' => 400 ) );
		}
		$html_now = EGSM_Builders::get_html( $post );
		// even_if_linked: add a second, better-worded link to a page that is already linked (e.g. a keyword
		// anchor when the only existing link says "View details").
		if ( empty( $p['even_if_linked'] ) || ! EGSM_Util::bool( $p['even_if_linked'] ) ) {
			foreach ( EGSM_Util::links( $html_now ) as $l ) {
				if ( EGSM_Redirects::site_path( $l['href'] ) === EGSM_Redirects::site_path( $url ) && EGSM_Util::is_internal( $l['href'] ) ) {
					return new WP_Error( 'egsm_already_linked', 'This page already links to that URL (pass even_if_linked=true to add another link with this anchor).', array( 'status' => 409 ) );
				}
			}
		}
		// Optional class / style so a new link can match the page's design (e.g. style="text-decoration:none").
		$extra = '';
		foreach ( array( 'class', 'style' ) as $att ) {
			if ( isset( $p[ $att ] ) && '' !== trim( (string) $p[ $att ] ) ) {
				$extra .= ' ' . $att . '="' . esc_attr( trim( (string) $p[ $att ] ) ) . '"';
			}
		}
		$ci      = ! isset( $p['case_insensitive'] ) || EGSM_Util::bool( $p['case_insensitive'] );
		$rel     = isset( $p['rel'] ) ? implode( ' ', array_intersect( preg_split( '/[\s,]+/', strtolower( (string) $p['rel'] ) ), array( 'nofollow', 'sponsored', 'ugc', 'follow', 'noopener' ) ) ) : '';
		$max     = max( 1, (int) ( isset( $p['max'] ) ? $p['max'] : 1 ) );
		$count   = 0;
		$builder = EGSM_Builders::detect( $post );
		$before  = EGSM_Log::snapshot_post( $post->ID );

		if ( 'elementor' === $builder ) {
			$data = EGSM_Elementor::get_data( $post->ID );
			self::link_in_elementor( $data, $anchor, $url, $ci, $max, $count, $rel );
			if ( $count ) {
				EGSM_Elementor::save_data( $post->ID, $data );
			}
		} elseif ( 'thrive' === $builder ) {
			$count = EGSM_Builders::thrive_apply(
				$post->ID,
				function ( $html, &$c ) use ( $anchor, $url, $ci, $max, $rel, $extra ) {
					return self::link_in_html( $html, $anchor, $url, $ci, $max, $c, $rel, $extra );
				}
			);
		} elseif ( in_array( $builder, array( 'gutenberg', 'classic', 'divi', 'wpbakery' ), true ) ) {
			$new = self::link_in_html( $post->post_content, $anchor, $url, $ci, $max, $count, $rel, $extra );
			if ( $count ) {
				wp_update_post(
					array(
						'ID'           => $post->ID,
						'post_content' => wp_slash( $new ),
					)
				);
			}
		} else {
			return new WP_Error( 'egsm_builder', "Automatic link insertion is not supported for $builder pages.", array( 'status' => 422 ) );
		}
		if ( ! $count ) {
			return new WP_Error( 'egsm_text_not_found', 'The anchor text was not found in linkable body text (headings and existing links are skipped).', array( 'status' => 422 ) );
		}
		self::flush_graph();
		EGSM_Cache::purge_post( $post->ID );
		return array(
			'post_id'   => $post->ID,
			'linked'    => $count,
			'url'       => $url,
			'change_id' => EGSM_Log::post_changed( 'link_insert', $post->ID, $before, "Linked \"$anchor\" → $url" ),
		);
	}

	private static function link_in_elementor( &$elements, $anchor, $url, $ci, $max, &$count, $rel = '' ) {
		foreach ( $elements as &$el ) {
			if ( $count >= $max ) {
				return;
			}
			if ( isset( $el['widgetType'] ) && 'text-editor' === $el['widgetType'] && ! empty( $el['settings']['editor'] ) ) {
				$el['settings']['editor'] = self::link_in_html( $el['settings']['editor'], $anchor, $url, $ci, $max, $count, $rel );
			}
			if ( ! empty( $el['elements'] ) ) {
				self::link_in_elementor( $el['elements'], $anchor, $url, $ci, $max, $count, $rel );
			}
		}
	}

	/** Replace a link URL (e.g. a broken or moved link) in one post or site-wide. */
	public static function replace_link( $p ) {
		$old = trim( (string) ( isset( $p['old_url'] ) ? $p['old_url'] : '' ) );
		$new = ! empty( $p['new_target_id'] ) ? get_permalink( (int) $p['new_target_id'] ) : esc_url_raw( isset( $p['new_url'] ) ? $p['new_url'] : '' );
		if ( '' === $old || ! $new ) {
			return new WP_Error( 'egsm_bad_request', 'old_url and new_url (or new_target_id) are required.', array( 'status' => 400 ) );
		}
		$ids = array();
		if ( ! empty( $p['post_id'] ) ) {
			$ids = array( (int) $p['post_id'] );
		} else {
			global $wpdb;
			$like = '%' . $wpdb->esc_like( EGSM_Redirects::site_path( $old ) ) . '%';
			$ids  = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT p.ID FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND ( m.meta_key = '_elementor_data' OR m.meta_key LIKE 'tve\\_updated\\_post%%' ) WHERE p.post_status IN ('publish','draft','private','future','pending') AND p.post_type NOT IN ('revision','nav_menu_item','attachment') AND (p.post_content LIKE %s OR m.meta_value LIKE %s) LIMIT 500", $like, $like ) );
		}
		$variants = array_unique( array( $old, EGSM_Util::absolute_url( $old ), untrailingslashit( EGSM_Util::absolute_url( $old ) ), trailingslashit( EGSM_Util::absolute_url( $old ) ), EGSM_Redirects::site_path( $old ), trailingslashit( EGSM_Redirects::site_path( $old ) ) ) );
		$done     = array();
		foreach ( $ids as $id ) {
			$before  = EGSM_Log::snapshot_post( (int) $id );
			$count   = 0;
			$post    = get_post( $id );
			$content = $post->post_content;
			foreach ( $variants as $v ) {
				$content = preg_replace_callback(
					'/(href\s*=\s*["\'])' . preg_quote( $v, '/' ) . '(["\'#?])/i',
					function ( $m ) use ( $new, &$count ) {
						$count++;
						return $m[1] . $new . $m[2];
					},
					$content
				);
			}
			if ( $content !== $post->post_content ) {
				wp_update_post(
					array(
						'ID'           => $id,
						'post_content' => wp_slash( $content ),
					)
				);
			}
			if ( 'thrive' === EGSM_Builders::detect( $id ) ) {
				$count = EGSM_Builders::thrive_apply(
					$id,
					function ( $html, &$c ) use ( $variants, $new ) {
						foreach ( $variants as $v ) {
							$html = preg_replace_callback(
								'/(href\s*=\s*["\'])' . preg_quote( $v, '/' ) . '(["\'#?])/i',
								function ( $m ) use ( $new, &$c ) {
									$c++;
									return $m[1] . $new . $m[2];
								},
								$html
							);
						}
						return $html;
					}
				) ?: $count;
			}
			if ( 'elementor' === EGSM_Builders::detect( $id ) ) {
				$data = EGSM_Elementor::get_data( $id );
				$c2   = 0;
				foreach ( $variants as $v ) {
					self::replace_url_deep( $data, $v, $new, $c2 );
				}
				if ( $c2 ) {
					EGSM_Elementor::save_data( $id, $data );
					$count += $c2;
				}
			}
			if ( $count ) {
				$done[] = array(
					'post_id'   => (int) $id,
					'replaced'  => $count,
					'change_id' => EGSM_Log::post_changed( 'link_replace', (int) $id, $before, "Replaced link $old → $new" ),
				);
				EGSM_Cache::purge_post( (int) $id );
			}
		}
		self::flush_graph();
		return array( 'updated' => $done );
	}

	/**
	 * Set the rel of existing links to a URL: {url, rel, post_id?}. rel = any of nofollow sponsored ugc follow
	 * ("follow" forces follow over site rules; "" removes the explicit rel). Without post_id every page/post
	 * linking to the URL is updated. Elementor link controls only support nofollow; text/HTML widgets get the full rel.
	 */
	public static function set_link_rel( $p ) {
		$url = trim( (string) ( isset( $p['url'] ) ? $p['url'] : '' ) );
		if ( '' === $url || ! isset( $p['rel'] ) ) {
			return new WP_Error( 'egsm_bad_request', 'url and rel are required (rel "" removes it).', array( 'status' => 400 ) );
		}
		$tokens = array_values( array_unique( array_intersect( preg_split( '/[\s,]+/', strtolower( (string) $p['rel'] ) ), array( 'nofollow', 'sponsored', 'ugc', 'follow' ) ) ) );
		if ( in_array( 'follow', $tokens, true ) ) {
			$tokens = array( 'follow' );
		}
		$abs      = EGSM_Util::absolute_url( $url );
		$internal = EGSM_Util::is_internal( $abs );
		$variants = array( $url, $abs, untrailingslashit( $abs ), trailingslashit( $abs ) );
		if ( $internal ) {
			$path       = EGSM_Redirects::site_path( $abs );
			$variants[] = $path;
			$variants[] = trailingslashit( $path );
		}
		$variants = array_values( array_filter( array_unique( $variants ) ) );
		if ( ! empty( $p['post_id'] ) ) {
			$ids = array( (int) $p['post_id'] );
		} else {
			global $wpdb;
			$like = '%' . $wpdb->esc_like( untrailingslashit( $internal ? EGSM_Redirects::site_path( $abs ) : preg_replace( '#^https?:#i', '', $abs ) ) ) . '%';
			$ids  = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT p.ID FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND ( m.meta_key = '_elementor_data' OR m.meta_key LIKE 'tve\\_updated\\_post%%' ) WHERE p.post_status IN ('publish','draft','private','future','pending') AND p.post_type NOT IN ('revision','nav_menu_item','attachment') AND (p.post_content LIKE %s OR m.meta_value LIKE %s) LIMIT 500", $like, $like ) );
		}
		$done = array();
		$note = null;
		foreach ( $ids as $id ) {
			$post = get_post( (int) $id );
			if ( ! $post ) {
				continue;
			}
			$before  = EGSM_Log::snapshot_post( $post->ID );
			$count   = 0;
			$content = self::rel_in_html( $post->post_content, $variants, $tokens, $count );
			if ( $content !== $post->post_content ) {
				wp_update_post( array( 'ID' => $post->ID, 'post_content' => wp_slash( $content ) ) );
			}
			if ( 'thrive' === EGSM_Builders::detect( $post->ID ) ) {
				$count = EGSM_Builders::thrive_apply(
					$post->ID,
					function ( $html, &$c ) use ( $variants, $tokens ) {
						return self::rel_in_html( $html, $variants, $tokens, $c );
					}
				) ?: $count;
			}
			if ( 'elementor' === EGSM_Builders::detect( $post->ID ) ) {
				$data = EGSM_Elementor::get_data( $post->ID );
				$c2   = 0;
				self::rel_deep( $data, $variants, $tokens, $c2, $note );
				if ( $c2 ) {
					EGSM_Elementor::save_data( $post->ID, $data );
					$count += $c2;
				}
			}
			if ( $count ) {
				$done[] = array(
					'post_id'   => $post->ID,
					'links'     => $count,
					'change_id' => EGSM_Log::post_changed( 'link_rel', $post->ID, $before, 'Link rel "' . implode( ' ', $tokens ) . '" on ' . $url ),
				);
				EGSM_Cache::purge_post( $post->ID );
			}
		}
		$out = array( 'rel' => implode( ' ', $tokens ), 'updated' => $done );
		if ( $note ) {
			$out['note'] = $note;
		}
		return $out;
	}

	private static function href_matches( $href, $variants ) {
		$h = html_entity_decode( (string) $href, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		foreach ( $variants as $v ) {
			if ( $h === $v || 0 === strpos( $h, $v . '#' ) || 0 === strpos( $h, $v . '?' ) ) {
				return true;
			}
		}
		return false;
	}

	public static function rel_in_html( $html, $variants, $tokens, &$count ) {
		if ( ! is_string( $html ) || false === stripos( $html, '<a' ) ) {
			return $html;
		}
		return preg_replace_callback(
			'#<a\s([^>]*)>#i',
			function ( $m ) use ( $variants, $tokens, &$count ) {
				$tag  = '<a ' . $m[1] . '>';
				$href = EGSM_Util::attr( $tag, 'href' );
				if ( null === $href || ! self::href_matches( $href, $variants ) ) {
					return $m[0];
				}
				$keep  = array_intersect( preg_split( '/\s+/', strtolower( (string) EGSM_Util::attr( $tag, 'rel' ) ) ), array( 'noopener', 'noreferrer' ) );
				$rel   = array_values( array_unique( array_merge( $tokens, $keep ) ) );
				$attrs = trim( preg_replace( '/\srel\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', ' ' . $m[1] ) );
				$count++;
				return '<a ' . $attrs . ( $rel ? ' rel="' . esc_attr( implode( ' ', $rel ) ) . '"' : '' ) . '>';
			},
			$html
		);
	}

	private static function rel_deep( &$v, $variants, $tokens, &$count, &$note ) {
		if ( ! is_array( $v ) ) {
			return;
		}
		// Elementor link control: {url, is_external, nofollow, custom_attributes}.
		if ( isset( $v['url'] ) && is_string( $v['url'] ) && ( array_key_exists( 'nofollow', $v ) || array_key_exists( 'is_external', $v ) || array_key_exists( 'custom_attributes', $v ) ) && self::href_matches( $v['url'], $variants ) ) {
			$v['nofollow'] = in_array( 'nofollow', $tokens, true ) ? 'on' : '';
			$count++;
			if ( array_intersect( $tokens, array( 'sponsored', 'ugc' ) ) ) {
				$note = 'Elementor button/link controls only support nofollow; sponsored/ugc were applied to links inside text widgets only.';
			}
		}
		foreach ( $v as $k => &$x ) {
			if ( is_string( $x ) && false !== stripos( $x, '<a' ) ) {
				$x = self::rel_in_html( $x, $variants, $tokens, $count );
			} elseif ( is_array( $x ) ) {
				self::rel_deep( $x, $variants, $tokens, $count, $note );
			}
		}
	}

	private static function replace_url_deep( &$v, $old, $new, &$count ) {
		if ( is_array( $v ) ) {
			foreach ( $v as $k => &$x ) {
				if ( 'url' === $k && is_string( $x ) && ( $x === $old ) ) {
					$x = $new;
					$count++;
				} elseif ( is_string( $x ) && false !== stripos( $x, $old ) && preg_match( '/href/i', $x ) ) {
					$x = preg_replace_callback(
						'/(href\s*=\s*["\'])' . preg_quote( $old, '/' ) . '(["\'#?])/i',
						function ( $m ) use ( $new, &$count ) {
							$count++;
							return $m[1] . $new . $m[2];
						},
						$x
					);
				} elseif ( is_array( $x ) ) {
					self::replace_url_deep( $x, $old, $new, $count );
				}
			}
		}
	}
}
