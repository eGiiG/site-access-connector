<?php
/**
 * Editor + list screens (only when this plugin or SEO Suite is the site's SEO plugin):
 *  - "SEO" panel on every page/post edit screen (block editor and classic): focus keyword, SEO title,
 *    meta description with Google preview, index/noindex, nofollow, canonical, and the live SEO score.
 *  - "SEO" column in the Pages/Posts lists with score + noindex, sortable, with a filter and bulk actions
 *    (set noindex / set index / recalculate score).
 *  - "Search settings" screen (archives, homepage, sitemap, link rules, IndexNow, score backfill).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Editor {

	const SETTINGS_SLUG = 'egsm-search-settings';

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_box' ) );
		add_action( 'save_post', array( __CLASS__, 'save_box' ), 20, 2 );
		add_action( 'wp_ajax_egsm_score', array( __CLASS__, 'ajax_score' ) );
		add_action( 'wp_ajax_egsm_score_batch', array( __CLASS__, 'ajax_batch' ) );
		add_action( 'admin_init', array( __CLASS__, 'list_hooks' ) );
		add_action( 'admin_menu', array( __CLASS__, 'settings_menu' ), 20 );
		add_action( 'admin_post_egsm_save_search', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_head', array( __CLASS__, 'css' ) );
		add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'sidebar_assets' ) );
	}

	private static function on() {
		return EGSM_SEO_Settings::we_are_seo_plugin();
	}

	/* =========================================================
	 * Edit screen panel
	 * ========================================================= */

	public static function add_box() {
		if ( ! self::on() ) {
			return;
		}
		foreach ( EGSM_Score::types() as $t ) {
			add_meta_box( 'egsm-seo', 'SEO', array( __CLASS__, 'render_box' ), $t, 'normal', 'high' );
		}
	}

	public static function render_box( $post ) {
		$seo  = EGSM_SEO::get( $post->ID );
		$data = EGSM_Score::analyze( $post );
		$site = get_bloginfo( 'name' );
		wp_nonce_field( 'egsm_box', 'egsm_box_nonce' );
		$is_elementor = 'elementor' === EGSM_Builders::detect( $post );
		?>
		<div id="egsm-box" data-post="<?php echo (int) $post->ID; ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'egsm_score' ) ); ?>" data-site="<?php echo esc_attr( $site ); ?>" data-builder="<?php echo esc_attr( EGSM_Builders::detect( $post ) ); ?>">
			<div class="egsm-grid">
				<div class="egsm-fields">
					<p><label for="egsm_kw"><strong>Focus keyword</strong></label>
						<input type="text" id="egsm_kw" name="egsm_seo[focus_keyword]" value="<?php echo esc_attr( $seo['focus_keyword'] ); ?>" placeholder="e.g. interior painting baltimore" class="widefat"></p>
					<p><label for="egsm_title"><strong>SEO title</strong> <span class="egsm-count" data-for="egsm_title" data-min="30" data-max="60"></span></label>
						<input type="text" id="egsm_title" name="egsm_seo[title]" value="<?php echo esc_attr( $seo['title'] ); ?>" placeholder="<?php echo esc_attr( trim( $post->post_title . ' - ' . $site, ' -' ) ); ?>" class="widefat"></p>
					<p><label for="egsm_desc"><strong>Meta description</strong> <span class="egsm-count" data-for="egsm_desc" data-min="120" data-max="160"></span></label>
						<textarea id="egsm_desc" name="egsm_seo[description]" rows="3" class="widefat" placeholder="Summarize the page in 120–160 characters, with the focus keyword."><?php echo esc_textarea( $seo['description'] ); ?></textarea></p>
					<div class="egsm-serp" aria-label="Google preview">
						<div class="egsm-serp-url"><?php echo esc_html( preg_replace( '#^https?://#', '', (string) get_permalink( $post ) ) ); ?></div>
						<div class="egsm-serp-title"></div>
						<div class="egsm-serp-desc"></div>
					</div>
					<details class="egsm-adv" <?php echo $seo['noindex'] || $seo['nofollow'] || $seo['canonical'] ? 'open' : ''; ?>>
						<summary>Indexing &amp; canonical</summary>
						<p><label><input type="radio" name="egsm_seo[noindex]" value="0" <?php checked( ! $seo['noindex'] ); ?>> Index — show in search results</label><br>
							<label><input type="radio" name="egsm_seo[noindex]" value="1" <?php checked( $seo['noindex'] ); ?>> Noindex — hide from search results</label></p>
						<p><label><input type="checkbox" name="egsm_seo[nofollow]" value="1" <?php checked( $seo['nofollow'] ); ?>> Nofollow all links on this page</label></p>
						<p><label for="egsm_canon">Canonical URL</label>
							<input type="url" id="egsm_canon" name="egsm_seo[canonical]" value="<?php echo esc_attr( $seo['canonical'] ); ?>" placeholder="<?php echo esc_attr( (string) get_permalink( $post ) ); ?>" class="widefat"></p>
					</details>
				</div>
				<div class="egsm-score-col">
					<div class="egsm-score-head">
						<span class="egsm-badge egsm-<?php echo esc_attr( $data['grade'] ); ?>" id="egsm-score"><?php echo (int) $data['score']; ?></span>
						<div><strong>SEO score</strong><br><span class="description" id="egsm-score-note"><?php echo $is_elementor ? 'Elementor page — updates after you save in Elementor.' : 'Updates as you edit.'; ?></span></div>
					</div>
					<div id="egsm-checks"><?php echo self::checks_html( $data['checks'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?></div>
				</div>
			</div>
		</div>
		<?php
		self::box_js();
	}

	public static function checks_html( $checks ) {
		$labels = array( 'keyword' => 'Focus keyword', 'basic' => 'Basic SEO', 'readability' => 'Readability', 'technical' => 'Technical' );
		$groups = array();
		foreach ( $checks as $c ) {
			$groups[ $c['group'] ][] = $c;
		}
		$h = '';
		foreach ( $labels as $g => $label ) {
			if ( empty( $groups[ $g ] ) ) {
				continue;
			}
			$bad = count( array_filter( $groups[ $g ], function ( $c ) {
				return 'bad' === $c['status'];
			} ) );
			$h  .= '<details class="egsm-group" ' . ( $bad ? 'open' : '' ) . '><summary>' . esc_html( $label ) . ( $bad ? ' <span class="egsm-errs">' . (int) $bad . ' to fix</span>' : ' <span class="egsm-ok">✓</span>' ) . '</summary><ul>';
			foreach ( $groups[ $g ] as $c ) {
				$h .= '<li class="egsm-c egsm-' . esc_attr( $c['status'] ) . '"><span class="egsm-dot"></span>' . esc_html( $c['message'] ) . '</li>';
			}
			$h .= '</ul></details>';
		}
		return $h;
	}

	private static function box_js() {
		?>
		<script>
		( function () {
			var box = document.getElementById( 'egsm-box' ); if ( ! box ) { return; }
			var $ = function ( id ) { return document.getElementById( id ); };
			var ajax = window.ajaxurl || '<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>';
			function count() {
				box.querySelectorAll( '.egsm-count' ).forEach( function ( c ) {
					var f = $( c.dataset.for ), v = ( f.value || f.placeholder || '' ), n = v.length;
					c.textContent = n + ' chars';
					c.className = 'egsm-count ' + ( n >= +c.dataset.min && n <= +c.dataset.max ? 'egsm-good' : ( n === 0 ? 'egsm-bad' : 'egsm-ok' ) );
				} );
				var t = $( 'egsm_title' ), d = $( 'egsm_desc' );
				var tt = t.value || t.placeholder; box.querySelector( '.egsm-serp-title' ).textContent = tt.length > 62 ? tt.slice( 0, 60 ) + '…' : tt;
				var dd = d.value || 'Google will pick text from the page when no description is set.'; box.querySelector( '.egsm-serp-desc' ).textContent = dd.length > 162 ? dd.slice( 0, 158 ) + '…' : dd;
			}
			function editorState() {
				var s = {};
				try {
					var ed = window.wp && wp.data && wp.data.select( 'core/editor' );
					if ( ed && ed.getEditedPostContent ) {
						s.content = ed.getEditedPostContent(); s.post_title = ed.getEditedPostAttribute( 'title' ) || ''; s.slug = ed.getEditedPostAttribute( 'slug' ) || '';
						return s;
					}
				} catch ( e ) {}
				if ( window.tinymce && tinymce.get( 'content' ) && ! tinymce.get( 'content' ).isHidden() ) { s.content = tinymce.get( 'content' ).getContent(); }
				else if ( $( 'content' ) ) { s.content = $( 'content' ).value; }
				if ( $( 'title' ) ) { s.post_title = $( 'title' ).value; }
				if ( $( 'post_name' ) ) { s.slug = $( 'post_name' ).value; }
				return s;
			}
			var timer = null, busy = false, last = '';
			function score() {
				if ( busy ) { return; }
				var s = editorState();
				s.keyword = $( 'egsm_kw' ).value; s.seo_title = $( 'egsm_title' ).value; s.description = $( 'egsm_desc' ).value;
				var key = JSON.stringify( s ); if ( key === last ) { return; } last = key;
				var fd = new FormData(); fd.append( 'action', 'egsm_score' ); fd.append( '_ajax_nonce', box.dataset.nonce ); fd.append( 'post_id', box.dataset.post );
				Object.keys( s ).forEach( function ( k ) { if ( s[ k ] !== undefined ) { fd.append( k, s[ k ] ); } } );
				busy = true;
				fetch( ajax, { method: 'POST', body: fd, credentials: 'same-origin' } ).then( function ( r ) { return r.json(); } ).then( function ( j ) {
					if ( ! j || ! j.success ) { return; }
					var b = $( 'egsm-score' ); b.textContent = j.data.score; b.className = 'egsm-badge egsm-' + j.data.grade;
					$( 'egsm-checks' ).innerHTML = j.data.html;
					announce();
				} ).finally( function () { busy = false; } );
			}
			function later( ms ) { clearTimeout( timer ); timer = setTimeout( score, ms ); }
			function announce() {
				var d = { score: +$( 'egsm-score' ).textContent, grade: ( $( 'egsm-score' ).className.match( /egsm-(good|ok|bad)/ ) || [] )[ 1 ], bad: box.querySelectorAll( '#egsm-checks .egsm-c.egsm-bad' ).length };
				window.egsmLastScore = d;
				window.dispatchEvent( new CustomEvent( 'egsm:score', { detail: d } ) );
			}
			announce();
			[ 'egsm_kw', 'egsm_title', 'egsm_desc' ].forEach( function ( id ) { $( id ).addEventListener( 'input', function () { count(); later( 700 ); } ); } );
			count();
			if ( window.wp && wp.data && wp.data.subscribe && wp.data.select( 'core/editor' ) ) {
				var prev = null;
				wp.data.subscribe( function () {
					var ed = wp.data.select( 'core/editor' ); if ( ! ed || ! ed.getEditedPostContent ) { return; }
					var c = ed.getEditedPostContent() + '|' + ed.getEditedPostAttribute( 'title' );
					if ( c !== prev ) { if ( prev !== null ) { later( 2500 ); } prev = c; }
				} );
			} else {
				setInterval( function () { later( 0 ); }, 15000 );
			}
		} )();
		</script>
		<?php
	}

	/** Score badge in the block editor's document sidebar (like Yoast/Rank Math), linked to the SEO panel. */
	public static function sidebar_assets() {
		if ( ! self::on() ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'post' !== $screen->base || ! in_array( $screen->post_type, EGSM_Score::types(), true ) ) {
			return;
		}
		wp_register_script( 'egsm-seo-sidebar', '', array( 'wp-plugins', 'wp-element', 'wp-data', 'wp-components', 'wp-editor', 'wp-dom-ready' ), EGSM_VERSION, true );
		wp_enqueue_script( 'egsm-seo-sidebar' );
		wp_add_inline_script( 'egsm-seo-sidebar', <<<'JS'
( function ( wp ) {
	var Panel = ( wp.editor && wp.editor.PluginDocumentSettingPanel ) || ( wp.editPost && wp.editPost.PluginDocumentSettingPanel );
	if ( ! wp.plugins || ! Panel ) { return; }
	var el = wp.element.createElement, useState = wp.element.useState, useEffect = wp.element.useEffect;
	var colors = { good: '#1e8e3e', ok: '#e37400', bad: '#d93025' };
	function openPanel() {
		try { wp.data.dispatch( 'core/preferences' ).set( 'core/edit-post', 'metaBoxesMainIsOpen', true ); } catch ( e ) {}
		setTimeout( function () { var b = document.getElementById( 'egsm-box' ); if ( b ) { b.scrollIntoView( { behavior: 'smooth', block: 'start' } ); } }, 250 );
	}
	function SeoScore() {
		var st = useState( window.egsmLastScore || null ), d = st[ 0 ], set = st[ 1 ];
		useEffect( function () {
			var h = function ( e ) { set( e.detail ); };
			window.addEventListener( 'egsm:score', h );
			return function () { window.removeEventListener( 'egsm:score', h ); };
		}, [] );
		if ( ! d ) { return el( Panel, { name: 'egsm-seo-score', title: 'SEO' }, 'Loading…' ); }
		return el( Panel, { name: 'egsm-seo-score', title: 'SEO score: ' + d.score, className: 'egsm-seo-score-panel' },
			el( 'div', { style: { display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' } },
				el( 'span', { style: { display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: '40px', height: '40px', borderRadius: '50%', color: '#fff', fontWeight: 700, background: colors[ d.grade ] || '#8c8f94' } }, d.score ),
				el( 'span', null, d.bad ? d.bad + ' issue' + ( d.bad > 1 ? 's' : '' ) + ' to fix' : 'Looking good' ) ),
			el( wp.components.Button, { variant: 'secondary', onClick: openPanel }, 'Open SEO panel' ) );
	}
	wp.plugins.registerPlugin( 'egsm-seo-score', { render: SeoScore, icon: 'chart-bar' } );
	// WP 6.7+ collapses meta boxes into a bottom drawer that starts closed. Open it for users who have never
	// toggled it (preference still unset); a user who closes it keeps it closed. The preferences store is
	// replaced when its persistence layer loads, so set after the editor is ready and re-check once.
	function ensureOpen( again ) {
		try {
			var p = wp.data.select( 'core/preferences' );
			if ( p && undefined === p.get( 'core/edit-post', 'metaBoxesMainIsOpen' ) ) {
				wp.data.dispatch( 'core/preferences' ).set( 'core/edit-post', 'metaBoxesMainIsOpen', true );
			}
		} catch ( e ) {}
		if ( again ) { setTimeout( function () { ensureOpen( false ); }, 1500 ); }
	}
	( wp.domReady || function ( f ) { document.addEventListener( 'DOMContentLoaded', f ); } )( function () { setTimeout( function () { ensureOpen( true ); }, 300 ); } );
} )( window.wp );
JS
		);
	}

	public static function css() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ! in_array( $screen->base, array( 'post', 'edit', 'settings_page_' . self::SETTINGS_SLUG, 'toplevel_page_' . self::SETTINGS_SLUG ), true ) && false === strpos( (string) $screen->id, self::SETTINGS_SLUG ) ) {
			return;
		}
		?>
		<style>
			#egsm-box .egsm-grid{display:grid;grid-template-columns:minmax(0,1.2fr) minmax(0,1fr);gap:20px}
			@media(max-width:900px){#egsm-box .egsm-grid{grid-template-columns:1fr}}
			#egsm-box .egsm-count{float:right;font-weight:600;font-size:12px}
			.egsm-good{color:#137333}.egsm-ok{color:#b06000}.egsm-bad{color:#c5221f}.egsm-info{color:#50575e}
			#egsm-box .egsm-serp{border:1px solid #dcdcde;border-radius:8px;padding:10px 12px;background:#fff;margin:6px 0 12px;font-family:arial,sans-serif}
			#egsm-box .egsm-serp-url{font-size:12px;color:#202124;word-break:break-all}
			#egsm-box .egsm-serp-title{font-size:18px;color:#1a0dab;line-height:1.3;margin:2px 0}
			#egsm-box .egsm-serp-desc{font-size:13px;color:#4d5156;line-height:1.5}
			.egsm-badge{display:inline-flex;align-items:center;justify-content:center;min-width:44px;height:44px;border-radius:50%;font-weight:700;font-size:16px;color:#fff;background:#8c8f94}
			.egsm-badge.egsm-good{background:#1e8e3e;color:#fff}.egsm-badge.egsm-ok{background:#e37400;color:#fff}.egsm-badge.egsm-bad{background:#d93025;color:#fff}
			.egsm-score-head{display:flex;gap:12px;align-items:center;margin-bottom:8px}
			#egsm-box .egsm-group{border-top:1px solid #f0f0f1;padding:6px 0}#egsm-box .egsm-group summary{cursor:pointer;font-weight:600}
			#egsm-box .egsm-errs{color:#c5221f;font-weight:600;font-size:12px}#egsm-box ul{margin:6px 0 0}
			#egsm-box .egsm-c{display:flex;gap:8px;align-items:flex-start;margin:4px 0;color:#1d2327}
			#egsm-box .egsm-dot{flex:0 0 10px;height:10px;border-radius:50%;margin-top:5px;background:#8c8f94}
			#egsm-box .egsm-c.egsm-good .egsm-dot{background:#1e8e3e}#egsm-box .egsm-c.egsm-ok .egsm-dot{background:#e37400}#egsm-box .egsm-c.egsm-bad .egsm-dot{background:#d93025}
			.column-egsm_seo{width:92px}.egsm-list-badge{display:inline-block;min-width:30px;padding:2px 6px;border-radius:10px;color:#fff;font-weight:700;text-align:center;font-size:12px;background:#8c8f94}
			.egsm-list-badge.egsm-good{background:#1e8e3e}.egsm-list-badge.egsm-ok{background:#e37400}.egsm-list-badge.egsm-bad{background:#d93025}
			.egsm-tag{display:inline-block;margin-top:3px;padding:0 5px;border-radius:3px;background:#f0f0f1;color:#50575e;font-size:11px}
		</style>
		<?php
	}

	public static function save_box( $id, $post ) {
		if ( ! isset( $_POST['egsm_box_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['egsm_box_nonce'] ), 'egsm_box' ) ) {
			return;
		}
		if ( wp_is_post_revision( $id ) || wp_is_post_autosave( $id ) || ! current_user_can( 'edit_post', $id ) ) {
			return;
		}
		$in = isset( $_POST['egsm_seo'] ) && is_array( $_POST['egsm_seo'] ) ? wp_unslash( $_POST['egsm_seo'] ) : array();
		$f  = array(
			'focus_keyword' => isset( $in['focus_keyword'] ) ? $in['focus_keyword'] : '',
			'title'         => isset( $in['title'] ) ? $in['title'] : '',
			'description'   => isset( $in['description'] ) ? $in['description'] : '',
			'canonical'     => isset( $in['canonical'] ) ? $in['canonical'] : '',
			'noindex'       => ! empty( $in['noindex'] ),
			'nofollow'      => ! empty( $in['nofollow'] ),
		);
		remove_action( 'save_post', array( __CLASS__, 'save_box' ), 20 );
		EGSM_SEO::set( $id, $f );
		add_action( 'save_post', array( __CLASS__, 'save_box' ), 20, 2 );
	}

	public static function ajax_score() {
		check_ajax_referer( 'egsm_score' );
		$id = isset( $_POST['post_id'] ) ? (int) $_POST['post_id'] : 0;
		if ( ! $id || ! current_user_can( 'edit_post', $id ) ) {
			wp_send_json_error( 'Not allowed.', 403 );
		}
		$o = array();
		foreach ( array( 'content', 'post_title', 'slug', 'seo_title', 'description', 'keyword' ) as $k ) {
			if ( isset( $_POST[ $k ] ) ) {
				$o[ $k ] = 'content' === $k ? wp_kses_post( wp_unslash( $_POST[ $k ] ) ) : sanitize_text_field( wp_unslash( $_POST[ $k ] ) );
			}
		}
		$r = EGSM_Score::analyze( get_post( $id ), $o );
		wp_send_json_success(
			array(
				'score' => $r['score'],
				'grade' => $r['grade'],
				'html'  => self::checks_html( $r['checks'] ),
			)
		);
	}

	/* =========================================================
	 * Pages / Posts lists
	 * ========================================================= */

	public static function list_hooks() {
		if ( ! self::on() ) {
			return;
		}
		foreach ( EGSM_Score::types() as $t ) {
			add_filter( "manage_{$t}_posts_columns", array( __CLASS__, 'col' ) );
			add_action( "manage_{$t}_posts_custom_column", array( __CLASS__, 'col_value' ), 10, 2 );
			add_filter( "manage_edit-{$t}_sortable_columns", array( __CLASS__, 'sortable' ) );
			add_filter( "bulk_actions-edit-{$t}", array( __CLASS__, 'bulk_actions' ) );
			add_filter( "handle_bulk_actions-edit-{$t}", array( __CLASS__, 'handle_bulk' ), 10, 3 );
		}
		add_action( 'restrict_manage_posts', array( __CLASS__, 'filter_ui' ) );
		add_action( 'pre_get_posts', array( __CLASS__, 'list_query' ) );
		add_action( 'admin_notices', array( __CLASS__, 'bulk_notice' ) );
	}

	public static function col( $cols ) {
		$out = array();
		foreach ( $cols as $k => $v ) {
			$out[ $k ] = $v;
			if ( 'title' === $k ) {
				$out['egsm_seo'] = 'SEO';
			}
		}
		if ( ! isset( $out['egsm_seo'] ) ) {
			$out['egsm_seo'] = 'SEO';
		}
		return $out;
	}

	public static function col_value( $col, $id ) {
		if ( 'egsm_seo' !== $col ) {
			return;
		}
		$s = get_post_meta( $id, '_egsm_score', true );
		if ( '' === $s ) {
			echo '<span class="egsm-list-badge" title="Not scored yet">–</span>';
		} else {
			$d  = get_post_meta( $id, '_egsm_score_data', true );
			$ti = '';
			if ( is_array( $d ) && ! empty( $d['top'] ) ) {
				$ti = implode( "\n", wp_list_pluck( $d['top'], 'message' ) );
			}
			echo '<span class="egsm-list-badge egsm-' . esc_attr( EGSM_Score::grade( (int) $s ) ) . '" title="' . esc_attr( $ti ) . '">' . (int) $s . '</span>';
		}
		if ( '1' === get_post_meta( $id, '_egsm_noindex', true ) ) {
			echo '<br><span class="egsm-tag">noindex</span>';
		}
		$kw = get_post_meta( $id, '_egsm_focus_kw', true );
		if ( $kw ) {
			echo '<br><span class="egsm-tag" title="Focus keyword">' . esc_html( mb_strimwidth( $kw, 0, 24, '…' ) ) . '</span>';
		}
	}

	public static function sortable( $cols ) {
		$cols['egsm_seo'] = 'egsm_score';
		return $cols;
	}

	public static function filter_ui( $type ) {
		if ( ! in_array( $type, EGSM_Score::types(), true ) ) {
			return;
		}
		$cur  = isset( $_GET['egsm_filter'] ) ? sanitize_key( $_GET['egsm_filter'] ) : '';
		$opts = array(
			''         => 'All SEO scores',
			'good'     => 'Good (80+)',
			'ok'       => 'Needs work (50–79)',
			'bad'      => 'Poor (under 50)',
			'nokw'     => 'No focus keyword',
			'noindex'  => 'Noindex',
			'unscored' => 'Not scored yet',
		);
		echo '<select name="egsm_filter">';
		foreach ( $opts as $k => $v ) {
			echo '<option value="' . esc_attr( $k ) . '" ' . selected( $cur, $k, false ) . '>' . esc_html( $v ) . '</option>';
		}
		echo '</select>';
	}

	public static function list_query( $q ) {
		if ( ! is_admin() || ! $q->is_main_query() ) {
			return;
		}
		if ( 'egsm_score' === $q->get( 'orderby' ) ) {
			$q->set( 'meta_key', '_egsm_score' );
			$q->set( 'orderby', 'meta_value_num' );
		}
		$f = isset( $_GET['egsm_filter'] ) ? sanitize_key( $_GET['egsm_filter'] ) : '';
		if ( '' === $f ) {
			return;
		}
		$c = EGSM_Score::filter_clause( $f );
		if ( ! $c ) {
			return;
		}
		$mq   = (array) $q->get( 'meta_query' );
		$mq[] = $c;
		$q->set( 'meta_query', $mq );
	}

	public static function bulk_actions( $a ) {
		$a['egsm_noindex'] = 'SEO: set noindex (hide from search)';
		$a['egsm_index']   = 'SEO: set index (show in search)';
		$a['egsm_rescore'] = 'SEO: recalculate score';
		return $a;
	}

	public static function handle_bulk( $redirect, $action, $ids ) {
		if ( ! in_array( $action, array( 'egsm_noindex', 'egsm_index', 'egsm_rescore' ), true ) ) {
			return $redirect;
		}
		$n = 0;
		foreach ( (array) $ids as $id ) {
			if ( ! current_user_can( 'edit_post', $id ) ) {
				continue;
			}
			if ( 'egsm_rescore' === $action ) {
				EGSM_Score::sync_flat_meta( (int) $id );
				EGSM_Score::store( (int) $id );
			} else {
				EGSM_SEO::set( (int) $id, array( 'noindex' => 'egsm_noindex' === $action ) );
			}
			$n++;
		}
		return add_query_arg( array( 'egsm_bulk' => $action, 'egsm_n' => $n ), $redirect );
	}

	public static function bulk_notice() {
		if ( empty( $_GET['egsm_bulk'] ) ) {
			return;
		}
		$n   = isset( $_GET['egsm_n'] ) ? (int) $_GET['egsm_n'] : 0;
		$map = array( 'egsm_noindex' => 'set to noindex', 'egsm_index' => 'set to index', 'egsm_rescore' => 'rescored' );
		$a   = sanitize_key( $_GET['egsm_bulk'] );
		if ( isset( $map[ $a ] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . (int) $n . ' item(s) ' . esc_html( $map[ $a ] ) . '.</p></div>';
		}
	}

	/* =========================================================
	 * Search settings screen
	 * ========================================================= */

	public static function settings_menu() {
		if ( ! self::on() ) {
			return;
		}
		if ( EGSM_SSEO::on() ) {
			add_submenu_page( 'sseo', 'Search settings', 'Search settings', 'manage_options', self::SETTINGS_SLUG, array( __CLASS__, 'settings_page' ) );
		} else {
			add_submenu_page( EGSM_Admin::SLUG, 'Search settings', 'Search settings', 'manage_options', self::SETTINGS_SLUG, array( __CLASS__, 'settings_page' ) );
		}
	}

	public static function save_settings() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'egsm_search' ) ) {
			wp_die( 'Not allowed.' );
		}
		$p = isset( $_POST['egsm'] ) && is_array( $_POST['egsm'] ) ? wp_unslash( $_POST['egsm'] ) : array();
		foreach ( array( 'noindex_author', 'noindex_date', 'link_external_newtab', 'indexnow' ) as $b ) {
			$p[ $b ] = ! empty( $p[ $b ] );
		}
		$p['noindex_tax']           = isset( $p['noindex_tax'] ) ? array_keys( (array) $p['noindex_tax'] ) : array();
		$p['sitemap_exclude_types'] = isset( $p['sitemap_exclude_types'] ) ? array_keys( (array) $p['sitemap_exclude_types'] ) : array();
		$p['sitemap_exclude_tax']   = isset( $p['sitemap_exclude_tax'] ) ? array_keys( (array) $p['sitemap_exclude_tax'] ) : array();
		EGSM_SEO_Settings::update( $p );
		wp_safe_redirect( add_query_arg( 'saved', 1, wp_get_referer() ) );
		exit;
	}

	public static function settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s     = EGSM_SEO_Settings::all();
		$taxes = get_taxonomies( array( 'public' => true ), 'objects' );
		$types = get_post_types( array( 'public' => true ), 'objects' );
		unset( $types['attachment'] );
		$cursor = (int) get_option( 'egsm_score_cursor', 0 );
		?>
		<div class="wrap" style="max-width:900px">
			<h1>Search settings</h1>
			<?php if ( ! empty( $_GET['saved'] ) ) : ?><div class="notice notice-success"><p>Saved.</p></div><?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'egsm_search' ); ?><input type="hidden" name="action" value="egsm_save_search">
				<h2>Homepage (when it shows your latest posts)</h2>
				<table class="form-table">
					<tr><th><label for="egsm_ht">SEO title</label></th><td><input class="regular-text" id="egsm_ht" name="egsm[home_title]" value="<?php echo esc_attr( $s['home_title'] ); ?>" placeholder="<?php echo esc_attr( get_bloginfo( 'name' ) . ' – ' . get_bloginfo( 'description' ) ); ?>"></td></tr>
					<tr><th><label for="egsm_hd">Meta description</label></th><td><textarea class="large-text" rows="2" id="egsm_hd" name="egsm[home_description]"><?php echo esc_textarea( $s['home_description'] ); ?></textarea>
						<p class="description">When the homepage is a static page, edit that page's SEO panel instead. The blog page uses its own page's SEO panel too.</p></td></tr>
				</table>
				<h2>Social sharing</h2>
				<table class="form-table">
					<tr><th><label for="egsm_ogi">Default share image</label></th><td><input class="large-text" type="url" id="egsm_ogi" name="egsm[default_og_image]" value="<?php echo esc_attr( $s['default_og_image'] ); ?>" placeholder="https://…/photo.jpg">
						<p class="description">Shown on Facebook, LinkedIn and in text-message previews for any page that has no share image and no featured image of its own. Without it, those pages show the site icon. Use a photo at least 1200×630.</p></td></tr>
				</table>
				<h2>Archives in search results</h2>
				<table class="form-table">
					<tr><th>Hide from search (noindex)</th><td>
						<?php foreach ( $taxes as $t ) : ?>
							<label style="display:block"><input type="checkbox" name="egsm[noindex_tax][<?php echo esc_attr( $t->name ); ?>]" value="1" <?php checked( ! empty( $s['noindex_tax'][ $t->name ] ) ); ?>> <?php echo esc_html( $t->labels->name ); ?> archives</label>
						<?php endforeach; ?>
						<label style="display:block"><input type="checkbox" name="egsm[noindex_author]" value="1" <?php checked( $s['noindex_author'] ); ?>> Author archives (recommended for single-author sites)</label>
						<label style="display:block"><input type="checkbox" name="egsm[noindex_date]" value="1" <?php checked( $s['noindex_date'] ); ?>> Date archives (recommended)</label>
						<p class="description">Each category/tag also has its own SEO title, description and noindex on its edit screen.</p></td></tr>
				</table>
				<h2>Sitemap</h2>
				<p>Your sitemap: <a href="<?php echo esc_url( get_sitemap_url( 'index' ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( get_sitemap_url( 'index' ) ); ?></a>. Noindexed pages, categories and archives are left out automatically.</p>
				<table class="form-table">
					<tr><th>Leave out content types</th><td>
						<?php foreach ( $types as $t ) : ?>
							<label style="display:block"><input type="checkbox" name="egsm[sitemap_exclude_types][<?php echo esc_attr( $t->name ); ?>]" value="1" <?php checked( in_array( $t->name, $s['sitemap_exclude_types'], true ) ); ?>> <?php echo esc_html( $t->labels->name ); ?></label>
						<?php endforeach; ?></td></tr>
					<tr><th>Leave out taxonomies</th><td>
						<?php foreach ( $taxes as $t ) : ?>
							<label style="display:block"><input type="checkbox" name="egsm[sitemap_exclude_tax][<?php echo esc_attr( $t->name ); ?>]" value="1" <?php checked( in_array( $t->name, $s['sitemap_exclude_tax'], true ) ); ?>> <?php echo esc_html( $t->labels->name ); ?></label>
						<?php endforeach; ?></td></tr>
				</table>
				<h2>Links</h2>
				<table class="form-table">
					<tr><th><label for="egsm_ext">All external links</label></th><td><select id="egsm_ext" name="egsm[link_external_rel]">
						<?php foreach ( array( '' => 'Follow (default)', 'nofollow' => 'Nofollow', 'sponsored' => 'Sponsored', 'nofollow sponsored' => 'Nofollow + sponsored' ) as $k => $v ) : ?>
							<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $s['link_external_rel'], $k ); ?>><?php echo esc_html( $v ); ?></option>
						<?php endforeach; ?></select>
						<label style="display:block;margin-top:6px"><input type="checkbox" name="egsm[link_external_newtab]" value="1" <?php checked( $s['link_external_newtab'] ); ?>> Open external links in a new tab</label></td></tr>
					<tr><th><label for="egsm_rules">Rules by domain</label></th><td><textarea id="egsm_rules" class="large-text code" rows="5" name="egsm[link_rules]" placeholder="amazon.com, amzn.to = sponsored nofollow&#10;partner-site.com = sponsored"><?php echo esc_textarea( EGSM_SEO_Settings::rules_to_text( $s['link_rules'] ) ); ?></textarea>
						<p class="description">One rule per line: <code>domains = nofollow | sponsored | ugc</code>. Subdomains match too. A link you mark yourself in the editor (Link attributes, or core's "Mark as nofollow") always wins. Rules apply when pages are shown; your saved content is not changed.</p></td></tr>
				</table>
				<h2>Instant indexing</h2>
				<table class="form-table"><tr><th>IndexNow</th><td><label><input type="checkbox" name="egsm[indexnow]" value="1" <?php checked( $s['indexnow'] ); ?>> Notify Bing, Yandex and other IndexNow search engines when content is published, updated or removed</label>
					<p class="description">Google does not use IndexNow; it finds changes through the sitemap.</p></td></tr></table>
				<?php submit_button( 'Save search settings' ); ?>
			</form>
			<h2>SEO scores</h2>
			<p>Scores update whenever content is saved. Existing pages and posts are scored in the background after installing or updating; you can also run it now.</p>
			<p><button type="button" class="button" id="egsm-rescore">Score all pages and posts now</button> <span id="egsm-rescore-status"><?php echo -1 === $cursor ? 'All content has been scored.' : ''; ?></span></p>
			<script>
			document.getElementById( 'egsm-rescore' ).addEventListener( 'click', function () {
				var btn = this, st = document.getElementById( 'egsm-rescore-status' ), done = 0, first = true; btn.disabled = true;
				function step() {
					var fd = new FormData(); fd.append( 'action', 'egsm_score_batch' ); fd.append( '_ajax_nonce', '<?php echo esc_js( wp_create_nonce( 'egsm_score_batch' ) ); ?>' ); if ( first ) { fd.append( 'restart', '1' ); first = false; }
					fetch( ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' } ).then( function ( r ) { return r.json(); } ).then( function ( j ) {
						if ( ! j.success ) { st.textContent = 'Stopped: ' + ( j.data || 'error' ); btn.disabled = false; return; }
						done += j.data.scored; st.textContent = done + ' scored, ' + j.data.remaining + ' left…';
						if ( j.data.done ) { st.textContent = 'Done — ' + done + ' scored.'; btn.disabled = false; } else { step(); }
					} );
				}
				step();
			} );
			</script>
		</div>
		<?php
	}

	public static function ajax_batch() {
		check_ajax_referer( 'egsm_score_batch' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Not allowed.', 403 );
		}
		if ( ! empty( $_POST['restart'] ) ) {
			update_option( 'egsm_score_cursor', 0, false );
		}
		wp_send_json_success( EGSM_Score::backfill_batch( 25 ) );
	}
}
