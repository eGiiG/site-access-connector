<?php
/**
 * Custom tables: change log, redirects, 404 log.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_DB {

	public static function table( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'egsm_' . $name;
	}

	public static function activate() {
		self::install();
		if ( class_exists( 'EGSM_Score' ) ) {
			EGSM_Score::start_backfill();
		}
		if ( ! get_option( 'egsm_level' ) ) {
			add_option( 'egsm_level', 'publish', '', false );
		}
		if ( function_exists( 'wp_get_current_user' ) && current_user_can( 'manage_options' ) && ! get_option( 'egsm_service_user' ) ) {
			update_option( 'egsm_service_user', get_current_user_id(), false );
		}
	}

	public static function maybe_upgrade() {
		if ( get_option( 'egsm_db_version' ) !== EGSM_DB_VERSION ) {
			self::install();
			// Score every existing page/post in the background (batches via WP-Cron).
			if ( class_exists( 'EGSM_Score' ) ) {
				EGSM_Score::start_backfill();
			}
		}
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();

		$changes   = self::table( 'changes' );
		$redirects = self::table( 'redirects' );
		$log404    = self::table( '404' );

		dbDelta(
			"CREATE TABLE {$changes} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			created_at datetime NOT NULL,
			actor varchar(100) NOT NULL DEFAULT '',
			action varchar(60) NOT NULL DEFAULT '',
			object_type varchar(30) NOT NULL DEFAULT '',
			object_id bigint(20) NOT NULL DEFAULT 0,
			summary text NULL,
			before_state longtext NULL,
			after_state longtext NULL,
			reverted_at datetime NULL,
			revert_change_id bigint(20) unsigned NULL,
			PRIMARY KEY  (id),
			KEY object_idx (object_type,object_id),
			KEY created_idx (created_at)
			) {$charset};"
		);

		dbDelta(
			"CREATE TABLE {$redirects} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			source varchar(255) NOT NULL DEFAULT '',
			target text NOT NULL,
			code smallint(5) unsigned NOT NULL DEFAULT 301,
			hits bigint(20) unsigned NOT NULL DEFAULT 0,
			last_hit datetime NULL,
			note varchar(191) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY source_idx (source(191))
			) {$charset};"
		);

		dbDelta(
			"CREATE TABLE {$log404} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			path varchar(255) NOT NULL DEFAULT '',
			hits bigint(20) unsigned NOT NULL DEFAULT 1,
			referrer varchar(255) NOT NULL DEFAULT '',
			first_seen datetime NOT NULL,
			last_seen datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY path_idx (path(191)),
			KEY last_idx (last_seen)
			) {$charset};"
		);

		update_option( 'egsm_db_version', EGSM_DB_VERSION, false );
	}
}
