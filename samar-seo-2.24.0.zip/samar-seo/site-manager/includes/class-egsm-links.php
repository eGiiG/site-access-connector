<?php
/**
 * Link relationship control.
 *
 *  - Per link (block editor): a "Link attributes" control on any selected link to mark it
 *    nofollow / sponsored / ugc, force "follow" (overrides site rules) or open in a new tab.
 *    Core's own "Mark as nofollow" in the link popover keeps working alongside it.
 *  - Site rules, applied when the page is displayed (stored content is not rewritten):
 *    domain rules (e.g. "amazon.com, amzn.to = sponsored nofollow"), a default for all external links,
 *    and optional new-tab for external links (with noopener).
 *  - An explicit rel on a link always wins over the rules. rel="follow" is our marker for
 *    "follow this link even if a rule matches"; it is removed from the output.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Links {

	const EXPLICIT = array( 'nofollow', 'sponsored', 'ugc' );

	public static function init() {
		add_filter( 'the_content', array( __CLASS__, 'filter_content' ), 99 );
		add_filter( 'widget_block_content', array( __CLASS__, 'filter_content' ), 99 );
		add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'editor_assets' ) );
	}

	private static function active_rules() {
		$s = EGSM_SEO_Settings::all();
		return array(
			'rules'  => (array) $s['link_rules'],
			'ext'    => (string) $s['link_external_rel'],
			'newtab' => ! empty( $s['link_external_newtab'] ),
		);
	}

	private static function host_matches( $host, $domain ) {
		return $host === $domain || ( strlen( $host ) > strlen( $domain ) && substr( $host, -strlen( $domain ) - 1 ) === '.' . $domain );
	}

	public static function filter_content( $html ) {
		if ( ! is_string( $html ) || false === stripos( $html, '<a ' ) ) {
			return $html;
		}
		$cfg = self::active_rules();
		if ( ! $cfg['rules'] && '' === $cfg['ext'] && ! $cfg['newtab'] && false === stripos( $html, 'follow' ) ) {
			return $html;
		}
		return self::apply( $html, $cfg );
	}

	public static function apply( $html, $cfg ) {
		$home = preg_replace( '/^www\./', '', EGSM_Util::home_host() );
		return preg_replace_callback(
			'#<a\s([^>]*)>#i',
			function ( $m ) use ( $cfg, $home ) {
				$attrs = $m[1];
				$href  = EGSM_Util::attr( '<a ' . $attrs . '>', 'href' );
				if ( null === $href ) {
					return $m[0];
				}
				$rel_raw = (string) EGSM_Util::attr( '<a ' . $attrs . '>', 'rel' );
				$rel     = array_values( array_filter( preg_split( '/\s+/', strtolower( trim( $rel_raw ) ) ) ) );
				$forced  = in_array( 'follow', $rel, true ) || in_array( 'dofollow', $rel, true );
				$rel     = array_values( array_diff( $rel, array( 'follow', 'dofollow' ) ) );
				$host    = strtolower( preg_replace( '/^www\./', '', (string) wp_parse_url( $href, PHP_URL_HOST ) ) );
				$external = '' !== $host && $host !== $home && preg_match( '#^(https?:)?//#i', $href );
				$target  = EGSM_Util::attr( '<a ' . $attrs . '>', 'target' );

				if ( ! $forced && ! array_intersect( $rel, self::EXPLICIT ) && $external ) {
					$add = array();
					foreach ( $cfg['rules'] as $r ) {
						foreach ( $r['domains'] as $d ) {
							if ( self::host_matches( $host, $d ) ) {
								$add = preg_split( '/\s+/', $r['rel'] );
								break 2;
							}
						}
					}
					if ( ! $add && '' !== $cfg['ext'] ) {
						$add = preg_split( '/\s+/', $cfg['ext'] );
					}
					$rel = array_values( array_unique( array_merge( $rel, array_diff( $add, array( 'follow' ) ) ) ) );
				}
				if ( $external && $cfg['newtab'] && null === $target ) {
					$attrs .= ' target="_blank"';
					$target = '_blank';
				}
				if ( '_blank' === $target && ! in_array( 'noopener', $rel, true ) ) {
					$rel[] = 'noopener';
				}
				$attrs = preg_replace( '/\srel\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', ' ' . $attrs );
				$attrs = trim( $attrs );
				if ( $rel ) {
					$attrs .= ' rel="' . esc_attr( implode( ' ', $rel ) ) . '"';
				}
				return '<a ' . $attrs . '>';
			},
			$html
		);
	}

	/* ---------- block editor control ---------- */

	public static function editor_assets() {
		if ( 'rankmath' === EGSM_SEO::active_plugin() ) {
			return; // Rank Math ships its own link attribute controls.
		}
		wp_register_script( 'egsm-link-rel', '', array( 'wp-rich-text', 'wp-block-editor', 'wp-element', 'wp-components' ), EGSM_VERSION, true );
		wp_enqueue_script( 'egsm-link-rel' );
		wp_add_inline_script( 'egsm-link-rel', self::editor_js() );
	}

	private static function editor_js() {
		return <<<'JS'
( function ( wp ) {
	if ( ! wp || ! wp.richText || ! wp.blockEditor ) { return; }
	var el = wp.element.createElement, useState = wp.element.useState;
	var rt = wp.richText, C = wp.components;
	var EXPLICIT = [ 'nofollow', 'sponsored', 'ugc' ];

	function linkAt( value ) {
		var i = value.start, f = value.formats || [];
		var at = function ( k ) { return ( f[ k ] || [] ).filter( function ( x ) { return x.type === 'core/link'; } )[ 0 ]; };
		var cur = at( i ) || at( i - 1 );
		if ( ! cur ) { return null; }
		var url = cur.attributes && cur.attributes.url;
		var same = function ( k ) { var x = at( k ); return x && x.attributes && x.attributes.url === url; };
		var s = value.start, e = value.end;
		if ( s === e ) {
			s = same( i ) ? i : i - 1;
			e = s;
			while ( s > 0 && same( s - 1 ) ) { s--; }
			while ( e < f.length && same( e ) ) { e++; }
		}
		return { format: cur, start: s, end: e };
	}

	rt.registerFormatType( 'egsm/link-rel', {
		title: 'Link attributes',
		tagName: 'span',
		className: 'egsm-link-rel',
		edit: function ( props ) {
			var st = useState( false ), open = st[ 0 ], setOpen = st[ 1 ];
			var hit = linkAt( props.value );
			if ( ! hit ) { return null; }
			var attrs = hit.format.attributes || {};
			var rel = ( attrs.rel || '' ).split( /\s+/ ).filter( Boolean );
			var has = function ( t ) { return rel.indexOf( t ) !== -1; };
			function apply( next, target ) {
				var a = Object.assign( {}, attrs );
				var r = next.filter( function ( t, k ) { return next.indexOf( t ) === k; } );
				if ( target !== undefined ) {
					if ( target ) { a.target = '_blank'; if ( r.indexOf( 'noopener' ) === -1 ) { r.push( 'noopener' ); } }
					else { delete a.target; r = r.filter( function ( t ) { return t !== 'noopener' && t !== 'noreferrer'; } ); }
				}
				if ( r.length ) { a.rel = r.join( ' ' ); } else { delete a.rel; }
				props.onChange( rt.applyFormat( props.value, { type: 'core/link', attributes: a }, hit.start, hit.end ) );
			}
			function toggle( t, on ) {
				var r = rel.filter( function ( x ) { return x !== t; } );
				if ( on ) {
					if ( t === 'follow' ) { r = r.filter( function ( x ) { return EXPLICIT.indexOf( x ) === -1; } ); }
					else { r = r.filter( function ( x ) { return x !== 'follow'; } ); }
					r.push( t );
				}
				apply( r );
			}
			var box = function ( t, label, help ) {
				return el( C.CheckboxControl, { key: t, label: label, help: help, checked: has( t ), onChange: function ( v ) { toggle( t, v ); } } );
			};
			return el( wp.element.Fragment, null,
				el( wp.blockEditor.RichTextToolbarButton, {
					name: 'link', icon: 'admin-generic', title: 'Link attributes (nofollow, sponsored…)',
					onClick: function () { setOpen( true ); }, isActive: open
				} ),
				open && el( C.Modal, { title: 'Link attributes', onRequestClose: function () { setOpen( false ); }, className: 'egsm-link-rel-modal' },
					el( 'p', { style: { marginTop: 0, wordBreak: 'break-all' } }, attrs.url || '' ),
					box( 'nofollow', 'Nofollow', 'Do not pass ranking credit to this page.' ),
					box( 'sponsored', 'Sponsored', 'Paid, affiliate or advertising link.' ),
					box( 'ugc', 'UGC', 'User-generated content (comments, forum posts).' ),
					box( 'follow', 'Always follow', 'Ignore the site’s nofollow rules for this link.' ),
					el( C.CheckboxControl, { label: 'Open in new tab', checked: attrs.target === '_blank', onChange: function ( v ) { apply( rel, v ); } } ),
					el( C.Button, { variant: 'primary', onClick: function () { setOpen( false ); } }, 'Done' )
				)
			);
		}
	} );
} )( window.wp );
JS;
	}
}
