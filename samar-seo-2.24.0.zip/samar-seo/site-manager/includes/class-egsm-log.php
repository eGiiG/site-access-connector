<?php
/**
 * Change log with before/after state and one-click revert.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Log {

	const POST_FIELDS = array( 'post_title', 'post_content', 'post_excerpt', 'post_status', 'post_name', 'post_parent', 'menu_order', 'post_author', 'post_password', 'post_date', 'post_date_gmt' );
	const SKIP_META   = array( '_edit_lock', '_edit_last', '_encloseme', '_pingme' );

	/* ---------- snapshots ---------- */

	public static function snapshot_post( $id ) {
		$post = get_post( $id );
		if ( ! $post ) {
			return null;
		}
		$fields = array();
		foreach ( self::POST_FIELDS as $f ) {
			$fields[ $f ] = $post->$f;
		}
		$meta = array();
		foreach ( (array) get_post_meta( $id ) as $k => $vals ) {
			if ( in_array( $k, self::SKIP_META, true ) ) {
				continue;
			}
			$meta[ $k ] = array_values( (array) $vals );
		}
		$terms = array();
		foreach ( get_object_taxonomies( $post->post_type ) as $tax ) {
			$ids = wp_get_object_terms( $id, $tax, array( 'fields' => 'ids' ) );
			if ( ! is_wp_error( $ids ) ) {
				sort( $ids );
				$terms[ $tax ] = array_map( 'intval', $ids );
			}
		}
		$snap = array(
			'post'  => $fields,
			'meta'  => $meta,
			'terms' => $terms,
		);
		$aioseo = EGSM_SEO::aioseo_row( $id );
		if ( null !== $aioseo ) {
			$snap['aioseo'] = $aioseo;
		}
		return $snap;
	}

	/** Keep only the parts that differ between two post snapshots. */
	private static function diff_post( $before, $after ) {
		$b = array(
			'post'  => array(),
			'meta'  => array(),
			'terms' => array(),
		);
		$a = $b;
		foreach ( self::POST_FIELDS as $f ) {
			if ( (string) $before['post'][ $f ] !== (string) $after['post'][ $f ] ) {
				$b['post'][ $f ] = $before['post'][ $f ];
				$a['post'][ $f ] = $after['post'][ $f ];
			}
		}
		$keys = array_unique( array_merge( array_keys( $before['meta'] ), array_keys( $after['meta'] ) ) );
		foreach ( $keys as $k ) {
			$bv = isset( $before['meta'][ $k ] ) ? $before['meta'][ $k ] : null;
			$av = isset( $after['meta'][ $k ] ) ? $after['meta'][ $k ] : null;
			if ( $bv !== $av ) {
				$b['meta'][ $k ] = $bv;
				$a['meta'][ $k ] = $av;
			}
		}
		$taxes = array_unique( array_merge( array_keys( $before['terms'] ), array_keys( $after['terms'] ) ) );
		foreach ( $taxes as $t ) {
			$bv = isset( $before['terms'][ $t ] ) ? $before['terms'][ $t ] : array();
			$av = isset( $after['terms'][ $t ] ) ? $after['terms'][ $t ] : array();
			if ( $bv !== $av ) {
				$b['terms'][ $t ] = $bv;
				$a['terms'][ $t ] = $av;
			}
		}
		$ba = isset( $before['aioseo'] ) ? $before['aioseo'] : null;
		$aa = isset( $after['aioseo'] ) ? $after['aioseo'] : null;
		if ( $ba !== $aa ) {
			$b['aioseo'] = $ba;
			$a['aioseo'] = $aa;
		}
		$empty = empty( $b['post'] ) && empty( $b['meta'] ) && empty( $b['terms'] ) && ! array_key_exists( 'aioseo', $b );
		return $empty ? null : array( $b, $a );
	}

	/* ---------- recording ---------- */

	public static function record( $action, $type, $object_id, $before, $after, $summary = '' ) {
		global $wpdb;
		$wpdb->insert(
			EGSM_DB::table( 'changes' ),
			array(
				'created_at'   => EGSM_Util::now(),
				'actor'        => substr( EGSM_Auth::actor(), 0, 100 ),
				'action'       => substr( $action, 0, 60 ),
				'object_type'  => $type,
				'object_id'    => (int) $object_id,
				'summary'      => $summary,
				'before_state' => null === $before ? null : wp_json_encode( $before ),
				'after_state'  => null === $after ? null : wp_json_encode( $after ),
			)
		);
		return (int) $wpdb->insert_id;
	}

	/** Record a post edit given the snapshot taken before it. Returns change id or 0 if nothing changed. */
	public static function post_changed( $action, $id, $before, $summary = '' ) {
		$after = self::snapshot_post( $id );
		if ( null === $before ) {
			return self::record( $action, 'post', $id, null, array( 'post' => array( 'post_status' => $after ? $after['post']['post_status'] : '' ) ), $summary );
		}
		$diff = self::diff_post( $before, $after );
		if ( null === $diff ) {
			return 0;
		}
		return self::record( $action, 'post', $id, $diff[0], $diff[1], $summary );
	}

	/** Undo everything done to a post since $before was taken (used when a multi-step edit fails). */
	public static function rollback( $id, $before ) {
		$after = self::snapshot_post( $id );
		if ( ! $after || ! $before ) {
			return;
		}
		$diff = self::diff_post( $before, $after );
		if ( null !== $diff ) {
			self::revert_post( $id, $diff[0], $diff[1], true );
		}
	}

	/* ---------- listing ---------- */

	public static function list_changes( $args ) {
		global $wpdb;
		$t     = EGSM_DB::table( 'changes' );
		$where = array( '1=1' );
		$vals  = array();
		if ( ! empty( $args['object_type'] ) ) {
			$where[] = 'object_type = %s';
			$vals[]  = $args['object_type'];
		}
		if ( ! empty( $args['object_id'] ) ) {
			$where[] = 'object_id = %d';
			$vals[]  = (int) $args['object_id'];
		}
		$limit  = max( 1, min( 200, (int) ( isset( $args['limit'] ) ? $args['limit'] : 50 ) ) );
		$offset = max( 0, (int) ( isset( $args['offset'] ) ? $args['offset'] : 0 ) );
		$sql    = "SELECT id, created_at, actor, action, object_type, object_id, summary, reverted_at, revert_change_id FROM {$t} WHERE " . implode( ' AND ', $where ) . " ORDER BY id DESC LIMIT {$limit} OFFSET {$offset}";
		$rows   = $vals ? $wpdb->get_results( $wpdb->prepare( $sql, $vals ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A );
		foreach ( $rows as &$r ) {
			$r['id']          = (int) $r['id'];
			$r['object_id']   = (int) $r['object_id'];
			$r['revertable']  = empty( $r['reverted_at'] ) && self::is_revertable_action( $r['action'] );
			$r['created_at'] .= 'Z';
		}
		return $rows;
	}

	public static function get( $id ) {
		global $wpdb;
		$t = EGSM_DB::table( 'changes' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ), ARRAY_A );
	}

	private static function is_revertable_action( $action ) {
		return ! in_array( $action, array( 'revert', 'update_plugin', 'update_theme', 'cache_purge', 'key_rotated', 'menu_delete', 'paired', 'agency_login', 'ability_run' ), true );
	}

	/* ---------- revert ---------- */

	/** @return array|WP_Error */
	public static function revert( $change_id, $force = false ) {
		global $wpdb;
		$row = self::get( $change_id );
		if ( ! $row ) {
			return new WP_Error( 'egsm_not_found', 'Change not found.', array( 'status' => 404 ) );
		}
		if ( ! empty( $row['reverted_at'] ) ) {
			return new WP_Error( 'egsm_already_reverted', 'This change was already reverted.', array( 'status' => 409 ) );
		}
		if ( ! self::is_revertable_action( $row['action'] ) ) {
			return new WP_Error( 'egsm_not_revertable', 'This kind of change cannot be reverted automatically.', array( 'status' => 400 ) );
		}
		$before = null === $row['before_state'] ? null : json_decode( $row['before_state'], true );
		$after  = null === $row['after_state'] ? null : json_decode( $row['after_state'], true );
		$id     = (int) $row['object_id'];

		switch ( $row['object_type'] ) {
			case 'post':
				$res = self::revert_post( $id, $before, $after, $force );
				break;
			case 'option':
				$res = self::revert_option( $before );
				break;
			case 'redirect':
				$res = EGSM_Redirects::revert_row( $id, $before, $after );
				break;
			case 'sseo_redirect':
				EGSM_SSEO::redirect_restore( $id, $before );
				$res = true;
				break;
			case 'term':
				$res = self::revert_term( $id, $before );
				break;
			case 'user':
				$res = self::revert_user( $id, $before );
				break;
			default:
				$res = new WP_Error( 'egsm_not_revertable', 'Unknown change type.', array( 'status' => 400 ) );
		}
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$revert_id = self::record( 'revert', $row['object_type'], $id, null, null, 'Reverted change #' . $change_id );
		$wpdb->update(
			EGSM_DB::table( 'changes' ),
			array(
				'reverted_at'      => EGSM_Util::now(),
				'revert_change_id' => $revert_id,
			),
			array( 'id' => $change_id )
		);
		if ( 'post' === $row['object_type'] ) {
			EGSM_Cache::purge_post( $id );
		}
		return array(
			'reverted'         => (int) $change_id,
			'revert_change_id' => $revert_id,
			'object_type'      => $row['object_type'],
			'object_id'        => $id,
		);
	}

	private static function revert_post( $id, $before, $after, $force ) {
		$post = get_post( $id );
		if ( null === $before ) {
			// The change created this object.
			if ( ! $post ) {
				return true;
			}
			if ( in_array( $post->post_type, array( 'attachment', 'nav_menu_item' ), true ) ) {
				if ( 'attachment' === $post->post_type ) {
					wp_delete_attachment( $id, true );
				} else {
					wp_delete_post( $id, true );
				}
				return true;
			}
			wp_trash_post( $id );
			return true;
		}
		if ( ! $post ) {
			return new WP_Error( 'egsm_gone', 'The post no longer exists.', array( 'status' => 410 ) );
		}

		$current = self::snapshot_post( $id );
		if ( ! $force ) {
			$conflicts = array();
			foreach ( (array) $after['post'] as $f => $v ) {
				if ( (string) $current['post'][ $f ] !== (string) $v ) {
					$conflicts[] = 'post.' . $f;
				}
			}
			foreach ( (array) $after['meta'] as $k => $v ) {
				$cv = isset( $current['meta'][ $k ] ) ? $current['meta'][ $k ] : null;
				if ( $cv !== $v && 0 !== strpos( $k, '_wp_trash_meta' ) && '_wp_desired_post_slug' !== $k ) {
					$conflicts[] = 'meta.' . $k;
				}
			}
			if ( $conflicts ) {
				return new WP_Error(
					'egsm_conflict',
					'The content was edited after this change. Revert with force=true to overwrite those newer edits.',
					array(
						'status'    => 409,
						'conflicts' => $conflicts,
					)
				);
			}
		}

		if ( 'trash' === $post->post_status && isset( $before['post']['post_status'] ) && 'trash' !== $before['post']['post_status'] ) {
			wp_untrash_post( $id );
		}

		if ( ! empty( $before['post'] ) ) {
			$fields       = $before['post'];
			$fields['ID'] = $id;
			if ( isset( $fields['post_date'] ) ) {
				$fields['edit_date'] = true;
			}
			$r = wp_update_post( wp_slash( $fields ), true );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		foreach ( (array) $before['meta'] as $k => $vals ) {
			delete_post_meta( $id, $k );
			if ( null === $vals ) {
				continue;
			}
			foreach ( $vals as $raw ) {
				add_post_meta( $id, $k, EGSM_Util::deep_slash( maybe_unserialize( $raw ) ) );
			}
		}
		foreach ( (array) $before['terms'] as $tax => $ids ) {
			wp_set_object_terms( $id, array_map( 'intval', (array) $ids ), $tax );
		}
		if ( array_key_exists( 'aioseo', $before ) ) {
			EGSM_SEO::restore_aioseo_row( $id, $before['aioseo'] );
		}
		if ( ! empty( $before['meta'] ) && isset( $before['meta']['_elementor_data'] ) ) {
			EGSM_Elementor::clear_css( $id );
		}
		clean_post_cache( $id );
		return true;
	}

	private static function revert_option( $before ) {
		foreach ( (array) $before as $name => $state ) {
			if ( empty( $state['exists'] ) ) {
				delete_option( $name );
			} else {
				update_option( $name, $state['value'] );
			}
		}
		return true;
	}

	public static function option_state( $names ) {
		$out = array();
		foreach ( (array) $names as $n ) {
			$sentinel  = '__egsm_missing__';
			$v         = get_option( $n, $sentinel );
			$out[ $n ] = $sentinel === $v ? array( 'exists' => false ) : array(
				'exists' => true,
				'value'  => $v,
			);
		}
		return $out;
	}

	private static function revert_term( $id, $before ) {
		if ( null === $before ) {
			$term = get_term( $id );
			if ( $term && ! is_wp_error( $term ) ) {
				wp_delete_term( $id, $term->taxonomy );
			}
			return true;
		}
		$r = wp_update_term( $id, $before['taxonomy'], wp_slash( $before['fields'] ) );
		if ( isset( $before['seo'] ) && class_exists( 'EGSM_Archive' ) ) {
			EGSM_Archive::set_term_seo( $id, $before['seo'] );
		}
		return is_wp_error( $r ) ? $r : true;
	}

	private static function revert_user( $id, $before ) {
		$data       = (array) $before;
		$data['ID'] = $id;
		$r          = wp_update_user( wp_slash( $data ) );
		return is_wp_error( $r ) ? $r : true;
	}
}
