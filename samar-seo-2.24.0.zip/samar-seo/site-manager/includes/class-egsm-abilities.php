<?php
/**
 * Plugin actions: lets the agency platform discover and run actions that other plugins
 * register with the WordPress Abilities API (WordPress 6.9+), e.g. "levelup-events/create-event".
 *
 * This is the generic bridge: any plugin on any client site that registers abilities becomes
 * usable from the platform with no plugin-specific code here.
 *
 * Access levels (the site owner's connection level still applies):
 *   readonly ability            -> read
 *   ability that changes things -> publish
 *   destructive ability         -> full
 * The ability's own permission_callback runs too (signed requests act as the site's
 * service administrator, see EGSM_Auth).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Abilities {

	/** Abilities that exist only to describe WordPress itself; hidden unless asked for. */
	const CORE_PREFIX = 'core/';

	public static function available() {
		return function_exists( 'wp_get_abilities' ) && function_exists( 'wp_get_ability' );
	}

	private static function unavailable() {
		return new WP_Error(
			'egsm_abilities_unavailable',
			'This site has no plugin actions: it needs WordPress 6.9 or newer (it runs ' . get_bloginfo( 'version' ) . ').',
			array( 'status' => 501 )
		);
	}

	/** Access level an ability needs, from its annotations. */
	public static function level_for( $ability ) {
		$meta = method_exists( $ability, 'get_meta' ) ? (array) $ability->get_meta() : array();
		$ann  = isset( $meta['annotations'] ) && is_array( $meta['annotations'] ) ? $meta['annotations'] : array();
		if ( ! empty( $ann['destructive'] ) ) {
			return 'full';
		}
		if ( ! empty( $ann['readonly'] ) ) {
			return 'read';
		}
		return 'publish';
	}

	private static function describe( $ability ) {
		$meta = method_exists( $ability, 'get_meta' ) ? (array) $ability->get_meta() : array();
		$ann  = isset( $meta['annotations'] ) && is_array( $meta['annotations'] ) ? $meta['annotations'] : array();
		return array(
			'name'          => $ability->get_name(),
			'label'         => $ability->get_label(),
			'description'   => $ability->get_description(),
			'category'      => method_exists( $ability, 'get_category' ) ? $ability->get_category() : '',
			'level'         => self::level_for( $ability ),
			'allowed'       => EGSM_Settings::level_allows( self::level_for( $ability ) ),
			'readonly'      => ! empty( $ann['readonly'] ),
			'destructive'   => ! empty( $ann['destructive'] ),
			'idempotent'    => ! empty( $ann['idempotent'] ),
			'input_schema'  => $ability->get_input_schema(),
		);
	}

	/** GET /actions?category=&search=&include_core=1 */
	public static function list_actions( WP_REST_Request $req ) {
		if ( ! self::available() ) {
			return self::unavailable();
		}
		$category     = sanitize_key( (string) $req->get_param( 'category' ) );
		$search       = strtolower( trim( (string) $req->get_param( 'search' ) ) );
		$include_core = (bool) $req->get_param( 'include_core' );

		$out  = array();
		$cats = array();
		foreach ( wp_get_abilities() as $ability ) {
			$name = $ability->get_name();
			if ( ! $include_core && 0 === strpos( $name, self::CORE_PREFIX ) ) {
				continue;
			}
			$row = self::describe( $ability );
			if ( $category && $row['category'] !== $category ) {
				continue;
			}
			if ( $search && false === strpos( strtolower( $name . ' ' . $row['label'] . ' ' . $row['description'] ), $search ) ) {
				continue;
			}
			$out[]                    = $row;
			$cats[ $row['category'] ] = true;
		}
		return array(
			'access_level' => EGSM_Settings::level(),
			'categories'   => array_keys( $cats ),
			'count'        => count( $out ),
			'actions'      => $out,
		);
	}

	/** POST /actions/run {name, input} */
	public static function run_action( WP_REST_Request $req ) {
		if ( ! self::available() ) {
			return self::unavailable();
		}
		$b     = $req->get_json_params();
		$b     = is_array( $b ) ? $b : $req->get_body_params();
		$name  = isset( $b['name'] ) ? trim( (string) $b['name'] ) : '';
		$input = array_key_exists( 'input', $b ) ? $b['input'] : null;

		if ( '' === $name ) {
			return new WP_Error( 'egsm_bad_request', 'name is required (e.g. "levelup-events/create-event"). List actions with GET /actions.', array( 'status' => 400 ) );
		}
		$ability = wp_get_ability( $name );
		if ( ! $ability ) {
			return new WP_Error( 'egsm_not_found', "No action named '{$name}' on this site. List actions with GET /actions.", array( 'status' => 404 ) );
		}

		$level = self::level_for( $ability );
		if ( ! EGSM_Settings::level_allows( $level ) ) {
			return new WP_Error(
				'egsm_level',
				sprintf( "The site owner set this connection to '%s' access. The action '%s' needs '%s' access — they can raise it in the plugin settings.", EGSM_Settings::level(), $name, $level ),
				array(
					'status'         => 403,
					'site_level'     => EGSM_Settings::level(),
					'required_level' => $level,
				)
			);
		}

		if ( is_array( $input ) && empty( $input ) ) {
			$input = null; // let the ability apply its schema default
		}

		$result = $ability->execute( $input );

		$writes = 'read' !== $level;
		if ( is_wp_error( $result ) ) {
			$data = $result->get_error_data();
			if ( ! is_array( $data ) || empty( $data['status'] ) ) {
				$data = array_merge( is_array( $data ) ? $data : array(), array( 'status' => 400 ) );
				$result = new WP_Error( $result->get_error_code(), $result->get_error_message(), $data );
			}
			return $result;
		}

		$change_id = 0;
		if ( $writes ) {
			$change_id = EGSM_Log::record(
				'ability_run',
				'ability',
				0,
				null,
				array(
					'name'  => $name,
					'input' => $input,
				),
				'Ran plugin action ' . $name
			);
		}

		return array(
			'action'    => $name,
			'level'     => $level,
			'change_id' => $change_id,
			'result'    => $result,
		);
	}
}
