<?php
/**
 * Media: upload from URL or base64 with SEO filename, alt text, WebP conversion,
 * featured image; bulk alt-text fixes that also update images already placed in content.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Media {

	const MAX_BYTES = 20971520; // 20 MB
	const ALLOWED   = array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif' );

	private static function load_admin() {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
	}

	/** @return array|WP_Error */
	public static function upload( $p ) {
		self::load_admin();
		$tmp = '';
		if ( ! empty( $p['url'] ) ) {
			$url = esc_url_raw( $p['url'] );
			if ( ! wp_http_validate_url( $url ) ) {
				return new WP_Error( 'egsm_bad_url', 'Image URL is not allowed (must be a public http/https URL).', array( 'status' => 400 ) );
			}
			$tmp = download_url( $url, 60 );
			if ( is_wp_error( $tmp ) ) {
				return new WP_Error( 'egsm_download_failed', 'Could not download the image: ' . $tmp->get_error_message(), array( 'status' => 422 ) );
			}
		} elseif ( ! empty( $p['base64'] ) ) {
			$b64 = preg_replace( '#^data:[^;]+;base64,#', '', (string) $p['base64'] );
			$bin = base64_decode( $b64, true );
			if ( false === $bin ) {
				return new WP_Error( 'egsm_bad_request', 'base64 is not valid.', array( 'status' => 400 ) );
			}
			$tmp = wp_tempnam( 'egsm-upload' );
			file_put_contents( $tmp, $bin ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		} else {
			return new WP_Error( 'egsm_bad_request', 'Give url or base64.', array( 'status' => 400 ) );
		}

		$cleanup = function () use ( &$tmp ) {
			if ( $tmp && file_exists( $tmp ) ) {
				wp_delete_file( $tmp );
			}
		};
		if ( filesize( $tmp ) > self::MAX_BYTES ) {
			$cleanup();
			return new WP_Error( 'egsm_too_large', 'Image is larger than 20 MB.', array( 'status' => 413 ) );
		}
		$info = function_exists( 'wp_getimagesize' ) ? wp_getimagesize( $tmp ) : getimagesize( $tmp );
		if ( ! $info || ! in_array( $info['mime'], self::ALLOWED, true ) ) {
			$cleanup();
			return new WP_Error( 'egsm_bad_image', 'Not a supported image (JPEG, PNG, WebP, GIF, AVIF).', array( 'status' => 415 ) );
		}
		$mime = $info['mime'];
		$ext  = array(
			'image/jpeg' => 'jpg',
			'image/png'  => 'png',
			'image/webp' => 'webp',
			'image/gif'  => 'gif',
			'image/avif' => 'avif',
		)[ $mime ];

		// Resize very large images and optionally convert to WebP.
		$max_w = isset( $p['max_width'] ) ? max( 200, (int) $p['max_width'] ) : 2400;
		$webp  = ! isset( $p['webp'] ) || EGSM_Util::bool( $p['webp'] );
		if ( 'image/gif' !== $mime && ( $info[0] > $max_w || ( $webp && 'image/webp' !== $mime ) ) ) {
			$editor = wp_get_image_editor( $tmp );
			if ( ! is_wp_error( $editor ) ) {
				if ( $info[0] > $max_w ) {
					$editor->resize( $max_w, null, false );
				}
				$target_mime = $mime;
				if ( $webp && $editor->supports_mime_type( 'image/webp' ) ) {
					$target_mime = 'image/webp';
				}
				$editor->set_quality( 82 );
				$new_ext = 'image/webp' === $target_mime ? 'webp' : $ext;
				$saved   = $editor->save( $tmp . '-egsm.' . $new_ext, $target_mime );
				if ( ! is_wp_error( $saved ) && ! empty( $saved['path'] ) ) {
					$cleanup();
					$tmp  = $saved['path'];
					$mime = $target_mime;
					$ext  = $new_ext;
				}
			}
		}

		$base = ! empty( $p['filename'] ) ? sanitize_title( preg_replace( '/\.[a-z0-9]{2,4}$/i', '', (string) $p['filename'] ) ) : '';
		if ( '' === $base ) {
			$base = sanitize_title( ! empty( $p['alt'] ) ? wp_trim_words( $p['alt'], 8, '' ) : ( ! empty( $p['title'] ) ? $p['title'] : 'image' ) );
		}
		$file = array(
			'name'     => substr( $base, 0, 90 ) . '.' . $ext,
			'tmp_name' => $tmp,
		);
		$post_id = ! empty( $p['post_id'] ) ? (int) $p['post_id'] : 0;
		$id      = media_handle_sideload( $file, $post_id, isset( $p['title'] ) ? sanitize_text_field( $p['title'] ) : null );
		if ( is_wp_error( $id ) ) {
			$cleanup();
			return $id;
		}
		if ( isset( $p['alt'] ) ) {
			update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( $p['alt'] ) );
		}
		$upd = array( 'ID' => $id );
		if ( isset( $p['caption'] ) ) {
			$upd['post_excerpt'] = sanitize_text_field( $p['caption'] );
		}
		if ( isset( $p['description'] ) ) {
			$upd['post_content'] = sanitize_textarea_field( $p['description'] );
		}
		if ( count( $upd ) > 1 ) {
			wp_update_post( wp_slash( $upd ) );
		}
		$change_id = EGSM_Log::post_changed( 'media_upload', $id, null, 'Uploaded image ' . $file['name'] );

		$featured = null;
		if ( $post_id && ! empty( $p['set_featured'] ) ) {
			$before = EGSM_Log::snapshot_post( $post_id );
			set_post_thumbnail( $post_id, $id );
			$featured = EGSM_Log::post_changed( 'set_featured_image', $post_id, $before, 'Set featured image' );
			EGSM_Cache::purge_post( $post_id );
		}
		$meta = wp_get_attachment_metadata( $id );
		return array(
			'id'                  => $id,
			'url'                 => wp_get_attachment_url( $id ),
			'mime'                => $mime,
			'width'               => isset( $meta['width'] ) ? (int) $meta['width'] : null,
			'height'              => isset( $meta['height'] ) ? (int) $meta['height'] : null,
			'alt'                 => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
			'change_id'           => $change_id,
			'featured_change_id'  => $featured,
			'html'                => '<img src="' . esc_url( wp_get_attachment_url( $id ) ) . '" alt="' . esc_attr( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) ) . '" class="wp-image-' . $id . '"/>',
		);
	}

	public static function list_items( $p ) {
		$args = array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => 'image',
			'posts_per_page' => max( 1, min( 200, (int) ( isset( $p['per_page'] ) ? $p['per_page'] : 50 ) ) ),
			'paged'          => max( 1, (int) ( isset( $p['page'] ) ? $p['page'] : 1 ) ),
		);
		if ( ! empty( $p['missing_alt'] ) && EGSM_Util::bool( $p['missing_alt'] ) ) {
			$args['meta_query'] = array(
				'relation' => 'OR',
				array(
					'key'     => '_wp_attachment_image_alt',
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'   => '_wp_attachment_image_alt',
					'value' => '',
				),
			);
		}
		if ( ! empty( $p['search'] ) ) {
			$args['s'] = (string) $p['search'];
		}
		$q   = new WP_Query( $args );
		$out = array();
		foreach ( $q->posts as $a ) {
			$meta  = wp_get_attachment_metadata( $a->ID );
			$file  = get_attached_file( $a->ID );
			$out[] = array(
				'id'       => $a->ID,
				'url'      => wp_get_attachment_url( $a->ID ),
				'title'    => $a->post_title,
				'alt'      => (string) get_post_meta( $a->ID, '_wp_attachment_image_alt', true ),
				'caption'  => $a->post_excerpt,
				'mime'     => $a->post_mime_type,
				'width'    => isset( $meta['width'] ) ? (int) $meta['width'] : null,
				'height'   => isset( $meta['height'] ) ? (int) $meta['height'] : null,
				'bytes'    => $file && file_exists( $file ) ? filesize( $file ) : null,
				'parent'   => (int) $a->post_parent,
			);
		}
		return array(
			'items' => $out,
			'total' => (int) $q->found_posts,
		);
	}

	/**
	 * Update alt/title/caption. With propagate (default), also sets the alt on <img>
	 * tags already placed in post content, which the attachment alt alone does not change.
	 */
	public static function update( $id, $p ) {
		$a = get_post( (int) $id );
		if ( ! $a || 'attachment' !== $a->post_type ) {
			return new WP_Error( 'egsm_not_found', 'Attachment not found.', array( 'status' => 404 ) );
		}
		$before = EGSM_Log::snapshot_post( $a->ID );
		if ( isset( $p['alt'] ) ) {
			update_post_meta( $a->ID, '_wp_attachment_image_alt', sanitize_text_field( $p['alt'] ) );
		}
		$upd = array( 'ID' => $a->ID );
		if ( isset( $p['title'] ) ) {
			$upd['post_title'] = sanitize_text_field( $p['title'] );
		}
		if ( isset( $p['caption'] ) ) {
			$upd['post_excerpt'] = sanitize_text_field( $p['caption'] );
		}
		if ( count( $upd ) > 1 ) {
			wp_update_post( wp_slash( $upd ) );
		}
		$out = array(
			'id'        => $a->ID,
			'change_id' => EGSM_Log::post_changed( 'media_update', $a->ID, $before, 'Updated image details' ),
		);
		if ( isset( $p['alt'] ) && ( ! isset( $p['propagate'] ) || EGSM_Util::bool( $p['propagate'] ) ) ) {
			$out['content_updated'] = self::propagate_alt( $a->ID, sanitize_text_field( $p['alt'] ), ! empty( $p['overwrite_existing'] ) );
		}
		return $out;
	}

	private static function propagate_alt( $att_id, $alt, $overwrite ) {
		global $wpdb;
		$file  = basename( (string) get_attached_file( $att_id ) );
		$stem  = preg_replace( '/\.[a-z0-9]+$/i', '', $file );
		$like1 = '%wp-image-' . $att_id . '%';
		$like2 = '%' . $wpdb->esc_like( $stem ) . '%';
		$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type NOT IN ('revision','attachment') AND post_status IN ('publish','draft','private','future','pending') AND (post_content LIKE %s OR post_content LIKE %s) LIMIT 200", $like1, $like2 ) );
		// [alt-thrive v1] Thrive pages render from tve_updated_post meta, and their post_content mirror may hold no <img> at all.
		$tids = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT m.post_id FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key LIKE %s AND p.post_type NOT IN ('revision','attachment') AND p.post_status IN ('publish','draft','private','future','pending') AND (m.meta_value LIKE %s OR m.meta_value LIKE %s) LIMIT 200", $wpdb->esc_like( 'tve_updated_post' ) . '%', $like1, $like2 ) );
		$ids   = array_values( array_unique( array_map( 'intval', array_merge( (array) $ids, (array) $tids ) ) ) );
		$fix   = function ( $html, &$count ) use ( $att_id, $stem, $alt, $overwrite ) {
			return preg_replace_callback(
				'#<img\b[^>]*>#i',
				function ( $m ) use ( $att_id, $stem, $alt, $overwrite, &$count ) {
					$tag = $m[0];
					$cls = (string) EGSM_Util::attr( $tag, 'class' );
					$src = (string) EGSM_Util::attr( $tag, 'src' );
					if ( false === strpos( $cls, 'wp-image-' . $att_id ) && ( '' === $stem || false === strpos( $src, $stem ) ) ) {
						return $tag;
					}
					$cur = EGSM_Util::attr( $tag, 'alt' );
					if ( null !== $cur && '' !== trim( $cur ) && ! $overwrite ) {
						return $tag;
					}
					$count++;
					if ( null === $cur ) {
						return preg_replace( '#^<img\b#i', '<img alt="' . esc_attr( $alt ) . '"', $tag );
					}
					return preg_replace( '/\salt\s*=\s*("[^"]*"|\'[^\']*\')/i', ' alt="' . esc_attr( $alt ) . '"', $tag, 1 );
				},
				(string) $html
			);
		};
		$done  = array();
		foreach ( $ids as $pid ) {
			if ( class_exists( 'EGSM_Builders' ) && EGSM_Builders::is_thrive( $pid ) ) {
				$before = EGSM_Log::snapshot_post( $pid );
				$count  = EGSM_Builders::thrive_apply( $pid, $fix );
				if ( $count ) {
					$done[] = array(
						'post_id'   => (int) $pid,
						'images'    => $count,
						'change_id' => EGSM_Log::post_changed( 'alt_in_content', (int) $pid, $before, 'Set image alt text in content' ),
					);
					EGSM_Cache::purge_post( (int) $pid );
				}
				continue;
			}
			$post    = get_post( $pid );
			$count   = 0;
			$content = $fix( $post->post_content, $count );
			if ( $count ) {
				$before = EGSM_Log::snapshot_post( $pid );
				wp_update_post(
					array(
						'ID'           => $pid,
						'post_content' => wp_slash( $content ),
					)
				);
				$done[] = array(
					'post_id'   => (int) $pid,
					'images'    => $count,
					'change_id' => EGSM_Log::post_changed( 'alt_in_content', (int) $pid, $before, 'Set image alt text in content' ),
				);
				EGSM_Cache::purge_post( (int) $pid );
			}
		}
		return $done;
	}
}
