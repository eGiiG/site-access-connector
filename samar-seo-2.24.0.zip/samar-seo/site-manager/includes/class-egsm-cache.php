<?php
/**
 * Page-cache purging across common caching plugins and hosts.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Cache {

	public static function purge_post( $id ) {
		clean_post_cache( $id );
		if ( ! EGSM_Settings::get( 'auto_purge' ) ) {
			return array();
		}
		$done = array();
		$url  = get_permalink( $id );
		try {
			if ( function_exists( 'rocket_clean_post' ) ) {
				rocket_clean_post( $id );
				$done[] = 'wp-rocket';
			}
			if ( has_action( 'litespeed_purge_post' ) || defined( 'LSCWP_V' ) ) {
				do_action( 'litespeed_purge_post', $id );
				$done[] = 'litespeed';
			}
			if ( function_exists( 'w3tc_flush_post' ) ) {
				w3tc_flush_post( $id );
				$done[] = 'w3-total-cache';
			}
			if ( function_exists( 'wp_cache_post_change' ) ) {
				wp_cache_post_change( $id );
				$done[] = 'wp-super-cache';
			}
			if ( function_exists( 'sg_cachepress_purge_cache' ) && $url ) {
				sg_cachepress_purge_cache( $url );
				$done[] = 'siteground';
			}
			if ( class_exists( 'WpeCommon' ) && method_exists( 'WpeCommon', 'purge_varnish_cache' ) ) {
				WpeCommon::purge_varnish_cache( $id );
				$done[] = 'wp-engine';
			}
			if ( isset( $GLOBALS['wp_fastest_cache'] ) && method_exists( $GLOBALS['wp_fastest_cache'], 'singleDeleteCache' ) ) {
				$GLOBALS['wp_fastest_cache']->singleDeleteCache( false, $id );
				$done[] = 'wp-fastest-cache';
			}
			if ( function_exists( 'breeze_cache_flush' ) ) {
				do_action( 'breeze_clear_all_cache' );
				$done[] = 'breeze';
			}
			do_action( 'egsm_purge_post', $id );
		} catch ( \Throwable $e ) {
			$done[] = 'error:' . $e->getMessage();
		}
		return $done;
	}

	public static function purge_all() {
		$done = array();
		wp_cache_flush();
		$done[] = 'object-cache';
		try {
			if ( function_exists( 'rocket_clean_domain' ) ) {
				rocket_clean_domain();
				$done[] = 'wp-rocket';
			}
			if ( has_action( 'litespeed_purge_all' ) || defined( 'LSCWP_V' ) ) {
				do_action( 'litespeed_purge_all' );
				$done[] = 'litespeed';
			}
			if ( function_exists( 'w3tc_flush_all' ) ) {
				w3tc_flush_all();
				$done[] = 'w3-total-cache';
			}
			if ( function_exists( 'wp_cache_clear_cache' ) ) {
				wp_cache_clear_cache();
				$done[] = 'wp-super-cache';
			}
			if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
				sg_cachepress_purge_cache();
				$done[] = 'siteground';
			}
			if ( class_exists( 'WpeCommon' ) ) {
				if ( method_exists( 'WpeCommon', 'purge_memcached' ) ) {
					WpeCommon::purge_memcached();
				}
				if ( method_exists( 'WpeCommon', 'purge_varnish_cache' ) ) {
					WpeCommon::purge_varnish_cache();
				}
				$done[] = 'wp-engine';
			}
			if ( isset( $GLOBALS['wp_fastest_cache'] ) && method_exists( $GLOBALS['wp_fastest_cache'], 'deleteCache' ) ) {
				$GLOBALS['wp_fastest_cache']->deleteCache( true );
				$done[] = 'wp-fastest-cache';
			}
			if ( class_exists( 'autoptimizeCache' ) && method_exists( 'autoptimizeCache', 'clearall' ) ) {
				autoptimizeCache::clearall();
				$done[] = 'autoptimize';
			}
			if ( function_exists( 'breeze_cache_flush' ) ) {
				do_action( 'breeze_clear_all_cache' );
				$done[] = 'breeze';
			}
			if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
				\Elementor\Plugin::$instance->files_manager->clear_cache();
				$done[] = 'elementor-css';
			}
			do_action( 'egsm_purge_all' );
		} catch ( \Throwable $e ) {
			$done[] = 'error:' . $e->getMessage();
		}
		return $done;
	}

	public static function detected() {
		$found = array();
		$map   = array(
			'wp-rocket'        => function_exists( 'rocket_clean_domain' ),
			'litespeed'        => defined( 'LSCWP_V' ),
			'w3-total-cache'   => function_exists( 'w3tc_flush_all' ),
			'wp-super-cache'   => function_exists( 'wp_cache_clear_cache' ),
			'siteground'       => function_exists( 'sg_cachepress_purge_cache' ),
			'wp-engine'        => class_exists( 'WpeCommon' ),
			'wp-fastest-cache' => isset( $GLOBALS['wp_fastest_cache'] ),
			'autoptimize'      => class_exists( 'autoptimizeCache' ),
			'breeze'           => function_exists( 'breeze_cache_flush' ),
		);
		foreach ( $map as $k => $v ) {
			if ( $v ) {
				$found[] = $k;
			}
		}
		return $found;
	}
}
