<?php
/**
 * Options, permission levels and branding.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Settings {

	const LEVELS = array( 'read', 'draft', 'publish', 'full' );

	public static function level() {
		$level = get_option( 'egsm_level', 'publish' );
		return in_array( $level, self::LEVELS, true ) ? $level : 'publish';
	}

	/** True when the site's configured level is at least $required. */
	public static function level_allows( $required ) {
		$have = array_search( self::level(), self::LEVELS, true );
		$need = array_search( $required, self::LEVELS, true );
		return false !== $need && $have >= $need;
	}

	public static function get( $key, $default = null ) {
		$all = get_option( 'egsm_settings', array() );
		if ( ! is_array( $all ) ) {
			$all = array();
		}
		$defaults = array(
			'app_password_auth' => true,
			'log_404'           => true,
			'auto_purge'        => true,
			'native_seo'        => true,
		);
		if ( array_key_exists( $key, $all ) ) {
			return $all[ $key ];
		}
		return array_key_exists( $key, $defaults ) ? $defaults[ $key ] : $default;
	}

	public static function set( $key, $value ) {
		$all = get_option( 'egsm_settings', array() );
		if ( ! is_array( $all ) ) {
			$all = array();
		}
		$all[ $key ] = $value;
		update_option( 'egsm_settings', $all, false );
	}

	public static function branding() {
		$b = get_option( 'egsm_branding', array() );
		$b = is_array( $b ) ? $b : array();
		return wp_parse_args(
			$b,
			array(
				'name'          => '',
				'logo_url'      => '',
				'color'         => '#f97316',
				'support_url'   => '',
				'support_email' => '',
			)
		);
	}

	/** Display name for the agency (white-label aware). */
	public static function agency_name() {
		if ( EGSM_SSEO::on() && '' !== (string) get_option( 'sseo_whitelabel_name', '' ) ) {
			return (string) get_option( 'sseo_whitelabel_name' );
		}
		$b = self::branding();
		return '' !== $b['name'] ? $b['name'] : 'your agency';
	}

	/** User the plugin acts as for signed requests (an administrator). */
	public static function service_user_id() {
		$uid = (int) get_option( 'egsm_service_user', 0 );
		if ( $uid && user_can( $uid, 'manage_options' ) ) {
			return $uid;
		}
		$admins = get_users(
			array(
				'role'    => 'administrator',
				'number'  => 1,
				'orderby' => 'ID',
				'order'   => 'ASC',
				'fields'  => 'ID',
			)
		);
		return $admins ? (int) $admins[0] : 0;
	}
}
