<?php
/**
 * IndexNow: tells Bing, Yandex, Seznam, Naver and other IndexNow engines about new, updated and removed URLs.
 * (Google does not use IndexNow and retired its sitemap "ping"; it discovers changes from the sitemap.)
 * Only runs when this plugin (or SEO Suite) is the site's SEO plugin, the site is public, and it is enabled.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_IndexNow {

	const ENDPOINT = 'https://api.indexnow.org/indexnow';

	private static $urls = array();

	public static function init() {
		add_action( 'wp_loaded', array( __CLASS__, 'serve_key' ), 0 );
		add_action( 'transition_post_status', array( __CLASS__, 'on_transition' ), 10, 3 );
		add_action( 'shutdown', array( __CLASS__, 'flush' ) );
	}

	public static function key() {
		$k = (string) get_option( 'egsm_indexnow_key', '' );
		if ( ! preg_match( '/^[a-f0-9]{32}$/', $k ) ) {
			$k = bin2hex( random_bytes( 16 ) );
			update_option( 'egsm_indexnow_key', $k, true );
		}
		return $k;
	}

	private static function enabled() {
		return EGSM_SEO_Settings::we_are_seo_plugin() && EGSM_SEO_Settings::get( 'indexnow' ) && '0' !== (string) get_option( 'blog_public' );
	}

	public static function serve_key() {
		if ( ! isset( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		$path = (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH );
		$base = rtrim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
		$key  = (string) get_option( 'egsm_indexnow_key', '' );
		if ( '' === $key || $path !== $base . '/' . $key . '.txt' ) {
			return;
		}
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo esc_html( $key );
		exit;
	}

	public static function on_transition( $new, $old, $post ) {
		if ( ! self::enabled() || wp_is_post_revision( $post ) || ! is_post_type_viewable( $post->post_type ) || 'attachment' === $post->post_type ) {
			return;
		}
		if ( 'publish' === $new || 'publish' === $old ) {
			self::queue( get_permalink( $post ) );
		}
	}

	public static function queue( $url ) {
		if ( $url ) {
			self::$urls[ $url ] = true;
		}
	}

	public static function flush() {
		if ( ! self::$urls || ! self::enabled() ) {
			return;
		}
		$urls       = array();
		foreach ( array_keys( self::$urls ) as $u ) {
			$t = 'egsm_inx_' . md5( $u );
			if ( ! get_transient( $t ) ) {
				set_transient( $t, 1, 5 * MINUTE_IN_SECONDS );
				$urls[] = $u;
			}
		}
		self::$urls = array();
		if ( ! $urls ) {
			return;
		}
		$key = self::key();
		$res = wp_remote_post(
			apply_filters( 'egsm_indexnow_endpoint', self::ENDPOINT ),
			array(
				'blocking' => false,
				'timeout'  => 3,
				'headers'  => array( 'Content-Type' => 'application/json; charset=utf-8' ),
				'body'     => wp_json_encode(
					array(
						'host'        => (string) wp_parse_url( home_url(), PHP_URL_HOST ),
						'key'         => $key,
						'keyLocation' => home_url( '/' . $key . '.txt' ),
						'urlList'     => array_values( $urls ),
					)
				),
			)
		);
		update_option( 'egsm_indexnow_last', array( 'at' => time(), 'urls' => array_slice( $urls, 0, 20 ) ), false );
	}
}
