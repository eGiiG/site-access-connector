<?php
/**
 * Pairing with the agency platform (one-time code) and secure one-click agency sign-in.
 *
 * Pairing: the site generates a key pair, sends it with the agency's code to
 *   {EGSM_API_URL}/api/wp-plugin/manager-pair
 * and keeps it only if the platform accepts. The secret signs every API request (EGSM_Auth)
 * and every sign-in link.
 *
 * Sign-in link: {home}/?egsm_sso=1&exp=&nonce=&role=&sig=  where sig = HMAC-SHA256(exp.nonce.role, secret).
 * 60-second expiry, nonce single-use (stored), HTTPS only, dedicated user, logged in the change log.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Pairing {

	const SSO_USER = 'agency-access';

	public static function init() {
		if ( EGSM_SSEO::on() ) {
			return; // SEO Suite handles pairing and one-click sign-in.
		}
		add_action( 'init', array( __CLASS__, 'maybe_sso' ), 1 );
	}

	public static function api_base() {
		if ( defined( 'EGSM_API_URL' ) && EGSM_API_URL ) {
			return rtrim( EGSM_API_URL, '/' );
		}
		$opt = (string) get_option( 'egsm_api_url', '' );
		return '' !== $opt ? rtrim( $opt, '/' ) : 'https://api.egiig.com';
	}

	/** @return array|WP_Error branding on success */
	public static function pair( $code ) {
		$code = strtoupper( preg_replace( '/[^A-Z0-9\-]/i', '', (string) $code ) );
		if ( '' === $code ) {
			return new WP_Error( 'egsm_pair', 'Enter the pairing code from your agency.' );
		}
		$kid    = bin2hex( random_bytes( 8 ) );
		$secret = bin2hex( random_bytes( 32 ) );
		$resp   = wp_remote_post(
			self::api_base() . '/api/wp-plugin/manager-pair',
			array(
				'timeout' => 25,
				'headers' => array(
					'Content-Type' => 'application/json',
					'Accept'       => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'pair_code'      => $code,
						'site_url'       => home_url(),
						'rest_url'       => rest_url( EGSM_NS . '/' ),
						'kid'            => $kid,
						'secret'         => $secret,
						'site_name'      => get_bloginfo( 'name' ),
						'plugin_version' => EGSM_VERSION,
					)
				),
			)
		);
		if ( is_wp_error( $resp ) ) {
			return new WP_Error( 'egsm_pair', 'Could not reach your agency\'s server (' . $resp->get_error_message() . '). Check that this site can make outgoing HTTPS requests and try again.' );
		}
		$status = (int) wp_remote_retrieve_response_code( $resp );
		$body   = json_decode( (string) wp_remote_retrieve_body( $resp ), true );
		if ( 200 !== $status || empty( $body['ok'] ) ) {
			$msg = is_array( $body ) && ! empty( $body['message'] ) ? $body['message'] : 'That pairing code was not accepted (HTTP ' . $status . '). Ask your agency for a new code.';
			return new WP_Error( 'egsm_pair', $msg );
		}

		update_option( 'egsm_kid', $kid, false );
		update_option( 'egsm_secret', $secret, false );
		update_option( 'egsm_key_created', time(), false );
		if ( current_user_can( 'manage_options' ) ) {
			update_option( 'egsm_service_user', get_current_user_id(), false );
		}
		update_option(
			'egsm_paired',
			array(
				'platform_url' => self::api_base(),
				'paired_at'    => gmdate( 'c' ),
				'via'          => 'code',
			),
			false
		);
		$branding = isset( $body['branding'] ) && is_array( $body['branding'] ) ? $body['branding'] : array( 'name' => isset( $body['brand'] ) ? $body['brand'] : '' );
		EGSM_Maintenance::set_branding( $branding );
		EGSM_Log::record( 'paired', 'option', 0, null, null, 'Connected to ' . EGSM_Settings::agency_name() );
		return EGSM_Settings::branding();
	}

	/* ---------- one-click agency sign-in ---------- */

	public static function maybe_sso() {
		if ( ! isset( $_GET['egsm_sso'] ) ) {
			return;
		}
		$secret = (string) get_option( 'egsm_secret', '' );
		if ( '' === $secret ) {
			wp_die( 'This site is not connected to an agency.', 'Sign-in unavailable', array( 'response' => 403 ) );
		}
		$exp   = isset( $_GET['exp'] ) ? (int) $_GET['exp'] : 0;
		$nonce = isset( $_GET['nonce'] ) ? preg_replace( '/[^A-Za-z0-9]/', '', (string) wp_unslash( $_GET['nonce'] ) ) : '';
		$role  = isset( $_GET['role'] ) ? sanitize_key( wp_unslash( $_GET['role'] ) ) : 'administrator';
		$sig   = isset( $_GET['sig'] ) ? strtolower( preg_replace( '/[^a-f0-9]/i', '', (string) wp_unslash( $_GET['sig'] ) ) ) : '';

		if ( ! is_ssl() && ! apply_filters( 'egsm_sso_allow_http', false ) ) {
			wp_die( 'A secure (HTTPS) connection is required.', 'Sign-in unavailable', array( 'response' => 403 ) );
		}
		if ( $exp < time() || $exp > time() + 120 ) {
			wp_die( 'This sign-in link has expired. Request a new one from your agency dashboard.', 'Link expired', array( 'response' => 403 ) );
		}
		if ( strlen( $nonce ) < 16 || '' === $sig ) {
			wp_die( 'Invalid sign-in link.', 'Sign-in unavailable', array( 'response' => 403 ) );
		}
		$expected = hash_hmac( 'sha256', $exp . '.' . $nonce . '.' . $role, $secret );
		if ( ! hash_equals( $expected, $sig ) ) {
			wp_die( 'Invalid sign-in link.', 'Sign-in unavailable', array( 'response' => 403 ) );
		}
		$key = 'egsm_sso_' . md5( $nonce );
		if ( get_transient( $key ) ) {
			wp_die( 'This sign-in link was already used.', 'Sign-in unavailable', array( 'response' => 403 ) );
		}
		set_transient( $key, 1, 300 );

		if ( ! EGSM_Settings::level_allows( 'publish' ) ) {
			wp_die( 'The site owner has limited this connection to ' . esc_html( EGSM_Settings::level() ) . ' access, so dashboard sign-in is turned off.', 'Sign-in unavailable', array( 'response' => 403 ) );
		}
		$role = in_array( $role, array( 'administrator', 'editor' ), true ) ? $role : 'editor';
		$user = get_user_by( 'login', self::SSO_USER );
		if ( ! $user ) {
			$uid = wp_insert_user(
				array(
					'user_login'   => self::SSO_USER,
					'user_pass'    => wp_generate_password( 64, true, true ),
					'user_email'   => self::SSO_USER . '@' . preg_replace( '/[^a-z0-9.\-]/', '', EGSM_Util::home_host() ?: 'localhost' ),
					'role'         => $role,
					'display_name' => EGSM_Settings::agency_name(),
					'nickname'     => EGSM_Settings::agency_name(),
				)
			);
			if ( is_wp_error( $uid ) ) {
				wp_die( 'Could not create the agency sign-in user: ' . esc_html( $uid->get_error_message() ) );
			}
			$user = get_user_by( 'id', $uid );
		} elseif ( ! in_array( $role, (array) $user->roles, true ) ) {
			$user->set_role( $role );
		}
		wp_set_current_user( $user->ID );
		wp_set_auth_cookie( $user->ID, false, is_ssl() );
		EGSM_Log::record( 'agency_login', 'user', $user->ID, null, null, EGSM_Settings::agency_name() . ' signed in to the dashboard' );
		wp_safe_redirect( admin_url() );
		exit;
	}

	/** Remove the agency's sign-in user; their posts are kept and reassigned to a site admin. */
	public static function remove_sso_user() {
		$u = get_user_by( 'login', self::SSO_USER );
		if ( ! $u ) {
			return;
		}
		require_once ABSPATH . 'wp-admin/includes/user.php';
		$reassign = EGSM_Settings::service_user_id();
		if ( $reassign === $u->ID ) {
			$reassign = null;
		}
		wp_delete_user( $u->ID, $reassign );
	}

	/** Deactivation revokes access. Settings, logs and redirects stay until the plugin is deleted. */
	public static function deactivate() {
		EGSM_Auth::revoke();
		self::remove_sso_user();
	}
}
