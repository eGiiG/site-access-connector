<?php
/**
 * Search output for non-single pages when this plugin (or SEO Suite) is the SEO plugin:
 * category/tag/custom-taxonomy archives, blog page, latest-posts homepage, author and date archives.
 * Also: term SEO fields on the term edit screen and a self-referencing canonical on archives.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Archive {

	public static function init() {
		add_action( 'wp', array( __CLASS__, 'frontend' ) );
		add_action( 'admin_init', array( __CLASS__, 'term_fields' ) );
	}

	/* ---------- term SEO data ---------- */

	public static function get_term_seo( $term_id ) {
		$m = get_term_meta( (int) $term_id, '_egsm_seo', true );
		$m = is_array( $m ) ? $m : array();
		return array(
			'title'       => isset( $m['title'] ) ? (string) $m['title'] : '',
			'description' => isset( $m['description'] ) ? (string) $m['description'] : '',
			'noindex'     => ! empty( $m['noindex'] ),
		);
	}

	public static function set_term_seo( $term_id, $fields ) {
		$cur = self::get_term_seo( $term_id );
		foreach ( array( 'title', 'description' ) as $f ) {
			if ( isset( $fields[ $f ] ) ) {
				$cur[ $f ] = sanitize_text_field( (string) $fields[ $f ] );
			}
		}
		if ( isset( $fields['noindex'] ) ) {
			$cur['noindex'] = EGSM_Util::bool( $fields['noindex'] );
		}
		$store = array_filter( $cur, function ( $v ) {
			return '' !== $v && false !== $v;
		} );
		if ( $store ) {
			update_term_meta( (int) $term_id, '_egsm_seo', $store );
		} else {
			delete_term_meta( (int) $term_id, '_egsm_seo' );
		}
		if ( $cur['noindex'] ) {
			update_term_meta( (int) $term_id, '_egsm_noindex', '1' );
		} else {
			delete_term_meta( (int) $term_id, '_egsm_noindex' );
		}
		return $cur;
	}

	/* ---------- term edit screen ---------- */

	public static function term_fields() {
		if ( ! EGSM_SEO_Settings::we_are_seo_plugin() ) {
			return;
		}
		foreach ( get_taxonomies( array( 'public' => true ), 'names' ) as $tax ) {
			add_action( "{$tax}_edit_form_fields", array( __CLASS__, 'edit_fields' ), 20 );
			add_action( "{$tax}_add_form_fields", array( __CLASS__, 'add_fields' ), 20 );
			add_action( "edited_{$tax}", array( __CLASS__, 'save_fields' ) );
			add_action( "created_{$tax}", array( __CLASS__, 'save_fields' ) );
		}
	}

	public static function edit_fields( $term ) {
		$s = self::get_term_seo( $term->term_id );
		wp_nonce_field( 'egsm_term_seo', 'egsm_term_nonce' );
		?>
		<tr class="form-field"><th colspan="2"><h2 style="margin:0">Search engines</h2></th></tr>
		<tr class="form-field"><th><label for="egsm_term_title">SEO title</label></th>
			<td><input name="egsm_term_seo[title]" id="egsm_term_title" type="text" value="<?php echo esc_attr( $s['title'] ); ?>" placeholder="<?php echo esc_attr( $term->name . ' – ' . get_bloginfo( 'name' ) ); ?>"><p class="description">Leave empty to use the default.</p></td></tr>
		<tr class="form-field"><th><label for="egsm_term_desc">Meta description</label></th>
			<td><textarea name="egsm_term_seo[description]" id="egsm_term_desc" rows="3"><?php echo esc_textarea( $s['description'] ); ?></textarea><p class="description">Leave empty to use the description above.</p></td></tr>
		<tr class="form-field"><th>Indexing</th>
			<td><label><input type="checkbox" name="egsm_term_seo[noindex]" value="1" <?php checked( $s['noindex'] ); ?>> Hide this archive from search engines (noindex)</label></td></tr>
		<?php
	}

	public static function add_fields() {
		wp_nonce_field( 'egsm_term_seo', 'egsm_term_nonce' );
		?>
		<div class="form-field"><label for="egsm_term_title">SEO title</label><input name="egsm_term_seo[title]" id="egsm_term_title" type="text"></div>
		<div class="form-field"><label for="egsm_term_desc">Meta description</label><textarea name="egsm_term_seo[description]" id="egsm_term_desc" rows="3"></textarea></div>
		<div class="form-field"><label><input type="checkbox" name="egsm_term_seo[noindex]" value="1"> Hide from search engines (noindex)</label></div>
		<?php
	}

	public static function save_fields( $term_id ) {
		if ( ! isset( $_POST['egsm_term_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['egsm_term_nonce'] ), 'egsm_term_seo' ) || ! current_user_can( 'manage_categories' ) ) {
			return;
		}
		$in = isset( $_POST['egsm_term_seo'] ) && is_array( $_POST['egsm_term_seo'] ) ? wp_unslash( $_POST['egsm_term_seo'] ) : array();
		self::set_term_seo(
			$term_id,
			array(
				'title'       => isset( $in['title'] ) ? $in['title'] : '',
				'description' => isset( $in['description'] ) ? $in['description'] : '',
				'noindex'     => ! empty( $in['noindex'] ),
			)
		);
	}

	/* ---------- front end ---------- */

	/** Title / description / noindex / canonical for the current non-singular request, or null. */
	public static function current() {
		$site = get_bloginfo( 'name' );
		$paged = max( 1, (int) get_query_var( 'paged' ) );
		if ( is_front_page() && is_home() ) {
			return array(
				'title'       => EGSM_SEO_Settings::get( 'home_title' ),
				'description' => EGSM_SEO_Settings::get( 'home_description' ) ?: get_bloginfo( 'description' ),
				'noindex'     => false,
				'canonical'   => $paged > 1 ? get_pagenum_link( $paged ) : home_url( '/' ),
			);
		}
		if ( is_home() ) {
			$pid = (int) get_option( 'page_for_posts' );
			if ( ! $pid ) {
				return null;
			}
			$seo = EGSM_SEO::get( $pid );
			return array(
				'title'       => $seo['title'] ? $seo['effective_title'] : '',
				'description' => $seo['effective_description'],
				'noindex'     => $seo['noindex'],
				'canonical'   => $paged > 1 ? get_pagenum_link( $paged ) : get_permalink( $pid ),
			);
		}
		if ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			if ( ! $term || empty( $term->term_id ) ) {
				return null;
			}
			$seo   = self::get_term_seo( $term->term_id );
			$noidx = $seo['noindex'] || ! empty( EGSM_SEO_Settings::get( 'noindex_tax' )[ $term->taxonomy ] );
			$desc  = '' !== $seo['description'] ? $seo['description'] : wp_html_excerpt( wp_strip_all_tags( term_description( $term ) ), 155, '…' );
			$link  = get_term_link( $term );
			return array(
				'title'       => '' !== $seo['title'] ? strtr( $seo['title'], array( '%%term%%' => $term->name, '%%sitename%%' => $site ) ) : '',
				'description' => trim( $desc ),
				'noindex'     => $noidx,
				'canonical'   => $paged > 1 ? get_pagenum_link( $paged ) : ( is_wp_error( $link ) ? '' : $link ),
			);
		}
		if ( is_author() ) {
			$a = get_queried_object();
			return array(
				'title'       => '',
				'description' => $a ? wp_html_excerpt( wp_strip_all_tags( (string) $a->description ), 155, '…' ) : '',
				'noindex'     => (bool) EGSM_SEO_Settings::get( 'noindex_author' ),
				'canonical'   => $a ? get_author_posts_url( $a->ID ) : '',
			);
		}
		if ( is_date() ) {
			return array(
				'title'       => '',
				'description' => '',
				'noindex'     => (bool) EGSM_SEO_Settings::get( 'noindex_date' ),
				'canonical'   => '',
			);
		}
		return null;
	}

	public static function frontend() {
		if ( is_admin() || is_singular() || ! EGSM_SEO_Settings::we_are_seo_plugin() ) {
			return;
		}
		$c = self::current();
		if ( ! $c ) {
			return;
		}
		if ( '' !== (string) $c['title'] ) {
			$t = $c['title'];
			add_filter( 'pre_get_document_title', function () use ( $t ) {
				return $t;
			}, 100 );
		}
		if ( $c['noindex'] ) {
			add_filter( 'wp_robots', function ( $r ) {
				$r['noindex'] = true;
				$r['follow']  = true;
				unset( $r['max-image-preview'] );
				return $r;
			} );
		}
		add_action( 'wp_head', function () use ( $c ) {
			if ( '' !== (string) $c['description'] ) {
				echo '<meta name="description" content="' . esc_attr( $c['description'] ) . '" />' . "\n";
			}
			if ( ! $c['noindex'] && '' !== (string) $c['canonical'] ) {
				echo '<link rel="canonical" href="' . esc_url( $c['canonical'] ) . '" />' . "\n";
			}
		}, 2 );
	}
}
