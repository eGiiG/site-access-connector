<?php
/**
 * Site info, settings, updates, cache, taxonomy terms, branding.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Maintenance {

	public static function site_info() {
		global $wp_version;
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$active  = array();
		$plugins = get_plugins();
		foreach ( (array) get_option( 'active_plugins', array() ) as $file ) {
			if ( isset( $plugins[ $file ] ) ) {
				$active[] = array(
					'file'    => $file,
					'name'    => $plugins[ $file ]['Name'],
					'version' => $plugins[ $file ]['Version'],
				);
			}
		}
		$theme  = wp_get_theme();
		$counts = array();
		foreach ( EGSM_Content::post_types() as $t ) {
			$c              = wp_count_posts( $t );
			$counts[ $t ]   = array(
				'publish' => isset( $c->publish ) ? (int) $c->publish : 0,
				'draft'   => isset( $c->draft ) ? (int) $c->draft : 0,
			);
		}
		return array(
			'name'            => get_bloginfo( 'name' ),
			'tagline'         => get_bloginfo( 'description' ),
			'url'             => home_url( '/' ),
			'admin_url'       => admin_url(),
			'language'        => get_locale(),
			'timezone'        => wp_timezone_string(),
			'wordpress'       => $wp_version,
			'php'             => PHP_VERSION,
			'multisite'       => is_multisite(),
			'plugin_version'  => EGSM_VERSION,
			'access_level'    => EGSM_Settings::level(),
			'agency'          => EGSM_Settings::agency_name(),
			'search_engines_visible' => '0' !== (string) get_option( 'blog_public' ),
			'permalinks'      => (string) get_option( 'permalink_structure' ),
			'front_page'      => 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : null,
			'posts_page'      => (int) get_option( 'page_for_posts' ) ?: null,
			'theme'           => array(
				'name'    => $theme->get( 'Name' ),
				'version' => $theme->get( 'Version' ),
				'parent'  => $theme->parent() ? $theme->parent()->get( 'Name' ) : null,
				'block_theme' => function_exists( 'wp_is_block_theme' ) ? wp_is_block_theme() : false,
			),
			'builders'        => EGSM_Builders::site_builders(),
			'seo_plugin'      => EGSM_SEO::active_plugin(),
			'cache_plugins'   => EGSM_Cache::detected(),
			'post_types'      => EGSM_Content::post_types(),
			'content_counts'  => $counts,
			'active_plugins'  => $active,
			'filesystem_direct' => 'direct' === self::fs_method(),
			'capabilities'    => array(
				'build_pages'  => array( 'gutenberg', 'classic', 'elementor' ),
				'text_edit'    => array( 'divi', 'wpbakery', 'bricks', 'beaver', 'oxygen', 'breakdance', 'thrive' ),
				'seo_plugins'  => array( 'yoast', 'rankmath', 'aioseo', 'seopress', 'tsf', 'native' ),
			),
		);
	}

	private static function fs_method() {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		return get_filesystem_method();
	}

	/* ---------- settings ---------- */

	public static function get_site_settings() {
		return array(
			'blogname'        => get_option( 'blogname' ),
			'blogdescription' => get_option( 'blogdescription' ),
			'blog_public'     => (int) get_option( 'blog_public' ),
			'site_icon'       => (int) get_option( 'site_icon' ),
		);
	}

	public static function set_site_settings( $p ) {
		$map    = array(
			'blogname'        => 'sanitize_text_field',
			'blogdescription' => 'sanitize_text_field',
			'blog_public'     => 'absint',
			'site_icon'       => 'absint',
		);
		$names  = array_values( array_intersect( array_keys( $map ), array_keys( (array) $p ) ) );
		if ( ! $names ) {
			return new WP_Error( 'egsm_bad_request', 'Nothing to update. Allowed: ' . implode( ', ', array_keys( $map ) ), array( 'status' => 400 ) );
		}
		if ( isset( $p['site_icon'] ) && (int) $p['site_icon'] && 'attachment' !== get_post_type( (int) $p['site_icon'] ) ) {
			return new WP_Error( 'egsm_bad_request', 'site_icon must be an attachment id.', array( 'status' => 422 ) );
		}
		$before = EGSM_Log::option_state( $names );
		foreach ( $names as $n ) {
			$v = call_user_func( $map[ $n ], $p[ $n ] );
			if ( 'blog_public' === $n ) {
				$v = $v ? 1 : 0;
			}
			update_option( $n, $v );
		}
		$cid = EGSM_Log::record( 'site_settings', 'option', 0, $before, EGSM_Log::option_state( $names ), 'Updated site settings: ' . implode( ', ', $names ) );
		EGSM_Cache::purge_all();
		return array_merge( self::get_site_settings(), array( 'change_id' => $cid ) );
	}

	/* ---------- updates ---------- */

	public static function updates( $refresh ) {
		if ( $refresh ) {
			wp_update_plugins();
			wp_update_themes();
			wp_version_check();
		}
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$plugins = array();
		$tr      = get_site_transient( 'update_plugins' );
		$all     = get_plugins();
		if ( $tr && ! empty( $tr->response ) ) {
			foreach ( $tr->response as $file => $u ) {
				$plugins[] = array(
					'file'    => $file,
					'name'    => isset( $all[ $file ] ) ? $all[ $file ]['Name'] : $file,
					'current' => isset( $all[ $file ] ) ? $all[ $file ]['Version'] : '',
					'new'     => isset( $u->new_version ) ? $u->new_version : '',
					'active'  => is_plugin_active( $file ),
				);
			}
		}
		$themes = array();
		$tt     = get_site_transient( 'update_themes' );
		if ( $tt && ! empty( $tt->response ) ) {
			foreach ( $tt->response as $slug => $u ) {
				$th       = wp_get_theme( $slug );
				$themes[] = array(
					'slug'    => $slug,
					'name'    => $th->get( 'Name' ),
					'current' => $th->get( 'Version' ),
					'new'     => isset( $u['new_version'] ) ? $u['new_version'] : '',
				);
			}
		}
		$core = null;
		$cu   = get_site_transient( 'update_core' );
		if ( $cu && ! empty( $cu->updates ) ) {
			foreach ( $cu->updates as $u ) {
				if ( 'upgrade' === $u->response ) {
					$core = $u->current;
					break;
				}
			}
		}
		return array(
			'core'    => $core,
			'plugins' => $plugins,
			'themes'  => $themes,
		);
	}

	public static function update_plugins( $files ) {
		if ( 'direct' !== self::fs_method() ) {
			return new WP_Error( 'egsm_fs', 'WordPress cannot write plugin files directly on this server (FTP credentials needed). Update from the dashboard.', array( 'status' => 409 ) );
		}
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$available = wp_list_pluck( self::updates( true )['plugins'], 'current', 'file' );
		if ( 'all' === $files ) {
			$files = array_keys( $available );
		}
		$files = array_values( array_intersect( (array) $files, array_keys( $available ) ) );
		if ( ! $files ) {
			return array(
				'updated' => array(),
				'message' => 'No matching plugin updates available.',
			);
		}
		$was_active = array();
		foreach ( $files as $f ) {
			$was_active[ $f ] = is_plugin_active( $f );
		}
		$skin     = new WP_Ajax_Upgrader_Skin();
		$upgrader = new Plugin_Upgrader( $skin );
		$results  = $upgrader->bulk_upgrade( $files );
		$out      = array();
		$all      = get_plugins();
		foreach ( $files as $f ) {
			if ( $was_active[ $f ] && ! is_plugin_active( $f ) ) {
				activate_plugin( $f, '', false, true );
			}
			$ok    = isset( $results[ $f ] ) && ! is_wp_error( $results[ $f ] ) && false !== $results[ $f ];
			$out[] = array(
				'file'      => $f,
				'from'      => $available[ $f ],
				'to'        => isset( $all[ $f ] ) ? $all[ $f ]['Version'] : '',
				'ok'        => $ok,
				'error'     => $ok ? null : ( isset( $results[ $f ] ) && is_wp_error( $results[ $f ] ) ? $results[ $f ]->get_error_message() : implode( ' ', (array) $skin->get_error_messages() ) ),
				'change_id' => EGSM_Log::record( 'update_plugin', 'plugin', 0, array( 'file' => $f, 'version' => $available[ $f ] ), array( 'version' => isset( $all[ $f ] ) ? $all[ $f ]['Version'] : '' ), "Updated plugin $f" ),
			);
		}
		return array( 'updated' => $out );
	}

	public static function update_themes( $slugs ) {
		if ( 'direct' !== self::fs_method() ) {
			return new WP_Error( 'egsm_fs', 'WordPress cannot write theme files directly on this server.', array( 'status' => 409 ) );
		}
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		$available = wp_list_pluck( self::updates( true )['themes'], 'current', 'slug' );
		if ( 'all' === $slugs ) {
			$slugs = array_keys( $available );
		}
		$slugs = array_values( array_intersect( (array) $slugs, array_keys( $available ) ) );
		if ( ! $slugs ) {
			return array( 'updated' => array() );
		}
		$skin     = new WP_Ajax_Upgrader_Skin();
		$upgrader = new Theme_Upgrader( $skin );
		$results  = $upgrader->bulk_upgrade( $slugs );
		$out      = array();
		foreach ( $slugs as $s ) {
			$ok    = isset( $results[ $s ] ) && ! is_wp_error( $results[ $s ] ) && false !== $results[ $s ];
			$out[] = array(
				'slug'      => $s,
				'from'      => $available[ $s ],
				'to'        => wp_get_theme( $s )->get( 'Version' ),
				'ok'        => $ok,
				'change_id' => EGSM_Log::record( 'update_theme', 'theme', 0, array( 'slug' => $s, 'version' => $available[ $s ] ), array( 'version' => wp_get_theme( $s )->get( 'Version' ) ), "Updated theme $s" ),
			);
		}
		return array( 'updated' => $out );
	}

	/* ---------- terms ---------- */

	public static function list_terms( $taxonomy ) {
		if ( ! taxonomy_exists( $taxonomy ) ) {
			return new WP_Error( 'egsm_bad_request', 'Unknown taxonomy.', array( 'status' => 400 ) );
		}
		$out = array();
		foreach ( get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false ) ) as $t ) {
			$out[] = array(
				'id'          => $t->term_id,
				'name'        => $t->name,
				'slug'        => $t->slug,
				'parent'      => $t->parent,
				'count'       => $t->count,
				'description' => $t->description,
				'url'         => get_term_link( $t ),
				'seo'         => EGSM_Archive::get_term_seo( $t->term_id ),
			);
		}
		return $out;
	}

	public static function create_term( $p ) {
		$tax = isset( $p['taxonomy'] ) ? sanitize_key( $p['taxonomy'] ) : 'category';
		if ( ! taxonomy_exists( $tax ) || empty( $p['name'] ) ) {
			return new WP_Error( 'egsm_bad_request', 'taxonomy and name are required.', array( 'status' => 400 ) );
		}
		$args = array();
		foreach ( array( 'slug', 'description' ) as $f ) {
			if ( isset( $p[ $f ] ) ) {
				$args[ $f ] = 'slug' === $f ? sanitize_title( $p[ $f ] ) : wp_kses_post( $p[ $f ] );
			}
		}
		if ( isset( $p['parent'] ) ) {
			$args['parent'] = (int) $p['parent'];
		}
		$r = wp_insert_term( sanitize_text_field( $p['name'] ), $tax, wp_slash( $args ) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		if ( ! empty( $p['seo'] ) && is_array( $p['seo'] ) ) {
			EGSM_Archive::set_term_seo( $r['term_id'], $p['seo'] );
		}
		return array(
			'id'        => $r['term_id'],
			'change_id' => EGSM_Log::record( 'create_term', 'term', $r['term_id'], null, array( 'taxonomy' => $tax ), "Created $tax " . $p['name'] ),
		);
	}

	public static function update_term( $id, $p ) {
		$t = get_term( (int) $id );
		if ( ! $t || is_wp_error( $t ) ) {
			return new WP_Error( 'egsm_not_found', 'Term not found.', array( 'status' => 404 ) );
		}
		$before = array(
			'taxonomy' => $t->taxonomy,
			'fields'   => array(
				'name'        => $t->name,
				'slug'        => $t->slug,
				'description' => $t->description,
				'parent'      => $t->parent,
			),
		);
		$args   = array();
		if ( isset( $p['name'] ) ) {
			$args['name'] = sanitize_text_field( $p['name'] );
		}
		if ( isset( $p['slug'] ) ) {
			$args['slug'] = sanitize_title( $p['slug'] );
		}
		if ( isset( $p['description'] ) ) {
			$args['description'] = wp_kses_post( $p['description'] );
		}
		if ( isset( $p['parent'] ) ) {
			$args['parent'] = (int) $p['parent'];
		}
		$old_url = get_term_link( $t );
		$before['seo'] = EGSM_Archive::get_term_seo( $t->term_id );
		$r       = $args ? wp_update_term( $t->term_id, $t->taxonomy, wp_slash( $args ) ) : true;
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		if ( ! empty( $p['seo'] ) && is_array( $p['seo'] ) ) {
			$args['seo'] = EGSM_Archive::set_term_seo( $t->term_id, $p['seo'] );
		}
		$out = array(
			'id'        => $t->term_id,
			'change_id' => EGSM_Log::record( 'update_term', 'term', $t->term_id, $before, array( 'taxonomy' => $t->taxonomy, 'fields' => $args ), 'Updated ' . $t->taxonomy . ' ' . $t->name ),
		);
		$new_url = get_term_link( (int) $t->term_id, $t->taxonomy );
		if ( ! is_wp_error( $old_url ) && ! is_wp_error( $new_url ) && EGSM_Redirects::site_path( $old_url ) !== EGSM_Redirects::site_path( $new_url ) ) {
			$red = EGSM_Redirects::add( $old_url, $new_url, 301, 'Term URL changed' );
			if ( ! is_wp_error( $red ) ) {
				$out['redirect'] = $red;
			}
		}
		return $out;
	}

	/* ---------- branding ---------- */

	public static function set_branding( $p ) {
		$b = EGSM_Settings::branding();
		foreach ( array( 'name', 'support_email' ) as $f ) {
			if ( isset( $p[ $f ] ) ) {
				$b[ $f ] = 'support_email' === $f ? sanitize_email( $p[ $f ] ) : sanitize_text_field( $p[ $f ] );
			}
		}
		foreach ( array( 'logo_url', 'support_url' ) as $f ) {
			if ( isset( $p[ $f ] ) ) {
				$b[ $f ] = esc_url_raw( $p[ $f ] );
			}
		}
		if ( isset( $p['color'] ) && preg_match( '/^#[0-9a-f]{3,8}$/i', $p['color'] ) ) {
			$b['color'] = $p['color'];
		}
		update_option( 'egsm_branding', $b, false );
		if ( isset( $p['platform_url'] ) ) {
			$paired                 = (array) get_option( 'egsm_paired', array() );
			$paired['platform_url'] = esc_url_raw( $p['platform_url'] );
			$paired['paired_at']    = isset( $paired['paired_at'] ) ? $paired['paired_at'] : gmdate( 'c' );
			update_option( 'egsm_paired', $paired, false );
		}
		return $b;
	}
}
