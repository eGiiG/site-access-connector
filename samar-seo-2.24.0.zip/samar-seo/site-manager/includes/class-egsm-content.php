<?php
/**
 * Pages and posts: list, read (builder-aware), create (incl. clone-and-fill), update, trash.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Content {

	const CLONE_SKIP_META = '/^(_edit_|_wp_old_|_wp_trash|_wp_desired|_pingme|_encloseme|_thumbnail_id|_egsm_|_yoast_|rank_math_|_aioseo_|_seopress_|_genesis_|_open_graph_|_social_image|_elementor_css|_elementor_element_cache|_elementor_page_assets|_elementor_screenshot)/';

	public static function post_types() {
		$types = get_post_types( array( 'public' => true ), 'names' );
		unset( $types['attachment'] );
		return array_values( $types );
	}

	private static function check_type( $type ) {
		if ( ! in_array( $type, self::post_types(), true ) ) {
			return new WP_Error( 'egsm_bad_type', 'Unsupported post type. Available: ' . implode( ', ', self::post_types() ), array( 'status' => 400 ) );
		}
		return true;
	}

	/** @return WP_Post|WP_Error */
	public static function get_post_or_error( $id ) {
		$post = get_post( (int) $id );
		if ( ! $post || ! in_array( $post->post_type, self::post_types(), true ) ) {
			return new WP_Error( 'egsm_not_found', 'Content not found.', array( 'status' => 404 ) );
		}
		return $post;
	}

	public static function is_live_status( $status ) {
		return in_array( $status, array( 'publish', 'private', 'future' ), true );
	}

	/* ---------- output shapes ---------- */

	public static function summary( $post, $with_counts = true ) {
		$seo = EGSM_SEO::get( $post->ID );
		$out = array(
			'id'        => $post->ID,
			'type'      => $post->post_type,
			'status'    => $post->post_status,
			'title'     => $post->post_title,
			'slug'      => $post->post_name,
			'url'       => get_permalink( $post ),
			'parent'    => (int) $post->post_parent,
			'modified'  => mysql_to_rfc3339( $post->post_modified_gmt ),
			'builder'   => EGSM_Builders::detect( $post ),
			'seo'       => array(
				'title'         => $seo['title'],
				'description'   => $seo['description'],
				'focus_keyword' => $seo['focus_keyword'],
				'noindex'       => $seo['noindex'],
			),
			'has_image' => (bool) get_post_thumbnail_id( $post ),
			'seo_score' => '' === get_post_meta( $post->ID, '_egsm_score', true ) ? null : (int) get_post_meta( $post->ID, '_egsm_score', true ),
		);
		if ( $with_counts ) {
			$out['word_count'] = EGSM_Util::word_count( EGSM_Builders::get_text( $post ) );
		}
		return $out;
	}

	public static function detail( $post, $include = array() ) {
		$builder = EGSM_Builders::detect( $post );
		$html    = EGSM_Builders::get_html( $post );
		$text    = EGSM_Util::text_from_html( $html );
		$links   = self::dedupe_links( EGSM_Util::links( $html ) );
		$thumb   = (int) get_post_thumbnail_id( $post );
		$author  = get_userdata( $post->post_author );

		$editable = 'text_replace_only';
		if ( in_array( $builder, array( 'gutenberg', 'classic' ), true ) ) {
			$editable = 'gutenberg' === $builder ? 'blocks' : 'classic_html';
		} elseif ( 'elementor' === $builder ) {
			$editable = 'elementor_slots_and_ops';
		}

		$out = array(
			'id'             => $post->ID,
			'type'           => $post->post_type,
			'status'         => $post->post_status,
			'title'          => $post->post_title,
			'slug'           => $post->post_name,
			'url'            => get_permalink( $post ),
			'edit_url'       => get_edit_post_link( $post->ID, 'raw' ),
			'parent'         => (int) $post->post_parent,
			'children'       => array_map( 'intval', get_children( array( 'post_parent' => $post->ID, 'post_type' => $post->post_type, 'fields' => 'ids', 'post_status' => array( 'publish', 'draft', 'private', 'pending', 'future' ) ) ) ),
			'menu_order'     => (int) $post->menu_order,
			'template'       => (string) get_page_template_slug( $post ),
			'author'         => array(
				'id'   => (int) $post->post_author,
				'name' => $author ? $author->display_name : '',
				'bio'  => $author ? (string) $author->description : '',
			),
			'date'           => mysql_to_rfc3339( $post->post_date_gmt ),
			'modified'       => mysql_to_rfc3339( $post->post_modified_gmt ),
			'excerpt'        => $post->post_excerpt,
			'builder'        => $builder,
			'editable_as'    => $editable,
			'seo'            => EGSM_SEO::get( $post->ID ),
			'keywords'       => (object) ( is_array( get_post_meta( $post->ID, '_egsm_keywords', true ) ) ? get_post_meta( $post->ID, '_egsm_keywords', true ) : array() ),
			'schema'         => EGSM_AISEO::get_post_schema( $post->ID ),
			'featured_image' => $thumb ? array(
				'id'  => $thumb,
				'url' => wp_get_attachment_url( $thumb ),
				'alt' => (string) get_post_meta( $thumb, '_wp_attachment_image_alt', true ),
			) : null,
			'terms'          => self::terms_of( $post ),
			'analysis'       => array(
				'word_count' => EGSM_Util::word_count( $text ),
				'headings'   => EGSM_Util::headings( $html ),
				'internal_links' => array_values( array_filter( $links, function ( $l ) {
					return $l['internal'];
				} ) ),
				'external_links' => array_values( array_filter( $links, function ( $l ) {
					return ! $l['internal'];
				} ) ),
				'images'     => self::dedupe_images( EGSM_Util::images( $html ) ),
			),
		);
		// Lean by default so a long page fits in one AI tool result: plain text up to 12k characters and the
		// stored HTML only when it is short. include=text_full / include=raw return them in full.
		$full_text = in_array( 'text_full', $include, true ) || in_array( 'full', $include, true );
		$want_raw  = in_array( 'raw', $include, true ) || in_array( 'full', $include, true );
		if ( ! in_array( 'no_text', $include, true ) ) {
			$cap         = $full_text ? 60000 : 12000;
			$out['text'] = mb_substr( $text, 0, $cap );
			if ( mb_strlen( $text ) > $cap ) {
				$out['text_truncated'] = 'Text is ' . mb_strlen( $text ) . ' characters; showing the first ' . $cap . '. Pass include=text_full for all of it.';
			}
		}
		// [thrive-support v1] For Thrive pages the raw HTML is Thrive's own content (what replace_text edits).
		$raw     = 'thrive' === $builder ? EGSM_Builders::thrive_source( $post->ID ) : (string) $post->post_content;
		$raw_len = strlen( $raw );
		if ( ! in_array( 'no_raw', $include, true ) && ( $want_raw || $raw_len <= 15000 ) ) {
			$out['content_raw'] = $raw;
		} elseif ( ! in_array( 'no_raw', $include, true ) ) {
			$out['content_raw_omitted'] = "Stored HTML is {$raw_len} characters (not included to keep this short). Pass include=raw to get it — needed for replace_text on HTML inside the page.";
		}
		if ( 'elementor' === $builder ) {
			$data                  = EGSM_Elementor::get_data( $post->ID );
			$out['elementor']      = array(
				'outline' => EGSM_Elementor::outline( $data ),
				'slots'   => EGSM_Elementor::slots( $data ),
			);
			$out['content_raw_note'] = 'content_raw is a text mirror; edit Elementor pages with elementor_slots / elementor_ops / replace_text.';
		} elseif ( 'thrive' === $builder ) {
			$out['builder_note'] = 'This page is built with Thrive Architect. Edit it with replace_text (exact text or HTML from content_raw) and the links tools; changes are written into Thrive\'s own content, its copy and the search mirror, so the live page, the Thrive editor and search stay in step. For a page built from one Custom HTML element, content_html replaces the whole layout (scripts are converted to Thrive\'s own format); keep the page\'s CSS and scripts in that HTML.';
		} elseif ( 'text_replace_only' === $editable ) {
			$out['builder_note'] = 'This page uses ' . $builder . '. Edit its text with replace_text; to build new pages in the same design, use clone_from with replace_text.';
		}
		return $out;
	}

	/** Same link repeated (e.g. "See on Amazon" ×20) is listed once with a count; lists capped at 40. */
	private static function dedupe_links( $links ) {
		$seen = array();
		foreach ( $links as $l ) {
			$k = $l['href'] . '|' . ( $l['rel'] ?? '' );
			if ( isset( $seen[ $k ] ) ) {
				$seen[ $k ]['count']++;
				continue;
			}
			$seen[ $k ] = $l + array( 'count' => 1 );
		}
		$in  = array_values( array_filter( $seen, fn ( $l ) => ! empty( $l['internal'] ) ) );
		$ext = array_values( array_filter( $seen, fn ( $l ) => empty( $l['internal'] ) ) );
		return array_merge( array_slice( $in, 0, 40 ), array_slice( $ext, 0, 40 ) );
	}

	private static function dedupe_images( $images ) {
		$seen = array();
		foreach ( $images as $i ) {
			$k = $i['src'];
			if ( ! isset( $seen[ $k ] ) || ( null === $seen[ $k ]['alt'] || '' === $seen[ $k ]['alt'] ) ) {
				$seen[ $k ] = $i;
			}
		}
		return array_slice( array_values( $seen ), 0, 40 );
	}

	private static function terms_of( $post ) {
		$out = array();
		foreach ( get_object_taxonomies( $post->post_type, 'objects' ) as $tax ) {
			if ( ! $tax->public ) {
				continue;
			}
			$terms = wp_get_object_terms( $post->ID, $tax->name );
			if ( is_wp_error( $terms ) || ! $terms ) {
				continue;
			}
			$out[ $tax->name ] = array_map(
				function ( $t ) {
					return array(
						'id'   => $t->term_id,
						'name' => $t->name,
						'slug' => $t->slug,
					);
				},
				$terms
			);
		}
		return (object) $out;
	}

	/* ---------- list ---------- */

	public static function list_items( WP_REST_Request $req ) {
		$type = $req->get_param( 'type' ) ? array_map( 'trim', explode( ',', $req->get_param( 'type' ) ) ) : array( 'page', 'post' );
		$type = array_values( array_intersect( $type, self::post_types() ) );
		if ( ! $type ) {
			return new WP_Error( 'egsm_bad_type', 'Unsupported post type.', array( 'status' => 400 ) );
		}
		$status = $req->get_param( 'status' ) ? array_map( 'trim', explode( ',', $req->get_param( 'status' ) ) ) : array( 'publish', 'draft', 'pending', 'future', 'private' );
		$per    = max( 1, min( 200, (int) ( $req->get_param( 'per_page' ) ? $req->get_param( 'per_page' ) : 50 ) ) );
		$page   = max( 1, (int) ( $req->get_param( 'page' ) ? $req->get_param( 'page' ) : 1 ) );
		$args   = array(
			'post_type'      => $type,
			'post_status'    => $status,
			'posts_per_page' => $per,
			'paged'          => $page,
			'orderby'        => $req->get_param( 'orderby' ) ? sanitize_key( $req->get_param( 'orderby' ) ) : 'modified',
			'order'          => 'asc' === strtolower( (string) $req->get_param( 'order' ) ) ? 'ASC' : 'DESC',
			'no_found_rows'  => false,
		);
		if ( $req->get_param( 'search' ) ) {
			$args['s'] = (string) $req->get_param( 'search' );
		}
		if ( null !== $req->get_param( 'parent' ) ) {
			$args['post_parent'] = (int) $req->get_param( 'parent' );
		}
		if ( $req->get_param( 'category' ) ) {
			$args['cat'] = (int) $req->get_param( 'category' );
		}
		$clause = $req->get_param( 'seo' ) ? EGSM_Score::filter_clause( sanitize_key( $req->get_param( 'seo' ) ) ) : null;
		$note   = null;
		if ( 'seo_score' === $args['orderby'] || ( $clause && 'unscored' !== $req->get_param( 'seo' ) ) ) {
			// Scores are filled in the background; make sure the next batch is done before sorting/filtering.
			$k = EGSM_Score::kick( 60 );
			if ( (int) get_option( 'egsm_score_cursor', -1 ) >= 0 ) {
				$note = 'Some content is still being scored in the background' . ( is_array( $k ) ? ' (' . (int) $k['remaining'] . ' left)' : '' ) . '; pages without a score yet have seo_score null. Ask again in a minute for a complete list.';
			}
		}
		if ( $clause ) {
			$args['meta_query'] = array( $clause );
		}
		if ( 'seo_score' === $args['orderby'] ) {
			$sort = array( 'key' => '_egsm_score', 'type' => 'NUMERIC', 'compare' => 'EXISTS' );
			if ( $clause ) {
				$args['meta_query'] = array( 'relation' => 'AND', $clause, 'egsm_sc' => $sort );
			} else {
				$args['meta_query'] = array( 'relation' => 'OR', 'egsm_sc' => $sort, array( 'key' => '_egsm_score', 'compare' => 'NOT EXISTS' ) );
			}
			$args['orderby'] = array( 'egsm_sc' => $args['order'] );
			unset( $args['order'] );
		}
		$q     = new WP_Query( $args );
		$items = array();
		$light = EGSM_Util::bool( $req->get_param( 'light' ) );
		foreach ( $q->posts as $p ) {
			$items[] = self::summary( $p, ! $light );
		}
		$out = array(
			'items'       => $items,
			'total'       => (int) $q->found_posts,
			'total_pages' => (int) $q->max_num_pages,
			'page'        => $page,
		);
		if ( $note ) {
			$out['note'] = $note;
		}
		return $out;
	}

	/* ---------- helpers for writes ---------- */

	private static function resolve_terms( $taxonomy, $values, $create ) {
		$ids = array();
		foreach ( (array) $values as $v ) {
			if ( is_numeric( $v ) ) {
				$t = get_term( (int) $v, $taxonomy );
				if ( ! $t || is_wp_error( $t ) ) {
					return new WP_Error( 'egsm_bad_term', "Term id $v not found in $taxonomy.", array( 'status' => 422 ) );
				}
				$ids[] = (int) $v;
				continue;
			}
			$name = trim( (string) $v );
			if ( '' === $name ) {
				continue;
			}
			$t = get_term_by( 'name', $name, $taxonomy );
			if ( ! $t ) {
				$t = get_term_by( 'slug', sanitize_title( $name ), $taxonomy );
			}
			if ( $t ) {
				$ids[] = (int) $t->term_id;
				continue;
			}
			if ( ! $create ) {
				return new WP_Error( 'egsm_level', "Creating the new $taxonomy '$name' needs 'publish' access.", array( 'status' => 403 ) );
			}
			$new = wp_insert_term( $name, $taxonomy );
			if ( is_wp_error( $new ) ) {
				return $new;
			}
			EGSM_Log::record( 'create_term', 'term', $new['term_id'], null, array( 'taxonomy' => $taxonomy ), "Created $taxonomy: $name" );
			$ids[] = (int) $new['term_id'];
		}
		return $ids;
	}

	/** Apply all content-level edit operations. @return true|WP_Error */
	private static function apply_content_ops( $id, $p, $is_new ) {
		$post    = get_post( $id );
		$builder = EGSM_Builders::detect( $post );
		$blocks  = 'gutenberg' === $builder || ( 'classic' !== $builder && 'gutenberg' === EGSM_Builders::default_editor( $post->post_type ) );
		$content = $post->post_content;
		$changed = false;

		$html = null;
		if ( isset( $p['content_blocks'] ) && '' !== $p['content_blocks'] ) {
			$html = (string) $p['content_blocks'];
		} elseif ( isset( $p['content_html'] ) ) {
			$html = (string) $p['content_html'];
		}
		if ( null !== $html && 'thrive' === $builder && isset( $p['content_html'] ) ) {
			// [thrive-set v1] A Thrive Custom HTML layout can be replaced as a whole.
			$r = EGSM_Builders::thrive_set_content( $id, $html );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			$html = null;
		}
		if ( null !== $html ) {
			if ( ! in_array( $builder, array( 'gutenberg', 'classic' ), true ) ) {
				return new WP_Error( 'egsm_builder', "This page is built with $builder — replacing the whole content would break its layout. Use replace_text" . ( 'elementor' === $builder ? ', elementor_slots or elementor_ops' : '' ) . ' instead.', array( 'status' => 422 ) );
			}
			$content = $blocks ? EGSM_Gutenberg::html_to_blocks( $html ) : $html;
			$changed = true;
		}
		if ( ! empty( $p['replace_section'] ) ) {
			if ( ! in_array( $builder, array( 'gutenberg', 'classic' ), true ) ) {
				return new WP_Error( 'egsm_builder', 'replace_section works on block-editor and classic pages. For ' . $builder . ' use replace_text' . ( 'elementor' === $builder ? ' or elementor_slots' : '' ) . '.', array( 'status' => 422 ) );
			}
			$sections = isset( $p['replace_section']['heading'] ) ? array( $p['replace_section'] ) : (array) $p['replace_section'];
			foreach ( $sections as $s ) {
				$r = EGSM_Gutenberg::replace_section( $content, (string) $s['heading'], (string) $s['html'], ! empty( $s['include_heading'] ) );
				if ( is_wp_error( $r ) ) {
					return $r;
				}
				$content = $r;
			}
			$changed = true;
		}
		foreach ( array( 'append_html', 'prepend_html' ) as $op ) {
			if ( empty( $p[ $op ] ) ) {
				continue;
			}
			if ( 'elementor' === $builder ) {
				$data = EGSM_Elementor::get_data( $id );
				$r    = EGSM_Elementor::apply_ops( $data, array( array( 'op' => 'append_html', 'html' => (string) $p[ $op ] ) ) );
				if ( is_wp_error( $r ) ) {
					return $r;
				}
				EGSM_Elementor::save_data( $id, $data );
				continue;
			}
			if ( ! in_array( $builder, array( 'gutenberg', 'classic' ), true ) ) {
				return new WP_Error( 'egsm_builder', "$op is not supported for $builder pages.", array( 'status' => 422 ) );
			}
			$content = 'append_html' === $op ? EGSM_Gutenberg::append( $content, $p[ $op ], $blocks ) : EGSM_Gutenberg::prepend( $content, $p[ $op ], $blocks );
			$changed = true;
		}
		if ( $changed ) {
			$r = wp_update_post(
				array(
					'ID'           => $id,
					'post_content' => wp_slash( $content ),
				),
				true
			);
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}

		if ( ! empty( $p['elementor_slots'] ) || ! empty( $p['elementor_ops'] ) ) {
			if ( 'elementor' !== EGSM_Builders::detect( $id ) ) {
				return new WP_Error( 'egsm_builder', 'elementor_slots / elementor_ops only apply to Elementor pages.', array( 'status' => 422 ) );
			}
			$data = EGSM_Elementor::get_data( $id );
			foreach ( (array) ( isset( $p['elementor_slots'] ) ? $p['elementor_slots'] : array() ) as $path => $val ) {
				$r = EGSM_Elementor::set_slot( $data, $path, $val );
				if ( is_wp_error( $r ) ) {
					return $r;
				}
			}
			if ( ! empty( $p['elementor_ops'] ) ) {
				$r = EGSM_Elementor::apply_ops( $data, $p['elementor_ops'] );
				if ( is_wp_error( $r ) ) {
					return $r;
				}
				$GLOBALS['egsm_last_elementor_created'] = $r;
			}
			EGSM_Elementor::save_data( $id, $data );
		}

		if ( ! empty( $p['replace_text'] ) ) {
			$r = EGSM_Builders::replace_text( $id, (array) $p['replace_text'], ! empty( $p['case_insensitive'] ) );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			$GLOBALS['egsm_last_replace'] = $r;
		}
		return true;
	}

	/** Terms, image, SEO, keywords, schema, FAQ. @return true|WP_Error */
	private static function apply_meta_ops( $id, $p ) {
		$post = get_post( $id );
		$can  = EGSM_Settings::level_allows( 'publish' );
		if ( isset( $p['categories'] ) && is_object_in_taxonomy( $post->post_type, 'category' ) ) {
			$ids = self::resolve_terms( 'category', $p['categories'], $can );
			if ( is_wp_error( $ids ) ) {
				return $ids;
			}
			wp_set_post_categories( $id, $ids );
		}
		if ( isset( $p['tags'] ) && is_object_in_taxonomy( $post->post_type, 'post_tag' ) ) {
			$ids = self::resolve_terms( 'post_tag', $p['tags'], $can );
			if ( is_wp_error( $ids ) ) {
				return $ids;
			}
			wp_set_post_tags( $id, $ids );
		}
		if ( isset( $p['terms'] ) && is_array( $p['terms'] ) ) {
			foreach ( $p['terms'] as $tax => $vals ) {
				if ( ! is_object_in_taxonomy( $post->post_type, $tax ) ) {
					return new WP_Error( 'egsm_bad_term', "Taxonomy $tax does not apply to this content type.", array( 'status' => 422 ) );
				}
				$ids = self::resolve_terms( $tax, $vals, $can );
				if ( is_wp_error( $ids ) ) {
					return $ids;
				}
				wp_set_object_terms( $id, $ids, $tax );
			}
		}
		if ( isset( $p['featured_media'] ) ) {
			$mid = (int) $p['featured_media'];
			if ( 0 === $mid ) {
				delete_post_thumbnail( $id );
			} elseif ( 'attachment' === get_post_type( $mid ) ) {
				set_post_thumbnail( $id, $mid );
			} else {
				return new WP_Error( 'egsm_bad_media', 'featured_media must be an attachment id.', array( 'status' => 422 ) );
			}
		}
		if ( ! empty( $p['keywords'] ) && is_array( $p['keywords'] ) ) {
			EGSM_AISEO::set_keywords( $id, $p['keywords'], true );
		}
		if ( ! empty( $p['seo'] ) && is_array( $p['seo'] ) ) {
			$r = EGSM_SEO::set( $id, $p['seo'] );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		if ( isset( $p['schema'] ) ) {
			$r = EGSM_AISEO::set_post_schema( $id, $p['schema'] );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		if ( ! empty( $p['faq']['items'] ) ) {
			$r = EGSM_AISEO::add_faq( $id, $p['faq'] );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		return true;
	}

	/* ---------- create ---------- */

	public static function create( WP_REST_Request $req ) {
		$p      = $req->get_json_params();
		$p      = is_array( $p ) ? $p : $req->get_params();
		$status = isset( $p['status'] ) ? sanitize_key( $p['status'] ) : 'draft';
		if ( ! in_array( $status, array( 'draft', 'pending', 'publish', 'future', 'private' ), true ) ) {
			return new WP_Error( 'egsm_bad_status', 'status must be draft, pending, publish, future or private.', array( 'status' => 400 ) );
		}
		if ( self::is_live_status( $status ) && ! EGSM_Settings::level_allows( 'publish' ) ) {
			return new WP_Error( 'egsm_level', "Publishing needs 'publish' access; this site allows '" . EGSM_Settings::level() . "'. Create it as a draft instead.", array( 'status' => 403 ) );
		}

		$source = null;
		if ( ! empty( $p['clone_from'] ) ) {
			$source = self::get_post_or_error( $p['clone_from'] );
			if ( is_wp_error( $source ) ) {
				return $source;
			}
		}
		$type = isset( $p['type'] ) ? sanitize_key( $p['type'] ) : ( $source ? $source->post_type : 'page' );
		$ok   = self::check_type( $type );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		if ( empty( $p['title'] ) ) {
			return new WP_Error( 'egsm_bad_request', 'title is required.', array( 'status' => 400 ) );
		}

		$postarr = array(
			'post_type'    => $type,
			'post_title'   => sanitize_text_field( $p['title'] ),
			'post_status'  => 'draft',
			'post_content' => $source ? $source->post_content : '',
			'post_excerpt' => isset( $p['excerpt'] ) ? (string) $p['excerpt'] : '',
			'post_author'  => ! empty( $p['author'] ) ? (int) $p['author'] : get_current_user_id(),
		);
		if ( ! empty( $p['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( $p['slug'] );
		}
		if ( isset( $p['parent'] ) ) {
			$postarr['post_parent'] = (int) $p['parent'];
		} elseif ( $source ) {
			$postarr['post_parent'] = (int) $source->post_parent;
		}
		if ( isset( $p['menu_order'] ) ) {
			$postarr['menu_order'] = (int) $p['menu_order'];
		}
		if ( ! empty( $p['date'] ) ) {
			$postarr['post_date'] = get_date_from_gmt( gmdate( 'Y-m-d H:i:s', strtotime( $p['date'] ) ) );
		}

		$id = wp_insert_post( wp_slash( $postarr ), true );
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		$fail = function ( $err ) use ( $id ) {
			wp_delete_post( $id, true );
			return $err;
		};

		if ( $source ) {
			foreach ( (array) get_post_meta( $source->ID ) as $k => $vals ) {
				if ( preg_match( self::CLONE_SKIP_META, $k ) ) {
					continue;
				}
				foreach ( $vals as $raw ) {
					add_post_meta( $id, $k, EGSM_Util::deep_slash( maybe_unserialize( $raw ) ) );
				}
			}
			if ( 'elementor' === EGSM_Builders::detect( $source ) ) {
				EGSM_Elementor::clear_css( $id );
			}
		}
		if ( ! empty( $p['template'] ) ) {
			update_post_meta( $id, '_wp_page_template', sanitize_text_field( $p['template'] ) );
		}

		$r = self::apply_content_ops( $id, $p, true );
		if ( is_wp_error( $r ) ) {
			return $fail( $r );
		}
		$r = self::apply_meta_ops( $id, $p );
		if ( is_wp_error( $r ) ) {
			return $fail( $r );
		}

		if ( 'draft' !== $status ) {
			$upd = array(
				'ID'          => $id,
				'post_status' => $status,
			);
			wp_update_post( $upd );
		}
		$change_id = EGSM_Log::post_changed( 'create', $id, null, sprintf( 'Created %s "%s"%s', $type, $postarr['post_title'], $source ? ' from #' . $source->ID : '' ) );
		if ( self::is_live_status( $status ) ) {
			EGSM_Cache::purge_post( $id );
		}
		$out              = self::summary( get_post( $id ) );
		$out['change_id'] = $change_id;
		$out['edit_url']  = get_edit_post_link( $id, 'raw' );
		if ( ! empty( $GLOBALS['egsm_last_elementor_created'] ) ) {
			$out['elementor_created'] = $GLOBALS['egsm_last_elementor_created'];
		}
		if ( ! empty( $GLOBALS['egsm_last_replace'] ) ) {
			$out['replaced'] = $GLOBALS['egsm_last_replace'];
		}
		if ( 'publish' !== $status ) {
			$out['preview_url'] = get_preview_post_link( $id );
		}
		return $out;
	}

	/* ---------- update ---------- */

	public static function update( WP_REST_Request $req ) {
		$post = self::get_post_or_error( $req['id'] );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$id = $post->ID;
		$p  = $req->get_json_params();
		$p  = is_array( $p ) ? $p : $req->get_params();

		$publish_ok = EGSM_Settings::level_allows( 'publish' );
		if ( ! $publish_ok ) {
			if ( self::is_live_status( $post->post_status ) ) {
				return new WP_Error( 'egsm_level', "This page is live. Editing live content needs 'publish' access; this site allows '" . EGSM_Settings::level() . "'.", array( 'status' => 403 ) );
			}
			if ( isset( $p['status'] ) && self::is_live_status( $p['status'] ) ) {
				return new WP_Error( 'egsm_level', "Publishing needs 'publish' access.", array( 'status' => 403 ) );
			}
		}

		$before     = EGSM_Log::snapshot_post( $id );
		$old_urls   = EGSM_Structure::urls_of_tree( $id );
		$was_live   = 'publish' === $post->post_status;

		$fields = array( 'ID' => $id );
		if ( isset( $p['title'] ) ) {
			$fields['post_title'] = sanitize_text_field( $p['title'] );
		}
		if ( isset( $p['slug'] ) ) {
			$fields['post_name'] = sanitize_title( $p['slug'] );
		}
		if ( isset( $p['excerpt'] ) ) {
			$fields['post_excerpt'] = (string) $p['excerpt'];
		}
		if ( isset( $p['parent'] ) ) {
			$fields['post_parent'] = (int) $p['parent'];
			if ( (int) $p['parent'] === $id ) {
				return new WP_Error( 'egsm_bad_parent', 'A page cannot be its own parent.', array( 'status' => 400 ) );
			}
		}
		if ( isset( $p['menu_order'] ) ) {
			$fields['menu_order'] = (int) $p['menu_order'];
		}
		if ( isset( $p['author'] ) ) {
			$fields['post_author'] = (int) $p['author'];
		}
		if ( isset( $p['status'] ) ) {
			$st = sanitize_key( $p['status'] );
			if ( ! in_array( $st, array( 'draft', 'pending', 'publish', 'future', 'private' ), true ) ) {
				return new WP_Error( 'egsm_bad_status', 'Invalid status.', array( 'status' => 400 ) );
			}
			$fields['post_status'] = $st;
		}
		if ( ! empty( $p['date'] ) ) {
			$fields['post_date'] = get_date_from_gmt( gmdate( 'Y-m-d H:i:s', strtotime( $p['date'] ) ) );
			$fields['edit_date'] = true;
		}

		$rollback = function ( $err ) use ( $id, $before ) {
			EGSM_Log::rollback( $id, $before );
			return $err;
		};

		if ( count( $fields ) > 1 ) {
			$r = wp_update_post( wp_slash( $fields ), true );
			if ( is_wp_error( $r ) ) {
				return $rollback( $r );
			}
		}
		if ( ! empty( $p['template'] ) ) {
			update_post_meta( $id, '_wp_page_template', sanitize_text_field( $p['template'] ) );
		}
		$r = self::apply_content_ops( $id, $p, false );
		if ( is_wp_error( $r ) ) {
			return $rollback( $r );
		}
		$r = self::apply_meta_ops( $id, $p );
		if ( is_wp_error( $r ) ) {
			return $rollback( $r );
		}

		// URL changed on a live page → 301s for it and every descendant.
		$redirects = array();
		if ( $was_live && 'publish' === get_post_status( $id ) && ! isset( $p['no_redirect'] ) ) {
			$redirects = EGSM_Redirects::create_for_moves( $old_urls, EGSM_Structure::urls_of_tree( $id ) );
		}

		$summary   = isset( $p['change_note'] ) ? sanitize_text_field( $p['change_note'] ) : 'Updated ' . $post->post_type . ' "' . get_the_title( $id ) . '"';
		$change_id = EGSM_Log::post_changed( 'update', $id, $before, $summary );
		$purged    = EGSM_Cache::purge_post( $id );

		$out              = self::summary( get_post( $id ) );
		$out['change_id'] = $change_id;
		$out['changed']   = $change_id > 0;
		if ( $redirects ) {
			$out['redirects_created'] = $redirects;
		}
		if ( ! empty( $GLOBALS['egsm_last_elementor_created'] ) ) {
			$out['elementor_created'] = $GLOBALS['egsm_last_elementor_created'];
		}
		if ( ! empty( $GLOBALS['egsm_last_replace'] ) ) {
			$out['replaced'] = $GLOBALS['egsm_last_replace'];
		}
		if ( $purged ) {
			$out['cache_purged'] = $purged;
		}
		return $out;
	}

	/* ---------- trash ---------- */

	public static function trash( WP_REST_Request $req ) {
		$post = self::get_post_or_error( $req['id'] );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$before = EGSM_Log::snapshot_post( $post->ID );
		$url    = get_permalink( $post );
		if ( ! wp_trash_post( $post->ID ) ) {
			return new WP_Error( 'egsm_trash_failed', 'Could not move to trash.', array( 'status' => 500 ) );
		}
		$redirect = null;
		$target   = $req->get_param( 'redirect_to' );
		if ( $target && 'publish' === $before['post']['post_status'] ) {
			$redirect = EGSM_Redirects::add( $url, $target, 301, 'Trashed #' . $post->ID );
		}
		$change_id = EGSM_Log::post_changed( 'trash', $post->ID, $before, 'Trashed "' . $post->post_title . '"' );
		EGSM_Cache::purge_post( $post->ID );
		return array(
			'trashed'   => $post->ID,
			'change_id' => $change_id,
			'redirect'  => is_wp_error( $redirect ) ? $redirect->get_error_message() : $redirect,
		);
	}
}
