<?php
/**
 * AI search optimization (AEO / GEO): AI crawler access, llms.txt, JSON-LD schema,
 * FAQ sections, keyword map, answer-readiness scoring, author (E-E-A-T) data.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_AISEO {

	/** user-agent token => [company, purpose] */
	const AI_BOTS = array(
		'GPTBot'             => array( 'OpenAI', 'training' ),
		'OAI-SearchBot'      => array( 'OpenAI', 'ai_search' ),
		'ChatGPT-User'       => array( 'OpenAI', 'user_fetch' ),
		'ClaudeBot'          => array( 'Anthropic', 'training' ),
		'Claude-SearchBot'   => array( 'Anthropic', 'ai_search' ),
		'Claude-User'        => array( 'Anthropic', 'user_fetch' ),
		'PerplexityBot'      => array( 'Perplexity', 'ai_search' ),
		'Perplexity-User'    => array( 'Perplexity', 'user_fetch' ),
		'Google-Extended'    => array( 'Google', 'training' ),
		'Applebot-Extended'  => array( 'Apple', 'training' ),
		'Amazonbot'          => array( 'Amazon', 'ai_search' ),
		'DuckAssistBot'      => array( 'DuckDuckGo', 'ai_search' ),
		'MistralAI-User'     => array( 'Mistral', 'user_fetch' ),
		'meta-externalagent' => array( 'Meta', 'training' ),
		'CCBot'              => array( 'Common Crawl', 'training' ),
		'Bytespider'         => array( 'ByteDance', 'training' ),
		'cohere-ai'          => array( 'Cohere', 'training' ),
	);
	const SEARCH_BOTS = array( 'Googlebot', 'Bingbot' );

	public static function init_frontend() {
		add_filter( 'robots_txt', array( __CLASS__, 'filter_robots' ), 99, 2 );
		add_action( 'wp_loaded', array( __CLASS__, 'maybe_serve_llms' ), 1 );
		add_action( 'wp_head', array( __CLASS__, 'output_schema' ), 30 );
		add_action( 'save_post', array( __CLASS__, 'flush_llms_cache' ) );
		add_action( 'egsm_llms_regen', array( __CLASS__, 'regen_llms' ) );
	}

	/* =========================================================
	 * robots.txt / AI crawlers
	 * ========================================================= */

	public static function physical_robots() {
		$f = ABSPATH . 'robots.txt';
		return file_exists( $f ) ? $f : null;
	}

	public static function filter_robots( $output, $public ) {
		if ( EGSM_SSEO::on() && '0' !== (string) $public ) {
			list( $src, $txt ) = EGSM_SSEO::robots_source();
			if ( 'option' === $src ) {
				$output = $txt; // SEO Suite saves this but never serves it; serve it here.
			}
		}
		$add = self::managed_block();
		return '' === $add ? $output : rtrim( $output ) . "\n" . $add;
	}

	/** Our robots.txt rules (AI crawler choices + extra lines), or '' when there are none. */
	public static function managed_block() {
		$rules = get_option( 'egsm_ai_bots', array() );
		$extra = (string) get_option( 'egsm_robots_extra', '' );
		if ( ( ! is_array( $rules ) || ! $rules ) && '' === trim( $extra ) ) {
			return '';
		}
		$add = "\n# BEGIN egsm\n";
		foreach ( (array) $rules as $bot => $mode ) {
			if ( 'block' === $mode ) {
				$add .= "User-agent: {$bot}\nDisallow: /\n\n";
			} elseif ( 'allow' === $mode ) {
				$add .= "User-agent: {$bot}\nAllow: /\n\n";
			}
		}
		if ( '' !== trim( $extra ) ) {
			$add .= trim( $extra ) . "\n";
		}
		$add .= "# END egsm\n";
		return $add;
	}

	/** A physical robots.txt ignores WordPress filters: write our block into the file (SEO Suite sites only). */
	private static function sync_robots_file() {
		if ( self::physical_robots() && EGSM_SSEO::on() ) {
			return EGSM_SSEO::robots_write_file_block( self::managed_block() );
		}
		return true;
	}

	private static function robots_file_blocks_edit() {
		return self::physical_robots() && ! ( EGSM_SSEO::on() && is_writable( ABSPATH . 'robots.txt' ) );
	}

	/** The robots.txt the site actually serves (physical file or WordPress's virtual one). */
	public static function effective_robots() {
		$file = self::physical_robots();
		if ( $file ) {
			return array(
				'source' => 'file',
				'text'   => (string) file_get_contents( $file ),
			);
		}
		$public = (string) get_option( 'blog_public' );
		$out    = "User-agent: *\n";
		if ( '0' === $public ) {
			$out .= "Disallow: /\n";
		} else {
			$path = (string) wp_parse_url( site_url(), PHP_URL_PATH );
			$out .= "Disallow: $path/wp-admin/\n";
			$out .= "Allow: $path/wp-admin/admin-ajax.php\n";
		}
		return array(
			'source' => 'virtual',
			'text'   => (string) apply_filters( 'robots_txt', $out, $public ),
		);
	}

	/** Parse robots.txt into groups of user-agents + rules. */
	public static function parse_robots( $text ) {
		$groups = array();
		$cur    = null;
		$last   = '';
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			$line = trim( preg_replace( '/#.*$/', '', $line ) );
			if ( '' === $line || false === strpos( $line, ':' ) ) {
				continue;
			}
			list( $k, $v ) = array_map( 'trim', explode( ':', $line, 2 ) );
			$k             = strtolower( $k );
			if ( 'user-agent' === $k ) {
				if ( null === $cur || 'ua' !== $last ) {
					if ( null !== $cur ) {
						$groups[] = $cur;
					}
					$cur = array(
						'agents' => array(),
						'rules'  => array(),
					);
				}
				$cur['agents'][] = strtolower( $v );
				$last            = 'ua';
			} elseif ( in_array( $k, array( 'allow', 'disallow' ), true ) && null !== $cur ) {
				$cur['rules'][] = array( $k, $v );
				$last           = 'rule';
			} else {
				$last = 'other';
			}
		}
		if ( null !== $cur ) {
			$groups[] = $cur;
		}
		return $groups;
	}

	/** Is path "/" crawlable for this user-agent? Longest-match wins, ties go to allow. */
	public static function bot_allowed( $groups, $bot, $path = '/' ) {
		$bot   = strtolower( $bot );
		$rules = null;
		$best  = -1;
		foreach ( $groups as $g ) {
			foreach ( $g['agents'] as $a ) {
				if ( '*' !== $a && ( $a === $bot || 0 === strpos( $bot, $a ) ) && strlen( $a ) > $best ) {
					$best  = strlen( $a );
					$rules = $g['rules'];
				}
			}
		}
		if ( null === $rules ) {
			$rules = array();
			foreach ( $groups as $g ) {
				if ( in_array( '*', $g['agents'], true ) ) {
					$rules = array_merge( $rules, $g['rules'] );
				}
			}
		}
		$verdict = true;
		$len     = -1;
		foreach ( $rules as $r ) {
			list( $type, $pattern ) = $r;
			if ( '' === $pattern ) {
				continue;
			}
			$regex = '#^' . str_replace( array( '\*', '\$' ), array( '.*', '$' ), preg_quote( $pattern, '#' ) ) . '#';
			if ( preg_match( $regex, $path ) ) {
				$l = strlen( $pattern );
				if ( $l > $len || ( $l === $len && 'allow' === $type ) ) {
					$len     = $l;
					$verdict = 'allow' === $type;
				}
			}
		}
		return $verdict;
	}

	public static function bots_status() {
		$robots  = self::effective_robots();
		$groups  = self::parse_robots( $robots['text'] );
		$managed = get_option( 'egsm_ai_bots', array() );
		$bots    = array();
		foreach ( self::AI_BOTS as $bot => $info ) {
			$bots[] = array(
				'bot'     => $bot,
				'company' => $info[0],
				'purpose' => $info[1],
				'allowed' => self::bot_allowed( $groups, $bot ),
				'managed' => isset( $managed[ $bot ] ) ? $managed[ $bot ] : 'default',
			);
		}
		$search = array();
		foreach ( self::SEARCH_BOTS as $bot ) {
			$search[ $bot ] = self::bot_allowed( $groups, $bot );
		}
		return array(
			'robots_source' => $robots['source'],
			'robots_txt'    => $robots['text'],
			'editable'      => 'virtual' === $robots['source'],
			'ai_bots'       => $bots,
			'search_bots'   => $search,
			'purposes'      => array(
				'training'   => 'Collects content to train AI models. Blocking does not remove you from AI answers that use live search.',
				'ai_search'  => 'Indexes pages for AI answer engines (ChatGPT search, Perplexity, Claude search). Block these and the site stops being cited in AI answers.',
				'user_fetch' => 'Fetches a page when a user asks an assistant about it.',
			),
		);
	}

	/** @param array $changes bot => allow|block|default */
	public static function set_bots( $changes ) {
		if ( self::robots_file_blocks_edit() ) {
			return new WP_Error( 'egsm_robots_file', 'This site serves a physical robots.txt file, so rules must be edited in that file on the server (or delete it to let WordPress manage robots.txt).', array( 'status' => 409 ) );
		}
		$before = EGSM_Log::option_state( array( 'egsm_ai_bots' ) );
		$rules  = get_option( 'egsm_ai_bots', array() );
		$rules  = is_array( $rules ) ? $rules : array();
		foreach ( (array) $changes as $bot => $mode ) {
			$bot = preg_replace( '/[^A-Za-z0-9\-_.]/', '', (string) $bot );
			if ( '' === $bot ) {
				continue;
			}
			if ( 'default' === $mode ) {
				unset( $rules[ $bot ] );
			} elseif ( in_array( $mode, array( 'allow', 'block' ), true ) ) {
				$rules[ $bot ] = $mode;
			} else {
				return new WP_Error( 'egsm_bad_request', "Mode for $bot must be allow, block or default.", array( 'status' => 400 ) );
			}
		}
		update_option( 'egsm_ai_bots', $rules, false );
		$w = self::sync_robots_file();
		if ( is_wp_error( $w ) ) {
			return $w;
		}
		$cid = EGSM_Log::record( 'robots_ai_bots', 'option', 0, $before, EGSM_Log::option_state( array( 'egsm_ai_bots' ) ), 'Updated AI crawler rules' );
		return array_merge( self::bots_status(), array( 'change_id' => $cid ) );
	}

	public static function set_robots_extra( $text ) {
		if ( self::robots_file_blocks_edit() ) {
			return new WP_Error( 'egsm_robots_file', 'This site serves a physical robots.txt file; edit it on the server.', array( 'status' => 409 ) );
		}
		$text = trim( (string) $text );
		if ( preg_match( '/[<>]/', $text ) ) {
			return new WP_Error( 'egsm_bad_request', 'robots.txt rules cannot contain HTML or code.', array( 'status' => 400 ) );
		}
		foreach ( preg_split( '/\r\n|\r|\n/', $text ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || '#' === $line[0] ) {
				continue;
			}
			if ( ! preg_match( '/^(user-agent|allow|disallow|sitemap|crawl-delay|host)\s*:/i', $line ) ) {
				return new WP_Error( 'egsm_bad_request', 'Invalid robots.txt line: ' . $line, array( 'status' => 400 ) );
			}
		}
		$before = EGSM_Log::option_state( array( 'egsm_robots_extra' ) );
		update_option( 'egsm_robots_extra', $text, false );
		$w = self::sync_robots_file();
		if ( is_wp_error( $w ) ) {
			return $w;
		}
		$cid = EGSM_Log::record( 'robots_extra', 'option', 0, $before, EGSM_Log::option_state( array( 'egsm_robots_extra' ) ), 'Updated custom robots.txt rules' );
		$r   = self::effective_robots();
		return array(
			'robots_txt' => $r['text'],
			'change_id'  => $cid,
		);
	}

	/* =========================================================
	 * llms.txt
	 * ========================================================= */

	public static function llms_settings() {
		$s = get_option( 'egsm_llms', array() );
		return wp_parse_args(
			is_array( $s ) ? $s : array(),
			array(
				'enabled'       => false,
				'full'          => false,
				'intro'         => '',
				'include_posts' => 25,
				'sections'      => array(),
				'custom_text'   => '',
			)
		);
	}

	public static function set_llms( $params ) {
		$before = EGSM_Log::option_state( array( 'egsm_llms' ) );
		$s      = self::llms_settings();
		foreach ( array( 'enabled', 'full' ) as $b ) {
			if ( isset( $params[ $b ] ) ) {
				$s[ $b ] = EGSM_Util::bool( $params[ $b ] );
			}
		}
		if ( isset( $params['intro'] ) ) {
			$s['intro'] = sanitize_textarea_field( $params['intro'] );
		}
		if ( isset( $params['include_posts'] ) ) {
			$s['include_posts'] = max( 0, min( 200, (int) $params['include_posts'] ) );
		}
		if ( isset( $params['custom_text'] ) ) {
			$s['custom_text'] = sanitize_textarea_field( $params['custom_text'] );
		}
		if ( isset( $params['sections'] ) && is_array( $params['sections'] ) ) {
			$clean = array();
			foreach ( $params['sections'] as $sec ) {
				if ( empty( $sec['title'] ) ) {
					continue;
				}
				$items = array();
				foreach ( (array) ( isset( $sec['items'] ) ? $sec['items'] : array() ) as $it ) {
					if ( is_numeric( $it ) ) {
						$items[] = (int) $it;
					} elseif ( is_array( $it ) && ! empty( $it['url'] ) ) {
						$items[] = array(
							'url'         => esc_url_raw( $it['url'] ),
							'title'       => sanitize_text_field( isset( $it['title'] ) ? $it['title'] : $it['url'] ),
							'description' => sanitize_text_field( isset( $it['description'] ) ? $it['description'] : '' ),
						);
					}
				}
				$clean[] = array(
					'title' => sanitize_text_field( $sec['title'] ),
					'items' => $items,
				);
			}
			$s['sections'] = $clean;
		}
		$names  = EGSM_SSEO::on() ? array( 'egsm_llms', 'sseo_llms_txt_content' ) : array( 'egsm_llms' );
		$before = EGSM_Log::option_state( $names );
		update_option( 'egsm_llms', $s, false );
		self::flush_llms_cache();
		if ( EGSM_SSEO::on() ) {
			// SEO Suite serves /llms.txt from this option (empty = its own default file).
			EGSM_SSEO::llms_write( $s['enabled'] ? self::generate_llms( false ) : '' );
		}
		$cid = EGSM_Log::record( 'llms_txt', 'option', 0, $before, EGSM_Log::option_state( $names ), 'Updated llms.txt' );
		return array(
			'settings'  => $s,
			'url'       => home_url( '/llms.txt' ),
			'preview'   => self::generate_llms(),
			'change_id' => $cid,
			'physical_file_conflict' => file_exists( ABSPATH . 'llms.txt' ),
		);
	}

	public static function flush_llms_cache() {
		delete_transient( 'egsm_llms' );
		delete_transient( 'egsm_llms_full' );
		// SEO Suite serves a stored copy, so refresh it a few minutes after content changes (batched).
		if ( EGSM_SSEO::on() && did_action( 'init' ) ) {
			$s = self::llms_settings();
			if ( $s['enabled'] && '' === trim( $s['custom_text'] ) && ! wp_next_scheduled( 'egsm_llms_regen' ) ) {
				wp_schedule_single_event( time() + 300, 'egsm_llms_regen' );
			}
		}
	}

	public static function regen_llms() {
		$s = self::llms_settings();
		if ( EGSM_SSEO::on() && $s['enabled'] ) {
			EGSM_SSEO::llms_write( self::generate_llms( false ) );
		}
	}

	private static function describe( $post ) {
		$seo = EGSM_SEO::get( $post->ID );
		if ( '' !== $seo['description'] ) {
			return $seo['effective_description'];
		}
		if ( '' !== trim( $post->post_excerpt ) ) {
			return wp_strip_all_tags( $post->post_excerpt );
		}
		$w = EGSM_Util::first_words( EGSM_Builders::get_text( $post ), 28 );
		return '' !== $w ? $w . '…' : '';
	}

	private static function line( $title, $url, $desc ) {
		$title = str_replace( array( '[', ']' ), array( '(', ')' ), $title );
		return '- [' . $title . '](' . $url . ')' . ( '' !== $desc ? ': ' . preg_replace( '/\s+/', ' ', $desc ) : '' );
	}

	private static function indexable( $post ) {
		if ( 'publish' !== $post->post_status || '' !== $post->post_password ) {
			return false;
		}
		$seo = EGSM_SEO::get( $post->ID );
		return ! $seo['noindex'];
	}

	public static function generate_llms( $full = false ) {
		$s = self::llms_settings();
		if ( '' !== trim( $s['custom_text'] ) && ! $full ) {
			return $s['custom_text'];
		}
		$included = array();
		$out      = '# ' . get_bloginfo( 'name' ) . "\n\n";
		$tagline  = get_bloginfo( 'description' );
		$intro    = '' !== $s['intro'] ? $s['intro'] : $tagline;
		if ( '' !== trim( $intro ) ) {
			$out .= '> ' . preg_replace( '/\s+/', ' ', trim( $intro ) ) . "\n\n";
		}

		$utility = '/(privacy|terms|cookie|disclaimer|accessibility|sitemap|thank|login|account|cart|checkout)/i';
		$sections = array();
		if ( $s['sections'] ) {
			foreach ( $s['sections'] as $sec ) {
				$lines = array();
				foreach ( $sec['items'] as $it ) {
					if ( is_int( $it ) ) {
						$p = get_post( $it );
						if ( $p && self::indexable( $p ) ) {
							$lines[]    = self::line( $p->post_title, get_permalink( $p ), self::describe( $p ) );
							$included[] = $p->ID;
						}
					} else {
						$lines[] = self::line( $it['title'], $it['url'], $it['description'] );
					}
				}
				if ( $lines ) {
					$sections[ $sec['title'] ] = $lines;
				}
			}
		} else {
			$pages    = get_pages(
				array(
					'post_status' => 'publish',
					'sort_column' => 'menu_order,post_title',
				)
			);
			$by_parent = array();
			foreach ( $pages as $p ) {
				$by_parent[ (int) $p->post_parent ][] = $p;
			}
			$front    = (int) get_option( 'page_on_front' );
			$main     = array();
			$optional = array();
			foreach ( isset( $by_parent[0] ) ? $by_parent[0] : array() as $p ) {
				if ( ! self::indexable( $p ) ) {
					continue;
				}
				$line = self::line( $p->ID === $front ? $p->post_title . ' (home)' : $p->post_title, get_permalink( $p ), self::describe( $p ) );
				if ( preg_match( $utility, $p->post_name ) ) {
					$optional[] = $line;
					continue;
				}
				$included[] = $p->ID;
				if ( ! empty( $by_parent[ $p->ID ] ) ) {
					$group = array( $line );
					$stack = $by_parent[ $p->ID ];
					while ( $stack ) {
						$c = array_shift( $stack );
						if ( self::indexable( $c ) ) {
							$group[]    = self::line( $c->post_title, get_permalink( $c ), self::describe( $c ) );
							$included[] = $c->ID;
						}
						if ( ! empty( $by_parent[ $c->ID ] ) ) {
							$stack = array_merge( $stack, $by_parent[ $c->ID ] );
						}
					}
					$sections[ $p->post_title ] = $group;
				} else {
					$main[] = $line;
				}
			}
			if ( $main ) {
				$sections = array( 'Pages' => $main ) + $sections;
			}
			if ( $s['include_posts'] > 0 ) {
				$posts = get_posts(
					array(
						'post_type'   => 'post',
						'post_status' => 'publish',
						'numberposts' => (int) $s['include_posts'],
					)
				);
				$lines = array();
				foreach ( $posts as $p ) {
					if ( self::indexable( $p ) ) {
						$lines[]    = self::line( $p->post_title, get_permalink( $p ), self::describe( $p ) );
						$included[] = $p->ID;
					}
				}
				if ( $lines ) {
					$sections['Articles'] = $lines;
				}
			}
			if ( $optional ) {
				$sections['Optional'] = $optional;
			}
		}
		foreach ( $sections as $title => $lines ) {
			$out .= '## ' . $title . "\n\n" . implode( "\n", $lines ) . "\n\n";
		}
		if ( $full ) {
			$out .= "---\n\n";
			$budget = 400000;
			foreach ( array_unique( $included ) as $pid ) {
				$p = get_post( $pid );
				$t = EGSM_Builders::get_text( $p );
				$chunk = '# ' . $p->post_title . "\n\nURL: " . get_permalink( $p ) . "\n\n" . $t . "\n\n---\n\n";
				if ( strlen( $chunk ) > $budget ) {
					break;
				}
				$budget -= strlen( $chunk );
				$out    .= $chunk;
			}
		}
		return trim( $out ) . "\n";
	}

	public static function maybe_serve_llms() {
		if ( ! isset( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		$path = (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH );
		$base = rtrim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
		$full = null;
		if ( $path === $base . '/llms.txt' ) {
			if ( EGSM_SSEO::on() ) {
				// Serve SEO Suite's llms.txt here, before WordPress adds a trailing-slash redirect to /llms.txt/
				// and without depending on a rewrite-rule flush.
				$text = EGSM_SSEO::llms_text();
				if ( '' !== $text ) {
					status_header( 200 );
					header( 'Content-Type: text/plain; charset=utf-8' );
					header( 'Cache-Control: public, max-age=3600' );
					echo $text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plain text document.
					exit;
				}
				return;
			}
			$full = false;
		} elseif ( $path === $base . '/llms-full.txt' ) {
			$full = true;
		}
		if ( null === $full ) {
			return;
		}
		$s = self::llms_settings();
		if ( ! $s['enabled'] || ( $full && ! $s['full'] ) ) {
			return;
		}
		$key  = $full ? 'egsm_llms_full' : 'egsm_llms';
		$text = get_transient( $key );
		if ( false === $text ) {
			$text = self::generate_llms( $full );
			set_transient( $key, $text, 12 * HOUR_IN_SECONDS );
		}
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' );
		echo $text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plain text document.
		exit;
	}

	/* =========================================================
	 * JSON-LD schema
	 * ========================================================= */

	private static function clean_schema( $schema ) {
		if ( null === $schema || array() === $schema || '' === $schema ) {
			return array();
		}
		if ( is_string( $schema ) ) {
			$schema = json_decode( $schema, true );
			if ( null === $schema ) {
				return new WP_Error( 'egsm_bad_schema', 'Schema must be valid JSON-LD.', array( 'status' => 400 ) );
			}
		}
		if ( isset( $schema['@type'] ) || isset( $schema['@graph'] ) ) {
			$schema = array( $schema );
		}
		$out = array();
		foreach ( (array) $schema as $i => $obj ) {
			if ( ! is_array( $obj ) || ( empty( $obj['@type'] ) && empty( $obj['@graph'] ) ) ) {
				return new WP_Error( 'egsm_bad_schema', "Schema item $i needs an @type.", array( 'status' => 400 ) );
			}
			if ( empty( $obj['@context'] ) ) {
				$obj = array( '@context' => 'https://schema.org' ) + $obj;
			}
			$out[] = $obj;
		}
		if ( strlen( wp_json_encode( $out ) ) > 100000 ) {
			return new WP_Error( 'egsm_bad_schema', 'Schema is too large (max 100 KB).', array( 'status' => 400 ) );
		}
		return $out;
	}

	public static function get_post_schema( $id ) {
		$s = get_post_meta( $id, '_egsm_schema', true );
		return is_array( $s ) ? $s : array();
	}

	/** Replaces the page's schema list. Pass [] to clear. */
	public static function set_post_schema( $id, $schema ) {
		$clean = self::clean_schema( $schema );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}
		if ( ! $clean ) {
			delete_post_meta( $id, '_egsm_schema' );
		} else {
			EGSM_Util::set_meta( $id, '_egsm_schema', $clean );
		}
		return true;
	}

	/** Add/replace one schema type on a page (e.g. FAQPage) keeping the others. */
	public static function upsert_post_schema( $id, $obj ) {
		$list  = self::get_post_schema( $id );
		$type  = isset( $obj['@type'] ) ? $obj['@type'] : '';
		$list  = array_values(
			array_filter(
				$list,
				function ( $o ) use ( $type ) {
					return ! isset( $o['@type'] ) || $o['@type'] !== $type;
				}
			)
		);
		$list[] = $obj;
		return self::set_post_schema( $id, $list );
	}

	public static function get_site_schema() {
		$s = get_option( 'egsm_site_schema', array() );
		return is_array( $s ) ? $s : array();
	}

	public static function set_site_schema( $schema ) {
		$clean = self::clean_schema( $schema );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}
		$names   = array( 'egsm_site_schema' );
		$mapped  = array();
		$ignored = array();
		if ( EGSM_SSEO::on() ) {
			$names = array_merge( $names, array_keys( EGSM_SSEO::business_options_snapshot() ) );
		}
		$before = EGSM_Log::option_state( $names );
		if ( EGSM_SSEO::on() ) {
			// Business details go into SEO Suite's business profile, which prints the LocalBusiness schema.
			$keep = array();
			foreach ( $clean as $obj ) {
				if ( EGSM_SSEO::is_business( $obj ) ) {
					list( $m, $ig ) = EGSM_SSEO::map_business( $obj );
					$mapped         = array_merge( $mapped, $m );
					$ignored        = array_merge( $ignored, $ig );
				} else {
					$keep[] = $obj;
				}
			}
			$clean = $keep;
		}
		update_option( 'egsm_site_schema', $clean );
		$cid = EGSM_Log::record( 'site_schema', 'option', 0, $before, EGSM_Log::option_state( $names ), 'Updated site-wide schema' );
		$out = array(
			'schema'    => $clean,
			'change_id' => $cid,
		);
		if ( $mapped || $ignored ) {
			$out['business_profile'] = array(
				'saved_to_seo_suite' => array_values( array_unique( $mapped ) ),
				'not_supported'      => array_values( array_unique( $ignored ) ),
				'note'               => 'The LocalBusiness object was saved to SEO Suite\'s business profile, which outputs it on the home, contact and about pages. Fields under not_supported (e.g. opening hours, services, reviews) must be set in SEO Suite\'s Local SEO screen.',
			);
		}
		return $out;
	}

	public static function output_schema() {
		$items = self::get_site_schema();
		if ( is_singular() ) {
			$items = array_merge( $items, self::get_post_schema( get_queried_object_id() ) );
		}
		if ( EGSM_SSEO::on() ) {
			$skip  = EGSM_SSEO::types_emitted_here();
			$items = array_filter(
				$items,
				function ( $o ) use ( $skip ) {
					return ! array_intersect( (array) ( isset( $o['@type'] ) ? $o['@type'] : array() ), $skip );
				}
			);
		}
		foreach ( $items as $obj ) {
			echo '<script type="application/ld+json" class="egsm-schema">' . wp_json_encode( $obj, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ) . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	/**
	 * Add a visible FAQ section + FAQPage schema.
	 * $faq = { items:[{question,answer}], title?, schema?:bool, content?:bool }
	 */
	public static function add_faq( $id, $faq ) {
		$items = array();
		foreach ( (array) $faq['items'] as $it ) {
			$q = trim( (string) ( isset( $it['question'] ) ? $it['question'] : ( isset( $it['q'] ) ? $it['q'] : '' ) ) );
			$a = trim( (string) ( isset( $it['answer'] ) ? $it['answer'] : ( isset( $it['a'] ) ? $it['a'] : '' ) ) );
			if ( '' !== $q && '' !== $a ) {
				$items[] = array(
					'question' => $q,
					'answer'   => wp_kses_post( $a ),
				);
			}
		}
		if ( ! $items ) {
			return new WP_Error( 'egsm_bad_request', 'faq.items needs question/answer pairs.', array( 'status' => 400 ) );
		}
		$title    = isset( $faq['title'] ) ? (string) $faq['title'] : 'Frequently Asked Questions';
		$warnings = array();

		if ( ! isset( $faq['content'] ) || EGSM_Util::bool( $faq['content'] ) ) {
			$post    = get_post( $id );
			$builder = EGSM_Builders::detect( $post );
			$html    = EGSM_Gutenberg::faq_html( $items, $title );
			if ( in_array( $builder, array( 'gutenberg', 'classic' ), true ) ) {
				$blocks  = 'gutenberg' === $builder || ( 'classic' !== $builder && 'gutenberg' === EGSM_Builders::default_editor( $post->post_type ) );
				$content = $post->post_content;
				$has     = '' !== $title && preg_match( '#<h[1-6][^>]*>\s*' . preg_quote( esc_html( $title ), '#' ) . '\s*</h[1-6]>#i', $content );
				if ( $has ) {
					$r = EGSM_Gutenberg::replace_section( $content, $title, $html, true );
					$content = is_wp_error( $r ) ? EGSM_Gutenberg::append( $content, $html, $blocks ) : $r;
				} else {
					$content = EGSM_Gutenberg::append( $content, $html, $blocks );
				}
				wp_update_post(
					array(
						'ID'           => $id,
						'post_content' => wp_slash( $content ),
					)
				);
			} elseif ( 'elementor' === $builder ) {
				$data = EGSM_Elementor::get_data( $id );
				$r    = EGSM_Elementor::apply_ops( $data, array( array( 'op' => 'append_html', 'html' => $html ) ) );
				if ( is_wp_error( $r ) ) {
					return $r;
				}
				EGSM_Elementor::save_data( $id, $data );
			} else {
				$warnings[] = "FAQ text was not added to the page because it is built with $builder — add it in the builder; the schema was still added.";
			}
		}
		if ( ! isset( $faq['schema'] ) || EGSM_Util::bool( $faq['schema'] ) ) {
			$entities = array();
			foreach ( $items as $it ) {
				$entities[] = array(
					'@type'          => 'Question',
					'name'           => wp_strip_all_tags( $it['question'] ),
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => wp_kses( $it['answer'], array( 'p' => array(), 'br' => array(), 'ul' => array(), 'ol' => array(), 'li' => array(), 'a' => array( 'href' => array() ), 'strong' => array(), 'em' => array(), 'b' => array(), 'i' => array() ) ),
					),
				);
			}
			$r = self::upsert_post_schema(
				$id,
				array(
					'@context'   => 'https://schema.org',
					'@type'      => 'FAQPage',
					'mainEntity' => $entities,
				)
			);
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		if ( $warnings ) {
			$GLOBALS['egsm_warnings'] = array_merge( isset( $GLOBALS['egsm_warnings'] ) ? $GLOBALS['egsm_warnings'] : array(), $warnings );
		}
		return true;
	}

	/* =========================================================
	 * Keyword map (from Search Console, SEMrush, Ubersuggest exports...)
	 * ========================================================= */

	public static function set_keywords( $id, $kw, $sync_focus = true ) {
		$map = get_post_meta( $id, '_egsm_keywords', true );
		$map = is_array( $map ) ? $map : array();
		foreach ( array( 'primary', 'intent', 'source', 'notes' ) as $f ) {
			if ( isset( $kw[ $f ] ) ) {
				$map[ $f ] = sanitize_text_field( $kw[ $f ] );
			}
		}
		foreach ( array( 'volume', 'difficulty', 'position', 'cpc' ) as $f ) {
			if ( isset( $kw[ $f ] ) && is_numeric( $kw[ $f ] ) ) {
				$map[ $f ] = 0 + $kw[ $f ];
			}
		}
		if ( isset( $kw['secondary'] ) ) {
			$sec              = is_array( $kw['secondary'] ) ? $kw['secondary'] : explode( ',', (string) $kw['secondary'] );
			$map['secondary'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', $sec ) ) ) );
		}
		$map['updated'] = gmdate( 'c' );
		EGSM_Util::set_meta( $id, '_egsm_keywords', $map );
		if ( $sync_focus && ! empty( $map['primary'] ) ) {
			EGSM_SEO::set( $id, array( 'focus_keyword' => $map['primary'] ) );
		}
		return $map;
	}

	public static function keyword_report() {
		$q    = new WP_Query(
			array(
				'post_type'      => EGSM_Content::post_types(),
				'post_status'    => 'publish',
				'posts_per_page' => 2000,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		$items    = array();
		$by_kw    = array();
		$unmapped = array();
		foreach ( $q->posts as $id ) {
			$seo = EGSM_SEO::get( $id );
			$map = get_post_meta( $id, '_egsm_keywords', true );
			$map = is_array( $map ) ? $map : array();
			$pk  = '' !== $seo['focus_keyword'] ? $seo['focus_keyword'] : ( isset( $map['primary'] ) ? $map['primary'] : '' );
			if ( '' === $pk ) {
				$unmapped[] = array(
					'id'    => $id,
					'title' => get_the_title( $id ),
					'url'   => get_permalink( $id ),
				);
				continue;
			}
			$items[]                            = array_merge(
				array(
					'id'      => $id,
					'title'   => get_the_title( $id ),
					'url'     => get_permalink( $id ),
					'primary' => $pk,
				),
				array_diff_key( $map, array( 'primary' => 1 ) )
			);
			$by_kw[ mb_strtolower( trim( $pk ) ) ][] = $id;
		}
		$cannibal = array();
		foreach ( $by_kw as $kw => $ids ) {
			if ( count( $ids ) > 1 ) {
				$cannibal[] = array(
					'keyword' => $kw,
					'pages'   => $ids,
				);
			}
		}
		return array(
			'mapped'         => $items,
			'unmapped'       => $unmapped,
			'cannibalization' => $cannibal,
		);
	}

	/* =========================================================
	 * Answer-readiness (how well a page can be quoted by AI answer engines)
	 * ========================================================= */

	public static function analyze( $post ) {
		$html     = EGSM_Builders::get_html( $post );
		$text     = EGSM_Util::text_from_html( $html );
		$words    = EGSM_Util::word_count( $text );
		$headings = EGSM_Util::headings( $html );
		$sections = EGSM_Util::sections( $html );
		$links    = EGSM_Util::links( $html );
		$schema   = self::get_post_schema( $post->ID );
		$checks   = array();
		$tips     = array();

		$qre = '/(\?\s*$)|^(how|what|why|when|where|which|who|can|do|does|is|are|should|will|much|cost)\b/i';
		$q_heads = array_values(
			array_filter(
				$headings,
				function ( $h ) use ( $qre ) {
					return $h['level'] >= 2 && preg_match( $qre, $h['text'] );
				}
			)
		);
		$checks['question_headings'] = count( $q_heads );
		if ( count( $q_heads ) < 2 ) {
			$tips[] = 'Phrase 2–4 subheadings as the questions people ask (e.g. "How much does X cost in {city}?").';
		}

		$answers_ok = 0;
		$answer_issues = array();
		foreach ( $sections as $s ) {
			if ( '' === $s['heading'] || ! preg_match( $qre, $s['heading'] ) ) {
				continue;
			}
			$first = isset( $s['paras'][0] ) ? EGSM_Util::word_count( $s['paras'][0] ) : 0;
			if ( $first >= 20 && $first <= 90 ) {
				$answers_ok++;
			} else {
				$answer_issues[] = array(
					'heading'           => $s['heading'],
					'first_paragraph_words' => $first,
				);
			}
		}
		$checks['direct_answers'] = array(
			'good'   => $answers_ok,
			'issues' => $answer_issues,
		);
		if ( $answer_issues ) {
			$tips[] = 'Start each question section with a 40–60 word direct answer, then add detail below it.';
		}

		$first_para = '';
		foreach ( $sections as $s ) {
			if ( ! empty( $s['paras'] ) ) {
				$first_para = $s['paras'][0];
				break;
			}
		}
		$fp_words              = EGSM_Util::word_count( $first_para );
		$checks['opening_summary_words'] = $fp_words;
		$summary_ok            = $fp_words >= 15 && $fp_words <= 70;
		if ( ! $summary_ok ) {
			$tips[] = 'Open with a short summary paragraph (15–70 words) that states who/what/where plainly.';
		}

		$has_faq = false;
		foreach ( $schema as $o ) {
			if ( isset( $o['@type'] ) && 'FAQPage' === $o['@type'] ) {
				$has_faq = true;
			}
		}
		if ( ! $has_faq && preg_match( '/wp:(yoast\/faq-block|rank-math\/faq-block)|"@type":\s*"FAQPage"/', $post->post_content ) ) {
			$has_faq = true;
		}
		$checks['faq'] = $has_faq;
		if ( ! $has_faq ) {
			$tips[] = 'Add an FAQ section with FAQPage schema (5–8 real customer questions).';
		}

		$lists  = preg_match_all( '#<(ul|ol)\b#i', $html );
		$tables = preg_match_all( '#<table\b#i', $html );
		$checks['lists']  = $lists;
		$checks['tables'] = $tables;
		if ( 0 === $lists + $tables ) {
			$tips[] = 'Add a bulleted list, steps or a comparison table — answer engines lift structured content.';
		}

		$stats           = preg_match_all( '/(\$\s?\d[\d,.]*|\b\d[\d,.]*\s?(%|percent|years?|months?|weeks?|days?|hours?|minutes?|miles?|sq\.?\s?ft|square feet|customers|clients|projects|homes|reviews|stars))/i', $text );
		$checks['stats'] = $stats;
		if ( $stats < 2 ) {
			$tips[] = 'Include concrete facts and numbers (prices, timelines, years in business, project counts).';
		}

		$ext = array_filter(
			$links,
			function ( $l ) {
				return ! $l['internal'] && ! preg_match( '#(facebook|instagram|twitter|x\.com|linkedin|youtube|tiktok|pinterest|yelp|google\.com/maps)#i', $l['href'] );
			}
		);
		$checks['citations'] = count( $ext );

		$author            = get_userdata( $post->post_author );
		$checks['author_bio'] = $author && '' !== trim( (string) $author->description );
		if ( 'post' === $post->post_type && ! $checks['author_bio'] ) {
			$tips[] = 'Add an author bio with credentials (E-E-A-T) for the post author.';
		}

		$age                     = ( time() - strtotime( $post->post_modified_gmt . ' UTC' ) ) / DAY_IN_SECONDS;
		$checks['days_since_update'] = (int) $age;

		$flesch                 = EGSM_Util::flesch( $text );
		$sent                   = EGSM_Util::sentences( $text );
		$avg                    = $sent ? round( $words / count( $sent ), 1 ) : 0;
		$checks['readability']  = array(
			'flesch'             => $flesch,
			'avg_sentence_words' => $avg,
		);
		if ( null !== $flesch && $flesch < 45 ) {
			$tips[] = 'Simplify wording — shorter sentences and plain words are quoted more often.';
		}

		$h2 = count(
			array_filter(
				$headings,
				function ( $h ) {
					return 2 === $h['level'];
				}
			)
		);
		$checks['h2_count']   = $h2;
		$checks['word_count'] = $words;
		$checks['schema_types'] = array_values(
			array_filter(
				array_map(
					function ( $o ) {
						return isset( $o['@type'] ) ? $o['@type'] : null;
					},
					array_merge( $schema, self::get_site_schema() )
				)
			)
		);

		$score  = 0;
		$score += min( 10, count( $q_heads ) * 4 );
		$score += count( $q_heads ) ? (int) round( 15 * $answers_ok / max( 1, $answers_ok + count( $answer_issues ) ) ) : 0;
		$score += $summary_ok ? 10 : 0;
		$score += $has_faq ? 10 : 0;
		$score += min( 10, ( $lists + $tables ) * 5 );
		$score += min( 10, $stats * 3 );
		$score += min( 5, count( $ext ) * 3 );
		$score += $checks['author_bio'] || 'post' !== $post->post_type ? 5 : 0;
		$score += $age <= 365 ? 5 : 0;
		$score += ( null === $flesch || $flesch >= 50 ) ? 10 : ( $flesch >= 35 ? 5 : 0 );
		$score += $h2 >= 2 ? 5 : 0;
		$score += $checks['schema_types'] ? 5 : 0;

		return array(
			'score'  => min( 100, $score ),
			'checks' => $checks,
			'tips'   => $tips,
		);
	}

	/* =========================================================
	 * Authors (E-E-A-T)
	 * ========================================================= */

	public static function authors() {
		$users = get_users(
			array(
				'has_published_posts' => EGSM_Content::post_types(),
				'fields'              => 'all',
			)
		);
		$out   = array();
		foreach ( $users as $u ) {
			$out[] = array(
				'id'           => $u->ID,
				'display_name' => $u->display_name,
				'bio'          => (string) $u->description,
				'url'          => (string) $u->user_url,
				'posts'        => (int) count_user_posts( $u->ID, 'post', true ),
				'archive_url'  => get_author_posts_url( $u->ID ),
			);
		}
		return $out;
	}

	public static function update_author( $id, $p ) {
		$u = get_userdata( (int) $id );
		if ( ! $u ) {
			return new WP_Error( 'egsm_not_found', 'User not found.', array( 'status' => 404 ) );
		}
		$before = array(
			'description'  => $u->description,
			'user_url'     => $u->user_url,
			'display_name' => $u->display_name,
			'first_name'   => $u->first_name,
			'last_name'    => $u->last_name,
		);
		$data   = array( 'ID' => $u->ID );
		if ( isset( $p['bio'] ) ) {
			$data['description'] = wp_kses_post( $p['bio'] );
		}
		if ( isset( $p['url'] ) ) {
			$data['user_url'] = esc_url_raw( $p['url'] );
		}
		foreach ( array( 'display_name', 'first_name', 'last_name' ) as $f ) {
			if ( isset( $p[ $f ] ) ) {
				$data[ $f ] = sanitize_text_field( $p[ $f ] );
			}
		}
		$r = wp_update_user( wp_slash( $data ) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$cid = EGSM_Log::record( 'update_author', 'user', $u->ID, $before, array_diff_key( $data, array( 'ID' => 1 ) ), 'Updated author ' . $u->display_name );
		return array(
			'id'        => $u->ID,
			'change_id' => $cid,
		);
	}
}
