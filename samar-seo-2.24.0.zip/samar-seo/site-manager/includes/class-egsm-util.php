<?php
/**
 * Shared helpers: HTML analysis, text stats, slashing.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Util {

	public static function now() {
		return gmdate( 'Y-m-d H:i:s' );
	}

	/**
	 * Slash a value for WordPress meta/post APIs, including string properties of
	 * objects (wp_slash skips objects, but update_metadata unslashes them deeply,
	 * which would corrupt backslashes in builder data).
	 */
	public static function deep_slash( $value ) {
		if ( is_string( $value ) ) {
			return addslashes( $value );
		}
		if ( is_array( $value ) ) {
			foreach ( $value as $k => $v ) {
				$value[ $k ] = self::deep_slash( $v );
			}
			return $value;
		}
		if ( is_object( $value ) ) {
			foreach ( get_object_vars( $value ) as $k => $v ) {
				$value->$k = self::deep_slash( $v );
			}
			return $value;
		}
		return $value;
	}

	/** Update post meta safely for any value type (JSON strings, arrays, objects). */
	public static function set_meta( $post_id, $key, $value ) {
		return update_post_meta( $post_id, $key, self::deep_slash( $value ) );
	}

	public static function text_from_html( $html ) {
		$html = preg_replace( '#<(script|style|noscript)\b[^>]*>.*?</\1>#is', ' ', (string) $html );
		$html = preg_replace( '#<!--.*?-->#s', ' ', $html );
		$html = preg_replace( '#<(br|/p|/h[1-6]|/li|/div|/tr|/td|/th|/section|/blockquote)\b[^>]*>#i', "$0\n", $html );
		$text = wp_strip_all_tags( $html, false );
		$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = preg_replace( "/[ \t\x{00A0}]+/u", ' ', $text );
		$text = preg_replace( "/\n\s*\n+/", "\n\n", $text );
		return trim( (string) $text );
	}

	public static function word_count( $text ) {
		return (int) preg_match_all( "/[\p{L}\p{N}][\p{L}\p{N}'’\-]*/u", (string) $text );
	}

	public static function headings( $html ) {
		$out = array();
		if ( preg_match_all( '#<h([1-6])\b[^>]*>(.*?)</h\1>#is', (string) $html, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $h ) {
				$text = trim( self::text_from_html( $h[2] ) );
				if ( '' !== $text ) {
					$out[] = array(
						'level' => (int) $h[1],
						'text'  => $text,
					);
				}
			}
		}
		return $out;
	}

	public static function attr( $tag, $name ) {
		if ( preg_match( '/\s' . preg_quote( $name, '/' ) . '\s*=\s*("([^"]*)"|\'([^\']*)\'|([^\s>]+))/i', $tag, $m ) ) {
			$v = isset( $m[4] ) && '' !== $m[4] ? $m[4] : ( isset( $m[3] ) && '' !== $m[3] ? $m[3] : $m[2] );
			return html_entity_decode( $v, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		}
		return null;
	}

	public static function home_host() {
		return strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	}

	public static function is_internal( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url || 0 === strpos( $url, '#' ) || preg_match( '#^(mailto|tel|javascript|data|sms):#i', $url ) ) {
			return false;
		}
		$host = wp_parse_url( $url, PHP_URL_HOST );
		if ( ! $host ) {
			return true;
		}
		$host = strtolower( preg_replace( '/^www\./', '', $host ) );
		return preg_replace( '/^www\./', '', self::home_host() ) === $host;
	}

	/** Site-relative path ("/services/painting"), without trailing slash, for matching. */
	public static function normalize_path( $url ) {
		$url  = trim( (string) $url );
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		$path = rawurldecode( $path );
		$path = '/' . ltrim( $path, '/' );
		$path = untrailingslashit( $path );
		return '' === $path ? '/' : $path;
	}

	public static function absolute_url( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return '';
		}
		if ( preg_match( '#^https?://#i', $url ) ) {
			return $url;
		}
		if ( 0 === strpos( $url, '//' ) ) {
			return set_url_scheme( 'http:' . $url );
		}
		return home_url( '/' . ltrim( $url, '/' ) );
	}

	public static function links( $html ) {
		$out = array();
		if ( preg_match_all( '#<a\b([^>]*)>(.*?)</a>#is', (string) $html, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $a ) {
				$href = self::attr( '<a ' . $a[1] . '>', 'href' );
				if ( null === $href || '' === trim( $href ) ) {
					continue;
				}
				$internal = self::is_internal( $href );
				$item     = array(
					'href'     => $href,
					'anchor'   => self::text_from_html( $a[2] ),
					'internal' => $internal,
					'rel'      => (string) self::attr( '<a ' . $a[1] . '>', 'rel' ),
				);
				if ( $internal && 0 !== strpos( $href, '#' ) ) {
					$item['target_id'] = (int) url_to_postid( self::absolute_url( $href ) );
				}
				$out[] = $item;
			}
		}
		return $out;
	}

	public static function images( $html ) {
		$out = array();
		if ( preg_match_all( '#<img\b[^>]*>#is', (string) $html, $m ) ) {
			foreach ( $m[0] as $tag ) {
				$class = (string) self::attr( $tag, 'class' );
				$id    = 0;
				if ( preg_match( '/wp-image-(\d+)/', $class, $mm ) ) {
					$id = (int) $mm[1];
				}
				$src = (string) self::attr( $tag, 'src' );
				foreach ( array( 'data-src', 'data-lazy-src', 'data-original' ) as $lazy ) {
					if ( ( '' === $src || 0 === strpos( $src, 'data:' ) ) && self::attr( $tag, $lazy ) ) {
						$src = (string) self::attr( $tag, $lazy );
					}
				}
				// An <img> with no real source is a script placeholder (lightbox, slider), not content.
				if ( '' === trim( $src ) || ( 0 === strpos( $src, 'data:' ) && ! $id ) ) {
					continue;
				}
				$out[] = array(
					'src'           => $src,
					'alt'           => self::attr( $tag, 'alt' ),
					'attachment_id' => $id,
				);
			}
		}
		return $out;
	}

	/** Paragraph-ish blocks of text in order, each tagged with the heading above it. */
	public static function sections( $html ) {
		$out     = array();
		$current = array(
			'heading' => '',
			'level'   => 0,
			'paras'   => array(),
		);
		if ( preg_match_all( '#<(h[1-6]|p|li)\b[^>]*>(.*?)</\1>#is', (string) $html, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $el ) {
				$tag  = strtolower( $el[1] );
				$text = self::text_from_html( $el[2] );
				if ( '' === $text ) {
					continue;
				}
				if ( 'h' === $tag[0] ) {
					$out[]   = $current;
					$current = array(
						'heading' => $text,
						'level'   => (int) substr( $tag, 1 ),
						'paras'   => array(),
					);
				} else {
					$current['paras'][] = $text;
				}
			}
		}
		$out[] = $current;
		return array_values(
			array_filter(
				$out,
				function ( $s ) {
					return '' !== $s['heading'] || ! empty( $s['paras'] );
				}
			)
		);
	}

	public static function sentences( $text ) {
		$parts = preg_split( '/(?<=[.!?])\s+(?=[\p{Lu}\p{N}"“])/u', trim( (string) $text ) );
		return array_values( array_filter( array_map( 'trim', (array) $parts ) ) );
	}

	private static function syllables( $word ) {
		$word = strtolower( preg_replace( '/[^a-z]/i', '', $word ) );
		if ( '' === $word ) {
			return 0;
		}
		if ( strlen( $word ) <= 3 ) {
			return 1;
		}
		$word = preg_replace( '/(?:[^laeiouy]es|ed|[^laeiouy]e)$/', '', $word );
		$word = preg_replace( '/^y/', '', $word );
		$n    = preg_match_all( '/[aeiouy]{1,2}/', $word );
		return max( 1, (int) $n );
	}

	/** Flesch reading ease (English heuristic). Returns null for very short text. */
	public static function flesch( $text ) {
		$sentences = self::sentences( $text );
		preg_match_all( "/[A-Za-z][A-Za-z'’\-]*/", (string) $text, $m );
		$words = $m[0];
		if ( count( $words ) < 30 || count( $sentences ) < 2 ) {
			return null;
		}
		$syll = 0;
		foreach ( $words as $w ) {
			$syll += self::syllables( $w );
		}
		$score = 206.835 - 1.015 * ( count( $words ) / count( $sentences ) ) - 84.6 * ( $syll / count( $words ) );
		return round( max( 0, min( 100, $score ) ), 1 );
	}

	public static function first_words( $text, $n ) {
		preg_match_all( "/[\p{L}\p{N}][\p{L}\p{N}'’\-]*/u", (string) $text, $m );
		return implode( ' ', array_slice( $m[0], 0, $n ) );
	}

	public static function contains_phrase( $haystack, $phrase ) {
		$phrase = trim( (string) $phrase );
		if ( '' === $phrase ) {
			return false;
		}
		return false !== mb_stripos( self::text_from_html( $haystack ), $phrase, 0, 'UTF-8' );
	}

	public static function count_phrase( $text, $phrase ) {
		$phrase = trim( (string) $phrase );
		if ( '' === $phrase ) {
			return 0;
		}
		return (int) preg_match_all( '/(?<![\p{L}\p{N}])' . preg_quote( $phrase, '/' ) . '(?![\p{L}\p{N}])/iu', (string) $text );
	}

	public static function bool( $v ) {
		if ( is_bool( $v ) ) {
			return $v;
		}
		return in_array( strtolower( (string) $v ), array( '1', 'true', 'yes', 'on' ), true );
	}
}
