<?php
/**
 * SEO fields across SEO plugins (Yoast, Rank Math, AIOSEO, SEOPress, The SEO Framework)
 * with a built-in fallback that outputs tags itself when no SEO plugin is active.
 *
 * Normalized fields: title, description, focus_keyword, canonical, noindex, nofollow,
 * og_title, og_description, og_image
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_SEO {

	const FIELDS = array( 'title', 'description', 'focus_keyword', 'canonical', 'noindex', 'nofollow', 'og_title', 'og_description', 'og_image' );

	const MAPS = array(
		'yoast'    => array(
			'title'          => '_yoast_wpseo_title',
			'description'    => '_yoast_wpseo_metadesc',
			'focus_keyword'  => '_yoast_wpseo_focuskw',
			'canonical'      => '_yoast_wpseo_canonical',
			'noindex'        => '_yoast_wpseo_meta-robots-noindex',
			'nofollow'       => '_yoast_wpseo_meta-robots-nofollow',
			'og_title'       => '_yoast_wpseo_opengraph-title',
			'og_description' => '_yoast_wpseo_opengraph-description',
			'og_image'       => '_yoast_wpseo_opengraph-image',
		),
		'rankmath' => array(
			'title'          => 'rank_math_title',
			'description'    => 'rank_math_description',
			'focus_keyword'  => 'rank_math_focus_keyword',
			'canonical'      => 'rank_math_canonical_url',
			'og_title'       => 'rank_math_facebook_title',
			'og_description' => 'rank_math_facebook_description',
			'og_image'       => 'rank_math_facebook_image',
		),
		'seopress' => array(
			'title'          => '_seopress_titles_title',
			'description'    => '_seopress_titles_desc',
			'focus_keyword'  => '_seopress_analysis_target_kw',
			'canonical'      => '_seopress_robots_canonical',
			'noindex'        => '_seopress_robots_index',
			'nofollow'       => '_seopress_robots_follow',
			'og_title'       => '_seopress_social_fb_title',
			'og_description' => '_seopress_social_fb_desc',
			'og_image'       => '_seopress_social_fb_img',
		),
		'tsf'      => array(
			'title'          => '_genesis_title',
			'description'    => '_genesis_description',
			'canonical'      => '_genesis_canonical_uri',
			'noindex'        => '_genesis_noindex',
			'nofollow'       => '_genesis_nofollow',
			'og_title'       => '_open_graph_title',
			'og_description' => '_open_graph_description',
			'og_image'       => '_social_image_url',
		),
	);

	public static function active_plugin() {
		if ( defined( 'WPSEO_VERSION' ) ) {
			return 'yoast';
		}
		if ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) {
			return 'rankmath';
		}
		if ( defined( 'AIOSEO_VERSION' ) || function_exists( 'aioseo' ) ) {
			return 'aioseo';
		}
		if ( defined( 'SEOPRESS_VERSION' ) ) {
			return 'seopress';
		}
		if ( defined( 'THE_SEO_FRAMEWORK_VERSION' ) || function_exists( 'the_seo_framework' ) ) {
			return 'tsf';
		}
		if ( EGSM_SSEO::on() ) {
			return 'sseo'; // SEO Suite outputs titles/descriptions itself.
		}
		return 'native';
	}

	/* ---------- read ---------- */

	public static function get( $id ) {
		$plugin = self::active_plugin();
		$out    = array_fill_keys( self::FIELDS, '' );
		$out['noindex']  = false;
		$out['nofollow'] = false;

		if ( isset( self::MAPS[ $plugin ] ) ) {
			foreach ( self::MAPS[ $plugin ] as $field => $key ) {
				$out[ $field ] = get_post_meta( $id, $key, true );
			}
			if ( 'yoast' === $plugin ) {
				$out['noindex']  = '1' === (string) $out['noindex'];
				$out['nofollow'] = '1' === (string) $out['nofollow'];
			} elseif ( 'seopress' === $plugin ) {
				$out['noindex']  = 'yes' === (string) $out['noindex'];
				$out['nofollow'] = 'yes' === (string) $out['nofollow'];
			} elseif ( 'tsf' === $plugin ) {
				$out['noindex']  = '1' === (string) $out['noindex'];
				$out['nofollow'] = '1' === (string) $out['nofollow'];
			}
			if ( 'rankmath' === $plugin ) {
				$robots          = (array) get_post_meta( $id, 'rank_math_robots', true );
				$out['noindex']  = in_array( 'noindex', $robots, true );
				$out['nofollow'] = in_array( 'nofollow', $robots, true );
				$fk              = explode( ',', (string) $out['focus_keyword'] );
				$out['focus_keyword'] = trim( $fk[0] );
			}
		} elseif ( 'aioseo' === $plugin ) {
			$row = self::aioseo_row( $id );
			if ( $row ) {
				$out['title']          = (string) $row['title'];
				$out['description']    = (string) $row['description'];
				$out['canonical']      = (string) $row['canonical_url'];
				$out['noindex']        = ! empty( $row['robots_noindex'] ) && empty( $row['robots_default'] );
				$out['nofollow']       = ! empty( $row['robots_nofollow'] ) && empty( $row['robots_default'] );
				$out['og_title']       = (string) $row['og_title'];
				$out['og_description'] = (string) $row['og_description'];
				$out['og_image']       = (string) $row['og_image_custom_url'];
				$kp                    = json_decode( (string) $row['keyphrases'], true );
				$out['focus_keyword']  = isset( $kp['focus']['keyphrase'] ) ? (string) $kp['focus']['keyphrase'] : '';
			}
		} else {
			$native = (array) get_post_meta( $id, '_egsm_seo', true );
			foreach ( self::FIELDS as $f ) {
				if ( isset( $native[ $f ] ) ) {
					$out[ $f ] = $native[ $f ];
				}
			}
			if ( 'sseo' === $plugin ) {
				$out['title']       = (string) get_post_meta( $id, EGSM_SSEO::TITLE, true );
				$out['description'] = (string) get_post_meta( $id, EGSM_SSEO::DESC, true );
			}
			$out['noindex']  = ! empty( $out['noindex'] );
			$out['nofollow'] = ! empty( $out['nofollow'] );
		}
		if ( '' === (string) $out['focus_keyword'] ) {
			$map = get_post_meta( $id, '_egsm_keywords', true );
			if ( is_array( $map ) && ! empty( $map['primary'] ) ) {
				$out['focus_keyword'] = $map['primary'];
			}
		}
		foreach ( array( 'title', 'description', 'focus_keyword', 'canonical', 'og_title', 'og_description', 'og_image' ) as $f ) {
			$out[ $f ] = (string) $out[ $f ];
		}
		$out['plugin']                = $plugin;
		$out['effective_title']       = self::effective_title( $id, $out['title'] );
		$out['effective_description'] = self::effective_description( $id, $out['description'] );
		return $out;
	}

	/** Best-effort rendering of the title the page will show (template variables resolved). */
	public static function effective_title( $id, $custom ) {
		$site = get_bloginfo( 'name' );
		$post = get_post( $id );
		$pt   = $post ? $post->post_title : '';
		if ( '' === trim( (string) $custom ) ) {
			return trim( $pt . ' - ' . $site, ' -' );
		}
		$vars = array(
			'%%title%%'        => $pt,
			'%%sitename%%'     => $site,
			'%%sep%%'          => '-',
			'%%page%%'         => '',
			'%%primary_category%%' => '',
			'%%sitedesc%%'     => get_bloginfo( 'description' ),
			'%title%'          => $pt,
			'%sitename%'       => $site,
			'%sep%'            => '-',
			'%page%'           => '',
			'%sitedesc%'       => get_bloginfo( 'description' ),
			'#post_title'      => $pt,
			'#site_title'      => $site,
			'#separator_sa'    => '-',
			'%%post_title%%'   => $pt,
			'%%sitetitle%%'    => $site,
			'%%tagline%%'      => get_bloginfo( 'description' ),
		);
		$t = strtr( (string) $custom, $vars );
		$t = preg_replace( '/%%?[a-z_]+%%?|#[a-z_]+/i', '', $t );
		return trim( preg_replace( '/\s+/', ' ', $t ), ' -|' );
	}

	public static function effective_description( $id, $custom ) {
		if ( '' !== trim( (string) $custom ) ) {
			return trim( preg_replace( '/%%?[a-z_]+%%?|#[a-z_]+/i', '', (string) $custom ) );
		}
		return '';
	}

	/* ---------- write ---------- */

	/**
	 * @param int   $id
	 * @param array $fields subset of FIELDS
	 * @return true|WP_Error
	 */
	public static function set( $id, $fields ) {
		$plugin = self::active_plugin();
		$fields = array_intersect_key( (array) $fields, array_flip( self::FIELDS ) );
		foreach ( array( 'title', 'description', 'focus_keyword', 'og_title', 'og_description' ) as $f ) {
			if ( isset( $fields[ $f ] ) ) {
				$fields[ $f ] = sanitize_text_field( (string) $fields[ $f ] );
			}
		}
		foreach ( array( 'canonical', 'og_image' ) as $f ) {
			if ( isset( $fields[ $f ] ) ) {
				$fields[ $f ] = '' === $fields[ $f ] ? '' : esc_url_raw( $fields[ $f ] );
			}
		}
		foreach ( array( 'noindex', 'nofollow' ) as $f ) {
			if ( isset( $fields[ $f ] ) ) {
				$fields[ $f ] = EGSM_Util::bool( $fields[ $f ] );
			}
		}

		if ( 'aioseo' === $plugin ) {
			$r = self::set_aioseo( $id, $fields );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		} elseif ( isset( self::MAPS[ $plugin ] ) ) {
			$map = self::MAPS[ $plugin ];
			foreach ( $fields as $f => $v ) {
				if ( 'rankmath' === $plugin && in_array( $f, array( 'noindex', 'nofollow', 'focus_keyword' ), true ) ) {
					continue; // Handled below (robots array; primary + secondary keywords).
				}
				if ( ! isset( $map[ $f ] ) ) {
					continue;
				}
				if ( in_array( $f, array( 'noindex', 'nofollow' ), true ) ) {
					if ( 'yoast' === $plugin ) {
						$v = $v ? '1' : ( 'noindex' === $f ? '2' : '0' );
					} elseif ( 'seopress' === $plugin ) {
						$v = $v ? 'yes' : '';
					} else {
						$v = $v ? '1' : '';
					}
				}
				if ( '' === $v ) {
					delete_post_meta( $id, $map[ $f ] );
				} else {
					EGSM_Util::set_meta( $id, $map[ $f ], $v );
				}
			}
			if ( 'rankmath' === $plugin && ( isset( $fields['noindex'] ) || isset( $fields['nofollow'] ) ) ) {
				$current = self::get( $id );
				$noindex = isset( $fields['noindex'] ) ? $fields['noindex'] : $current['noindex'];
				$nofol   = isset( $fields['nofollow'] ) ? $fields['nofollow'] : $current['nofollow'];
				$robots  = array( $noindex ? 'noindex' : 'index' );
				if ( $nofol ) {
					$robots[] = 'nofollow';
				}
				update_post_meta( $id, 'rank_math_robots', $robots );
			}
			if ( 'rankmath' === $plugin && isset( $fields['focus_keyword'] ) ) {
				// Keep Rank Math's secondary keywords, replace the primary.
				$old  = array_map( 'trim', explode( ',', (string) get_post_meta( $id, 'rank_math_focus_keyword', true ) ) );
				$rest = array_slice( $old, 1 );
				$kw   = trim( implode( ',', array_filter( array_merge( array( $fields['focus_keyword'] ), $rest ) ) ), ',' );
				EGSM_Util::set_meta( $id, 'rank_math_focus_keyword', $kw );
			}
		} else {
			$native = (array) get_post_meta( $id, '_egsm_seo', true );
			foreach ( $fields as $f => $v ) {
				if ( 'sseo' === $plugin && in_array( $f, array( 'title', 'description' ), true ) ) {
					continue; // stored in SEO Suite's own fields below
				}
				$native[ $f ] = $v;
			}
			EGSM_Util::set_meta( $id, '_egsm_seo', array_filter( $native, function ( $v ) {
				return '' !== $v && false !== $v;
			} ) );
		}

		// SEO Suite keeps its own copy of title/description (its screens and standalone output read these).
		if ( EGSM_SSEO::on() ) {
			foreach ( array( 'title' => EGSM_SSEO::TITLE, 'description' => EGSM_SSEO::DESC ) as $f => $key ) {
				if ( isset( $fields[ $f ] ) ) {
					if ( '' === $fields[ $f ] ) {
						delete_post_meta( $id, $key );
					} else {
						EGSM_Util::set_meta( $id, $key, $fields[ $f ] );
					}
				}
			}
		}

		// Keep our keyword map in sync.
		if ( isset( $fields['focus_keyword'] ) ) {
			$map            = get_post_meta( $id, '_egsm_keywords', true );
			$map            = is_array( $map ) ? $map : array();
			$map['primary'] = $fields['focus_keyword'];
			EGSM_Util::set_meta( $id, '_egsm_keywords', $map );
		}

		// Nudge SEO plugins that cache per-post data (e.g. Yoast indexables) to rebuild.
		if ( in_array( $plugin, array( 'yoast', 'aioseo' ), true ) ) {
			wp_update_post( array( 'ID' => $id ) );
		}
		EGSM_Score::sync_flat_meta( $id );
		EGSM_Score::queue( $id );
		return true;
	}

	/* ---------- AIOSEO (custom table) ---------- */

	private static function aioseo_table() {
		global $wpdb;
		$t = $wpdb->prefix . 'aioseo_posts';
		static $exists = null;
		if ( null === $exists ) {
			$exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $t ) ) === $t );
		}
		return $exists ? $t : null;
	}

	public static function aioseo_row( $id ) {
		if ( 'aioseo' !== self::active_plugin() ) {
			return null;
		}
		global $wpdb;
		$t = self::aioseo_table();
		if ( ! $t ) {
			return null;
		}
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT title, description, keyphrases, canonical_url, robots_default, robots_noindex, robots_nofollow, og_title, og_description, og_image_custom_url FROM {$t} WHERE post_id = %d", $id ), ARRAY_A );
		return $row ? $row : null;
	}

	public static function restore_aioseo_row( $id, $row ) {
		global $wpdb;
		$t = self::aioseo_table();
		if ( ! $t ) {
			return;
		}
		if ( null === $row ) {
			$wpdb->delete( $t, array( 'post_id' => $id ) );
			return;
		}
		$wpdb->update( $t, $row, array( 'post_id' => $id ) );
	}

	private static function set_aioseo( $id, $fields ) {
		global $wpdb;
		$t = self::aioseo_table();
		if ( ! $t ) {
			return new WP_Error( 'egsm_aioseo', 'AIOSEO table not found.', array( 'status' => 500 ) );
		}
		$row  = self::aioseo_row( $id );
		$data = array();
		$map  = array(
			'title'          => 'title',
			'description'    => 'description',
			'canonical'      => 'canonical_url',
			'og_title'       => 'og_title',
			'og_description' => 'og_description',
			'og_image'       => 'og_image_custom_url',
		);
		foreach ( $map as $f => $col ) {
			if ( isset( $fields[ $f ] ) ) {
				$data[ $col ] = $fields[ $f ];
			}
		}
		if ( isset( $fields['og_image'] ) && '' !== $fields['og_image'] ) {
			$data['og_image_type'] = 'custom_image';
		}
		if ( isset( $fields['noindex'] ) || isset( $fields['nofollow'] ) ) {
			$data['robots_default'] = 0;
			if ( isset( $fields['noindex'] ) ) {
				$data['robots_noindex'] = $fields['noindex'] ? 1 : 0;
			}
			if ( isset( $fields['nofollow'] ) ) {
				$data['robots_nofollow'] = $fields['nofollow'] ? 1 : 0;
			}
		}
		if ( isset( $fields['focus_keyword'] ) ) {
			$kp = $row && $row['keyphrases'] ? json_decode( $row['keyphrases'], true ) : array();
			$kp = is_array( $kp ) ? $kp : array();
			$kp['focus'] = array( 'keyphrase' => $fields['focus_keyword'] );
			if ( ! isset( $kp['additional'] ) ) {
				$kp['additional'] = array();
			}
			$data['keyphrases'] = wp_json_encode( $kp );
		}
		if ( ! $data ) {
			return true;
		}
		$data['updated'] = current_time( 'mysql' );
		if ( $row ) {
			$wpdb->update( $t, $data, array( 'post_id' => $id ) );
		} else {
			$data['post_id'] = $id;
			$data['created'] = current_time( 'mysql' );
			$wpdb->insert( $t, $data );
		}
		return true;
	}

	/* ---------- built-in output when no SEO plugin is active ---------- */

	public static function init_frontend() {
		add_action( 'wp', array( __CLASS__, 'maybe_native_output' ) );
	}

	public static function maybe_native_output() {
		$mode = self::active_plugin();
		if ( is_admin() || ! in_array( $mode, array( 'native', 'sseo' ), true ) || ! EGSM_Settings::get( 'native_seo' ) ) {
			return;
		}
		// [og-context v1] Singular pages, plus the static "Posts page" (is_home() is not singular).
		if ( is_singular() ) {
			$id = get_queried_object_id();
		} elseif ( is_home() && ! is_front_page() && get_option( 'page_for_posts' ) ) {
			$id = (int) get_option( 'page_for_posts' );
		} else {
			return;
		}
		$meta = get_post_meta( $id, '_egsm_seo', true );
		if ( ! is_array( $meta ) || ! $meta ) {
			return;
		}
		if ( 'sseo' === $mode ) {
			// SEO Suite prints title, description and Open Graph; we only add canonical and robots.
			$meta = array_intersect_key( $meta, array_flip( array( 'canonical', 'noindex', 'nofollow' ) ) );
			if ( ! $meta ) {
				return;
			}
		}
		if ( ! empty( $meta['title'] ) ) {
			add_filter(
				'pre_get_document_title',
				function () use ( $meta ) {
					return $meta['title'];
				},
				99
			);
		}
		if ( ! empty( $meta['canonical'] ) ) {
			remove_action( 'wp_head', 'rel_canonical' );
		}
		if ( ! empty( $meta['noindex'] ) || ! empty( $meta['nofollow'] ) ) {
			add_filter(
				'wp_robots',
				function ( $robots ) use ( $meta ) {
					if ( ! empty( $meta['noindex'] ) ) {
						$robots['noindex'] = true;
						unset( $robots['max-image-preview'] );
					}
					if ( ! empty( $meta['nofollow'] ) ) {
						$robots['nofollow'] = true;
					}
					return $robots;
				}
			);
		}
		add_action(
			'wp_head',
			function () use ( $meta, $id, $mode ) {
				if ( 'sseo' === $mode ) {
					if ( ! empty( $meta['canonical'] ) ) {
						echo '<link rel="canonical" href="' . esc_url( $meta['canonical'] ) . '" />' . "\n";
					}
					return;
				}
				if ( ! empty( $meta['description'] ) ) {
					echo '<meta name="description" content="' . esc_attr( $meta['description'] ) . '" />' . "\n";
				}
				if ( ! empty( $meta['canonical'] ) ) {
					echo '<link rel="canonical" href="' . esc_url( $meta['canonical'] ) . '" />' . "\n";
				}
				$og_t = ! empty( $meta['og_title'] ) ? $meta['og_title'] : ( ! empty( $meta['title'] ) ? $meta['title'] : get_the_title( $id ) );
				$og_d = ! empty( $meta['og_description'] ) ? $meta['og_description'] : ( ! empty( $meta['description'] ) ? $meta['description'] : '' );
				echo '<meta property="og:type" content="' . ( is_singular( 'post' ) ? 'article' : 'website' ) . '" />' . "\n";
				echo '<meta property="og:title" content="' . esc_attr( $og_t ) . '" />' . "\n";
				if ( $og_d ) {
					echo '<meta property="og:description" content="' . esc_attr( $og_d ) . '" />' . "\n";
				}
				echo '<meta property="og:url" content="' . esc_url( get_permalink( $id ) ) . '" />' . "\n";
				$img = ! empty( $meta['og_image'] ) ? $meta['og_image'] : get_the_post_thumbnail_url( $id, 'large' );
				if ( ! $img ) {
					$img = EGSM_SEO_Settings::get( 'default_og_image' );
				}
				if ( $img ) {
					echo '<meta property="og:image" content="' . esc_url( $img ) . '" />' . "\n";
				}
			},
			1
		);
	}
}
