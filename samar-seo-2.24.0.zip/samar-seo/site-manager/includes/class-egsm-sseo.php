<?php
/**
 * SEO Suite integration. When Site Manager runs inside SEO Suite (the merged plugin), the features the two share
 * use SEO Suite's storage so the AI and SEO Suite's own screens always see the same data:
 *
 *   titles / descriptions  → _sseo_title / _sseo_meta_description (when no Yoast/Rank Math/AIOSEO)
 *   redirects              → {prefix}sseo_redirects (410s stay in Site Manager's table — SEO Suite has no 410)
 *   llms.txt               → sseo_llms_txt_content (served by SEO Suite)
 *   robots.txt             → SEO Suite's robots content (file or option); Site Manager also serves the option
 *                            version, which SEO Suite saves but never outputs
 *   LocalBusiness schema   → sseo_business_* options (SEO Suite outputs it); duplicate schema types are suppressed
 *   Open Graph             → SEO Suite (Site Manager's own OG output is off)
 *   one-click sign-in      → SEO Suite's sseo_sso (Site Manager's is off)
 *   pairing                → one code: SEO Suite pairs, then Site Manager registers its signing key using
 *                            SEO Suite's paired token (also upgrades sites that paired before this version)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_SSEO {

	const TITLE = '_sseo_title';
	const DESC  = '_sseo_meta_description';

	public static function on() {
		return defined( 'SSEO_VERSION' ) && defined( 'EGSM_IN_SSEO' );
	}

	public static function init() {
		if ( ! self::on() ) {
			return;
		}
		add_action( 'sseo_connected', array( __CLASS__, 'register' ) );
		add_action( 'sseo_disconnected', array( 'EGSM_Auth', 'revoke' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_register' ) );
		add_action( 'egsm_register_retry', array( __CLASS__, 'maybe_register' ) );
	}

	/** Which SEO plugin SEO Suite itself is writing to (mirrors SSEO_SEO_Integration::detect). */
	public static function seo_mode() {
		$s = get_option( 'sseo_seo_plugin', 'auto' );
		if ( 'auto' !== $s ) {
			return $s;
		}
		if ( defined( 'WPSEO_VERSION' ) ) {
			return 'yoast';
		}
		if ( defined( 'RANK_MATH_VERSION' ) ) {
			return 'rankmath';
		}
		if ( defined( 'AIOSEO_VERSION' ) ) {
			return 'aioseo';
		}
		return 'standalone';
	}

	/* ---------- pairing: register Site Manager's key with the SEO Suite token ---------- */

	public static function api_base() {
		return function_exists( 'sseo_api_base' ) ? rtrim( sseo_api_base(), '/' ) : 'https://api.egiig.com';
	}

	/** @return true|WP_Error */
	public static function register() {
		delete_option( 'egsm_owner_revoked' );
		if ( ! function_exists( 'sseo_is_connected' ) || ! sseo_is_connected() ) {
			return new WP_Error( 'egsm_register', 'SEO Suite is not paired with an agency yet.' );
		}
		$kid    = bin2hex( random_bytes( 8 ) );
		$secret = bin2hex( random_bytes( 32 ) );
		$resp   = wp_remote_post(
			self::api_base() . '/api/wp-plugin/manager-register',
			array(
				'timeout' => 25,
				'headers' => array(
					'Content-Type' => 'application/json',
					'Accept'       => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'token'          => sseo_connect_secret(),
						'site_url'       => home_url(),
						'rest_url'       => rest_url( EGSM_NS . '/' ),
						'kid'            => $kid,
						'secret'         => $secret,
						'plugin_version' => EGSM_VERSION,
					)
				),
			)
		);
		update_option( 'egsm_register_attempt', time(), false );
		if ( is_wp_error( $resp ) ) {
			return $resp;
		}
		$status = (int) wp_remote_retrieve_response_code( $resp );
		$body   = json_decode( (string) wp_remote_retrieve_body( $resp ), true );
		if ( 200 !== $status || empty( $body['ok'] ) ) {
			return new WP_Error( 'egsm_register', is_array( $body ) && ! empty( $body['message'] ) ? $body['message'] : "Registration failed (HTTP {$status})." );
		}
		update_option( 'egsm_kid', $kid, false );
		update_option( 'egsm_secret', $secret, false );
		update_option( 'egsm_key_created', time(), false );
		update_option(
			'egsm_paired',
			array(
				'platform_url' => self::api_base(),
				'paired_at'    => gmdate( 'c' ),
				'via'          => 'seo-suite',
			),
			false
		);
		if ( ! empty( $body['branding'] ) && is_array( $body['branding'] ) ) {
			EGSM_Maintenance::set_branding( $body['branding'] );
		}
		EGSM_Log::record( 'paired', 'option', 0, null, null, 'Site management connected for ' . EGSM_Settings::agency_name() );
		return true;
	}

	/**
	 * [connection-key v1] POST /connect/confirm — the platform finishes a connection-key connection. Stores what a
	 * pairing code would have (reporting token, agency name, lock password) without the site calling out.
	 */
	public static function confirm_key( $req ) {
		if ( ! EGSM_Auth::via_signature() ) {
			return new WP_Error( 'egsm_confirm', 'Only the agency platform can confirm a connection key (signed request).', array( 'status' => 403 ) );
		}
		$token = (string) $req->get_param( 'token' );
		if ( strlen( $token ) < 24 || strlen( $token ) > 128 ) {
			return new WP_Error( 'egsm_confirm', 'Missing or invalid reporting token.', array( 'status' => 400 ) );
		}
		update_option( 'sseo_connect_secret', $token );
		update_option( 'sseo_connect_paired', 1 );
		update_option( 'sseo_provider', 'platform' );
		$brand = sanitize_text_field( (string) $req->get_param( 'brand' ) );
		if ( '' !== $brand ) {
			update_option( 'sseo_whitelabel_name', $brand );
		}
		$lock = (string) $req->get_param( 'lock_password' );
		if ( '' !== $lock ) {
			update_option( 'sseo_plugin_password', wp_hash_password( $lock ) );
			update_option( 'sseo_lock_enabled', 1 );
		}
		$platform = esc_url_raw( (string) $req->get_param( 'platform_url' ) );
		if ( '' !== $platform && ! defined( 'SSEO_API_URL' ) ) {
			update_option( 'sseo_connect_api', untrailingslashit( $platform ) );
		}
		delete_option( 'egsm_owner_revoked' );
		update_option(
			'egsm_paired',
			array(
				'platform_url' => '' !== $platform ? $platform : self::api_base(),
				'paired_at'    => gmdate( 'c' ),
				'via'          => 'connection-key',
			),
			false
		);
		$b = $req->get_param( 'branding' );
		if ( is_array( $b ) ) {
			EGSM_Maintenance::set_branding( $b );
		}
		EGSM_Log::record( 'paired', 'option', 0, null, null, 'Connected with a connection key for ' . EGSM_Settings::agency_name() );
		return array(
			'ok'             => true,
			'site_url'       => home_url(),
			'site_name'      => get_bloginfo( 'name' ),
			'plugin_version' => defined( 'SSEO_VERSION' ) ? SSEO_VERSION : EGSM_VERSION,
		);
	}

	/** Paired in SEO Suite but no Site Manager key yet (e.g. paired before this version): register, at most hourly. */
	public static function maybe_register() {
		if ( EGSM_Auth::is_connected() || get_option( 'egsm_owner_revoked' ) || ! function_exists( 'sseo_is_connected' ) || ! sseo_is_connected() ) {
			return;
		}
		if ( time() - (int) get_option( 'egsm_register_attempt', 0 ) < HOUR_IN_SECONDS ) {
			return;
		}
		$r = self::register();
		if ( is_wp_error( $r ) && ! wp_next_scheduled( 'egsm_register_retry' ) ) {
			wp_schedule_single_event( time() + HOUR_IN_SECONDS + 60, 'egsm_register_retry' );
		}
	}

	/* ---------- redirects ---------- */

	public static function redirect_table() {
		global $wpdb;
		static $t = null;
		if ( null === $t ) {
			$name = $wpdb->prefix . 'sseo_redirects';
			$t    = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $name ) ) === $name ) ? $name : '';
		}
		return $t;
	}

	/** SEO Suite matches the full REQUEST_URI path, untrailingslashed. */
	public static function source_path( $site_path ) {
		$base = untrailingslashit( (string) wp_parse_url( home_url(), PHP_URL_PATH ) );
		$p    = untrailingslashit( $base . '/' . ltrim( $site_path, '/' ) );
		return '' === $p ? '/' : $p;
	}

	public static function redirect_rows() {
		global $wpdb;
		$t = self::redirect_table();
		return $t ? $wpdb->get_results( "SELECT * FROM {$t} ORDER BY id DESC LIMIT 1000", ARRAY_A ) : array();
	}

	public static function redirect_get( $id ) {
		global $wpdb;
		$t = self::redirect_table();
		return $t ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ), ARRAY_A ) : null;
	}

	/** Insert or update by source. @return array [row, before|null] */
	public static function redirect_upsert( $site_path, $target_url, $code ) {
		global $wpdb;
		$t      = self::redirect_table();
		$source = self::source_path( $site_path );
		$before = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE source_url = %s OR source_url = %s LIMIT 1", $source, trailingslashit( $source ) ), ARRAY_A );
		if ( $before ) {
			$wpdb->update(
				$t,
				array(
					'source_url' => $source,
					'target_url' => $target_url,
					'type'       => (int) $code,
				),
				array( 'id' => $before['id'] )
			);
			$id = (int) $before['id'];
		} else {
			$wpdb->insert(
				$t,
				array(
					'source_url' => $source,
					'target_url' => $target_url,
					'type'       => (int) $code,
				)
			);
			$id = (int) $wpdb->insert_id;
		}
		// Collapse chains: rules that pointed at this source now go straight to the final target.
		$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET target_url = %s WHERE id <> %d AND target_url IN (%s, %s, %s, %s)", $target_url, $id, home_url( $source ), trailingslashit( home_url( $source ) ), $source, trailingslashit( $source ) ) );
		return array( self::redirect_get( $id ), $before );
	}

	public static function redirect_delete( $id ) {
		global $wpdb;
		$t = self::redirect_table();
		return $t ? (bool) $wpdb->delete( $t, array( 'id' => (int) $id ) ) : false;
	}

	public static function redirect_restore( $id, $before ) {
		global $wpdb;
		$t = self::redirect_table();
		if ( ! $t ) {
			return;
		}
		if ( null === $before ) {
			$wpdb->delete( $t, array( 'id' => (int) $id ) );
		} else {
			$wpdb->replace( $t, array_intersect_key( $before, array_flip( array( 'id', 'source_url', 'target_url', 'type', 'hits', 'created_at' ) ) ) );
		}
	}

	/* ---------- llms.txt ---------- */

	public static function llms_write( $text ) {
		update_option( 'sseo_llms_txt_content', (string) $text );
	}

	/** What SEO Suite serves at /llms.txt: its saved content, else its generated default. */
	public static function llms_text() {
		$t = (string) get_option( 'sseo_llms_txt_content', '' );
		if ( '' === trim( $t ) && class_exists( 'SSEO_LLMS_Txt' ) && method_exists( 'SSEO_LLMS_Txt', 'generate_default' ) ) {
			try {
				$o = ( new ReflectionClass( 'SSEO_LLMS_Txt' ) )->newInstanceWithoutConstructor();
				$t = (string) $o->generate_default();
			} catch ( \Throwable $e ) {
				$t = '';
			}
		}
		return $t;
	}

	/* ---------- robots.txt ---------- */

	/** SEO Suite's robots content: file, option, or none. */
	public static function robots_source() {
		$file = ABSPATH . 'robots.txt';
		if ( file_exists( $file ) ) {
			return array( 'file', (string) file_get_contents( $file ), is_writable( $file ) );
		}
		$opt = (string) get_option( 'sseo_robots_txt', '' );
		return '' !== trim( $opt ) ? array( 'option', $opt, true ) : array( 'none', '', true );
	}

	/** Put our managed block into a physical robots.txt (the file wins over any filter). */
	public static function robots_write_file_block( $block ) {
		$file = ABSPATH . 'robots.txt';
		if ( ! file_exists( $file ) || ! is_writable( $file ) ) {
			return new WP_Error( 'egsm_robots_file', 'This site serves a robots.txt file the web server user cannot write; edit it on the server.', array( 'status' => 409 ) );
		}
		$txt = (string) file_get_contents( $file );
		$txt = preg_replace( "/\n?# BEGIN egsm.*?# END egsm\n?/s", "\n", $txt );
		$txt = rtrim( $txt ) . "\n" . ( '' !== trim( $block ) ? $block : '' );
		file_put_contents( $file, rtrim( $txt ) . "\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return true;
	}

	/* ---------- schema ---------- */

	/** Schema types SEO Suite will print on the current request (so we don't print them twice). */
	public static function types_emitted_here() {
		if ( ! get_option( 'sseo_schema_enabled', 1 ) ) {
			return array();
		}
		$types = array();
		$lb    = (string) get_option( 'sseo_business_type', 'LocalBusiness' );
		if ( get_option( 'sseo_brand_name', get_bloginfo( 'name' ) ) && ( is_front_page() || is_page( 'contact' ) || is_page( 'about' ) || ( is_singular() && get_post_meta( get_the_ID(), '_sseo_local_schema', true ) ) ) ) {
			$types[] = $lb ? $lb : 'LocalBusiness';
			$types[] = 'LocalBusiness';
		}
		if ( is_singular() ) {
			$types[] = 'BreadcrumbList';
			$post    = get_post();
			if ( $post && preg_match_all( '/<h[23][^>]*>([^<]*\?)<\/h[23]>\s*<p>([^<]+)<\/p>/i', $post->post_content, $m ) >= 2 ) {
				$types[] = 'FAQPage';
			}
		}
		return array_unique( $types );
	}

	public static function is_business( $obj ) {
		$type = isset( $obj['@type'] ) ? (array) $obj['@type'] : array();
		if ( array_intersect( $type, array( 'Organization', 'WebSite', 'WebPage', 'Person', 'Article', 'BlogPosting', 'FAQPage', 'BreadcrumbList', 'Product', 'Event', 'HowTo' ) ) ) {
			return false;
		}
		return isset( $obj['address'] ) || isset( $obj['telephone'] ) || (bool) preg_grep( '/(Business|Service|Contractor|Painter|Plumber|Electrician|Dentist|Physician|Store|Restaurant|Agency|Office|Clinic|Locksmith|Roofing|HVAC)/i', $type );
	}

	/**
	 * Write a LocalBusiness-style object into SEO Suite's business profile (which SEO Suite outputs).
	 * @return array [mapped field names, ignored field names]
	 */
	public static function map_business( $obj ) {
		$map    = array();
		$ignore = array();
		$set    = function ( $opt, $v ) use ( &$map ) {
			if ( null !== $v && '' !== $v ) {
				update_option( $opt, is_array( $v ) ? implode( ', ', array_filter( array_map( 'strval', $v ) ) ) : sanitize_text_field( (string) $v ) );
				$map[] = $opt;
			}
		};
		$type = isset( $obj['@type'] ) ? ( is_array( $obj['@type'] ) ? reset( $obj['@type'] ) : $obj['@type'] ) : '';
		$set( 'sseo_business_type', $type );
		$set( 'sseo_brand_name', isset( $obj['name'] ) ? $obj['name'] : null );
		$set( 'sseo_business_phone', isset( $obj['telephone'] ) ? $obj['telephone'] : null );
		$set( 'sseo_business_email', isset( $obj['email'] ) ? $obj['email'] : null );
		$set( 'sseo_business_founded', isset( $obj['foundingDate'] ) ? $obj['foundingDate'] : null );
		$a = isset( $obj['address'] ) ? $obj['address'] : null;
		if ( is_string( $a ) ) {
			$set( 'sseo_business_address', $a );
		} elseif ( is_array( $a ) ) {
			$set( 'sseo_business_address', isset( $a['streetAddress'] ) ? $a['streetAddress'] : null );
			$set( 'sseo_business_city', isset( $a['addressLocality'] ) ? $a['addressLocality'] : null );
			$set( 'sseo_business_state', isset( $a['addressRegion'] ) ? $a['addressRegion'] : null );
			$set( 'sseo_business_zip', isset( $a['postalCode'] ) ? $a['postalCode'] : null );
			$set( 'sseo_business_country', isset( $a['addressCountry'] ) ? ( is_array( $a['addressCountry'] ) ? ( isset( $a['addressCountry']['name'] ) ? $a['addressCountry']['name'] : '' ) : $a['addressCountry'] ) : null );
		}
		if ( isset( $obj['geo']['latitude'], $obj['geo']['longitude'] ) ) {
			$set( 'sseo_business_lat', $obj['geo']['latitude'] );
			$set( 'sseo_business_lng', $obj['geo']['longitude'] );
		}
		if ( isset( $obj['areaServed'] ) ) {
			$areas = array();
			foreach ( (array) $obj['areaServed'] as $ar ) {
				$areas[] = is_array( $ar ) ? ( isset( $ar['name'] ) ? $ar['name'] : '' ) : $ar;
			}
			$set( 'sseo_target_location', array_values( array_filter( $areas ) ) );
		}
		$known = array( '@context', '@type', '@id', 'name', 'telephone', 'email', 'foundingDate', 'address', 'geo', 'areaServed', 'url' );
		foreach ( array_keys( $obj ) as $k ) {
			if ( ! in_array( $k, $known, true ) ) {
				$ignore[] = $k;
			}
		}
		return array( $map, $ignore );
	}

	public static function business_options_snapshot() {
		$keys = array( 'sseo_business_type', 'sseo_brand_name', 'sseo_business_phone', 'sseo_business_email', 'sseo_business_founded', 'sseo_business_address', 'sseo_business_city', 'sseo_business_state', 'sseo_business_zip', 'sseo_business_country', 'sseo_business_lat', 'sseo_business_lng', 'sseo_target_location' );
		return EGSM_Log::option_state( $keys );
	}

	public static function has_business_profile() {
		return '' !== (string) get_option( 'sseo_brand_name', '' ) && '' !== (string) get_option( 'sseo_business_phone', '' );
	}
}
