<?php
/**
 * Site-wide SEO settings used when this plugin (or SEO Suite) is the site's SEO plugin:
 * archive indexing, homepage title, sitemap exclusions, link rules, IndexNow.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_SEO_Settings {

	const OPTION = 'egsm_seo_settings';

	public static function defaults() {
		return array(
			'noindex_tax'          => array(),      // taxonomy => true
			'noindex_author'       => false,
			'noindex_date'         => true,
			'home_title'           => '',
			'home_description'     => '',
			'sitemap_exclude_types' => array(),
			'sitemap_exclude_tax'  => array(),
			'link_external_rel'    => '',           // '' | 'nofollow'
			'link_external_newtab' => false,
			'link_rules'           => array(),      // [ ['domains'=>[...], 'rel'=>'sponsored nofollow'] ]
			'indexnow'             => true,
			'default_og_image'     => '',           // share image when a page has no og_image and no featured image
		);
	}

	public static function all() {
		$s = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $s ) ? $s : array(), self::defaults() );
	}

	public static function get( $key ) {
		$s = self::all();
		return isset( $s[ $key ] ) ? $s[ $key ] : null;
	}

	/** True when this plugin (or SEO Suite) is responsible for search output — no Yoast/Rank Math/etc. */
	public static function we_are_seo_plugin() {
		return in_array( EGSM_SEO::active_plugin(), array( 'native', 'sseo' ), true );
	}

	/** Parse "amazon.com, amzn.to = sponsored nofollow" lines (or arrays) into rules. */
	public static function parse_rules( $input ) {
		$rules = array();
		$lines = is_array( $input ) ? $input : preg_split( '/\r\n|\r|\n/', (string) $input );
		foreach ( $lines as $line ) {
			if ( is_array( $line ) ) {
				$domains = isset( $line['domains'] ) ? (array) $line['domains'] : array();
				$rel     = isset( $line['rel'] ) ? (string) $line['rel'] : '';
			} else {
				$line = trim( $line );
				if ( '' === $line || false === strpos( $line, '=' ) ) {
					continue;
				}
				list( $d, $rel ) = array_map( 'trim', explode( '=', $line, 2 ) );
				$domains         = preg_split( '/[\s,]+/', $d );
			}
			$domains = array_values( array_filter( array_map( function ( $x ) {
				$x = strtolower( trim( (string) $x ) );
				$x = preg_replace( '#^https?://#', '', $x );
				$x = preg_replace( '#^www\.#', '', $x );
				return trim( strtok( $x, '/' ) );
			}, $domains ) ) );
			$tokens  = array_values( array_intersect( array_unique( preg_split( '/[\s,]+/', strtolower( $rel ) ) ), array( 'nofollow', 'sponsored', 'ugc', 'noopener', 'noreferrer', 'follow' ) ) );
			if ( $domains && $tokens ) {
				$rules[] = array(
					'domains' => $domains,
					'rel'     => implode( ' ', $tokens ),
				);
			}
		}
		return $rules;
	}

	public static function rules_to_text( $rules ) {
		$out = array();
		foreach ( (array) $rules as $r ) {
			$out[] = implode( ', ', $r['domains'] ) . ' = ' . $r['rel'];
		}
		return implode( "\n", $out );
	}

	/** @return array|WP_Error updated settings */
	public static function update( $p ) {
		$s = self::all();
		foreach ( array( 'noindex_author', 'noindex_date', 'link_external_newtab', 'indexnow' ) as $b ) {
			if ( isset( $p[ $b ] ) ) {
				$s[ $b ] = EGSM_Util::bool( $p[ $b ] );
			}
		}
		foreach ( array( 'home_title', 'home_description' ) as $t ) {
			if ( isset( $p[ $t ] ) ) {
				$s[ $t ] = sanitize_text_field( (string) $p[ $t ] );
			}
		}
		if ( isset( $p['default_og_image'] ) ) {
			$u = esc_url_raw( trim( (string) $p['default_og_image'] ), array( 'http', 'https' ) );
			$s['default_og_image'] = $u ? $u : '';
		}
		if ( isset( $p['link_external_rel'] ) ) {
			$s['link_external_rel'] = in_array( $p['link_external_rel'], array( 'nofollow', 'sponsored', 'ugc', 'nofollow sponsored' ), true ) ? $p['link_external_rel'] : '';
		}
		if ( isset( $p['noindex_tax'] ) ) {
			$n = array();
			foreach ( (array) $p['noindex_tax'] as $k => $v ) {
				$tax = is_int( $k ) ? $v : $k;
				$on  = is_int( $k ) ? true : EGSM_Util::bool( $v );
				if ( taxonomy_exists( $tax ) && $on ) {
					$n[ $tax ] = true;
				}
			}
			$s['noindex_tax'] = $n;
		}
		foreach ( array( 'sitemap_exclude_types' => 'post_type_exists', 'sitemap_exclude_tax' => 'taxonomy_exists' ) as $k => $fn ) {
			if ( isset( $p[ $k ] ) ) {
				$s[ $k ] = array_values( array_filter( array_map( 'sanitize_key', (array) $p[ $k ] ), $fn ) );
			}
		}
		if ( isset( $p['link_rules'] ) ) {
			$s['link_rules'] = self::parse_rules( $p['link_rules'] );
		}
		$before = EGSM_Log::option_state( array( self::OPTION ) );
		update_option( self::OPTION, $s, true );
		$s['change_id'] = EGSM_Log::record( 'seo_settings', 'option', 0, $before, EGSM_Log::option_state( array( self::OPTION ) ), 'Updated SEO settings' );
		return $s;
	}

	public static function for_api() {
		$s                    = self::all();
		$s['link_rules_text'] = self::rules_to_text( $s['link_rules'] );
		$s['active']          = self::we_are_seo_plugin();
		$s['seo_plugin']      = EGSM_SEO::active_plugin();
		$s['sitemap_url']     = function_exists( 'get_sitemap_url' ) ? get_sitemap_url( 'index' ) : '';
		$s['indexnow_key']    = EGSM_IndexNow::key();
		$s['public_taxonomies'] = array_values( get_taxonomies( array( 'public' => true ), 'names' ) );
		return $s;
	}
}
