<?php
/**
 * Site Manager (agency + AI site management API, egsm/v1), built into SEO Suite.
 * Pairing and one-click sign-in come from SEO Suite; see includes/class-egsm-sseo.php for how shared features
 * use SEO Suite's storage.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( class_exists( 'EGSM_Auth' ) ) {
	// The standalone Site Manager Connector is also active; SEO Suite already includes it.
	add_action( 'admin_notices', function () {
		if ( current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-warning"><p>' . esc_html( sseo_product_name() ) . ' now includes site management. Please deactivate the separate "Site Manager Connector" plugin.</p></div>';
		}
	} );
	return;
}

define( 'EGSM_IN_SSEO', true );
define( 'EGSM_VERSION', '1.7.0' );
define( 'EGSM_DB_VERSION', '2' );
define( 'EGSM_FILE', SSEO_DIR . 'samar-seo.php' );
define( 'EGSM_DIR', plugin_dir_path( __FILE__ ) );
define( 'EGSM_NS', 'egsm/v1' );

foreach ( array( 'settings', 'db', 'auth', 'pairing', 'sseo', 'log', 'util', 'cache' ) as $f ) {
	require_once EGSM_DIR . "includes/class-egsm-{$f}.php";
}
require_once EGSM_DIR . 'includes/builders/class-egsm-builders.php';
require_once EGSM_DIR . 'includes/builders/class-egsm-gutenberg.php';
require_once EGSM_DIR . 'includes/builders/class-egsm-elementor.php';
foreach ( array( 'seo', 'content', 'aiseo', 'audit', 'structure', 'redirects', 'media', 'maintenance', 'rest', 'seo-settings', 'score', 'archive', 'sitemap', 'links', 'indexnow', 'editor', 'tracking', 'abilities' ) as $f ) {
	require_once EGSM_DIR . "includes/class-egsm-{$f}.php";
}
require_once EGSM_DIR . 'admin/class-egsm-admin.php';

add_action( 'plugins_loaded', array( 'EGSM_DB', 'maybe_upgrade' ) );
add_filter( 'determine_current_user', array( 'EGSM_Auth', 'determine_current_user' ), 30 );
add_action( 'rest_api_init', array( 'EGSM_REST', 'register_routes' ) );

EGSM_SEO::init_frontend();
EGSM_AISEO::init_frontend();
EGSM_Redirects::init_frontend();
EGSM_Pairing::init();
EGSM_SSEO::init();
EGSM_Score::init();
EGSM_Archive::init();
EGSM_Sitemap::init();
EGSM_Links::init();
EGSM_IndexNow::init();
EGSM_Editor::init();
EGSM_Tracking::init();
EGSM_Admin::init();
