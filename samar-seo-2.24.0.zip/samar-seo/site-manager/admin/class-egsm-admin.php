<?php
/**
 * Admin screen: connection key, access level (set by the site owner), options,
 * recent activity with revert, white-label naming.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EGSM_Admin {

	const SLUG = 'egsm-site-manager';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_egsm_generate_key', array( __CLASS__, 'handle_generate' ) );
		add_action( 'admin_post_egsm_pair', array( __CLASS__, 'handle_pair' ) );
		add_action( 'admin_post_egsm_revoke', array( __CLASS__, 'handle_revoke' ) );
		add_action( 'admin_post_egsm_save', array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_post_egsm_revert', array( __CLASS__, 'handle_revert' ) );
		add_action( 'admin_post_egsm_reconnect', array( __CLASS__, 'handle_reconnect' ) );
		if ( ! EGSM_SSEO::on() ) {
			add_filter( 'all_plugins', array( __CLASS__, 'white_label' ) );
			add_filter( 'plugin_action_links_' . plugin_basename( EGSM_FILE ), array( __CLASS__, 'action_links' ) );
		}
	}

	private static function title() {
		$b = EGSM_Settings::branding();
		return '' !== $b['name'] ? $b['name'] . ' Connect' : 'Site Manager';
	}

	public static function menu() {
		if ( EGSM_SSEO::on() ) {
			// Outside SEO Suite's (agency-locked) menu so the site owner can always see and limit access.
			add_options_page( EGSM_Settings::agency_name() . ' site access', 'Agency site access', 'manage_options', self::SLUG, array( __CLASS__, 'render' ) );
			return;
		}
		add_menu_page( self::title(), self::title(), 'manage_options', self::SLUG, array( __CLASS__, 'render' ), 'dashicons-admin-links', 81 );
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">Settings</a>' );
		return $links;
	}

	public static function white_label( $plugins ) {
		$b    = EGSM_Settings::branding();
		$base = plugin_basename( EGSM_FILE );
		if ( '' !== $b['name'] && isset( $plugins[ $base ] ) ) {
			$plugins[ $base ]['Name']        = $b['name'] . ' Site Connector';
			$plugins[ $base ]['Title']       = $b['name'] . ' Site Connector';
			$plugins[ $base ]['Author']      = $b['name'];
			$plugins[ $base ]['AuthorName']  = $b['name'];
			$plugins[ $base ]['AuthorURI']   = $b['support_url'];
			$plugins[ $base ]['PluginURI']   = $b['support_url'];
			$plugins[ $base ]['Description'] = 'Lets ' . $b['name'] . ' securely manage this site\'s SEO, AI search visibility, content and structure. Every change is logged and can be reverted.';
		}
		return $plugins;
	}

	private static function back( $args = array() ) {
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php?page=' . self::SLUG ) ) );
		exit;
	}

	public static function handle_generate() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'egsm_generate_key' ) ) {
			wp_die( 'Not allowed.' );
		}
		$key = EGSM_Auth::generate_key();
		set_transient( 'egsm_show_key_' . get_current_user_id(), $key, 10 * MINUTE_IN_SECONDS );
		self::back( array( 'egsm' => 'key' ) );
	}

	public static function handle_reconnect() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'egsm_reconnect' ) ) {
			wp_die( 'Not allowed.' );
		}
		$r = EGSM_SSEO::register();
		self::back( is_wp_error( $r ) ? array( 'egsm' => 'pair_failed', 'egsm_msg' => rawurlencode( $r->get_error_message() ) ) : array( 'egsm' => 'paired' ) );
	}

	public static function handle_pair() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'egsm_pair' ) ) {
			wp_die( 'Not allowed.' );
		}
		$code = isset( $_POST['egsm_code'] ) ? sanitize_text_field( wp_unslash( $_POST['egsm_code'] ) ) : '';
		$r    = EGSM_Pairing::pair( $code );
		self::back( is_wp_error( $r ) ? array( 'egsm' => 'pair_failed', 'egsm_msg' => rawurlencode( $r->get_error_message() ) ) : array( 'egsm' => 'paired' ) );
	}

	public static function handle_revoke() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'egsm_revoke' ) ) {
			wp_die( 'Not allowed.' );
		}
		EGSM_Auth::revoke();
		if ( EGSM_SSEO::on() ) {
			update_option( 'egsm_owner_revoked', 1, false ); // don't silently re-register
		} else {
			EGSM_Pairing::remove_sso_user();
		}
		self::back( array( 'egsm' => 'revoked' ) );
	}

	public static function handle_save() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'egsm_save' ) ) {
			wp_die( 'Not allowed.' );
		}
		$level = isset( $_POST['egsm_level'] ) ? sanitize_key( wp_unslash( $_POST['egsm_level'] ) ) : 'publish';
		if ( in_array( $level, EGSM_Settings::LEVELS, true ) ) {
			update_option( 'egsm_level', $level, false );
		}
		foreach ( array( 'app_password_auth', 'log_404', 'auto_purge', 'native_seo' ) as $k ) {
			EGSM_Settings::set( $k, ! empty( $_POST[ 'egsm_' . $k ] ) );
		}
		self::back( array( 'egsm' => 'saved' ) );
	}

	public static function handle_revert() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'egsm_revert' ) ) {
			wp_die( 'Not allowed.' );
		}
		$id = isset( $_POST['change_id'] ) ? (int) $_POST['change_id'] : 0;
		$r  = EGSM_Log::revert( $id, ! empty( $_POST['force'] ) );
		self::back( array( 'egsm' => is_wp_error( $r ) ? 'revert_failed' : 'reverted', 'egsm_msg' => is_wp_error( $r ) ? rawurlencode( $r->get_error_message() ) : '' ) );
	}

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$b         = EGSM_Settings::branding();
		$agency    = EGSM_Settings::agency_name();
		$connected = EGSM_Auth::is_connected();
		$level     = EGSM_Settings::level();
		$show_key  = get_transient( 'egsm_show_key_' . get_current_user_id() );
		if ( $show_key ) {
			delete_transient( 'egsm_show_key_' . get_current_user_id() );
		}
		$notice = isset( $_GET['egsm'] ) ? sanitize_key( $_GET['egsm'] ) : '';
		$color  = esc_attr( $b['color'] );
		$levels = array(
			'read'    => array( 'Read only', 'Audit and read content. No changes.' ),
			'draft'   => array( 'Drafts', 'Also create draft pages/posts and upload images. Live content is not touched.' ),
			'publish' => array( 'Publish', 'Also edit live pages, SEO fields, schema, redirects, menus, robots.txt and llms.txt. Recommended.' ),
			'full'    => array( 'Full', 'Also update plugins and themes.' ),
		);
		$changes = EGSM_Log::list_changes( array( 'limit' => 30 ) );
		?>
		<div class="wrap egsm-wrap">
			<style>
				.egsm-wrap{max-width:980px}
				.egsm-card{background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:20px 24px;margin:16px 0}
				.egsm-head{display:flex;align-items:center;gap:12px;margin:10px 0 4px}
				.egsm-head img{max-height:40px;width:auto}
				.egsm-pill{display:inline-block;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:600}
				.egsm-on{background:#e7f6ec;color:#116329}.egsm-off{background:#f6f7f7;color:#50575e}
				.egsm-key{font-family:monospace;font-size:12px;word-break:break-all;background:#f6f7f7;border:1px dashed #8c8f94;padding:12px;border-radius:6px;user-select:all}
				.egsm-levels label{display:block;padding:10px 12px;border:1px solid #dcdcde;border-radius:8px;margin:8px 0;cursor:pointer}
				.egsm-levels input:checked+strong{color:<?php echo $color; // phpcs:ignore ?>}
				.egsm-btn{background:<?php echo $color; // phpcs:ignore ?>!important;border-color:<?php echo $color; // phpcs:ignore ?>!important;color:#fff!important}
				.egsm-table td,.egsm-table th{padding:8px 10px;vertical-align:top}
				@media(max-width:700px){.egsm-card{padding:14px}}
			</style>
			<div class="egsm-head">
				<?php if ( $b['logo_url'] ) : ?><img src="<?php echo esc_url( $b['logo_url'] ); ?>" alt=""><?php endif; ?>
				<h1 style="margin:0"><?php echo esc_html( self::title() ); ?></h1>
				<span class="egsm-pill <?php echo $connected ? 'egsm-on' : 'egsm-off'; ?>"><?php echo $connected ? 'Connected' : 'Not connected'; ?></span>
			</div>
			<p><?php echo esc_html( $agency ); ?> uses this connection to audit and improve this site's SEO, AI-search visibility and content. Every change is recorded below and can be undone.</p>

			<?php if ( 'saved' === $notice ) : ?><div class="notice notice-success"><p>Settings saved.</p></div><?php endif; ?>
			<?php if ( 'revoked' === $notice ) : ?><div class="notice notice-warning"><p>Connection revoked. The agency can no longer access this site until you connect again.</p></div><?php endif; ?>
			<?php if ( 'paired' === $notice ) : ?><div class="notice notice-success"><p>Connected to <strong><?php echo esc_html( $agency ); ?></strong>.</p></div><?php endif; ?>
			<?php if ( 'pair_failed' === $notice ) : ?><div class="notice notice-error"><p><?php echo esc_html( isset( $_GET['egsm_msg'] ) ? rawurldecode( sanitize_text_field( wp_unslash( $_GET['egsm_msg'] ) ) ) : 'Pairing failed.' ); ?></p></div><?php endif; ?>
			<?php if ( 'reverted' === $notice ) : ?><div class="notice notice-success"><p>Change reverted.</p></div><?php endif; ?>
			<?php if ( 'revert_failed' === $notice ) : ?><div class="notice notice-error"><p>Revert failed: <?php echo esc_html( isset( $_GET['egsm_msg'] ) ? rawurldecode( sanitize_text_field( wp_unslash( $_GET['egsm_msg'] ) ) ) : '' ); ?></p></div><?php endif; ?>
			<?php if ( 'https' !== wp_parse_url( home_url(), PHP_URL_SCHEME ) ) : ?><div class="notice notice-warning"><p>This site is not using HTTPS. Requests are signed, but content travels unencrypted. Enable SSL before connecting.</p></div><?php endif; ?>

			<div class="egsm-card">
				<h2 style="margin-top:0">1. Connection</h2>
				<?php if ( $connected ) : ?>
					<p>Connected to <strong><?php echo esc_html( $agency ); ?></strong> since <?php echo esc_html( wp_date( get_option( 'date_format' ), (int) get_option( 'egsm_key_created' ) ) ); ?>.
					<?php $seen = (int) get_option( 'egsm_last_seen' ); ?>
					<?php echo $seen ? 'Last activity ' . esc_html( human_time_diff( $seen ) ) . ' ago.' : 'No activity yet.'; ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
						<?php wp_nonce_field( 'egsm_revoke' ); ?><input type="hidden" name="action" value="egsm_revoke">
						<button class="button" onclick="return confirm('Disconnect your agency from this site? Their sign-in account is removed too.')">Revoke connection</button>
					</form>
				<?php elseif ( EGSM_SSEO::on() ) : ?>
					<?php if ( function_exists( 'sseo_is_connected' ) && sseo_is_connected() ) : ?>
						<p><?php echo get_option( 'egsm_owner_revoked' ) ? 'You turned off site management for your agency.' : 'Your site is paired with your agency; site management is still being set up.'; ?></p>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<?php wp_nonce_field( 'egsm_reconnect' ); ?><input type="hidden" name="action" value="egsm_reconnect">
							<button class="button egsm-btn">Connect site management</button>
						</form>
					<?php else : ?>
						<p>Pair this site with your agency first, using the connection code in <?php echo esc_html( function_exists( 'sseo_product_name' ) ? sseo_product_name() : 'SEO Suite' ); ?>.</p>
					<?php endif; ?>
				<?php else : ?>
					<p>Enter the pairing code your agency gave you.</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php wp_nonce_field( 'egsm_pair' ); ?><input type="hidden" name="action" value="egsm_pair">
						<input name="egsm_code" type="text" placeholder="XXXX-XXXX" autocomplete="off" required style="font-size:18px;letter-spacing:3px;padding:8px 12px;text-transform:uppercase;width:220px;max-width:100%">
						<button class="button egsm-btn button-hero">Connect</button>
					</form>
				<?php endif; ?>
				<?php if ( ! EGSM_SSEO::on() ) : ?>
				<details style="margin-top:14px" <?php echo $show_key ? 'open' : ''; ?>>
					<summary>Advanced: connection key for other tools</summary>
					<?php if ( $show_key ) : ?>
						<p><strong>Copy this key now.</strong> For security it is shown only once.</p>
						<div class="egsm-key"><?php echo esc_html( $show_key ); ?></div>
					<?php else : ?>
						<p>Generates a signing key you can paste into another tool instead of using a pairing code. It replaces any current connection.</p>
					<?php endif; ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php wp_nonce_field( 'egsm_generate_key' ); ?><input type="hidden" name="action" value="egsm_generate_key">
						<button class="button" <?php echo $connected ? 'onclick="return confirm(\'This replaces the current connection. Continue?\')"' : ''; ?>>Generate connection key</button>
					</form>
				</details>
				<?php endif; ?>
			</div>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'egsm_save' ); ?><input type="hidden" name="action" value="egsm_save">
				<div class="egsm-card egsm-levels">
					<h2 style="margin-top:0">2. What the agency can do</h2>
					<?php foreach ( $levels as $k => $l ) : ?>
						<label><input type="radio" name="egsm_level" value="<?php echo esc_attr( $k ); ?>" <?php checked( $level, $k ); ?>> <strong><?php echo esc_html( $l[0] ); ?></strong> — <?php echo esc_html( $l[1] ); ?></label>
					<?php endforeach; ?>
				</div>
				<div class="egsm-card">
					<h2 style="margin-top:0">3. Options</h2>
					<p><label><input type="checkbox" name="egsm_app_password_auth" value="1" <?php checked( EGSM_Settings::get( 'app_password_auth' ) ); ?>> Also accept administrator Application Passwords (for older connections)</label></p>
					<p><label><input type="checkbox" name="egsm_log_404" value="1" <?php checked( EGSM_Settings::get( 'log_404' ) ); ?>> Log 404 errors so broken URLs can be redirected</label></p>
					<p><label><input type="checkbox" name="egsm_auto_purge" value="1" <?php checked( EGSM_Settings::get( 'auto_purge' ) ); ?>> Clear page cache automatically after changes</label></p>
					<p><label><input type="checkbox" name="egsm_native_seo" value="1" <?php checked( EGSM_Settings::get( 'native_seo' ) ); ?>> Output SEO tags when no SEO plugin is active</label></p>
					<button class="button egsm-btn">Save</button>
				</div>
			</form>
			<?php $egsm_tag = class_exists( 'EGSM_Tracking' ) ? EGSM_Tracking::current() : null; if ( $egsm_tag ) : ?>
			<div class="egsm-card">
				<h2 style="margin-top:0">Ad conversion tracking</h2>
				<p><?php echo esc_html( $agency ); ?> added its tracking tag to your pages <?php echo esc_html( human_time_diff( strtotime( $egsm_tag['at'] ) ) ); ?> ago. It counts form fills and calls from your ads; it does not change how the site looks.</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'egsm_tracking_remove' ); ?><input type="hidden" name="action" value="egsm_tracking_remove">
					<button class="button" onclick="return confirm('Remove the tracking tag? Your ads will stop counting form fills and calls from this site.')">Remove the tag</button>
				</form>
			</div>
			<?php endif; ?>

			<div class="egsm-card">
				<h2 style="margin-top:0">Recent changes</h2>
				<?php if ( ! $changes ) : ?>
					<p>No changes yet.</p>
				<?php else : ?>
				<table class="widefat striped egsm-table">
					<thead><tr><th>When</th><th>What</th><th>By</th><th></th></tr></thead>
					<tbody>
					<?php foreach ( $changes as $c ) : ?>
						<tr>
							<td><?php echo esc_html( human_time_diff( strtotime( $c['created_at'] ) ) ); ?> ago</td>
							<td><?php echo esc_html( $c['summary'] ? $c['summary'] : $c['action'] ); ?>
								<?php if ( 'post' === $c['object_type'] && $c['object_id'] && get_post( $c['object_id'] ) ) : ?> · <a href="<?php echo esc_url( get_edit_post_link( $c['object_id'] ) ); ?>">edit</a><?php endif; ?>
								<?php if ( $c['reverted_at'] ) : ?> <em>(reverted)</em><?php endif; ?></td>
							<td><?php echo esc_html( 0 === strpos( $c['actor'], 'agency:' ) ? $agency : preg_replace( '/^user:/', '', $c['actor'] ) ); ?></td>
							<td>
								<?php if ( $c['revertable'] ) : ?>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
									<?php wp_nonce_field( 'egsm_revert' ); ?><input type="hidden" name="action" value="egsm_revert"><input type="hidden" name="change_id" value="<?php echo (int) $c['id']; ?>">
									<button class="button button-small" onclick="return confirm('Undo this change?')">Undo</button>
								</form>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<?php endif; ?>
			</div>
			<?php if ( $b['support_url'] || $b['support_email'] ) : ?>
				<p>Need help? <?php if ( $b['support_url'] ) : ?><a href="<?php echo esc_url( $b['support_url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $agency ); ?> support</a><?php endif; ?> <?php echo $b['support_email'] ? esc_html( $b['support_email'] ) : ''; ?></p>
			<?php endif; ?>
		</div>
		<?php
	}
}
