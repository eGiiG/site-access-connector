(function($){
'use strict';

function ajax(action, data, cb) { data.action='sseo_'+action; data.nonce=sseo.nonce; $.post(sseo.ajax_url,data,cb).fail(function(x){cb({success:false,data:'Request failed: '+x.statusText})}); }
function esc(s) { return s ? $('<span>').text(s).html() : ''; }
function escA(s) { return s ? s.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/'/g,'&#39;').replace(/</g,'&lt;').replace(/>/g,'&gt;') : ''; }
function trunc(s,n) { return s && s.length>n ? s.substring(0,n)+'...' : (s||''); }
function charCls(c,min,max) { return c>=min&&c<=max?'sseo-char-ok':c>=min-10&&c<=max+10?'sseo-char-warn':'sseo-char-bad'; }

function buildModelPicker(idSuffix) {
    if (!sseo || !sseo.providers) return '';
    var h = '<div style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;margin-bottom:12px">';
    h += '<span style="font-size:12px;font-weight:600;color:#475569;white-space:nowrap">🤖 Model:</span>';
    h += '<select class="sseo-select-full model-picker" id="mp-'+idSuffix+'" style="font-size:13px;padding:4px 8px">';
    h += '<option value="">Use global ('+esc(sseo.provider||'default')+')</option>';
    for (var pk in sseo.providers) {
        var pv = sseo.providers[pk];
        if (!pv.has_key) continue;
        h += '<option value="'+pk+'">'+esc(pv.label)+' — '+esc(pv.model)+'</option>';
    }
    h += '</select></div>';
    return h;
}

// ─── Tool Router ──────────────

$(document).ready(function(){
    var $tool = $('.sseo-tool-container');
    if (!$tool.length) return;
    var tool = $tool.data('tool');

    // ── Model Switcher Bar ──
    var $bar = $('#sseo-model-bar');
    if ($bar.length && sseo.providers) {
        var cur = sseo.provider || 'openai';
        var tierColors = {premium:'#6366f1',budget:'#d97706',free:'#16a34a'};
        var tierLabels = {premium:'PREMIUM',budget:'BUDGET',free:'FREE'};
        var h = '<div class="sseo-model-switcher">';
        h += '<span class="sseo-model-label">🤖 AI Model:</span>';
        h += '<select class="sseo-model-select" id="sseo-prov-switch">';
        for (var pk in sseo.providers) {
            var pv = sseo.providers[pk];
            if (!pv.has_key) continue;
            var sel = pk===cur?' selected':'';
            var badge = tierLabels[pv.tier]||'';
            h += '<option value="'+pk+'"'+sel+'>['+badge+'] '+pv.label+' — '+pv.model+'</option>';
        }
        h += '</select>';
        h += '<span class="sseo-model-status" id="sseo-prov-status"></span>';
        h += '<a href="'+sseo.ajax_url.replace('admin-ajax.php','admin.php?page=sseo-settings')+'" class="sseo-model-settings" title="Configure API keys">⚙️</a>';
        h += '</div>';
        $bar.html(h);

        // Check if no providers configured
        var configured = 0;
        for (var pk2 in sseo.providers) { if (sseo.providers[pk2].has_key) configured++; }
        if (configured === 0) {
            $bar.html('<div class="sseo-model-switcher sseo-model-warn">⚠️ No AI provider configured. <a href="'+sseo.ajax_url.replace('admin-ajax.php','admin.php?page=sseo-settings')+'">Go to Settings</a> to add an API key.</div>');
        }

        // Switch handler
        $(document).on('change','#sseo-prov-switch',function(){
            var newProv = $(this).val();
            var $st = $('#sseo-prov-status');
            $st.html('Switching...').css('color','#6366f1');
            ajax('switch_provider',{provider:newProv},function(r){
                if (r.success) {
                    $st.html('✓ '+r.data.label+' — '+r.data.model).css('color','#16a34a');
                    sseo.provider = r.data.provider;
                    setTimeout(function(){$st.html('')},3000);
                } else {
                    $st.html('✗ '+r.data).css('color','#dc2626');
                }
            });
        });
    }
    var inits = { meta:initMeta, alts:initAlts, imgtitles:initImgTitles, titles:initTitles, h1:initH1, broken:initBroken, thin:initThin, redirects:initRedirects, schema:initSchema, testimonials_mgr:initTestimonials, llms:initLlms, log:initLog, settings:initSettings, content:initContent, templates:initTemplates, reports:initReports, imgopt:initImgOpt, robots:initRobots, orphans:initOrphans, crawl:initCrawl, anchors:initAnchors, linker:initLinker, chains:initChains, audit:initAudit, local_audit:initLocalAudit, ai_audit:initAIAudit };
    if (inits[tool]) inits[tool]($tool);
});

// ─── META DESCRIPTIONS ────────

function initMeta($c) {
    $c.html('<div class="sseo-toolbar"><input type="text" class="sseo-search" id="sseo-ms" placeholder="Search posts..."><select class="sseo-select" id="sseo-mf"><option value="all">All</option><option value="missing">Missing Meta</option><option value="has_meta">Has Meta</option></select><button class="sseo-btn" id="sseo-mr">Refresh</button><div class="sseo-toolbar-right"><button class="sseo-btn" id="sseo-msa">Select All</button><button class="sseo-btn-primary" id="sseo-mbulk" disabled>Bulk Generate</button><label class="sseo-cb-label"><input type="checkbox" id="sseo-maa"> Auto-apply</label></div></div><div class="sseo-card"><table class="sseo-table"><thead><tr><th class="sseo-check-col"><input type="checkbox" id="sseo-mca"></th><th>Title</th><th>Type</th><th>Current Meta</th><th>Chars</th><th>Action</th></tr></thead><tbody id="sseo-mtb"><tr><td colspan="6" class="sseo-loading">Loading...</td></tr></tbody></table><div class="sseo-pagination" id="sseo-mp"></div></div><div class="sseo-modal" id="sseo-mm" style="display:none"><div class="sseo-modal-content"><div class="sseo-modal-header"><h3 id="sseo-mmt"></h3><button class="sseo-modal-close" id="sseo-mmc">&times;</button></div><div class="sseo-modal-body" id="sseo-mmb"></div></div></div><div class="sseo-progress-wrap" id="sseo-mprog" style="display:none"><div class="sseo-progress-header"><h3>Bulk Progress</h3><span id="sseo-mpt">0/0</span></div><div class="sseo-progress-bar"><div class="sseo-progress-fill" id="sseo-mpf"></div></div><div class="sseo-progress-log" id="sseo-mpl"></div></div>');
    var pg=1;
    function load(p){
        pg=p||1;
        // Reset: hide progress bar, uncheck all, reset bulk button
        $('#sseo-mprog').hide();
        $('#sseo-mpl').html('');
        $('#sseo-mpf').css('width','0%');
        $('#sseo-mpt').text('0/0');
        $('#sseo-mca').prop('checked',false);
        $('#sseo-mbulk').prop('disabled',true).text('Bulk Generate Selected');
        
        $('#sseo-mtb').html('<tr><td colspan="6" class="sseo-loading">Loading...</td></tr>');
        ajax('get_posts',{paged:pg,search:$('#sseo-ms').val(),filter:$('#sseo-mf').val()},function(r){
            if(!r.success){$('#sseo-mtb').html('<tr><td colspan="6">'+r.data+'</td></tr>');return}
            var h='';
            if(!r.data.posts.length){
                h='<tr><td colspan="6" class="sseo-loading">No posts found.</td></tr>';
            } else {
                r.data.posts.forEach(function(p){
                    var mc=p.has_meta?'<span class="sseo-meta-cell" title="'+escA(p.meta)+'">'+esc(trunc(p.meta,50))+'</span>':'<span class="sseo-meta-missing">— Missing —</span>';
                    var cc=p.has_meta?'<span class="'+charCls(p.char_count,150,160)+'">'+p.char_count+'</span>':'—';
                    h+='<tr><td class="sseo-check-col"><input type="checkbox" class="sseo-mcb" value="'+p.id+'"></td>';
                    h+='<td><strong><a href="'+p.permalink+'" target="_blank">'+esc(p.title)+'</a></strong></td>';
                    h+='<td>'+p.type+'</td>';
                    h+='<td>'+mc+'</td>';
                    h+='<td>'+cc+'</td>';
                    h+='<td>';
                    h+='<button class="sseo-btn sseo-gen-meta" data-id="'+p.id+'">Generate</button> ';
                    h+='<button class="sseo-btn sseo-inline-edit-meta" data-id="'+p.id+'" data-meta="'+escA(p.meta||'')+'" title="'+(p.has_meta?'Edit existing meta':'Write meta manually')+'">'+(p.has_meta?'✏️':'✏️ Write')+'</button>';
                    h+='</td></tr>';
                });
            }
            $('#sseo-mtb').html(h);
            var pag='';
            if(r.data.total_pages>1){
                pag='<span class="sseo-page-info">Page '+r.data.paged+' of '+r.data.total_pages+' ('+r.data.total+' posts)</span>';
                if(r.data.paged>1) pag+='<button class="sseo-page-btn" data-p="'+(r.data.paged-1)+'">← Prev</button>';
                for(var i=1;i<=r.data.total_pages;i++){
                    if(r.data.total_pages>10 && Math.abs(i-r.data.paged)>3 && i!==1 && i!==r.data.total_pages){if(i===2||i===r.data.total_pages-1)pag+='<span style="padding:0 4px;color:#94a3b8">…</span>';continue;}
                    pag+='<button class="sseo-page-btn'+(i===r.data.paged?' active':'')+'" data-p="'+i+'">'+i+'</button>';
                }
                if(r.data.paged<r.data.total_pages) pag+='<button class="sseo-page-btn" data-p="'+(r.data.paged+1)+'">Next →</button>';
            }
            $('#sseo-mp').html(pag);
        });
    }
    load(1);
    var st;$('#sseo-ms').on('input',function(){clearTimeout(st);st=setTimeout(function(){load(1)},400)});$('#sseo-mf').on('change',function(){load(1)});$('#sseo-mr').on('click',function(){load(pg)});
    $(document).on('click','#sseo-mp .sseo-page-btn',function(){load($(this).data('p'))});
    $('#sseo-mca').on('change',function(){$('.sseo-mcb').prop('checked',this.checked);updBulk()});$('#sseo-msa').on('click',function(){$('.sseo-mcb').prop('checked',true);updBulk()});$(document).on('change','.sseo-mcb',updBulk);
    function updBulk(){var n=$('.sseo-mcb:checked').length;$('#sseo-mbulk').prop('disabled',!n).text(n?'Bulk Generate ('+n+')':'Bulk Generate');}
    $(document).on('click','.sseo-gen-meta',function(){var $b=$(this),id=$b.data('id');$b.addClass('generating').text('...');ajax('generate_meta',{post_id:id,count:3},function(r){$b.removeClass('generating').text('Generate');if(!r.success){alert(r.data);return}showModal(r.data)});});
    function showModal(d){var h='<p style="color:#646970">Post: <strong>'+esc(d.post_title)+'</strong></p>';d.descriptions.forEach(function(x,i){var cc=x.charCount||x.description.length;var uid='meta-edit-'+d.post_id+'-'+i;h+='<div class="sseo-result-item" data-uid="'+uid+'"><div class="sseo-result-top"><span class="sseo-approach-tag">'+esc(x.approach||'Option '+(i+1))+'</span><span class="sseo-charcount '+charCls(cc,150,160)+'">'+cc+' chars</span></div><p class="sseo-result-text sseo-editable-text">'+esc(x.description)+'</p><textarea class="sseo-edit-area" style="display:none;width:100%;min-height:70px;padding:10px;border:2px solid #6366f1;border-radius:6px;font-size:14px;line-height:1.5;resize:vertical;margin-bottom:8px">'+escA(x.description)+'</textarea><div class="sseo-result-actions"><button class="button button-primary sseo-apply-meta" data-pid="'+d.post_id+'" data-desc="'+escA(x.description)+'">Apply</button><button class="button sseo-edit-btn">✏️ Edit</button><button class="button sseo-cancel-edit" style="display:none">Cancel</button><button class="button sseo-copy" data-text="'+escA(x.description)+'">Copy</button></div></div>';});$('#sseo-mmb').html(h);$('#sseo-mmt').text('Generated: '+trunc(d.post_title,40));$('#sseo-mm').show();}
    $('#sseo-mmc').on('click',function(){$('#sseo-mm').hide()});$('#sseo-mm').on('click',function(e){if(e.target===this)$(this).hide()});
    $(document).on('click','.sseo-apply-meta',function(){var $b=$(this),$item=$b.closest('.sseo-result-item');var $area=$item.find('.sseo-edit-area');var desc=$area.is(':visible')?$area.val():$b.data('desc');$b.prop('disabled',true).text('...');ajax('apply_meta',{post_id:$b.data('pid'),description:desc},function(r){$b.text(r.success?'✓ Applied':'Error');if(r.success)setTimeout(function(){$('#sseo-mm').hide();load(pg)},600)});});
    $('#sseo-mbulk').on('click',function(){
        var ids=[];$('.sseo-mcb:checked').each(function(){ids.push($(this).val())});
        if(!ids.length)return;
        if(!confirm('Generate meta descriptions for '+ids.length+' posts? This will use API credits.'))return;
        var auto=$('#sseo-maa').is(':checked');
        // Show progress, disable bulk button
        $('#sseo-mprog').show();
        $('#sseo-mpl').html('');
        $('#sseo-mpf').css('width','0%');
        $('#sseo-mpt').text('0 / '+ids.length);
        $(this).prop('disabled',true).text('Running...');
        var done=0, errors=0;
        
        function next(i){
            if(i>=ids.length){
                // Complete — show summary and re-enable
                $('#sseo-mpt').text('✅ Done! '+done+' generated, '+errors+' errors');
                $('#sseo-mpf').css('width','100%');
                $('#sseo-mpl').append('<div class="sseo-log-ok" style="font-weight:600;margin-top:8px">✅ Bulk complete! '+done+'/'+ids.length+' generated'+(auto?' & applied':'')+'. '+errors+' errors.</div>');
                $('#sseo-mbulk').prop('disabled',false).text('Bulk Generate Selected');
                // Reload table to show updated metas + edit buttons
                load(pg);
                return;
            }
            $('#sseo-mpt').text((i+1)+' / '+ids.length);
            $('#sseo-mpf').css('width',((i+1)/ids.length*100)+'%');
            ajax('generate_meta',{post_id:ids[i],count:1},function(r){
                if(r.success&&r.data.descriptions&&r.data.descriptions.length){
                    done++;
                    var desc=r.data.descriptions[0].description;
                    $('#sseo-mpl').append('<div class="sseo-log-ok">✓ '+esc(r.data.post_title)+'</div>');
                    if(auto){
                        ajax('apply_meta',{post_id:ids[i],description:desc},function(){
                            $('#sseo-mpl').find('div:last').append(' — applied');
                            next(i+1);
                        });
                    } else next(i+1);
                } else {
                    errors++;
                    $('#sseo-mpl').append('<div class="sseo-log-err">✗ #'+ids[i]+': '+(r.data||'Error')+'</div>');
                    next(i+1);
                }
                $('#sseo-mpl').scrollTop($('#sseo-mpl')[0].scrollHeight);
            });
        }
        next(0);
    });
}

// ─── ALT TAGS ────────

function initAlts($c) {
    $c.html(`
    <div style="background:#eff6ff;border:1px solid #93c5fd;border-radius:10px;padding:14px 18px;margin-bottom:16px;font-size:13px;color:#1e40af">
        <strong>👁️ AI Vision Mode:</strong> When you click <strong>Generate</strong> on a single image, the AI actually <em>looks at the image</em> to describe what it sees.
        For bulk operations, you can choose between <strong>Vision mode</strong> (slower, but highly accurate) or <strong>Fast mode</strong> (uses filename + page context).
    </div>
    <div class="sseo-toolbar">
        <button class="sseo-btn" id="sseo-ar">Refresh</button>
        <div class="sseo-toolbar-right">
            <button class="sseo-btn" id="sseo-asa">Select All</button>
            <button class="sseo-btn-primary" id="sseo-abulk-vision" disabled title="AI sees each image — slower but accurate">👁️ Bulk Vision</button>
            <button class="sseo-btn-primary" id="sseo-abulk-fast" disabled style="background:linear-gradient(135deg,#d97706,#f59e0b)" title="Uses filename + page context — fast">⚡ Bulk Fast</button>
            <label class="sseo-cb-label"><input type="checkbox" id="sseo-aaa"> Auto-apply</label>
        </div>
    </div>
    <div class="sseo-card">
        <table class="sseo-table">
            <thead><tr><th class="sseo-check-col"><input type="checkbox" id="sseo-aca"></th><th>Thumb</th><th>Filename</th><th>Used On</th><th>Action</th></tr></thead>
            <tbody id="sseo-atb"><tr><td colspan="5" class="sseo-loading">Loading...</td></tr></tbody>
        </table>
        <div class="sseo-pagination" id="sseo-ap"></div>
    </div>
    <div class="sseo-modal" id="sseo-am" style="display:none">
        <div class="sseo-modal-content">
            <div class="sseo-modal-header">
                <h3 id="sseo-amt">Generated ALT Tags</h3>
                <button class="sseo-modal-close" id="sseo-amc">&times;</button>
            </div>
            <div class="sseo-modal-body" id="sseo-amb"></div>
        </div>
    </div>
    <div class="sseo-progress-wrap" id="sseo-aprog" style="display:none">
        <div class="sseo-progress-header"><h3>Bulk Progress</h3><span id="sseo-apt"></span></div>
        <div class="sseo-progress-bar"><div class="sseo-progress-fill" id="sseo-apf"></div></div>
        <div class="sseo-progress-log" id="sseo-apl"></div>
    </div>
    <div id="sseo-alt-changes" style="margin-top:16px"></div>`);

    // Load recent ALT changes
    loadRecentChanges('sseo-alt-changes', 'alt', 'ALT Tag');

    var pg=1;
    function load(p){
        pg=p||1;
        $('#sseo-aprog').hide();
        $('#sseo-aca').prop('checked',false);
        updA();
        $('#sseo-atb').html('<tr><td colspan="5" class="sseo-loading">Loading...</td></tr>');
        ajax('get_missing_alts',{paged:pg},function(r){
            if(!r.success)return;
            var imgs=r.data.images, h='';
            if(!imgs.length){
                h='<tr><td colspan="5" class="sseo-loading">All images have ALT tags! 🎉</td></tr>';
            } else {
                imgs.forEach(function(img){
                    h+='<tr>';
                    h+='<td class="sseo-check-col"><input type="checkbox" class="sseo-acb" value="'+img.attachment_id+'"></td>';
                    h+='<td><img class="sseo-thumb" src="'+escA(img.thumbnail)+'" alt=""></td>';
                    h+='<td>'+esc(img.filename)+'</td>';
                    h+='<td>'+(img.parent_title?esc(trunc(img.parent_title,30)):'—')+'</td>';
                    h+='<td><button class="sseo-btn sseo-gen-alt" data-id="'+img.attachment_id+'" title="AI Vision — sees the actual image">👁️ Generate</button></td>';
                    h+='</tr>';
                });
            }
            $('#sseo-atb').html(h);
            // Pagination
            var pag='';
            if(r.data.total_pages>1){
                pag='<span class="sseo-page-info">'+r.data.total+' images</span>';
                if(r.data.paged>1) pag+='<button class="sseo-page-btn" data-p="'+(r.data.paged-1)+'">← Prev</button>';
                for(var i=1;i<=Math.min(r.data.total_pages,10);i++) pag+='<button class="sseo-page-btn'+(i===r.data.paged?' active':'')+'" data-p="'+i+'">'+i+'</button>';
                if(r.data.paged<r.data.total_pages) pag+='<button class="sseo-page-btn" data-p="'+(r.data.paged+1)+'">Next →</button>';
            }
            $('#sseo-ap').html(pag);
        });
    }
    load(1);
    $('#sseo-ar').on('click',function(){load(pg)});
    $(document).on('click','#sseo-ap .sseo-page-btn',function(){load($(this).data('p'))});

    // Checkboxes
    $('#sseo-aca').on('change',function(){$('.sseo-acb').prop('checked',this.checked);updA()});
    $('#sseo-asa').on('click',function(){$('.sseo-acb').prop('checked',true);updA()});
    $(document).on('change','.sseo-acb',updA);
    function updA(){
        var n=$('.sseo-acb:checked').length;
        $('#sseo-abulk-vision').prop('disabled',!n).text(n?'👁️ Bulk Vision ('+n+')':'👁️ Bulk Vision');
        $('#sseo-abulk-fast').prop('disabled',!n).text(n?'⚡ Bulk Fast ('+n+')':'⚡ Bulk Fast');
    }

    // Single Generate — always uses Vision
    $(document).on('click','.sseo-gen-alt',function(){
        var $b=$(this),id=$b.data('id');
        $b.addClass('generating').html('👁️ Analyzing...');
        ajax('generate_alts',{image_ids:[id],use_vision:'true'},function(r){
            $b.removeClass('generating').html('👁️ Generate');
            if(!r.success){alert(r.data);return}
            var h='';
            var visionBadge = r.data.used_vision ? '<span style="background:#dcfce7;color:#16a34a;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;margin-left:8px">👁️ AI VISION</span>' : '<span style="background:#fef3c7;color:#d97706;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;margin-left:8px">📝 TEXT-BASED</span>';
            r.data.results.forEach(function(res){
                h+='<div class="sseo-result-item"><p style="font-weight:600">'+esc(res.filename)+visionBadge+'</p>';
                if(res.error){
                    h+='<p style="color:#dc2626;font-size:13px">Error: '+esc(res.error)+'</p>';
                } else {
                    res.alts.forEach(function(a,j){
                        var cc=a.charCount||a.text.length;
                        h+='<div style="margin:8px 0" class="sseo-result-item">';
                        h+='<span class="sseo-approach-tag">Option '+(j+1)+'</span> ';
                        h+='<span class="sseo-charcount '+charCls(cc,80,125)+'">'+cc+' chars</span>';
                        h+='<p class="sseo-editable-text" style="margin:6px 0"><code class="sseo-alt-code">alt="'+esc(a.text)+'"</code></p>';
                        h+='<textarea class="sseo-edit-area" style="display:none;width:100%;min-height:50px;padding:8px;border:2px solid #6366f1;border-radius:6px;font-size:13px;margin:6px 0">'+escA(a.text)+'</textarea>';
                        h+='<div class="sseo-result-actions">';
                        h+='<button class="button button-primary sseo-apply-alt" data-aid="'+res.attachment_id+'" data-alt="'+escA(a.text)+'">Apply</button> ';
                        h+='<button class="button sseo-edit-btn">✏️ Edit</button> ';
                        h+='<button class="button sseo-cancel-edit" style="display:none">Cancel</button> ';
                        h+='<button class="button sseo-copy" data-text="'+escA(a.text)+'">Copy</button>';
                        h+='</div></div>';
                    });
                }
                h+='</div>';
            });
            $('#sseo-amb').html(h);
            $('#sseo-amt').text('ALT Tags — AI Vision Results');
            $('#sseo-am').show();
        });
    });

    // Modal
    $('#sseo-amc').on('click',function(){$('#sseo-am').hide()});
    $('#sseo-am').on('click',function(e){if(e.target===this)$(this).hide()});

    // Apply ALT (reads from edit area if open)
    $(document).on('click','.sseo-apply-alt',function(){
        var $b=$(this),$item=$b.closest('.sseo-result-item');
        var $area=$item.find('.sseo-edit-area');
        var alt=$area.is(':visible')?$area.val():$b.data('alt');
        $b.prop('disabled',true).text('...');
        ajax('apply_alt',{attachment_id:$b.data('aid'),alt_text:alt},function(r){
            $b.text(r.success?'✓ Applied':'Error');
            if(r.success) setTimeout(function(){$('#sseo-am').hide();load(pg)},600);
        });
    });

    // Bulk Vision — processes one at a time with AI seeing each image
    $('#sseo-abulk-vision').on('click',function(){
        var ids=[];$('.sseo-acb:checked').each(function(){ids.push($(this).val())});
        if(!ids.length)return;
        if(!confirm('Generate ALT tags with AI Vision for '+ids.length+' images?\n\nVision mode analyzes each image individually — this is slower but much more accurate.\nEstimated time: ~'+Math.ceil(ids.length*3/60)+' minute(s).'))return;
        var auto=$('#sseo-aaa').is(':checked');
        $('#sseo-aprog').show();$('#sseo-apl').html('');$('#sseo-apf').css('width','0%');
        var done=0,errors=0;
        function next(i){
            if(i>=ids.length){
                $('#sseo-apt').text('✅ Done! '+done+' generated, '+errors+' errors');
                $('#sseo-apf').css('width','100%');
                $('#sseo-apl').append('<div class="sseo-log-ok" style="font-weight:600;margin-top:8px">✅ Vision bulk complete! '+done+'/'+ids.length+(auto?' applied':'')+'</div>');
                load(pg);return;
            }
            $('#sseo-apt').text('👁️ Analyzing '+(i+1)+'/'+ids.length);
            $('#sseo-apf').css('width',((i+1)/ids.length*100)+'%');
            ajax('generate_alts',{image_ids:[ids[i]],use_vision:'true'},function(r){
                if(r.success&&r.data.results&&r.data.results[0]&&r.data.results[0].alts&&r.data.results[0].alts.length){
                    done++;var alt=r.data.results[0].alts[0].text;
                    var fname=r.data.results[0].filename||'#'+ids[i];
                    $('#sseo-apl').append('<div class="sseo-log-ok">👁️ '+esc(fname)+': "'+esc(trunc(alt,50))+'"</div>');
                    if(auto){ajax('apply_alt',{attachment_id:ids[i],alt_text:alt},function(){next(i+1)});}
                    else next(i+1);
                } else {
                    errors++;
                    $('#sseo-apl').append('<div class="sseo-log-err">✗ #'+ids[i]+': '+(r.data||'Error')+'</div>');
                    next(i+1);
                }
                $('#sseo-apl').scrollTop($('#sseo-apl')[0].scrollHeight);
            });
        }
        next(0);
    });

    // Bulk Fast — text-based batch
    $('#sseo-abulk-fast').on('click',function(){
        var ids=[];$('.sseo-acb:checked').each(function(){ids.push($(this).val())});
        if(!ids.length)return;
        if(!confirm('Generate ALT tags in Fast mode for '+ids.length+' images?\n\nFast mode uses filenames + page context (AI does NOT see the images).'))return;
        var auto=$('#sseo-aaa').is(':checked');
        $('#sseo-aprog').show();$('#sseo-apf').css('width','50%');$('#sseo-apt').text('⚡ Processing batch...');
        ajax('bulk_alts',{image_ids:ids,auto_apply:auto?'true':'false'},function(r){
            $('#sseo-apf').css('width','100%');
            if(r.success){
                $('#sseo-apt').text('✅ Done! '+r.data.results.length+' processed');
                var lh='';r.data.results.forEach(function(x){lh+='<div class="sseo-log-ok">⚡ '+esc(x.filename)+(x.alt_applied?' — "'+esc(trunc(x.alt_applied,40))+'"':'')+'</div>';});
                $('#sseo-apl').html(lh);load(pg);
            } else {$('#sseo-apt').text('Error');$('#sseo-apl').html('<div class="sseo-log-err">'+esc(r.data)+'</div>');}
        });
    });
}

// ─── IMAGE TITLES ────────

function initImgTitles($c) {
    $c.html(`
    <div style="background:#fef3c7;border:1px solid #f59e0b;border-radius:10px;padding:14px 18px;margin-bottom:16px;font-size:13px;color:#92400e">
        <strong>📛 Why this matters:</strong> Images with titles like IMG_4521 or DSC_0034 hurt your SEO. Search engines use image titles for context. This tool finds all generic titles and renames them with AI-generated descriptive titles.
    </div>
    <div class="sseo-toolbar">
        <button class="sseo-btn-primary" id="it-scan">Scan for Generic Titles</button>
        <div class="sseo-toolbar-right">
            <label class="sseo-cb-label"><input type="checkbox" id="it-brand" checked> Append brand name to titles</label>
            <button class="sseo-btn" id="it-select-all">Select All</button>
            <button class="sseo-btn-primary" id="it-bulk-ai" disabled>🤖 AI Generate Titles</button>
            <button class="sseo-btn" id="it-bulk-auto" disabled style="background:#f59e0b;color:#fff;border-color:#f59e0b">⚡ Quick Auto-Title (from ALT text)</button>
        </div>
    </div>
    <div id="it-stats" style="display:none;margin-bottom:12px"></div>
    <div class="sseo-card">
        <table class="sseo-table">
            <thead><tr><th class="sseo-check-col"><input type="checkbox" id="it-ca"></th><th>Thumb</th><th>Current Title</th><th>ALT Text</th><th>Used On</th><th>New Title</th><th>Action</th></tr></thead>
            <tbody id="it-tbody"><tr><td colspan="7" class="sseo-loading">Click Scan...</td></tr>
        </table>
    </div>
    <div class="sseo-modal" id="it-modal" style="display:none">
        <div class="sseo-modal-content">
            <div class="sseo-modal-header"><h3 id="it-mt">AI Title Suggestions</h3><button class="sseo-modal-close" id="it-mc">&times;</button></div>
            <div class="sseo-modal-body" id="it-mb"></div>
        </div>
    </div>
    <div class="sseo-progress-wrap" id="it-progress" style="display:none">
        <div class="sseo-progress-header"><h3>Processing...</h3><span id="it-pt"></span></div>
        <div class="sseo-progress-bar"><div class="sseo-progress-fill" id="it-pf"></div></div>
        <div class="sseo-progress-log" id="it-pl"></div>
    </div>
    <div id="sseo-it-changes" style="margin-top:16px"></div>`);

    // Load recent image title changes
    loadRecentChanges('sseo-it-changes', 'img_title', 'Image Title');

    var scanData = [];

    // Scan
    $('#it-scan').on('click', function(){
        var $b=$(this);$b.text('Scanning...').prop('disabled',true);
        ajax('imgtitle_scan',{},function(r){
            $b.text('Scan for Generic Titles').prop('disabled',false);
            if(!r.success){alert(r.data);return}
            scanData = r.data.images;
            $('#it-stats').html('<span style="color:'+(r.data.total?'#dc2626':'#16a34a')+'"><strong>'+r.data.total+'</strong> images with generic/unhelpful titles found</span>').show();

            var h='';
            if(!scanData.length){
                h='<tr><td colspan="7" class="sseo-loading">All images have proper titles! ✓</td></tr>';
            } else {
                scanData.forEach(function(img,i){
                    h+='<tr data-idx="'+i+'">';
                    h+='<td class="sseo-check-col"><input type="checkbox" class="it-cb" value="'+img.id+'"></td>';
                    h+='<td><img class="sseo-thumb" src="'+escA(img.thumbnail)+'" alt=""></td>';
                    h+='<td><code style="color:#dc2626;font-size:12px">'+esc(img.current_title)+'</code></td>';
                    h+='<td style="font-size:12px;color:#64748b">'+(img.alt?esc(trunc(img.alt,35)):'<span style="color:#999">—</span>')+'</td>';
                    h+='<td style="font-size:12px">'+(img.parent_title?esc(trunc(img.parent_title,25)):'—')+'</td>';
                    h+='<td class="it-new-cell" data-idx="'+i+'"><span class="sseo-muted">—</span></td>';
                    h+='<td><button class="sseo-btn it-gen-single" data-id="'+img.id+'" data-idx="'+i+'">👁️ AI</button></td>';
                    h+='</tr>';
                });
            }
            $('#it-tbody').html(h);
        });
    });

    // Checkboxes
    $('#it-ca').on('change',function(){$('.it-cb').prop('checked',this.checked);updIT()});
    $('#it-select-all').on('click',function(){$('.it-cb').prop('checked',true);updIT()});
    $(document).on('change','.it-cb',updIT);
    function updIT(){
        var n=$('.it-cb:checked').length;
        $('#it-bulk-ai').prop('disabled',!n).text(n?'🤖 AI Generate ('+n+')':'🤖 AI Generate Titles');
        $('#it-bulk-auto').prop('disabled',!n).text(n?'⚡ Quick Auto-Title ('+n+')':'⚡ Quick Auto-Title');
    }

    // Single AI Vision generate
    $(document).on('click','.it-gen-single',function(){
        var $b=$(this), id=$b.data('id'), idx=$b.data('idx');
        $b.text('👁️...').prop('disabled',true);
        ajax('imgtitle_generate',{attachment_id:id,append_brand:$('#it-brand').is(':checked')?'true':'false'},function(r){
            $b.text('👁️ AI').prop('disabled',false);
            if(!r.success){alert(r.data);return}
            var h='<p class="sseo-muted">Current: <code>'+esc(r.data.current_title)+'</code> · File: '+esc(r.data.filename)+'</p>';
            r.data.suggestions.forEach(function(s){
                h+='<div class="sseo-result-item" style="display:flex;justify-content:space-between;align-items:center">';
                h+='<span style="font-size:14px">'+esc(s.title)+'</span>';
                h+='<div><button class="button button-primary it-apply-single" data-id="'+id+'" data-title="'+escA(s.title)+'" data-idx="'+idx+'">Apply</button> <button class="button sseo-edit-btn it-edit-title" data-title="'+escA(s.title)+'" data-id="'+id+'" data-idx="'+idx+'">✏️</button></div>';
                h+='</div>';
            });
            h+='<div style="margin-top:12px;padding-top:12px;border-top:1px solid #e2e8f0"><div class="sseo-field"><label>Custom Title</label><div style="display:flex;gap:8px"><input class="sseo-input" id="it-custom-input" placeholder="Type your own title..." style="flex:1"><button class="button button-primary" id="it-apply-custom" data-id="'+id+'" data-idx="'+idx+'">Apply Custom</button></div></div></div>';
            $('#it-mb').html(h);
            $('#it-mt').text('Rename: '+esc(r.data.filename));
            $('#it-modal').show();
        });
    });

    // Apply from modal
    $(document).on('click','.it-apply-single',function(){
        var $b=$(this), id=$b.data('id'), title=$b.data('title'), idx=$b.data('idx');
        $b.prop('disabled',true).text('...');
        ajax('imgtitle_apply',{attachment_id:id,title:title},function(r){
            $b.text(r.success?'✓ Applied':'Error');
            if(r.success){
                $('.it-new-cell[data-idx="'+idx+'"]').html('<strong style="color:#16a34a">'+esc(title)+'</strong>');
                setTimeout(function(){$('#it-modal').hide()},500);
            }
        });
    });

    // Apply custom from modal
    $(document).on('click','#it-apply-custom',function(){
        var $b=$(this), id=$b.data('id'), idx=$b.data('idx'), title=$('#it-custom-input').val();
        if(!title){alert('Enter a title.');return}
        $b.prop('disabled',true).text('...');
        ajax('imgtitle_apply',{attachment_id:id,title:title},function(r){
            $b.text(r.success?'✓ Applied':'Error');
            if(r.success){
                $('.it-new-cell[data-idx="'+idx+'"]').html('<strong style="color:#16a34a">'+esc(title)+'</strong>');
                setTimeout(function(){$('#it-modal').hide()},500);
            }
        });
    });

    // Modal close
    $('#it-mc').on('click',function(){$('#it-modal').hide()});
    $('#it-modal').on('click',function(e){if(e.target===this)$(this).hide()});

    // Bulk AI Generate (batch, text-based)
    $('#it-bulk-ai').on('click',function(){
        var ids=[];$('.it-cb:checked').each(function(){ids.push($(this).val())});
        if(!ids.length)return;
        if(ids.length > 20){
            // Process in chunks
            if(!confirm('Generate AI titles for '+ids.length+' images? This will process in batches.'))return;
        }
        var $b=$(this);$b.text('Generating...').prop('disabled',true);
        $('#it-progress').show();$('#it-pl').html('');$('#it-pf').css('width','50%');$('#it-pt').text('Generating titles...');

        // Process in batches of 15
        var chunks=[]; for(var ci=0;ci<ids.length;ci+=20) chunks.push(ids.slice(ci,ci+20));
        var done=0,total=ids.length;
        function nextChunk(ci){
            if(ci>=chunks.length){
                $b.text('🤖 AI Generate Titles').prop('disabled',false);
                $('#it-pt').text('✅ Done! '+done+' titles generated');
                $('#it-pf').css('width','100%');
                return;
            }
            $('#it-pf').css('width',((ci+1)/chunks.length*100)+'%');
            ajax('imgtitle_generate_batch',{ids:chunks[ci],append_brand:$('#it-brand').is(':checked')?'true':'false'},function(r){
                if(r.success){
                    r.data.results.forEach(function(res){
                        done++;
                        // Find the row and fill in suggestion
                        scanData.forEach(function(img,idx){
                            if(img.id==res.attachment_id){
                                var $cell=$('.it-new-cell[data-idx="'+idx+'"]');
                                $cell.html('<input class="sseo-input it-new-title-input" data-id="'+res.attachment_id+'" data-idx="'+idx+'" value="'+escA(res.title)+'" style="font-size:12px;padding:4px 8px;width:100%"> <button class="sseo-btn it-apply-row" data-id="'+res.attachment_id+'" data-idx="'+idx+'" style="margin-top:4px">Apply</button>');
                            }
                        });
                        $('#it-pl').append('<div class="sseo-log-ok">✓ '+esc(res.filename)+' → '+esc(res.title)+'</div>');
                    });
                } else {
                    $('#it-pl').append('<div class="sseo-log-err">✗ Batch error: '+esc(r.data)+'</div>');
                }
                $('#it-pl').scrollTop($('#it-pl')[0].scrollHeight);
                nextChunk(ci+1);
            });
        }
        nextChunk(0);
    });

    // Apply from row
    $(document).on('click','.it-apply-row',function(){
        var $b=$(this), id=$b.data('id'), idx=$b.data('idx');
        var title = $b.closest('td').find('.it-new-title-input').val();
        if(!title)return;
        $b.prop('disabled',true).text('...');
        ajax('imgtitle_apply',{attachment_id:id,title:title},function(r){
            $b.text(r.success?'✓':'Err');
            if(r.success) $b.closest('td').find('.it-new-title-input').css('border-color','#16a34a');
        });
    });

    // Quick Auto-Title (from ALT text, no AI call)
    $('#it-bulk-auto').on('click',function(){
        var ids=[];$('.it-cb:checked').each(function(){ids.push($(this).val())});
        if(!ids.length)return;
        if(!confirm('Auto-title '+ids.length+' images from their ALT text'+(($('#it-brand').is(':checked'))?' + brand name':'')+'?\n\nImages without ALT text will be skipped.'))return;
        var $b=$(this);$b.text('Processing...').prop('disabled',true);
        ajax('imgtitle_bulk_auto',{ids:ids,append_brand:$('#it-brand').is(':checked')?'true':'false'},function(r){
            $b.text('⚡ Quick Auto-Title').prop('disabled',false);
            if(r.success){
                alert('Done! '+r.data.fixed+' of '+r.data.total+' images renamed.');
                $('#it-scan').click(); // Refresh
            } else alert(r.data);
        });
    });
}

// ─── TITLE OPTIMIZER ────────

function initTitles($c) {
    $c.html('<button class="sseo-btn-primary" id="sseo-tscan">Scan Title Issues</button> <button class="sseo-btn" id="sseo-tbulkfix" style="background:#16a34a;border-color:#16a34a;color:#fff">🔧 Bulk Fix All</button> <button class="sseo-btn" id="sseo-tautoignore" style="background:#7c3aed;border-color:#7c3aed;color:#fff">🚀 Auto-Ignore Non-Content</button> <span id="sseo-tbulk-msg" style="font-size:13px"></span><div class="sseo-card" style="margin-top:16px"><table class="sseo-table"><thead><tr><th>Title</th><th>Chars</th><th>Issue</th><th>Type</th><th>Action</th></tr></thead><tbody id="sseo-ttb"><tr><td colspan="5" class="sseo-loading">Click Scan to check...</td></tr></tbody></table></div><div class="sseo-modal" id="sseo-tm" style="display:none"><div class="sseo-modal-content"><div class="sseo-modal-header"><h3 id="sseo-tmt">AI Title Suggestions</h3><button class="sseo-modal-close" id="sseo-tmc">&times;</button></div><div class="sseo-modal-body" id="sseo-tmb"></div></div></div>');
    $('#sseo-tbulkfix').on('click',function(){if(!confirm('Bulk fix all titles without AI?\n\nToo long: truncated. Too short: post title + brand.\n\nProceed?'))return;var $b=$(this);$b.text('Fixing...').prop('disabled',true);ajax('bulk_fix_titles',{},function(r){$b.text('🔧 Bulk Fix All').prop('disabled',false);if(r.success){$('#sseo-tbulk-msg').html('<span style="color:#16a34a">Fixed '+r.data.fixed+'/'+r.data.total+'</span>');$('#sseo-tscan').click();}});});
    $('#sseo-tautoignore').on('click',function(){if(!confirm('Auto-ignore gallery, award, and utility pages from all scanners?'))return;var $b=$(this);$b.text('...').prop('disabled',true);ajax('bulk_auto_ignore',{},function(r){$b.text('🚀 Auto-Ignore Non-Content').prop('disabled',false);if(r.success){$('#sseo-tbulk-msg').html('<span style="color:#16a34a">Ignored '+r.data.count+' pages</span>');$('#sseo-tscan').click();}});});
    $('#sseo-tscan').on('click',function(){$('#sseo-ttb').html('<tr><td colspan="5" class="sseo-loading">Scanning...</td></tr>');ajax('scan_titles',{},function(r){if(!r.success)return;var d=r.data,h='';if(!d.length){h='<tr><td colspan="5" class="sseo-loading">All titles look good! ✓</td></tr>';}else d.forEach(function(t){var ic=t.issue==='too_long'?'sseo-tag red':t.issue==='too_short'?'sseo-tag orange':'sseo-tag red';h+='<tr><td><a href="'+t.permalink+'" target="_blank">'+esc(trunc(t.title,50))+'</a></td><td><span class="'+charCls(t.char_count,30,60)+'">'+t.char_count+'</span></td><td><span class="'+ic+'">'+t.issue.replace('_',' ').toUpperCase()+'</span></td><td>'+t.post_type+'</td><td><button class="sseo-btn sseo-opt-title" data-id="'+t.post_id+'">Optimize</button></td></tr>';});$('#sseo-ttb').html(h);});});
    $(document).on('click','.sseo-opt-title',function(){var $b=$(this),id=$b.data('id');$b.addClass('generating').text('...');ajax('optimize_title',{post_id:id},function(r){$b.removeClass('generating').text('Optimize');if(!r.success){alert(r.data);return}var h='<p style="color:#646970">Current: <strong>'+esc(r.data.current)+'</strong> ('+r.data.current.length+' chars)</p>';r.data.titles.forEach(function(t,i){var cc=t.charCount||t.title.length;h+='<div class="sseo-result-item"><div class="sseo-result-top"><span class="sseo-approach-tag">'+(t.approach||'Option '+(i+1))+'</span><span class="sseo-charcount '+charCls(cc,50,60)+'">'+cc+' chars</span></div><p class="sseo-result-text sseo-editable-text">'+esc(t.title)+'</p><textarea class="sseo-edit-area" style="display:none;width:100%;padding:10px;border:2px solid #6366f1;border-radius:6px;font-size:14px;margin-bottom:8px">'+escA(t.title)+'</textarea><div class="sseo-result-actions"><button class="button button-primary sseo-apply-title" data-pid="'+r.data.post_id+'" data-title="'+escA(t.title)+'">Apply</button><button class="button sseo-edit-btn">✏️ Edit</button><button class="button sseo-cancel-edit" style="display:none">Cancel</button><button class="button sseo-copy" data-text="'+escA(t.title)+'">Copy</button></div></div>';});$('#sseo-tmb').html(h);$('#sseo-tm').show();});});
    $('#sseo-tmc').on('click',function(){$('#sseo-tm').hide()});
    $(document).on('click','.sseo-apply-title',function(){var $b=$(this),$item=$b.closest('.sseo-result-item');var $area=$item.find('.sseo-edit-area');var title=$area.is(':visible')?$area.val():$b.data('title');$b.prop('disabled',true).text('...');ajax('apply_title',{post_id:$b.data('pid'),title:title},function(r){$b.text(r.success?'✓ Applied':'Error');if(r.success)setTimeout(function(){$('#sseo-tm').hide();$('#sseo-tscan').click()},600)});});
}

// ─── H1 CHECKER ────────

function initH1($c) {
    $c.html('<button class="sseo-btn-primary" id="sseo-h1scan">Scan H1 Issues</button> <button class="sseo-btn" id="sseo-h1bulkfix" style="background:#16a34a;border-color:#16a34a;color:#fff">🔧 Bulk Fix All</button> <span id="sseo-h1bulk-msg" style="font-size:13px"></span><div class="sseo-card" style="margin-top:16px"><table class="sseo-table"><thead><tr><th>Page</th><th>Issue</th><th>Current H1s</th><th>Type</th><th>Action</th></tr></thead><tbody id="sseo-h1tb"><tr><td colspan="5" class="sseo-loading">Click Scan to check...</td></tr></tbody></table></div><div class="sseo-modal" id="sseo-h1m" style="display:none"><div class="sseo-modal-content"><div class="sseo-modal-header"><h3>AI H1 Suggestions</h3><button class="sseo-modal-close" id="sseo-h1mc">&times;</button></div><div class="sseo-modal-body" id="sseo-h1mb"></div></div></div>');
    $('#sseo-h1bulkfix').on('click',function(){if(!confirm('Bulk fix all H1 issues without AI?\n\nMissing: inserts page title. Multiple: keeps first, converts rest to H2.\n\nProceed?'))return;var $b=$(this);$b.text('Fixing...').prop('disabled',true);ajax('bulk_fix_h1',{},function(r){$b.text('🔧 Bulk Fix All').prop('disabled',false);if(r.success){$('#sseo-h1bulk-msg').html('<span style="color:#16a34a">Fixed '+r.data.fixed+'/'+r.data.total+'</span>');$('#sseo-h1scan').click();}});});
    $('#sseo-h1scan').on('click',function(){$('#sseo-h1tb').html('<tr><td colspan="5" class="sseo-loading">Scanning...</td></tr>');ajax('scan_h1',{},function(r){if(!r.success)return;var d=r.data,h='';if(!d.length){h='<tr><td colspan="5" class="sseo-loading">All pages have proper H1 tags! ✓</td></tr>';}else d.forEach(function(x){h+='<tr><td><a href="'+x.permalink+'" target="_blank">'+esc(x.title)+'</a></td><td><span class="sseo-tag '+(x.issue==='missing'?'red':'orange')+'">'+x.issue.toUpperCase()+'</span></td><td>'+(x.h1_tags.length?esc(x.h1_tags.join(', ')):'—')+'</td><td>'+x.post_type+'</td><td><button class="sseo-btn sseo-sug-h1" data-id="'+x.post_id+'">Suggest</button> <button class="sseo-btn sseo-thin-ignore" data-id="'+x.post_id+'" style="font-size:11px;color:#94a3b8">👁</button></td></tr>';});$('#sseo-h1tb').html(h);});});
    $(document).on('click','.sseo-sug-h1',function(){var $b=$(this),id=$b.data('id');$b.addClass('generating').text('...');ajax('suggest_h1',{post_id:id},function(r){$b.removeClass('generating').text('Suggest');if(!r.success){alert(r.data);return}var h='<p style="color:#646970">Page: <strong>'+esc(r.data.post_title)+'</strong></p><p class="sseo-muted">Edit if needed, then click \u2713 Apply to inject the H1 directly into your page content.</p>';r.data.suggestions.forEach(function(s,i){var cc=s.charCount||s.h1.length;h+='<div class="sseo-result-item"><p class="sseo-result-text sseo-editable-text">'+esc(s.h1)+'</p><textarea class="sseo-edit-area" style="display:none;width:100%;padding:10px;border:2px solid #6366f1;border-radius:6px;font-size:14px;margin-bottom:8px">'+escA(s.h1)+'</textarea><div class="sseo-result-actions"><span class="sseo-charcount '+charCls(cc,40,70)+'">'+cc+' chars</span> <button class="button sseo-edit-btn">✏️ Edit</button> <button class="button sseo-cancel-edit" style="display:none">Cancel</button> <button class="button sseo-copy" data-text="'+escA(s.h1)+'">Copy</button> <button class="button button-primary sseo-apply-h1" data-id="'+r.data.post_id+'" data-h1="'+escA(s.h1)+'" style="background:#16a34a;border-color:#16a34a;color:#fff">\u2713 Apply to Page</button></div></div>';});$('#sseo-h1mb').html(h);$('#sseo-h1m').show();});});
    $('#sseo-h1mc').on('click',function(){$('#sseo-h1m').hide()});
    $(document).on('click','#tm-review-link',function(){var $b=$(this);$b.text('Loading...');ajax('get_review_link',{},function(r){if(!r.success){alert(r.data);$b.text('📋 Get Review Link');return}var d=r.data;var h='<div style="padding:16px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;margin:12px 0">';h+='<p style="margin:0 0 8px;font-weight:600;color:#166534">Google Review Links</p>';h+='<p style="margin:4px 0;font-size:13px"><strong>Direct URL:</strong> <input type="text" value="'+d.review_url+'" onclick="this.select();document.execCommand(\'copy\')" readonly style="width:70%;padding:4px 8px;border:1px solid #d1d5db;border-radius:4px;font-size:12px"></p>';h+='<p style="margin:4px 0;font-size:13px"><strong>Short URL:</strong> <input type="text" value="'+d.short_url+'" onclick="this.select();document.execCommand(\'copy\')" readonly style="width:70%;padding:4px 8px;border:1px solid #d1d5db;border-radius:4px;font-size:12px"></p>';h+='<p style="margin:8px 0 4px;font-size:13px"><strong>Button HTML:</strong></p><textarea readonly onclick="this.select();document.execCommand(\'copy\')" style="width:100%;height:50px;padding:6px;font-size:11px;border:1px solid #d1d5db;border-radius:4px">'+d.embed_html.replace(/</g,'&lt;').replace(/>/g,'&gt;')+'</textarea>';h+='<p style="margin:8px 0 0;font-size:13px"><strong>QR Code:</strong> <a href="'+d.qr_url+'" target="_blank">Download QR</a></p>';h+='</div>';$('#tm-biz-info').after(h);$b.text('✓ Links Ready');});});
    $(document).on('click','.sseo-apply-h1',function(){var $b=$(this),id=$b.data('id'),h1=$b.closest('.sseo-result-item').find('.sseo-edit-area').filter(':visible').val()||$b.data('h1');$b.text('Applying...').prop('disabled',true);ajax('apply_h1',{post_id:id,h1:h1},function(r){$b.prop('disabled',false);if(!r.success){alert(r.data);$b.text('\u2713 Apply to Page');return;}$b.text('\u2713 Applied!').css({background:'#059669'});setTimeout(function(){$('#sseo-h1m').hide();$('#sseo-h1scan').click();},1200);});});
}

// ─── BROKEN LINKS ────────

function initBroken($c) {
    $c.html('<div class="sseo-notice sseo-notice-ok" style="display:none" id="sseo-bn"></div><button class="sseo-btn-primary" id="sseo-bscan">Scan Internal Links</button><p class="sseo-muted" style="margin:8px 0">This may take a minute for large sites.</p><div class="sseo-card" style="margin-top:16px"><table class="sseo-table"><thead><tr><th>Source Page</th><th>Broken URL</th><th>HTTP</th><th>Action</th></tr></thead><tbody id="sseo-btb"><tr><td colspan="4" class="sseo-loading">Click Scan to check...</td></tr></tbody></table></div>');
    $('#sseo-bscan').on('click',function(){$('#sseo-btb').html('<tr><td colspan="4" class="sseo-loading">Scanning links (this may take a minute)...</td></tr>');ajax('scan_broken',{},function(r){if(!r.success)return;var d=r.data,h='';if(!d.length){h='<tr><td colspan="4" class="sseo-loading">No broken internal links found! ✓</td></tr>';$('#sseo-bn').addClass('sseo-notice-ok').html('✓ No broken links found.').show();}else{$('#sseo-bn').addClass('sseo-notice-err').html('Found '+d.length+' broken internal links.').show();d.forEach(function(x){h+='<tr><td><a href="'+x.source_url+'" target="_blank">'+esc(x.source_title)+'</a></td><td><code>'+esc(x.broken_url)+'</code></td><td><span class="sseo-tag red">'+(x.http_code||'Err')+'</span></td><td><a href="'+sseo.ajax_url.replace('admin-ajax.php','admin.php?page=sseo-redirects&source=')+encodeURIComponent(x.broken_url)+'" class="sseo-btn">Create Redirect</a></td></tr>';});}$('#sseo-btb').html(h);});});
}

// ─── THIN CONTENT ────────

function initThin($c) {
    $c.html(`
    <button class="sseo-btn-primary" id="sseo-thscan">Scan Content</button>
    <button class="sseo-btn" id="sseo-thin-autoignore" style="background:#7c3aed;border-color:#7c3aed;color:#fff">🚀 Auto-Ignore Non-Content Pages</button>
    <span id="sseo-thin-msg" style="font-size:13px"></span>
    <div class="sseo-card" style="margin-top:16px">
        <table class="sseo-table">
            <thead><tr><th>Page</th><th>Words</th><th>Target</th><th>Text:HTML</th><th>Severity</th><th>Type</th><th>Action</th></tr></thead>
            <tbody id="sseo-thtb"><tr><td colspan="7" class="sseo-loading">Click Scan...</td></tr></tbody>
        </table>
    </div>
    <div class="sseo-modal" id="sseo-thin-modal" style="display:none">
        <div class="sseo-modal-content" style="max-width:800px">
            <div class="sseo-modal-header">
                <h3 id="sseo-thin-modal-title">AI Content Enhancement</h3>
                <button class="sseo-modal-close" id="sseo-thin-modal-close">&times;</button>
            </div>
            <div class="sseo-modal-body" id="sseo-thin-modal-body"></div>
        </div>
    </div>`);

    $('#sseo-thscan').on('click',function(){
        $('#sseo-thtb').html('<tr><td colspan="7" class="sseo-loading">Scanning...</td></tr>');
        ajax('scan_thin',{},function(r){
            if(!r.success)return;
            var pages=r.data.pages, h='';
            if(!pages.length){
                h='<tr><td colspan="7" class="sseo-loading">All pages have sufficient content! ✓</td></tr>';
            } else {
                pages.forEach(function(p){
                    h+='<tr>';
                    h+='<td><a href="'+p.permalink+'" target="_blank">'+esc(trunc(p.title,35))+'</a></td>';
                    h+='<td><strong>'+p.word_count+'</strong></td>';
                    h+='<td>'+p.target+'</td>';
                    h+='<td>'+p.ratio+'%</td>';
                    h+='<td><span class="sseo-sev-'+p.severity+'">'+p.severity.toUpperCase()+'</span></td>';
                    h+='<td>'+p.post_type+'</td>';
                    var isWWD = p.permalink && (p.permalink.indexOf('/what-we-do/') !== -1 || p.permalink.indexOf('/services/') !== -1);
                    h+='<td><button class="sseo-btn sseo-enhance-btn" data-id="'+p.post_id+'" data-title="'+escA(p.title)+'" data-wc="'+p.word_count+'" data-target="'+p.target+'">✨ Enhance</button> <button class="sseo-btn sseo-expand-btn" data-id="'+p.post_id+'" data-title="'+escA(p.title)+'" data-wc="'+p.word_count+'" data-target="'+p.target+'" data-archive="'+(p.is_archive?'1':'0')+'" style="background:#7c3aed;border-color:#7c3aed;color:#fff">📥 Expand</button>';
                    if(isWWD){h+=' <button class="sseo-btn sseo-gallery-btn" data-id="'+p.post_id+'" data-title="'+escA(p.title)+'" data-url="'+escA(p.permalink)+'" style="background:#d97706;border-color:#d97706;color:#fff">🖼️ Gallery</button>';}
                    h+=' <button class="sseo-btn sseo-thin-ignore" data-id="'+p.post_id+'" style="font-size:11px;color:#94a3b8">👁</button>';
                    h+='</td>';
                    h+='</tr>';
                });
            }
            $('#sseo-thtb').html(h);
        });
    });

    $('#sseo-thin-autoignore').on('click',function(){
        if(!confirm('Auto-ignore gallery, award/press, donation, and utility pages from all scanners?'))return;
        var $b=$(this);$b.text('Scanning...').prop('disabled',true);
        ajax('bulk_auto_ignore',{},function(r){
            $b.text('🚀 Auto-Ignore Non-Content Pages').prop('disabled',false);
            if(r.success){
                $('#sseo-thin-msg').html('<span style="color:#16a34a">Ignored '+r.data.count+' pages. Refresh to update score.</span>');
                $('#sseo-thscan').click();
            }
        });
    });

    // Enhance button — opens modal with options
    $(document).on('click','.sseo-enhance-btn',function(){
        var id=$(this).data('id'), title=$(this).data('title'), wc=$(this).data('wc'), target=$(this).data('target');
        var h='';
        h+='<div style="background:#f8fafc;padding:12px;border-radius:8px;margin-bottom:16px">';
        h+='<strong>'+esc(title)+'</strong><br>';
        h+='<span style="color:#64748b;font-size:13px">Current: '+wc+' words · Target: '+target+'+ words</span>';
        h+='</div>';
        h+='<div class="sseo-field"><label>Page Template</label>';
        h+='<div style="display:flex;gap:8px;align-items:flex-start"><select class="sseo-select-full" id="thin-template" style="flex:1">';
        h+='<option value="">No template (free-form enhance)</option>';
        h+='<option value="service_page">🔧 Service Page ✦</option>';
        h+='<option value="about_us">🏢 About Us ✦</option>';
        h+='<option value="faq_page">❓ FAQ Page ✦</option>';
        h+='<option value="landing_page">🎯 Landing Page ✦</option>';
        h+='<option value="blog_post">📝 Blog Post ✦</option>';
        h+='<option value="service_area">📍 Service Area</option>';
        h+='<option value="testimonials">⭐ Testimonials</option>';
        h+='<option value="gallery">🖼️ Portfolio</option>';
        h+='<option value="pricing">💰 Pricing</option><option value="privacy_policy">🔒 Privacy Policy</option><option value="terms_of_service">📜 Terms of Service</option>';
        h+='</select><button class="sseo-btn thin-browse-tpl" style="font-size:11px;white-space:nowrap">👁️ Browse</button></div></div>';
        h+='<div id="thin-tpl-gallery" style="display:none;margin-bottom:12px;border:1px solid #e2e8f0;border-radius:10px;padding:12px;background:#f8fafc"><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px" id="thin-tpl-cards"></div></div>';
        h+='<div class="sseo-field"><label>Content Scope</label>';
        h+='<select class="sseo-select-full" id="thin-scope">';
        h+='<option value="local">📍 Local (geo-keywords, NAP, service areas)</option>';
        h+='<option value="national">🌐 National (no location specifics)</option>';
        h+='</select></div>';
        h+='<div class="sseo-field"><label>Target Word Count</label>';
        h+='<div style="display:flex;gap:8px"><select class="sseo-select-full" id="thin-target-wc" style="flex:1"><option value="500">500</option><option value="800">800</option><option value="1000">1,000</option><option value="1200" selected>1,200</option><option value="1500">1,500</option><option value="2000">2,000</option><option value="2500">2,500</option><option value="custom">Custom...</option></select><input type="number" class="sseo-input" id="thin-wc-custom" min="300" max="5000" placeholder="e.g. 1750" style="width:120px;display:none"></div></div>';
        h+='<div class="sseo-field"><label style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="thin-internal-links" checked> Auto-insert internal links to related pages</label></div>';
        h+='<div class="sseo-field"><label style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="thin-add-testimonials"> Insert testimonials widget</label></div>';
        h+='<div class="sseo-field"><label style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="thin-add-service-schema"> Add Service schema to this page</label></div>';
        h+='<div class="sseo-field"><label style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="thin-add-local-schema"> Add LocalBusiness schema to this page</label></div>';
        h+='<div id="thin-testimonials-opts" style="display:none;padding:10px;background:#f8fafc;border-radius:8px;margin-bottom:8px">';
        h+='<div class="sseo-row"><div class="sseo-half sseo-field"><label style="font-size:12px">Widget Style</label><select class="sseo-select-full" id="thin-tm-style"><option value="cards">📇 Cards</option><option value="slider">🎠 Slider</option><option value="minimal">📝 Minimal</option></select></div>';
        h+='<div class="sseo-half sseo-field"><label style="font-size:12px">Show Count</label><select class="sseo-select-full" id="thin-tm-count"><option value="3" selected>3</option><option value="4">4</option><option value="6">6</option></select></div></div></div>';
        h+='<div class="sseo-field"><label>Target Keywords (optional)</label>';
        h+='<input class="sseo-input" id="thin-keywords" placeholder="e.g., kitchen remodeling maryland, licensed contractor"></div>';
        h+='<div class="sseo-field"><label>Custom Instructions / Prompt (optional)</label>';
        h+='<textarea class="sseo-textarea" id="thin-prompt" style="min-height:80px" placeholder="e.g., Add a FAQ section, mention our 20 years of experience..."></textarea></div>';
        h+=buildModelPicker('thin');
        h+='<div style="display:flex;gap:8px"><button class="sseo-btn" id="thin-preview-tmpl" style="flex:0 0 auto">👁️ Preview Template</button><button class="sseo-btn-primary" id="thin-do-enhance" data-id="'+id+'" style="flex:1;padding:12px">✨ Enhance Content with AI</button></div>';
        h+='<div id="thin-tmpl-preview" style="display:none;margin-top:12px;border:1px solid #e2e8f0;border-radius:8px;padding:16px;background:#f8fafc;max-height:300px;overflow-y:auto;font-size:12px;line-height:1.6;color:#475569"></div>';
        h+='<div id="thin-enhance-progress" style="display:none;margin-top:16px"><div class="sseo-progress-bar"><div class="sseo-progress-fill" style="width:60%"></div></div><p class="sseo-muted" style="text-align:center">AI is writing your page...</p></div>';
        h+='<div id="thin-enhance-result" style="display:none;margin-top:16px"></div>';

        $('#sseo-thin-modal-title').text('Enhance: '+trunc(title,40));
        $('#sseo-thin-modal-body').html(h);
        $('#sseo-thin-modal').show();
    });

    // Custom word count toggle (thin)
    $(document).on('change','#thin-target-wc',function(){
        $('#thin-wc-custom').toggle($(this).val()==='custom');
    });
    // Testimonials toggle
    $(document).on('change','#thin-add-testimonials',function(){
        $('#thin-testimonials-opts').toggle($(this).is(':checked'));
    });

    // Thin template gallery
    $(document).on('click','.thin-browse-tpl',function(){
        var tplDesigns={service_page:{icon:'🔧',name:'Service Page',color:'#6366f1'},about_us:{icon:'🏢',name:'About Us',color:'#0ea5e9'},faq_page:{icon:'❓',name:'FAQ Page',color:'#8b5cf6'},landing_page:{icon:'🎯',name:'Landing Page',color:'#dc2626'},blog_post:{icon:'📝',name:'Blog Post',color:'#16a34a'}};
        var h='';
        for(var k in tplDesigns){var t=tplDesigns[k];h+='<div class="thin-tpl-card" data-tpl="'+k+'" style="cursor:pointer;border:2px solid #e2e8f0;border-radius:8px;overflow:hidden;transition:all .2s;text-align:center"><div style="background:'+t.color+';padding:12px;color:#fff"><div style="font-size:24px">'+t.icon+'</div></div><div style="padding:8px;font-size:12px;font-weight:600">'+t.name+'</div></div>';}
        $('#thin-tpl-cards').html(h);
        $('#thin-tpl-gallery').toggle();
    });
    $(document).on('click','.thin-tpl-card',function(){
        $('#thin-template').val($(this).data('tpl'));
        $('.thin-tpl-card').css('border-color','#e2e8f0');$(this).css('border-color','#6366f1');
        setTimeout(function(){$('#thin-tpl-gallery').hide()},400);
    });

    // Template preview (thin)
    $(document).on('click','#thin-preview-tmpl',function(){
        var tmpl=$('#thin-template').val();
        if(!tmpl){$('#thin-tmpl-preview').html('<p class="sseo-muted">Select a template first.</p>').show();return;}
        var previews={
            service_page:'<strong>🔧 Service Page Structure:</strong><br>H1: [Service] in [City]<br>→ Intro (150-200w)<br>→ H2: Why Choose Us — 4-5 benefits (200-300w)<br>→ H2: Our Process — numbered steps (200-300w)<br>→ H2: What\'s Included — checklist (150-200w)<br>→ H2: Cost Factors in [City] (150-200w)<br>→ H2: Recent Projects + images (150-200w)<br>→ H2: FAQ — 5-7 questions with ? (300-400w)<br>→ H2: Service Areas — city list (100-150w)<br>→ H2: CTA with phone (100-150w)',
            about_us:'<strong>🏢 About Us Structure:</strong><br>H1: About [Brand]<br>→ Intro (150w)<br>→ H2: Our Story (200-300w)<br>→ H2: Mission & Values (150-200w)<br>→ H2: What Sets Us Apart — 4-5 items (250-300w)<br>→ H2: Our Team (150-200w)<br>→ H2: Credentials (100-150w)<br>→ H2: Service Area (150-200w)<br>→ H2: Customer Testimonials (150w)<br>→ H2: Contact CTA (100w)',
            faq_page:'<strong>❓ FAQ Page Structure:</strong><br>H1: Frequently Asked Questions<br>→ Intro (100-150w)<br>→ H2: General Questions — 4-5 H3s ending with ? (400-500w)<br>→ H2: Pricing Questions — 3-4 H3s (300w)<br>→ H2: Process Questions — 3-4 H3s (300w)<br>→ H2: Service Area Questions — 2-3 H3s (200w)<br>→ H2: CTA (100w)<br><em>Auto-generates FAQPage schema</em>',
            service_area:'<strong>📍 Service Area Structure:</strong><br>H1: [Service] in [Target City]<br>→ Intro (150-200w)<br>→ H2: Services in [City] (250-300w)<br>→ H2: Why [City] Trusts Us (200-250w)<br>→ H2: Recent Projects + images (200w)<br>→ H2: Neighborhoods — 6-10 listed (200w)<br>→ H2: FAQ for [City] (300w)<br>→ H2: Local Resources (100-150w)<br>→ H2: CTA (100w)',
            landing_page:'<strong>🎯 Landing Page Structure:</strong><br>H1: Value proposition headline<br>→ Pain → Solution → Proof (150-200w)<br>→ H2: Benefits — 4-5 detailed (250-300w)<br>→ H2: How It Works — 3-4 steps (200w)<br>→ H2: Testimonials (200w)<br>→ H2: Why Choose Us (150-200w)<br>→ H2: FAQ (200-250w)<br>→ H2: Urgency CTA (150w)',
            blog_post:'<strong>📝 Blog Post Structure:</strong><br>H1: Keyword-rich headline<br>→ Hook intro (150-200w)<br>→ H2: Deep dive + H3s (300-400w)<br>→ H2: Supporting info (300-400w)<br>→ H2: Practical tips (250-300w)<br>→ H2: Case study (200-250w)<br>→ H2: Expert tips (150-200w)<br>→ H2: FAQ — 3-5 H3 questions (250-300w)<br>→ H2: Conclusion + CTA (100-150w)',
            testimonials:'<strong>⭐ Testimonials Structure:</strong><br>H1: What Our Customers Say<br>→ Intro with rating (100w)<br>→ 8-10 review blocks with H3, stars, blockquote, name/city<br>→ H2: Our Commitment (150w)<br>→ H2: CTA (100w)',
            gallery:'<strong>🖼️ Portfolio Structure:</strong><br>H1: Our Work<br>→ Intro (100-150w)<br>→ 6-8 projects: H3 + image placeholder + description (80-120w each)<br>→ H2: Start Your Project CTA (100w)',
            pricing:'<strong>💰 Pricing Structure:</strong><br>H1: Services & Pricing<br>→ Intro (100-150w)<br>→ H2: Service 1 — desc + list + CTA (200w)<br>→ H2: Service 2 (200w)<br>→ H2: Service 3 (200w)<br>→ H2: Price Factors (150-200w)<br>→ H2: Financing (100w)<br>→ H2: Free Estimate CTA (100w)',
            contact:'<strong>📞 Contact Structure:</strong><br>H1: Contact Us<br>→ Intro (100w)<br>→ H2: Get In Touch — full NAP (100w)<br>→ H2: Request Estimate — form placeholder (100w)<br>→ H2: Business Hours (50w)<br>→ H2: Service Area (150-200w)<br>→ H2: Visit Us — map placeholder (100w)<br>→ H2: FAQ (200w)'
        };
        $('#thin-tmpl-preview').html(previews[tmpl]||'Template preview not available.').show();
    });

    // Do enhancement
    $(document).on('click','#thin-do-enhance',function(){
        var $b=$(this), id=$b.data('id');
        if(!id){alert('Error: No post ID found.');return}
        var targetWc = $('#thin-target-wc').val();
        if(targetWc==='custom') targetWc = $('#thin-wc-custom').val()||'1200';
        var keywords = $('#thin-keywords').val();
        var prompt = $('#thin-prompt').val();
        var addLinks = $('#thin-internal-links').is(':checked');
        var tmpl = $('#thin-template').val()||'';
        var designed = ['service_page','about_us','faq_page','landing_page','blog_post'];
        var useEngine = tmpl && designed.indexOf(tmpl)!==-1;

        $b.prop('disabled',true).text('Enhancing...');
        $('#thin-enhance-progress').show();
        $('#thin-enhance-result').hide();

        if(useEngine){
            var pageTitle = ($('#sseo-thin-modal-title').text()||'').replace('Enhance: ','');
            ajax('tpl_engine_generate',{
                template:tmpl, topic:pageTitle+(keywords?' - '+keywords:''),
                keywords:keywords, scope:$('#thin-scope').val()||'local',
                word_count:targetWc, custom:prompt,
                override_provider:$('#mp-thin').val()||'',
                add_testimonials:$('#thin-add-testimonials').is(':checked')?'true':'false',
                service_schema:$('#thin-add-service-schema').is(':checked')?'true':'false',
                local_schema:$('#thin-add-local-schema').is(':checked')?'true':'false',
                tm_style:$('#thin-tm-style').val()||'cards',
                tm_count:$('#thin-tm-count').val()||'3'
            },function(r){
                $b.prop('disabled',false).text('✨ Enhance Content with AI');
                $('#thin-enhance-progress').hide();
                if(!r.success){$('#thin-enhance-result').html('<div class="sseo-notice sseo-notice-err">'+esc(r.data||'AI error')+'</div>').show();return}
                showEnhanceResult(id, r.data.html||r.data.content||'', '?', r.data.word_count||0, r.data.tokens||0, r.data.images_matched, r.data.images_remaining);
            });
        } else {
            ajax('content_enhance',{
                post_id:id, target_words:targetWc, keywords:keywords, custom_prompt:prompt,
                template:tmpl, scope:$('#thin-scope').val()||'local',
                add_internal_links:addLinks?'true':'false',
                add_testimonials:$('#thin-add-testimonials').is(':checked')?'true':'false',
                service_schema:$('#thin-add-service-schema').is(':checked')?'true':'false',
                local_schema:$('#thin-add-local-schema').is(':checked')?'true':'false',
                tm_style:$('#thin-tm-style').val()||'cards', tm_count:$('#thin-tm-count').val()||'3',
                override_provider:$('#mp-thin').val()||''
            },function(r){
                $b.prop('disabled',false).text('✨ Enhance Content with AI');
                $('#thin-enhance-progress').hide();
                if(!r.success){$('#thin-enhance-result').html('<div class="sseo-notice sseo-notice-err">'+esc(r.data||'AI error')+'</div>').show();return}
                showEnhanceResult(id, r.data.content||'', r.data.original_words||'?', r.data.new_words||0, r.data.tokens||0, r.data.images_matched, r.data.images_remaining);
            });
        }
    });

    function showEnhanceResult(postId, content, origWords, newWords, tokens, imgMatched, imgRemaining){
        if(!newWords) newWords = content.replace(/<[^>]+>/g,' ').split(/\s+/).filter(Boolean).length;
        var h='<div class="sseo-notice sseo-notice-ok">✓ Content expanded: '+origWords+' → '+newWords+' words ('+tokens+' tokens)'+(imgMatched?' · 🖼️ '+imgMatched+' images':'')+(imgRemaining?' · 📷 '+imgRemaining+' placeholders':'')+'</div>';
        h+='<div style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap">';
        h+='<button class="sseo-btn-primary thin-apply-content" data-id="'+postId+'">Apply to Post</button>';
        h+='<button class="sseo-btn thin-copy-content">Copy HTML</button>';
        h+='<button class="sseo-btn thin-view-toggle active" data-view="preview">👁️ Preview</button>';
        h+='<button class="sseo-btn thin-view-toggle" data-view="code">📄 Code</button>';
        h+='<button class="sseo-btn thin-versions" data-id="'+postId+'" style="margin-left:auto">🕐 Versions</button>';
        h+='</div>';
        h+='<div id="thin-versions-panel" style="display:none;margin-bottom:12px;border:1px solid #e2e8f0;border-radius:8px;overflow:hidden"></div>';
        h+='<div class="thin-preview-content" style="border:1px solid #e2e8f0;border-radius:8px;padding:24px;max-height:500px;overflow-y:auto;line-height:1.8;font-size:15px">'+content+'</div>';
        h+='<div class="thin-code-content" style="display:none;border:1px solid #e2e8f0;border-radius:8px;max-height:500px;overflow-y:auto"><pre style="padding:16px;margin:0;font-size:12px;white-space:pre-wrap;word-break:break-all;font-family:monospace;color:#475569">'+esc(content)+'</pre></div>';
        h+='<textarea class="thin-raw-content" style="display:none">'+escA(content)+'</textarea>';
        $('#thin-enhance-result').html(h).show();
    }

    // View toggle (preview/code)
    $(document).on('click','.thin-view-toggle',function(){
        var view=$(this).data('view');
        $('.thin-view-toggle').removeClass('active');$(this).addClass('active');
        if(view==='preview'){$('.thin-preview-content').show();$('.thin-code-content').hide();}
        else{$('.thin-preview-content').hide();$('.thin-code-content').show();}
    });

    // Version history
    $(document).on('click','.thin-versions',function(){
        var id=$(this).data('id');
        var $panel=$('#thin-versions-panel');
        if($panel.is(':visible')){$panel.hide();return}
        $panel.html('<div style="padding:12px;text-align:center;color:#64748b">Loading versions...</div>').show();
        ajax('content_versions',{post_id:id},function(r){
            if(!r.success||!r.data.versions.length){$panel.html('<div style="padding:16px;text-align:center;color:#94a3b8">No previous versions saved yet. Versions are saved each time you apply content.</div>');return}
            var h='<div style="padding:12px 16px;background:#f8fafc;border-bottom:1px solid #e2e8f0;font-size:13px;font-weight:600;color:#475569">🕐 Version History — Current: '+r.data.current_words+' words</div>';
            h+='<table style="width:100%;border-collapse:collapse;font-size:13px">';
            r.data.versions.forEach(function(v){
                h+='<tr style="border-bottom:1px solid #f1f5f9"><td style="padding:8px 16px"><strong>'+esc(v.label)+'</strong><br><span style="font-size:11px;color:#94a3b8">'+esc(v.date)+'</span></td><td style="padding:8px;color:#64748b">'+v.word_count+' words</td><td style="padding:8px;font-size:11px;color:#94a3b8;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(v.preview)+'</td><td style="padding:8px"><button class="sseo-btn thin-revert" data-id="'+id+'" data-ver="'+v.index+'" style="font-size:11px;color:#d97706">⏪ Revert</button></td></tr>';
            });
            h+='</table>';
            $panel.html(h);
        });
    });

    // Revert to version
    $(document).on('click','.thin-revert',function(){
        var id=$(this).data('id'), ver=$(this).data('ver');
        if(!confirm('Revert to this version? Current content will be saved as a new version.'))return;
        var $b=$(this);$b.text('Reverting...').prop('disabled',true);
        ajax('content_revert',{post_id:id,version_index:ver},function(r){
            $b.text('⏪ Revert').prop('disabled',false);
            if(r.success){
                alert('Reverted! Now '+r.data.reverted_words+' words. Reload the page to see updated content.');
                $('.thin-versions').trigger('click').trigger('click'); // Refresh panel
            } else alert(r.data);
        });
    });

    // Copy
    $(document).on('click','.thin-copy-content',function(){
        var html = $(this).closest('#thin-enhance-result').find('.thin-raw-content').val();
        navigator.clipboard.writeText(html);
        $(this).text('Copied!');setTimeout(()=>$(this).text('Copy HTML'),1200);
    });

    // Apply to post
    $(document).on('click','.thin-apply-content',function(){
        var $b=$(this), id=$b.data('id');
        var content = $b.closest('#thin-enhance-result').find('.thin-raw-content').val();
        $b.prop('disabled',true).text('Saving...');
        ajax('content_apply_enhanced',{post_id:id,content:content,service_schema:$('#thin-add-service-schema').is(':checked')?'true':'false',local_schema:$('#thin-add-local-schema').is(':checked')?'true':'false'},function(r){
            if(r.success){
                $b.text('✓ Applied!').css('background','#16a34a');
                setTimeout(function(){ $('#sseo-thin-modal').hide(); $('#sseo-thscan').click(); },800);
            } else {
                $b.prop('disabled',false).text('Apply to Post');
                alert(r.data);
            }
        });
    });

    // Modal close
    $('#sseo-thin-modal-close').on('click',function(){$('#sseo-thin-modal').hide()});
    $('#sseo-thin-modal').on('click',function(e){if(e.target===this)$(this).hide()});

    // ─── Expand In-Place ──────────────
    $(document).on('click','.sseo-expand-btn',function(){
        var id=$(this).data('id'), title=$(this).data('title'), wc=$(this).data('wc'), target=$(this).data('target'), isArchive=$(this).data('archive')==='1'||$(this).data('archive')===1;
        var h='';
        h+='<div style="background:#f5f3ff;padding:12px;border-radius:8px;margin-bottom:16px;border:1px solid #ddd6fe">';
        h+='<strong>📥 Expand In-Place: '+esc(title)+'</strong><br>';
        h+='<span style="color:#7c3aed;font-size:13px">Current: '+wc+' words</span>';
        if(isArchive){
            h+='<div style="margin-top:8px;padding:8px 12px;background:#fef3c7;border:1px solid #fcd34d;border-radius:6px;font-size:12px;color:#92400e">📌 <strong>Archive/Listing Page Detected</strong> — This is a blog or category listing page. Content will be inserted as a styled intro above the post listing. Recommended: Quick Intro mode with 150-250 words.</div>';
            h+='<div style="margin-top:6px"><button class="sseo-btn" id="expand-clear-intro" data-id="'+id+'" style="font-size:11px;color:#dc2626;border-color:#fca5a5">🗑 Clear Existing Intro</button></div>';
        } else {
            h+='<br><span style="color:#64748b;font-size:12px">Keeps your existing page design intact. Appends content below.</span>';
        }
        h+='</div>';

        h+='<div class="sseo-field"><label style="font-weight:600">Expansion Mode</label>';
        h+='<div style="display:flex;gap:8px;margin-top:6px">';
        h+='<label style="flex:1;cursor:pointer;padding:14px;border:2px solid #ddd6fe;border-radius:10px;text-align:center;transition:all .2s" id="expand-mode-intro-label"><input type="radio" name="expand-mode" value="intro" style="display:none" id="expand-mode-intro"> <div style="font-size:20px;margin-bottom:4px">📝</div><div style="font-weight:600;font-size:14px">Quick Intro</div><div style="font-size:11px;color:#64748b;margin-top:2px">Short styled paragraph<br>Perfect for archive/category pages</div></label>';
        h+='<label style="flex:1;cursor:pointer;padding:14px;border:2px solid #7c3aed;border-radius:10px;text-align:center;background:#f5f3ff;transition:all .2s" id="expand-mode-full-label"><input type="radio" name="expand-mode" value="full" style="display:none" id="expand-mode-full" checked> <div style="font-size:20px;margin-bottom:4px">📄</div><div style="font-weight:600;font-size:14px">Full Expansion</div><div style="font-size:11px;color:#64748b;margin-top:2px">Descriptions, process, FAQ,<br>photos, areas, CTA</div></label>';
        h+='</div></div>';

        h+='<div class="sseo-field"><label>Word Count <span id="expand-wc-display" style="color:#7c3aed;font-weight:600">'+target+'</span> words</label>';
        h+='<input type="range" id="expand-target" min="100" max="2000" value="'+target+'" step="50" style="width:100%;accent-color:#7c3aed">';
        h+='<div style="display:flex;justify-content:space-between;font-size:11px;color:#94a3b8"><span>100 (intro)</span><span>800 (standard)</span><span>2000 (comprehensive)</span></div></div>';

        h+='<div class="sseo-field"><label>Target Keywords (optional)</label><input type="text" class="sseo-input" id="expand-keywords" placeholder="e.g. basement remodeling Baltimore"></div>';
        h+='<div class="sseo-field"><label style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="expand-add-testimonials"> Insert testimonials widget</label></div>';
        h+='<div class="sseo-field"><label style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="expand-service-schema" checked> Add Service schema</label></div>';
        h+='<div class="sseo-field"><label style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="expand-links" checked> Auto-insert internal links</label></div>';
        h+='<button class="sseo-btn-primary" id="expand-go" data-id="'+id+'" data-archive="'+(isArchive?'1':'0')+'" style="background:#7c3aed;border-color:#7c3aed">📥 Generate Content</button>';
        h+='<div id="expand-result" style="margin-top:16px;display:none"></div>';
        $('#sseo-thin-modal-title').text('Expand In-Place');
        $('#sseo-thin-modal-body').html(h);
        $('#sseo-thin-modal').show();

        // Auto-select intro mode for archive pages
        if(isArchive){
            $('#expand-mode-intro').prop('checked',true).trigger('change');
        }

        // Mode toggle styling
        $('input[name="expand-mode"]').on('change',function(){
            var v=$(this).val();
            $('#expand-mode-intro-label').css({border:'2px solid #ddd6fe',background:'transparent'});
            $('#expand-mode-full-label').css({border:'2px solid #ddd6fe',background:'transparent'});
            if(v==='intro'){
                $('#expand-mode-intro-label').css({border:'2px solid #7c3aed',background:'#f5f3ff'});
                $('#expand-target').val(200);$('#expand-wc-display').text('200');
            } else {
                $('#expand-mode-full-label').css({border:'2px solid #7c3aed',background:'#f5f3ff'});
                $('#expand-target').val(target);$('#expand-wc-display').text(target);
            }
        });
        $('#expand-target').on('input',function(){$('#expand-wc-display').text($(this).val())});
    });

    $(document).on('click','#expand-go',function(){
        var $b=$(this), id=$b.data('id'), mode=$('input[name="expand-mode"]:checked').val()||'full';
        $b.text(mode==='intro'?'Generating intro...':'Generating content...').prop('disabled',true);
        ajax('content_expand',{
            post_id:id,
            target_words:$('#expand-target').val()||800,
            keywords:$('#expand-keywords').val()||'',
            mode:mode,
            add_internal_links:$('#expand-links').is(':checked')?'true':'false',
            add_testimonials:$('#expand-add-testimonials').is(':checked')?'true':'false',
            tm_style:'cards', tm_count:'3'
        },function(r){
            $b.text('📥 Generate Content').prop('disabled',false);
            if(!r.success){
                var msg = r.data || 'Generation failed';
                var help = '<div style="background:#fef2f2;border:1px solid #fca5a5;padding:12px;border-radius:8px;margin-top:12px">';
                help += '<div style="color:#dc2626;font-weight:600;margin-bottom:6px">⚠️ Generation Failed</div>';
                help += '<div style="color:#991b1b;font-size:13px;margin-bottom:8px">'+msg+'</div>';
                help += '<div style="color:#64748b;font-size:12px">Try: Adjust word count, switch between Intro/Full mode, or try again in a moment.</div>';
                help += '</div>';
                $('#expand-result').html(help).show();
                return;
            }
            var d=r.data;
            var modeLabel = d.mode==='intro'?'Intro':'Full Expansion';
            var rh='<div style="background:#f0fdf4;padding:10px;border-radius:6px;margin-bottom:12px;font-size:13px;color:#166534">';
            rh+='✅ '+modeLabel+': <strong>'+d.new_words+'</strong> new words (total: <strong>'+d.total_words+'</strong>) · Images: '+d.images_matched;
            rh+='</div>';
            rh+='<div style="max-height:400px;overflow-y:auto;border:1px solid #e2e8f0;border-radius:8px;padding:16px;background:#fff;font-size:14px;line-height:1.7">'+d.content+'</div>';
            rh+='<div style="display:flex;gap:8px;margin-top:12px">';
            rh+='<button class="sseo-btn-primary" id="expand-apply" data-id="'+id+'" data-archive="'+$b.data('archive')+'" style="background:#16a34a;border-color:#16a34a">✅ Apply to Page</button>';
            rh+='<button class="sseo-btn" id="expand-cancel">Cancel</button>';
            rh+='</div>';
            $('#expand-result').html(rh).show();
            $('#expand-result').data('content', d.content);
        });
    });

    $(document).on('click','#expand-apply',function(){
        var $b=$(this), id=$b.data('id'), content=$('#expand-result').data('content'), isArchive=$b.data('archive')==='1'||$b.data('archive')===1;
        $b.text('Applying...').prop('disabled',true);
        ajax('content_apply_expand',{
            post_id:id,
            content:content,
            is_archive:isArchive?'true':'false',
            service_schema:$('#expand-service-schema').is(':checked')?'true':'false'
        },function(r){
            if(r.success){
                $b.text('✅ Applied!');
                setTimeout(function(){ $('#sseo-thin-modal').hide(); $('#sseo-thscan').click(); },800);
            } else {
                $b.text('✅ Apply to Page').prop('disabled',false);
                alert(r.data);
            }
        });
    });

    $(document).on('click','#expand-cancel',function(){
        $('#expand-result').hide();
    });

    $(document).on('click','#expand-clear-intro',function(){
        var $b=$(this), id=$b.data('id');
        if(!confirm('Remove the archive intro from this page?')) return;
        $b.text('Clearing...').prop('disabled',true);
        ajax('clear_archive_intro',{post_id:id},function(r){
            if(r.success){
                $b.text('✅ Cleared!').css('color','#16a34a');
                setTimeout(function(){$('#sseo-thin-modal').hide()},600);
            } else {
                $b.text('🗑 Clear Existing Intro').prop('disabled',false);
                alert(r.data);
            }
        });
    });

    // ─── Gallery Showcase for /what-we-do/ pages ──────────────
    $(document).on('click','.sseo-gallery-btn',function(){
        var $btn=$(this), id=$btn.data('id'), title=$btn.data('title'), url=$btn.data('url');
        $btn.text('Detecting...').prop('disabled',true);
        ajax('find_matching_service',{post_id:id},function(r){
            $btn.text('🖼️ Gallery').prop('disabled',false);
            var serviceUrl = (r.success && r.data.service_url) ? r.data.service_url : '/services/';
            var h='';
            h+='<div style="background:#fffbeb;padding:12px;border-radius:8px;margin-bottom:16px;border:1px solid #fde68a">';
            h+='<strong>🖼️ Gallery Showcase: '+esc(title)+'</strong><br>';
            h+='<span style="color:#92400e;font-size:13px">'+esc(url)+'</span><br>';
            h+='<span style="color:#78716c;font-size:12px">Generates a visual showcase page with project photos from your media library, before/after, stats, and testimonials. Links to the detailed /services/ page.</span>';
            h+='</div>';
            h+='<div class="sseo-field"><label>Service URL (auto-detected)</label><input class="sseo-input" id="gallery-service-url" value="'+escA(serviceUrl)+'">';
            if(r.success && r.data.score > 3){h+='<div style="font-size:11px;color:#16a34a;margin-top:4px">✅ Auto-matched to '+esc(serviceUrl)+'</div>';}
            else{h+='<div style="font-size:11px;color:#d97706;margin-top:4px">⚠️ Best guess — verify or update the URL</div>';}
            h+='</div>';
            h+='<div class="sseo-field"><label>Keywords (optional)</label><input class="sseo-input" id="gallery-keywords" placeholder="e.g. kitchen remodeling Baltimore"></div>';
            h+='<button class="sseo-btn-primary" id="gallery-generate" data-id="'+id+'" data-title="'+escA(title)+'" style="background:#d97706;border-color:#d97706">🖼️ Generate Gallery Page</button>';
            h+='<div id="gallery-result" style="margin-top:16px;display:none"></div>';
            $('#sseo-thin-modal-title').text('Gallery Showcase');
            $('#sseo-thin-modal-body').html(h);
            $('#sseo-thin-modal').show();
        });
    });

    $(document).on('click','#gallery-generate',function(){
        var $b=$(this), id=$b.data('id'), title=$b.data('title');
        $b.text('Generating gallery...').prop('disabled',true);
        ajax('template_generate',{
            template:'what_we_do',
            topic:title,
            keywords:$('#gallery-keywords').val()||'',
            word_count:1200,
            custom_prompt:'service_url is '+($('#gallery-service-url').val()||'/services/')
        },function(r){
            $b.text('🖼️ Generate Gallery Page').prop('disabled',false);
            if(!r.success){
                $('#gallery-result').html('<div style="color:#dc2626;padding:10px">'+r.data+'</div>').show();
                return;
            }
            var d=r.data;
            var rh='<div style="background:#f0fdf4;padding:10px;border-radius:6px;margin-bottom:12px;font-size:13px;color:#166534">';
            rh+='✅ Gallery page generated! Preview below:';
            rh+='</div>';
            rh+='<div style="max-height:400px;overflow-y:auto;border:1px solid #e2e8f0;border-radius:8px;padding:16px;background:#fff;font-size:14px;line-height:1.7">'+d.html+'</div>';
            rh+='<div style="display:flex;gap:8px;margin-top:12px">';
            rh+='<button class="sseo-btn-primary" id="gallery-apply" data-id="'+id+'" style="background:#16a34a;border-color:#16a34a">✅ Apply to Page (Replace Content)</button>';
            rh+='<button class="sseo-btn" id="gallery-cancel">Cancel</button>';
            rh+='</div>';
            $('#gallery-result').html(rh).show();
            $('#gallery-result').data('html', d.html);
            $('#gallery-result').data('meta', d.meta||'');
            $('#gallery-result').data('title', d.title||title);
        });
    });

    $(document).on('click','#gallery-apply',function(){
        var $b=$(this), id=$b.data('id');
        var html=$('#gallery-result').data('html');
        var meta=$('#gallery-result').data('meta');
        $b.text('Applying...').prop('disabled',true);
        ajax('content_apply_enhanced',{
            post_id:id,
            content:html,
            service_schema:'true'
        },function(r){
            if(r.success){
                $b.text('✅ Applied!');
                setTimeout(function(){$('#sseo-thin-modal').hide();$('#sseo-thscan').click()},800);
            } else {
                $b.text('✅ Apply to Page').prop('disabled',false);
                alert(r.data);
            }
        });
    });

    $(document).on('click','#gallery-cancel',function(){$('#gallery-result').hide()});
}

// ─── REDIRECTS ────────

function initRedirects($c) {
    var src=new URLSearchParams(window.location.search).get('source')||'';
    $c.html('<div class="sseo-redir-form"><div class="sseo-field"><label>Source URL (from)</label><input type="text" class="sseo-input" id="sseo-rsrc" placeholder="/old-page/" value="'+esc(src)+'"></div><div class="sseo-field"><label>Target URL (to)</label><input type="text" class="sseo-input" id="sseo-rtgt" placeholder="/new-page/"></div><div class="sseo-field"><label>Type</label><select class="sseo-select" id="sseo-rtype"><option value="301">301 Permanent</option><option value="302">302 Temporary</option></select></div><button class="sseo-btn-primary" id="sseo-radd" style="align-self:end;padding:8px 20px">Add Redirect</button></div><div class="sseo-card"><table class="sseo-table"><thead><tr><th>Source</th><th>Target</th><th>Type</th><th>Hits</th><th>Created</th><th>Action</th></tr></thead><tbody id="sseo-rtb"><tr><td colspan="6" class="sseo-loading">Loading...</td></tr></tbody></table></div>');
    function load(){ajax('get_redirects',{},function(r){if(!r.success)return;var d=r.data,h='';if(!d.length){h='<tr><td colspan="6" class="sseo-loading">No redirects yet.</td></tr>';}else d.forEach(function(x){h+='<tr><td><code>'+esc(x.source_url)+'</code></td><td><code>'+esc(x.target_url)+'</code></td><td><span class="sseo-tag blue">'+x.type+'</span></td><td>'+x.hits+'</td><td>'+x.created_at+'</td><td><button class="sseo-btn sseo-rdel" data-id="'+x.id+'">Delete</button></td></tr>';});$('#sseo-rtb').html(h);});}
    load();
    $('#sseo-radd').on('click',function(){var s=$('#sseo-rsrc').val(),t=$('#sseo-rtgt').val();if(!s||!t){alert('Both fields required.');return}ajax('add_redirect',{source:s,target:t,type:$('#sseo-rtype').val()},function(r){if(r.success){$('#sseo-rsrc,#sseo-rtgt').val('');load()}else alert(r.data)});});
    $(document).on('click','.sseo-rdel',function(){if(!confirm('Delete this redirect?'))return;ajax('delete_redirect',{id:$(this).data('id')},function(){load()})});
}

// ─── SCHEMA & OG ────────

function initSchema($c) {
    $c.html(`
    <div class="sseo-card" style="margin-bottom:16px">
        <h3>Schema Markup (JSON-LD)</h3>
        <p class="sseo-muted">Auto-injects LocalBusiness + Service + Article + FAQ + BreadcrumbList schema across your site. Configure business details in Settings.</p>
        <label class="sseo-cb-label"><input type="checkbox" id="sseo-sch-on" checked> Enable Schema Markup</label><br><br>
        <h3>Open Graph & Twitter Cards</h3>
        <p class="sseo-muted">Auto-generates og: and twitter: meta tags. Skipped if Yoast/RankMath handles it.</p>
        <label class="sseo-cb-label"><input type="checkbox" id="sseo-og-on" checked> Enable Open Graph Tags</label><br><br>
        <div style="display:flex;gap:8px">
            <button class="sseo-btn-primary" id="sseo-schema-save">Save</button>
            <button class="sseo-btn" id="sseo-schema-validate">✅ Validate Schema Coverage</button>
            <button class="sseo-btn" id="sseo-schema-bulk" style="background:#7c3aed;border-color:#7c3aed;color:#fff">🚀 Apply Schema to All Pages</button>
            <button class="sseo-btn" id="sseo-cleanup-published" style="background:#dc2626;border-color:#dc2626;color:#fff">🧹 Cleanup AI Artifacts</button>
        </div>
        <span id="sseo-schema-msg" style="margin-left:10px"></span>
        <div id="sseo-schema-bulk-result" style="display:none;margin-top:12px"></div>
        <div id="sseo-schema-validation" style="display:none;margin-top:16px"></div>
    </div>`);
    $('#sseo-schema-save').on('click',function(){ajax('save_schema',{schema_enabled:$('#sseo-sch-on').is(':checked')?1:0,og_enabled:$('#sseo-og-on').is(':checked')?1:0},function(r){$('#sseo-schema-msg').html(r.success?'<span style="color:#2e7d32">✓ Saved</span>':'Error')});});
    $('#sseo-schema-bulk').on('click',function(){
        var $b=$(this);$b.text('Scanning pages...').prop('disabled',true);
        ajax('schema_bulk_preview',{},function(r){
            $b.text('🚀 Apply Schema to All Pages').prop('disabled',false);
            if(!r.success){alert(r.data);return}
            var d=r.data, pages=d.pages;
            var h='<div style="padding:16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px">';
            h+='<h4 style="margin:0 0 8px;font-size:15px;color:#0f172a">Schema Preview — '+d.total_scanned+' pages scanned</h4>';
            h+='<div style="display:flex;gap:16px;margin-bottom:12px;font-size:13px">';
            h+='<span style="color:#16a34a">✅ Service: '+d.service_existing+' already applied</span>';
            h+='<span style="color:#2563eb">🆕 Service: '+d.service_new+' will be added</span>';
            h+='<span style="color:#16a34a">✅ LocalBusiness: '+d.local_existing+' already applied</span>';
            h+='<span style="color:#2563eb">🆕 LocalBusiness: '+d.local_new+' will be added</span>';
            h+='</div>';
            h+='<div style="margin-bottom:10px;font-size:13px;color:#7c3aed">🔗 BreadcrumbList: '+d.breadcrumb+'</div>';
            h+='<div style="max-height:350px;overflow-y:auto;border:1px solid #e2e8f0;border-radius:6px">';
            h+='<table class="sseo-table" style="margin:0;font-size:13px"><thead><tr><th>Page</th><th>URL</th><th>Type</th><th>Current Schema</th><th>Will Be Added</th></tr></thead><tbody>';
            if(!pages.length){
                h+='<tr><td colspan="5" style="text-align:center;padding:20px;color:#64748b">No pages need schema changes — everything is already configured!</td></tr>';
            } else {
                pages.forEach(function(p){
                    var existingHtml = p.existing.length ? p.existing.map(function(s){return '<span style="display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;background:#dcfce7;color:#166534;margin:1px 2px">✅ '+s+'</span>'}).join('') : '<span style="color:#94a3b8;font-size:11px">None</span>';
                    var newHtml = p.new.length ? p.new.map(function(s){return '<span style="display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;background:#dbeafe;color:#1d4ed8;margin:1px 2px;font-weight:600">🆕 '+s+'</span>'}).join('') : '<span style="color:#94a3b8;font-size:11px">—</span>';
                    h+='<tr>';
                    h+='<td style="font-weight:500">'+esc(p.title)+'</td>';
                    h+='<td style="font-size:11px;color:#64748b;font-family:monospace">'+esc(p.url)+'</td>';
                    h+='<td><span style="font-size:11px;color:#64748b">'+p.post_type+'</span></td>';
                    h+='<td>'+existingHtml+'</td>';
                    h+='<td>'+newHtml+'</td>';
                    h+='</tr>';
                });
            }
            h+='</tbody></table></div>';
            if(d.service_new > 0 || d.local_new > 0){
                h+='<div style="display:flex;gap:8px;margin-top:12px">';
                h+='<button class="sseo-btn-primary" id="sseo-schema-confirm" style="background:#16a34a;border-color:#16a34a">✅ Confirm & Apply All Schema</button>';
                h+='<button class="sseo-btn" id="sseo-schema-cancel">Cancel</button>';
                h+='</div>';
            } else {
                h+='<div style="margin-top:12px;padding:10px;background:#f0fdf4;border-radius:6px;color:#166534;font-size:13px">✅ All schema already applied — nothing to change!</div>';
            }
            h+='</div>';
            $('#sseo-schema-bulk-result').html(h).show();
        });
    });

    $(document).on('click','#sseo-schema-confirm',function(){
        var $b=$(this);$b.text('Applying...').prop('disabled',true);
        ajax('schema_bulk_apply',{},function(r){
            if(!r.success){alert(r.data);$b.text('✅ Confirm & Apply All Schema').prop('disabled',false);return}
            var d=r.data;
            var h='<div style="padding:16px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px">';
            h+='<p style="margin:0 0 8px;font-weight:700;color:#166534;font-size:15px">✅ Schema Applied Successfully!</p>';
            h+='<p style="margin:4px 0;font-size:13px;color:#15803d">Service schema added to <strong>'+d.service_pages_tagged+'</strong> service pages</p>';
            h+='<p style="margin:4px 0;font-size:13px;color:#15803d">LocalBusiness schema added to <strong>'+d.local_pages_tagged+'</strong> pages</p>';
            h+='<p style="margin:4px 0;font-size:13px;color:#15803d">BreadcrumbList + Open Graph enabled sitewide</p>';
            h+='<p style="margin:8px 0 0;font-size:12px;color:#64748b">Run ✅ Validate above to verify with Google Rich Results Test</p>';
            h+='</div>';
            $('#sseo-schema-bulk-result').html(h);
        });
    });

    $(document).on('click','#sseo-schema-cancel',function(){
        $('#sseo-schema-bulk-result').hide();
    });

    $('#sseo-cleanup-published').on('click',function(){
        if(!confirm('This will scan all published pages and remove:\\n- 📷 Image needed hint boxes\\n- <!-- IMAGE: --> template comments\\n- Empty paragraphs\\n\\nProceed?')) return;
        var $b=$(this);$b.text('Scanning...').prop('disabled',true);
        ajax('cleanup_published',{},function(r){
            $b.text('🧹 Cleanup AI Artifacts').prop('disabled',false);
            if(!r.success){alert(r.data);return}
            var d=r.data;
            var msg = d.cleaned > 0
                ? '<span style="color:#16a34a">✅ Cleaned '+d.cleaned+' pages ('+d.total_scanned+' scanned). AI template artifacts removed — pages are now clean for indexing.</span>'
                : '<span style="color:#16a34a">✅ All '+d.total_scanned+' pages are already clean — no artifacts found!</span>';
            $('#sseo-schema-msg').html(msg);
        });
    });
    $('#sseo-schema-validate').on('click',function(){
        var $b=$(this);$b.text('Checking...').prop('disabled',true);
        ajax('schema_validate',{},function(r){
            $b.text('✅ Validate Schema Coverage').prop('disabled',false);
            if(!r.success){alert(r.data);return}
            var d=r.data, h='<table class="sseo-table"><thead><tr><th>Schema Type</th><th>Status</th><th>Applied To</th><th>Fields</th></tr></thead><tbody>';
            ['local_business','service','breadcrumb','article','faq'].forEach(function(k){
                if(!d[k])return;
                var s=d[k], pass=s.status;
                h+='<tr><td><strong>'+esc(s.label)+'</strong></td>';
                h+='<td><span class="sseo-tag '+(pass?'green':'orange')+'">'+(pass?'ACTIVE':'INCOMPLETE')+'</span></td>';
                h+='<td style="font-size:12px">'+esc(s.pages)+'</td>';
                h+='<td style="font-size:12px">';
                if(s.fields){for(var f in s.fields){h+='<span style="margin-right:6px">'+(s.fields[f]?'✅':'❌')+' '+f+'</span>'}}
                else h+='—';
                h+='</td></tr>';
            });
            h+='</tbody></table>';
            h+='<a href="'+esc(d.google_test_url)+'" target="_blank" class="sseo-btn" style="margin-top:8px">🔍 Test in Google Rich Results</a>';
            h+=' <a href="'+sseo.ajax_url.replace('admin-ajax.php','admin.php?page=sseo-settings')+'" class="sseo-btn">⚙️ Edit Business Details</a>';
            $('#sseo-schema-validation').html(h).show();
        });
    });
}

// ─── LLMS.TXT ────────

function initLlms($c) {
    $c.html('<div class="sseo-card"><h3>llms.txt File</h3><p class="sseo-muted">This file helps AI models (ChatGPT, Claude, Gemini) understand your business. Served at <code>/llms.txt</code></p><button class="sseo-btn" id="sseo-llms-ai" style="margin-bottom:12px">✨ Generate with AI</button><div class="sseo-field"><label>llms.txt Content</label><textarea class="sseo-textarea" id="sseo-llms-txt" placeholder="# Your Business Name\n> Description..."></textarea></div><button class="sseo-btn-primary" id="sseo-llms-save">Save & Publish</button><span id="sseo-llms-msg" style="margin-left:10px"></span></div>');
    $('#sseo-llms-ai').on('click',function(){var $b=$(this);$b.text('Generating...').prop('disabled',true);ajax('generate_llms',{},function(r){$b.text('✨ Generate with AI').prop('disabled',false);if(r.success)$('#sseo-llms-txt').val(r.data);else alert(r.data)});});
    $('#sseo-llms-save').on('click',function(){ajax('save_llms',{content:$('#sseo-llms-txt').val()},function(r){$('#sseo-llms-msg').html(r.success?'<span style="color:#2e7d32">✓ Published</span>':'Error')});});
}

// ─── LOG ────────

function initLog($c) {
    $c.html('<div class="sseo-card"><table class="sseo-table"><thead><tr><th>Date</th><th>Post</th><th>Type</th><th>Old</th><th>New</th></tr></thead><tbody id="sseo-ltb"><tr><td colspan="5" class="sseo-loading">Loading...</td></tr></tbody></table></div>');
    ajax('get_log',{},function(r){if(!r.success||!r.data.length){$('#sseo-ltb').html('<tr><td colspan="5" class="sseo-loading">No activity yet.</td></tr>');return}var h='';r.data.forEach(function(e){h+='<tr><td style="white-space:nowrap">'+esc(e.date)+'</td><td>'+esc(e.post_title)+'</td><td><span class="sseo-approach-tag">'+e.type.toUpperCase()+'</span></td><td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#999">'+esc(e.old_value||'—')+'</td><td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(trunc(e.new_value,70))+'</td></tr>';});$('#sseo-ltb').html(h);});
}

// ─── SETTINGS ────────

function initSettings($c) {
    $c.html(`<div id="sseo-snot" style="display:none"></div>
    <div class="sseo-settings-grid">
        <div class="sseo-card" id="s-ai-card">
            <h3>🤖 AI Provider & Model</h3>
            <div id="s-ai-platform-banner" style="display:none;padding:12px 14px;border:1px solid #bbf7d0;background:#f0fdf4;border-radius:8px;margin-bottom:10px"><div style="font-weight:600;color:#166534">AI: Platform AI via <span id="s-ai-brand">your agency</span></div><div style="font-size:12px;color:#3f6b4a;margin-top:3px">This site runs AI through your agency — no API key needed here.</div></div>
            <div id="s-ai-advanced-toggle" style="display:none;margin-bottom:10px"><a href="#" id="s-ai-advanced-link" style="font-size:12px;color:#64748b;text-decoration:underline;cursor:pointer">Advanced — use your own AI key instead</a></div>
            <div id="s-ai-manual">
            <div class="sseo-field"><label>Provider</label><select class="sseo-select-full" id="s-prov">
                <optgroup label="Agency"><option value="platform">Platform AI (via your agency) — no key</option></optgroup>
                <optgroup label="Premium">
                    <option value="openai">OpenAI (GPT-4o, GPT-4.1)</option>
                    <option value="anthropic">Anthropic Claude (Sonnet 4, Opus 4)</option>
                    <option value="azure">Azure OpenAI</option>
                </optgroup>
                <optgroup label="Budget / Free">
                    <option value="deepseek">DeepSeek (Very Cheap)</option>
                    <option value="groq">Groq — Llama 3.3 (Free Tier)</option>
                    <option value="gemini">Google Gemini (Free Tier)</option>
                    <option value="openrouter">OpenRouter (Many Free Models)</option>
                </optgroup>
            </select></div>
            <div class="s-prov-fields" data-for="openai"><div class="sseo-field"><label>API Key</label><input type="password" class="sseo-input" id="s-okey" placeholder="sk-..."></div><div class="sseo-field"><label>Model</label><select class="sseo-select-full" id="s-omodel"><option value="gpt-4o-mini">gpt-4o-mini (cheap)</option><option value="gpt-4o">gpt-4o (best)</option><option value="gpt-4.1-mini">gpt-4.1-mini</option><option value="gpt-4.1">gpt-4.1</option><option value="gpt-4-turbo">gpt-4-turbo</option><option value="o4-mini">o4-mini (reasoning)</option></select></div></div>
            <div class="s-prov-fields" data-for="anthropic" style="display:none"><div class="sseo-field"><label>API Key</label><input type="password" class="sseo-input" id="s-akey" placeholder="sk-ant-..."></div><div class="sseo-field"><label>Model</label><select class="sseo-select-full" id="s-amodel"><option value="claude-sonnet-4-20250514">Claude Sonnet 4</option><option value="claude-opus-4-20250514">Claude Opus 4</option><option value="claude-haiku-4-5-20251001">Claude Haiku 4.5</option></select></div></div>
            <div class="s-prov-fields" data-for="azure" style="display:none"><div class="sseo-field"><label>API Key</label><input type="password" class="sseo-input" id="s-azkey" placeholder="32-char key from Azure Portal → Keys and Endpoint"></div><div class="sseo-field"><label>Endpoint URL</label><input class="sseo-input" id="s-azep" placeholder="https://your-resource.cognitiveservices.azure.com"><div style="font-size:11px;color:#94a3b8;margin-top:2px">Paste the full URL from Azure Portal — the plugin auto-cleans it. Works with .openai.azure.com or .cognitiveservices.azure.com</div></div><div class="sseo-field"><label>Deployment Name</label><input class="sseo-input" id="s-azdep" placeholder="my-gpt4o-deployment"><div style="font-size:11px;color:#94a3b8;margin-top:2px">The exact deployment name from Azure Portal → Model Deployments. Not the model name — the deployment name.</div></div><div class="sseo-field"><label>API Version</label><input class="sseo-input" id="s-azver" value="2025-04-01-preview"><div style="font-size:11px;color:#94a3b8;margin-top:2px">Use 2025-04-01-preview or later. Older versions may not support your model.</div></div></div>
            <div class="s-prov-fields" data-for="deepseek" style="display:none"><div class="sseo-field"><label>API Key</label><input type="password" class="sseo-input" id="s-dskey" placeholder="sk-..."></div><div class="sseo-field"><label>Model</label><select class="sseo-select-full" id="s-dsmodel"><option value="deepseek-chat">deepseek-chat (general)</option><option value="deepseek-reasoner">deepseek-reasoner (thinking)</option></select></div><div style="background:#dcfce7;padding:8px 12px;border-radius:6px;font-size:12px;color:#16a34a">💰 Very cheap — ~$0.07/million input tokens</div></div>
            <div class="s-prov-fields" data-for="groq" style="display:none"><div class="sseo-field"><label>API Key</label><input type="password" class="sseo-input" id="s-grkey" placeholder="gsk_..."></div><div class="sseo-field"><label>Model</label><select class="sseo-select-full" id="s-grmodel"><option value="llama-3.3-70b-versatile">Llama 3.3 70B (best free)</option><option value="llama-3.1-8b-instant">Llama 3.1 8B (fast)</option><option value="mixtral-8x7b-32768">Mixtral 8x7B</option><option value="gemma2-9b-it">Gemma 2 9B</option></select></div><div style="background:#dcfce7;padding:8px 12px;border-radius:6px;font-size:12px;color:#16a34a">🆓 Free tier: 6,000 req/day at blazing speed</div></div>
            <div class="s-prov-fields" data-for="gemini" style="display:none"><div class="sseo-field"><label>API Key</label><input type="password" class="sseo-input" id="s-gmkey" placeholder="AIza..."></div><div class="sseo-field"><label>Model</label><select class="sseo-select-full" id="s-gmmodel"><option value="gemini-2.0-flash">Gemini 2.0 Flash (free)</option><option value="gemini-2.0-flash-lite">Gemini 2.0 Flash Lite (free)</option><option value="gemini-1.5-flash">Gemini 1.5 Flash (free)</option><option value="gemini-1.5-pro">Gemini 1.5 Pro</option></select></div><div style="background:#dcfce7;padding:8px 12px;border-radius:6px;font-size:12px;color:#16a34a">🆓 Free tier: 1,500 req/day · Get key at <a href="https://aistudio.google.com/apikey" target="_blank">aistudio.google.com</a></div></div>
            <div class="s-prov-fields" data-for="openrouter" style="display:none"><div class="sseo-field"><label>API Key</label><input type="password" class="sseo-input" id="s-orkey" placeholder="sk-or-..."></div><div class="sseo-field"><label>Model</label><select class="sseo-select-full" id="s-ormodel"><optgroup label="Free Models"><option value="meta-llama/llama-3.3-70b-instruct:free">Llama 3.3 70B (FREE)</option><option value="qwen/qwen-2.5-72b-instruct:free">Qwen 2.5 72B (FREE)</option><option value="microsoft/phi-4:free">Microsoft Phi-4 (FREE)</option><option value="google/gemma-3-27b-it:free">Google Gemma 3 27B (FREE)</option></optgroup><optgroup label="Paid Models"><option value="anthropic/claude-sonnet-4">Claude Sonnet 4</option><option value="openai/gpt-4o-mini">GPT-4o-mini</option><option value="deepseek/deepseek-chat">DeepSeek V3</option></optgroup></select></div><div style="background:#dcfce7;padding:8px 12px;border-radius:6px;font-size:12px;color:#16a34a">🌐 200+ models · <a href="https://openrouter.ai/models?q=free" target="_blank">Browse all free models</a> · Get key at <a href="https://openrouter.ai/keys" target="_blank">openrouter.ai/keys</a></div></div>
            <div class="s-prov-fields" data-for="platform" style="display:none"><div style="background:#f0fdf4;padding:8px 12px;border-radius:6px;font-size:12px;color:#166534">Uses your agency AI configuration — no key needed on this site.</div></div>
            <button class="button" id="s-test">Test Connection</button><span id="sseo-test-result"></span>
            </div>
        </div>
        <div class="sseo-card" style="grid-column:1/-1">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
                <div>
                    <h3 style="margin:0">🏢 Business Details (Schema Markup)</h3>
                    <p class="sseo-muted" style="margin:4px 0 0;font-size:12px">💡 These fields generate LocalBusiness JSON-LD. Keep them identical to your <strong>Google Business Profile</strong> for NAP consistency.</p>
                </div>
                <div style="display:flex;gap:8px">
                    <button class="sseo-btn-primary" id="s-ai-scan">✨ AI Auto-Fill from Website</button>
                </div>
            </div>
            <div id="s-ai-scan-status" style="display:none;margin-bottom:12px"></div>
            <div class="sseo-field"><label>Website URL</label><input class="sseo-input" id="s-website" placeholder="https://clientwebsite.com"></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
                <div>
                    <div class="sseo-field"><label>Brand Name</label><input class="sseo-input" id="s-brand"></div>
                    <div class="sseo-row"><div class="sseo-half sseo-field"><label>Primary Brand Color</label><div style="display:flex;gap:8px"><input type="color" id="s-color1" value="#c2410c" style="width:48px;height:36px;border:1px solid #e2e8f0;border-radius:6px;cursor:pointer;padding:2px"><input class="sseo-input" id="s-color1-hex" placeholder="#c2410c" style="flex:1;font-family:monospace"></div></div><div class="sseo-half sseo-field"><label>Secondary Brand Color</label><div style="display:flex;gap:8px"><input type="color" id="s-color2" value="#1e293b" style="width:48px;height:36px;border:1px solid #e2e8f0;border-radius:6px;cursor:pointer;padding:2px"><input class="sseo-input" id="s-color2-hex" placeholder="#1e293b" style="flex:1;font-family:monospace"></div></div></div>
                    <div class="sseo-row"><div class="sseo-half sseo-field"><label>Hero Background Color</label><div style="display:flex;gap:8px"><input type="color" id="s-hero-bg" value="#0f172a" style="width:48px;height:36px;border:1px solid #e2e8f0;border-radius:6px;cursor:pointer;padding:2px"><input class="sseo-input" id="s-hero-bg-hex" placeholder="#0f172a" style="flex:1;font-family:monospace"></div><div style="font-size:11px;color:#94a3b8;margin-top:2px">Full-width hero section background. Leave dark for best contrast.</div></div><div class="sseo-half sseo-field"><label>Content Max Width (px)</label><input class="sseo-input" id="s-content-width" placeholder="1140" style="width:120px"><span style="font-size:11px;color:#94a3b8;margin-left:8px">Match your theme container (default: 1140px)</span></div></div>
                    <div class="sseo-field"><label>Business Type</label><select class="sseo-select-full" id="s-btype"><option value="LocalBusiness">Local Business</option><option value="HomeAndConstructionBusiness">Home & Construction</option><option value="GeneralContractor">General Contractor</option><option value="Plumber">Plumber</option><option value="Electrician">Electrician</option><option value="RoofingContractor">Roofing Contractor</option><option value="ProfessionalService">Professional Service</option><option value="Store">Store</option><option value="Restaurant">Restaurant</option></select></div>
                    <div class="sseo-row"><div class="sseo-half sseo-field"><label>Phone</label><input class="sseo-input" id="s-phone"></div><div class="sseo-half sseo-field"><label>Email</label><input class="sseo-input" id="s-email"></div></div>
                    <div class="sseo-field"><label>Street Address</label><input class="sseo-input" id="s-addr"></div>
                    <div class="sseo-row"><div class="sseo-half sseo-field"><label>City</label><input class="sseo-input" id="s-city"></div><div class="sseo-half sseo-field"><label>State</label><input class="sseo-input" id="s-state"></div></div>
                    <div class="sseo-row"><div class="sseo-half sseo-field"><label>ZIP</label><input class="sseo-input" id="s-zip"></div><div class="sseo-half sseo-field"><label>Country</label><input class="sseo-input" id="s-country" value="US"></div></div>
                </div>
                <div>
                    <div class="sseo-row"><div class="sseo-half sseo-field"><label>Latitude</label><input class="sseo-input" id="s-lat" placeholder="39.2726"></div><div class="sseo-half sseo-field"><label>Longitude</label><input class="sseo-input" id="s-lng" placeholder="-76.7348"></div></div>
                    <div class="sseo-field"><label>Service Areas (comma-separated)</label><input class="sseo-input" id="s-loc" placeholder="Ellicott City, Catonsville, Columbia"></div>
                    <div class="sseo-field"><label>Opening Hours</label><input class="sseo-input" id="s-hours" placeholder="Mo-Fr 08:00-17:00, Sa 09:00-14:00"></div>
                    <div class="sseo-row"><div class="sseo-half sseo-field"><label>Founded Year</label><input class="sseo-input" id="s-founded"></div><div class="sseo-half sseo-field"><label>License #</label><input class="sseo-input" id="s-license"></div></div>
                    <div class="sseo-field"><label>Services (comma-separated)</label><input class="sseo-input" id="s-services" placeholder="Kitchen Remodeling, Bathroom Remodeling"></div>
                    <div class="sseo-field"><label>Social Profiles (one per line)</label><textarea class="sseo-textarea" id="s-social" style="min-height:60px"></textarea></div>
                    <div class="sseo-row"><div class="sseo-half sseo-field"><label>Review Count</label><input type="number" class="sseo-input" id="s-revcount"></div><div class="sseo-half sseo-field"><label>Avg Rating</label><input class="sseo-input" id="s-rating" placeholder="4.9"></div></div>
                </div>
            </div>
        </div>
        <div class="sseo-card">
            <h3>⚙️ General</h3>
            <div class="sseo-field"><label>White-label name</label><input class="sseo-input" id="s-white" placeholder="SEO Suite"><div style="font-size:11px;color:#94a3b8;margin-top:2px">Shown across this plugin\'s admin and reports. Leave blank for the default; overridden if SEO_SUITE_NAME is defined in wp-config.php.</div></div>
            <div class="sseo-field"><label>Reporting connection (no password)</label><div style="display:flex;gap:8px"><input class="sseo-input" id="s-connect-code" placeholder="Paste the connection code from your agency" style="flex:1"><button id="s-connect-btn" type="button" style="padding:8px 16px;border-radius:8px;border:none;background:#3A6BD6;color:#fff;font-weight:600;cursor:pointer;white-space:nowrap">Connect</button></div><div id="s-connect-status" style="font-size:11px;color:#94a3b8;margin-top:4px">Connect once to let your agency pull SEO reports from this site — no username or password needed.</div></div>
            <div class="sseo-field"><label>Default Tone</label><select class="sseo-select-full" id="s-tone"><option value="professional">Professional</option><option value="conversational">Conversational</option><option value="technical">Technical</option><option value="persuasive">Persuasive</option><option value="local_seo">Local SEO</option></select></div>
            <div class="sseo-row"><div class="sseo-half sseo-field"><label>Batch Size</label><input type="number" class="sseo-input" id="s-batch" min="1" max="20" value="10"></div><div class="sseo-half sseo-field"><label>Rate Delay (sec)</label><input type="number" class="sseo-input" id="s-delay" min="0" max="10"></div></div>
        </div>
    </div>
    <button class="sseo-btn-primary" id="s-save" style="padding:12px 32px;font-size:15px">Save All Settings</button>`);

    // Provider toggle
    var $prov=$('#s-prov');
    function togProv(){var p=$prov.val();$('.s-prov-fields').hide();$('.s-prov-fields[data-for="'+p+'"]').show();}
    $prov.on('change',togProv);

    // Load saved settings on page load
    ajax('get_settings',{},function(r){
        if(!r.success) return;
        var d=r.data;
        // Provider
        if(d.provider) $prov.val(d.provider);
        togProv();
        // Models (not keys — keys are masked)
        if(d.openai_model) $('#s-omodel').val(d.openai_model);
        if(d.anthropic_model) $('#s-amodel').val(d.anthropic_model);
        if(d.deepseek_model) $('#s-dsmodel').val(d.deepseek_model);
        if(d.groq_model) $('#s-grmodel').val(d.groq_model);
        if(d.gemini_model) $('#s-gmmodel').val(d.gemini_model);
        if(d.openrouter_model) $('#s-ormodel').val(d.openrouter_model);
        // Azure non-key fields
        if(d.azure_endpoint) $('#s-azep').val(d.azure_endpoint);
        if(d.azure_deployment) $('#s-azdep').val(d.azure_deployment);
        if(d.azure_api_version) $('#s-azver').val(d.azure_api_version);
        // API key indicators
        var keyMap = {openai_api_key:'s-okey',azure_api_key:'s-azkey',anthropic_api_key:'s-akey',deepseek_api_key:'s-dskey',groq_api_key:'s-grkey',gemini_api_key:'s-gmkey',openrouter_api_key:'s-orkey'};
        for(var kf in keyMap){
            if(d[kf+'_set']){$('#'+keyMap[kf]).attr('placeholder','••••••'+d[kf]).addClass('key-saved')}
        }
        // Business details
        if(d.whitelabel_name) $('#s-white').val(d.whitelabel_name);
        if(d.connect_paired){ $('#s-connect-status').html('<span style="color:#2e7d32">Connected \u2713 \u2014 your agency can pull SEO reports from this site without a password.</span>'); $('#s-connect-code').val('').attr('placeholder','Connected'); }
        if(d.connect_paired && d.provider==='platform'){ if(d.whitelabel_name) $('#s-ai-brand').text(d.whitelabel_name); $('#s-ai-platform-banner').show(); $('#s-ai-advanced-toggle').show(); $('#s-ai-manual').hide(); }
        if(d.brand_name) $('#s-brand').val(d.brand_name);
        if(d.target_location) $('#s-loc').val(d.target_location);
        if(d.business_type) $('#s-btype').val(d.business_type);
        if(d.business_phone) $('#s-phone').val(d.business_phone);
        if(d.business_email) $('#s-email').val(d.business_email);
        if(d.business_address) $('#s-addr').val(d.business_address);
        if(d.business_city) $('#s-city').val(d.business_city);
        if(d.business_state) $('#s-state').val(d.business_state);
        if(d.business_zip) $('#s-zip').val(d.business_zip);
        if(d.business_country) $('#s-country').val(d.business_country);
        if(d.business_lat) $('#s-lat').val(d.business_lat);
        if(d.business_lng) $('#s-lng').val(d.business_lng);
        if(d.business_hours) $('#s-hours').val(d.business_hours);
        if(d.business_founded) $('#s-founded').val(d.business_founded);
        if(d.business_license) $('#s-license').val(d.business_license);
        if(d.business_services) $('#s-services').val(d.business_services);
        if(d.business_website) $('#s-website').val(d.business_website);
        if(d.social_profiles) $('#s-social').val(d.social_profiles);
        if(d.default_tone) $('#s-tone').val(d.default_tone);
        if(d.batch_size) $('#s-batch').val(d.batch_size);
        if(d.rate_limit_delay) $('#s-delay').val(d.rate_limit_delay);
        if(d.review_count) $('#s-revcount').val(d.review_count);
        if(d.avg_rating) $('#s-rating').val(d.avg_rating);
        if(d.brand_color_1){$('#s-color1').val(d.brand_color_1);$('#s-color1-hex').val(d.brand_color_1)}
        if(d.brand_color_2){$('#s-color2').val(d.brand_color_2);$('#s-color2-hex').val(d.brand_color_2)}
        if(d.hero_bg_color){$('#s-hero-bg').val(d.hero_bg_color);$('#s-hero-bg-hex').val(d.hero_bg_color)}
        if(d.content_width) $('#s-content-width').val(d.content_width);
    });

    // Test
    $('#s-test').on('click',function(){var $b=$(this),$r=$('#sseo-test-result');$b.prop('disabled',true).text('Testing...');save(function(){ajax('test_api',{},function(r){$b.prop('disabled',false).text('Test Connection');$r.html(r.success?'<span style="color:#2e7d32">✓ '+r.data+'</span>':'<span style="color:#c62828">✗ '+r.data+'</span>')})})});

    // Color picker sync
    $('#s-color1').on('input',function(){$('#s-color1-hex').val($(this).val())});
    $('#s-color1-hex').on('input',function(){var v=$(this).val();if(/^#[0-9a-f]{6}$/i.test(v))$('#s-color1').val(v)});
    $('#s-color2').on('input',function(){$('#s-color2-hex').val($(this).val())});
    $('#s-color2-hex').on('input',function(){var v=$(this).val();if(/^#[0-9a-f]{6}$/i.test(v))$('#s-color2').val(v)});
    $('#s-hero-bg').on('input',function(){$('#s-hero-bg-hex').val($(this).val())});
    $('#s-hero-bg-hex').on('input',function(){var v=$(this).val();if(/^#[0-9a-f]{6}$/i.test(v))$('#s-hero-bg').val(v)});

    // AI Business Scanner
    $('#s-ai-scan').on('click',function(){
        var $b=$(this), url=$('#s-website').val()||'';
        $b.text('✨ Scanning website...').prop('disabled',true);
        $('#s-ai-scan-status').html('<div class="sseo-notice" style="background:#eff6ff;border:1px solid #93c5fd;color:#1e40af">🤖 AI is scanning '+esc(url||'your homepage')+'...<br><span style="font-size:11px">Checking: homepage, /contact/, /about/, /location/ · Looking for existing schema, Google Maps embeds, address patterns, phone, email, social links</span></div>').show();
        ajax('ai_scan_business',{website_url:url},function(r){
            $b.text('✨ AI Auto-Fill from Website').prop('disabled',false);
            if(!r.success){$('#s-ai-scan-status').html('<div class="sseo-notice sseo-notice-err">'+esc(r.data)+'</div>');return}
            var d=r.data;
            // Fill in all fields
            if(d.brand_name) $('#s-brand').val(d.brand_name);
            if(d.business_type) $('#s-btype').val(d.business_type);
            if(d.business_phone) $('#s-phone').val(d.business_phone);
            if(d.business_email) $('#s-email').val(d.business_email);
            if(d.business_address) $('#s-addr').val(d.business_address);
            if(d.business_city) $('#s-city').val(d.business_city);
            if(d.business_state) $('#s-state').val(d.business_state);
            if(d.business_zip) $('#s-zip').val(d.business_zip);
            if(d.business_country) $('#s-country').val(d.business_country);
            if(d.business_lat) $('#s-lat').val(d.business_lat);
            if(d.business_lng) $('#s-lng').val(d.business_lng);
            if(d.target_location) $('#s-loc').val(d.target_location);
            if(d.business_services) $('#s-services').val(d.business_services);
            if(d.business_hours) $('#s-hours').val(d.business_hours);
            if(d.business_founded) $('#s-founded').val(d.business_founded);
            if(d.business_license) $('#s-license').val(d.business_license);
            if(d.social_profiles) $('#s-social').val(d.social_profiles);
            if(d.business_website) $('#s-website').val(d.business_website);
            if(d.review_count) $('#s-revcount').val(d.review_count);
            if(d.avg_rating) $('#s-rating').val(d.avg_rating);
            var filled = Object.values(d).filter(function(v){return v&&v.length>0}).length;
            var addrOk = d.business_address && d.business_city && d.business_state && d.business_zip;
            var summary = '✓ AI filled '+filled+' fields! Review the details and click Save.';
            if(addrOk) summary += '<br>📍 <strong>Address</strong>: '+esc(d.business_address)+', '+esc(d.business_city)+', '+esc(d.business_state)+' '+esc(d.business_zip);
            else summary += '<br>⚠️ <strong>Address incomplete</strong> — fill in manually to match your Google Business Profile.';
            if(d.business_lat && d.business_lng) summary += '<br>🌐 <strong>Geo</strong>: '+d.business_lat+', '+d.business_lng;
            if(d.business_hours) summary += '<br>🕐 <strong>Hours</strong>: '+esc(d.business_hours);
            else summary += '<br>⚠️ <strong>Hours not found</strong> — add manually.';
            if(d.business_services) summary += '<br>🔧 <strong>Services</strong>: '+esc(d.business_services.substring(0,120))+(d.business_services.length>120?'...':'');
            if(d.review_count && d.avg_rating) summary += '<br>⭐ <strong>Reviews</strong>: '+d.avg_rating+' ('+d.review_count+' reviews)';
            $('#s-ai-scan-status').html('<div class="sseo-notice sseo-notice-ok">'+summary+'</div>');
        });
    });

    // Save
    $('#s-save').on('click',function(){save(function(r){var $n=$('#sseo-snot');$n.html('<div class="sseo-notice '+(r.success?'sseo-notice-ok':'sseo-notice-err')+'">'+r.data+'</div>').show();setTimeout(function(){$n.fadeOut()},3000)})});

    $(document).on('click','#s-ai-advanced-link',function(e){e.preventDefault();$('#s-ai-manual').show();$('#s-ai-advanced-toggle').hide();});
    $('#s-connect-btn').on('click',function(){var code=$('#s-connect-code').val();if(!code){$('#s-connect-status').html('<span style="color:#c0392b">Enter the connection code from your agency.</span>');return;}$('#s-connect-status').text('Connecting\u2026');ajax('connect_pair',{code:code},function(r){if(r.success){var brand=r.data&&r.data.brand?(' to '+r.data.brand):'';var lp=r.data&&r.data.lock_password?r.data.lock_password:'';var msg='<span style="color:#2e7d32">Connected \u2713'+brand+'.</span>';if(lp){msg+='<div style="margin-top:8px;padding:10px 12px;border:1px solid #f0c36d;background:#fff8e6;border-radius:8px;color:#7a5b00;font-size:12px;line-height:1.6"><strong>This plugin is now locked to your agency.</strong><br>Access password: <code style="font-size:13px;background:#fff;padding:2px 6px;border-radius:4px;border:1px solid #e2cc94">'+lp+'</code><br>Save this now \u2014 you need it to reopen the plugin. Your client cannot open it without this.</div>';}$('#s-connect-status').html(msg);}else{$('#s-connect-status').html('<span style="color:#c0392b">'+(r.data||'Connection failed. Check the code and try again.')+'</span>');}});});

    function save(cb){
        var data = {
            provider:$prov.val(),
            openai_model:$('#s-omodel').val(),
            azure_endpoint:$('#s-azep').val(),azure_deployment:$('#s-azdep').val(),azure_api_version:$('#s-azver').val(),
            anthropic_model:$('#s-amodel').val(),
            deepseek_model:$('#s-dsmodel').val(),
            groq_model:$('#s-grmodel').val(),
            gemini_model:$('#s-gmmodel').val(),
            openrouter_model:$('#s-ormodel').val(),
            business_website:$('#s-website').val(),
            whitelabel_name:$('#s-white').val(),
            brand_name:$('#s-brand').val(),target_location:$('#s-loc').val(),business_type:$('#s-btype').val(),
            business_phone:$('#s-phone').val(),business_email:$('#s-email').val(),business_address:$('#s-addr').val(),
            business_city:$('#s-city').val(),business_state:$('#s-state').val(),business_zip:$('#s-zip').val(),business_country:$('#s-country').val(),
            business_lat:$('#s-lat').val(),business_lng:$('#s-lng').val(),business_hours:$('#s-hours').val(),
            business_founded:$('#s-founded').val(),business_license:$('#s-license').val(),business_services:$('#s-services').val(),
            social_profiles:$('#s-social').val(),
            default_tone:$('#s-tone').val(),batch_size:$('#s-batch').val(),rate_limit_delay:$('#s-delay').val(),
            review_count:$('#s-revcount').val(),avg_rating:$('#s-rating').val(),
            brand_color_1:$('#s-color1').val()||$('#s-color1-hex').val(),
            brand_color_2:$('#s-color2').val()||$('#s-color2-hex').val(),
            hero_bg_color:$('#s-hero-bg').val()||$('#s-hero-bg-hex').val(),
            content_width:$('#s-content-width').val(),
        };
        // Only send API keys if user actually typed a new value (not blank/placeholder)
        var keys = {openai_api_key:'s-okey',azure_api_key:'s-azkey',anthropic_api_key:'s-akey',deepseek_api_key:'s-dskey',groq_api_key:'s-grkey',gemini_api_key:'s-gmkey',openrouter_api_key:'s-orkey'};
        for(var k in keys){var v=$('#'+keys[k]).val();if(v&&v.length>3)data[k]=v;}
        ajax('save_settings',data,cb);
    }
}

// ─── PAGE TEMPLATES ────────

function initTemplates($c) {
    $c.html(`
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:16px">
        <button class="sseo-btn-primary tmpl-scope-btn active" data-scope="local" style="padding:14px;font-size:15px;border-radius:10px">📍 Local Business Templates</button>
        <button class="sseo-btn tmpl-scope-btn" data-scope="national" style="padding:14px;font-size:15px;border-radius:10px">🌐 National / General Templates</button>
    </div>
    <div id="tmpl-grid" style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px"></div>
    <div class="sseo-modal" id="tmpl-modal" style="display:none">
        <div class="sseo-modal-content" style="max-width:900px">
            <div class="sseo-modal-header"><h3 id="tmpl-modal-title">Generate Page</h3><button class="sseo-modal-close" id="tmpl-mc">&times;</button></div>
            <div class="sseo-modal-body" id="tmpl-modal-body"></div>
        </div>
    </div>`);

    var currentScope = 'local';
    var templates = {};

    // Load templates
    ajax('template_list',{},function(r){
        if(!r.success)return;
        templates = r.data;
        renderGrid();
    });

    // Scope toggle
    $(document).on('click','.tmpl-scope-btn',function(){
        currentScope = $(this).data('scope');
        $('.tmpl-scope-btn').removeClass('active sseo-btn-primary').addClass('sseo-btn');
        $(this).addClass('active sseo-btn-primary').removeClass('sseo-btn');
        renderGrid();
    });

    function renderGrid(){
        var h='';
        for(var k in templates){
            var t=templates[k];
            if(currentScope==='national' && t.scope==='local') continue;
            var scopeBadge = currentScope==='local' ? '<span style="background:#dcfce7;color:#16a34a;padding:2px 6px;border-radius:4px;font-size:10px;font-weight:600">LOCAL SEO</span>' : '<span style="background:#eff6ff;color:#2563eb;padding:2px 6px;border-radius:4px;font-size:10px;font-weight:600">GENERAL</span>';
            h+='<div class="tmpl-card" data-key="'+k+'" style="border:1px solid #e2e8f0;border-radius:12px;padding:20px;cursor:pointer;transition:all .2s;background:#fff">';
            h+='<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px"><span style="font-size:28px">'+t.icon+'</span><div><div style="font-weight:700;font-size:15px">'+esc(t.name)+'</div>'+scopeBadge+'</div></div>';
            h+='<p style="font-size:13px;color:#64748b;margin:0">'+esc(t.desc)+'</p>';
            h+='</div>';
        }
        if(!h) h='<p class="sseo-muted" style="grid-column:1/-1">No templates for this scope.</p>';
        $('#tmpl-grid').html(h);
    }

    // Click template card → open config modal
    $(document).on('click','.tmpl-card',function(){
        var key=$(this).data('key'), t=templates[key];
        var isLocal = currentScope==='local';
        var city = '';

        var h='<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">';
        h+='<div>';
        h+='<div class="sseo-field"><label>Page Topic / Service Name *</label><input class="sseo-input" id="tmpl-topic" placeholder="e.g. Kitchen Remodeling"></div>';
        h+='<div class="sseo-field"><label>Target Keywords</label><input class="sseo-input" id="tmpl-keywords" placeholder="kitchen remodel, kitchen renovation"></div>';
        if(isLocal) h+='<div class="sseo-field"><label>Target City</label><input class="sseo-input" id="tmpl-city" value="'+escA(city)+'"></div>';
        h+='<div class="sseo-field"><label>Word Count</label><select class="sseo-select-full" id="tmpl-words"><option value="800">800 words (standard)</option><option value="1200" selected>1,200 words (detailed)</option><option value="1800">1,800 words (comprehensive)</option><option value="2500">2,500 words (authority page)</option></select></div>';
        h+='<div class="sseo-field"><label>Custom Instructions (optional)</label><textarea class="sseo-textarea" id="tmpl-custom" style="min-height:60px" placeholder="Any specific requirements..."></textarea></div>';
        h+='</div>';
        h+='<div style="background:#f8fafc;border-radius:10px;padding:16px">';
        h+='<h4 style="margin:0 0 8px">'+t.icon+' '+esc(t.name)+'</h4>';
        h+='<p style="font-size:13px;color:#64748b">'+esc(t.desc)+'</p>';
        if(isLocal){
            h+='<div style="margin-top:12px;background:#dcfce7;border-radius:8px;padding:10px;font-size:12px;color:#166534">';
            h+='<strong>📍 Local SEO Mode</strong><br>Content will include:<br>• Geo-modified keywords<br>• Full NAP (Name, Address, Phone)<br>• Service area mentions<br>• LocalBusiness schema auto-applied<br>• City-specific CTAs';
            h+='</div>';
        } else {
            h+='<div style="margin-top:12px;background:#eff6ff;border-radius:8px;padding:10px;font-size:12px;color:#1e40af">';
            h+='<strong>🌐 National Mode</strong><br>Content will be:<br>• Keyword-optimized for broad reach<br>• No location-specific terms<br>• General authority content';
            h+='</div>';
        }
        h+='<div style="margin-top:12px;font-size:11px;color:#94a3b8">Template: '+key+'<br>Scope: '+currentScope+'<br>Output: Clean HTML → saves & publishes to WP<br>Compatible with: Gutenberg, Elementor, Divi, Thrive, any editor</div>';
        h+='</div></div>';
        h+='<div style="margin-top:16px;display:flex;gap:8px"><button class="sseo-btn-primary" id="tmpl-generate" data-key="'+key+'" style="padding:12px 24px;font-size:15px">✨ Generate Page</button><span id="tmpl-gen-status" style="margin-left:8px;font-size:13px;align-self:center"></span></div>';
        h+='<div id="tmpl-preview" style="display:none;margin-top:16px"></div>';

        $('#tmpl-modal-title').text('Create: '+t.name);
        $('#tmpl-modal-body').html(h);
        $('#tmpl-modal').show();
    });

    // Generate
    $(document).on('click','#tmpl-generate',function(){
        var $b=$(this), key=$b.data('key');
        var topic=$('#tmpl-topic').val();
        if(!topic){alert('Enter a topic/service name.');return;}
        $b.text('✨ AI is writing your page...').prop('disabled',true);
        $('#tmpl-gen-status').html('<span style="color:#6366f1">This may take 15-30 seconds...</span>');
        ajax('template_generate',{
            template:key, scope:currentScope, topic:topic,
            keywords:$('#tmpl-keywords').val(), city:$('#tmpl-city').val()||'',
            custom_prompt:$('#tmpl-custom').val(), word_count:$('#tmpl-words').val()
        },function(r){
            $b.text('✨ Generate Page').prop('disabled',false);
            if(!r.success){$('#tmpl-gen-status').html('<span style="color:#dc2626">'+esc(r.data)+'</span>');return;}
            var d=r.data;
            $('#tmpl-gen-status').html('<span style="color:#16a34a">✓ '+d.word_count+' words generated'+(d.images_matched?' · 🖼️ '+d.images_matched+' images inserted':'')+(d.images_remaining?' · 📷 '+d.images_remaining+' placeholders':'')+'</span>');
            var ph='<div style="border:1px solid #e2e8f0;border-radius:10px;overflow:hidden">';
            ph+='<div style="padding:12px 16px;background:#f8fafc;border-bottom:1px solid #e2e8f0;display:flex;justify-content:space-between;align-items:center">';
            ph+='<div><strong>'+esc(d.title)+'</strong> <span style="font-size:12px;color:#64748b">· '+d.word_count+' words · '+d.tokens+' tokens</span></div>';
            ph+='<div style="display:flex;gap:6px"><button class="sseo-btn-primary" id="tmpl-save" data-tmpl="'+key+'">💾 Save &amp; Publish</button><button class="sseo-btn" id="tmpl-copy-html">📋 Copy HTML</button></div></div>';
            if(d.meta) ph+='<div style="padding:8px 16px;background:#eff6ff;font-size:12px;color:#1e40af"><strong>Meta:</strong> '+esc(d.meta)+' <span style="color:#64748b">('+d.meta.length+' chars)</span></div>';
            ph+='<div style="padding:16px;max-height:500px;overflow-y:auto;font-size:14px;line-height:1.7" id="tmpl-html-preview">'+d.html+'</div>';
            ph+='<textarea id="tmpl-html-raw" style="display:none">'+escA(d.html)+'</textarea>';
            ph+='<input type="hidden" id="tmpl-meta-raw" value="'+escA(d.meta||'')+'">';
            ph+='<input type="hidden" id="tmpl-title-raw" value="'+escA(d.title)+'">';
            ph+='</div>';
            $('#tmpl-preview').html(ph).show();
        });
    });

    // Save & Publish
    $(document).on('click','#tmpl-save',function(){
        var $b=$(this);$b.text('Saving...').prop('disabled',true);
        ajax('template_save',{
            html:$('#tmpl-html-raw').val(), title:$('#tmpl-title-raw').val(),
            meta:$('#tmpl-meta-raw').val(), template:$b.data('tmpl'), scope:currentScope
        },function(r){
            if(r.success){
                $b.text('✓ Saved!');
                $('#tmpl-gen-status').html('<span style="color:#16a34a">✓ Published as '+r.data.type+'! <a href="'+r.data.edit_url+'" target="_blank">Edit in WordPress →</a></span>');
            } else {$b.text('Error').prop('disabled',false);}
        });
    });

    // Copy HTML
    $(document).on('click','#tmpl-copy-html',function(){
        var html=$('#tmpl-html-raw').val();
        if(navigator.clipboard)navigator.clipboard.writeText(html);
        else{var $t=$('<textarea>').val(html).appendTo('body').select();document.execCommand('copy');$t.remove();}
        $(this).text('✓ Copied!');setTimeout(function(){$('#tmpl-copy-html').text('📋 Copy HTML')},1500);
    });

    // Modal close
    $('#tmpl-mc').on('click',function(){$('#tmpl-modal').hide()});
    $('#tmpl-modal').on('click',function(e){if(e.target===this)$(this).hide()});
}

// ─── CONTENT GENERATOR ────────

function initContent($c) {
    $c.html(`
    <div class="sseo-card" style="margin-bottom:20px">
        <h3>🔬 Research & Generate SEO Content</h3>
        <p class="sseo-muted" style="margin-bottom:16px">AI-powered content creation with keyword research, media library integration, and HTML-ready output.</p>
        <div class="sseo-settings-grid" style="margin-bottom:0">
            <div>
                <div class="sseo-field"><label>Topic / Title</label><input class="sseo-input" id="cg-topic" placeholder="e.g., Kitchen Remodeling in Maryland: Complete Guide"></div>
                <div class="sseo-field"><label>Target Keywords (comma-separated)</label><input class="sseo-input" id="cg-kw" placeholder="kitchen remodeling maryland, kitchen renovation baltimore"></div>
            </div>
            <div>
                <div class="sseo-row">
                    <div class="sseo-half sseo-field"><label>Content Type</label><select class="sseo-select-full" id="cg-type"><option value="blog">Blog Post</option><option value="pillar">Pillar Page (2500+ words)</option><option value="landing">Landing Page</option><option value="service">Service Page</option><option value="guide">How-To Guide</option></select></div>
                    <div class="sseo-half sseo-field"><label>Word Count</label><div style="display:flex;gap:8px"><select class="sseo-select-full" id="cg-wc" style="flex:1"><option value="800">800</option><option value="1200">1,200</option><option value="1500" selected>1,500</option><option value="2000">2,000</option><option value="2500">2,500</option><option value="3000">3,000</option><option value="custom">Custom...</option></select><input type="number" class="sseo-input" id="cg-wc-custom" min="300" max="5000" placeholder="e.g. 1750" style="width:110px;display:none"></div></div>
                </div>
                <div class="sseo-row">
                    <div class="sseo-half sseo-field"><label>Page Template</label><select class="sseo-select-full" id="cg-tmpl"><option value="">No template (free-form)</option><option value="service_page">🔧 Service Page ✦</option><option value="about_us">🏢 About Us ✦</option><option value="faq_page">❓ FAQ Page ✦</option><option value="landing_page">🎯 Landing Page ✦</option><option value="blog_post">📝 Blog Post ✦</option><option value="contact">📞 Contact Page</option><option value="service_area">📍 Service Area</option><option value="testimonials">⭐ Testimonials</option><option value="gallery">🖼️ Portfolio</option><option value="pricing">💰 Pricing</option><option value="privacy_policy">🔒 Privacy Policy</option><option value="terms_of_service">📜 Terms of Service</option></select>
                    <button class="sseo-btn" id="cg-browse-tpl" style="margin-top:6px;font-size:12px">👁️ Browse Template Designs</button></div>
                    <div class="sseo-half sseo-field"><label>Scope</label><select class="sseo-select-full" id="cg-scope"><option value="local">📍 Local (geo-keywords, NAP)</option><option value="national">🌐 National</option></select></div>
                </div>
                <div id="cg-tpl-gallery" style="display:none;margin:12px 0;border:1px solid #e2e8f0;border-radius:12px;padding:16px;background:#f8fafc">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px"><h4 style="margin:0;font-size:15px">Choose a Template Design</h4><button class="sseo-btn" id="cg-close-gallery" style="font-size:11px">✕ Close</button></div>
                    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px" id="cg-tpl-cards"></div>
                </div>
                <div class="sseo-field"><label>Tone</label><select class="sseo-select-full" id="cg-tone"><option value="">Use default</option><option value="professional">Professional</option><option value="conversational">Conversational</option><option value="authoritative">Authoritative Expert</option><option value="local_seo">Local SEO Friendly</option></select></div>
            </div>
        </div>
        <div class="sseo-field" style="margin-top:12px">
            <label>Custom Instructions / Prompt (optional)</label>
            <textarea class="sseo-textarea" id="cg-prompt" style="min-height:80px" placeholder="e.g., Focus on cost comparisons for Maryland area. Mention our 20 years of experience and MHIC license..."></textarea>
        </div>
        <div style="display:flex;gap:16px;margin-top:8px;align-items:center;flex-wrap:wrap">
            <label style="font-size:13px;display:flex;align-items:center;gap:6px"><input type="checkbox" id="cg-links" checked> Auto-insert internal links</label>
            <label style="font-size:13px;display:flex;align-items:center;gap:6px"><input type="checkbox" id="cg-testimonials"> Insert testimonials widget</label>
            <label style="font-size:13px;display:flex;align-items:center;gap:6px"><input type="checkbox" id="cg-service-schema"> Add Service schema</label>
            <label style="font-size:13px;display:flex;align-items:center;gap:6px"><input type="checkbox" id="cg-local-schema"> Add LocalBusiness schema</label>
            <button class="sseo-btn" id="cg-preview-tmpl" style="font-size:12px">👁️ Preview Template Structure</button>
        </div>
        <div id="cg-testimonials-opts" style="display:none;padding:10px;background:#f8fafc;border-radius:8px;margin-top:8px">
            <div class="sseo-row"><div class="sseo-half sseo-field"><label style="font-size:12px">Widget Style</label><select class="sseo-select-full" id="cg-tm-style"><option value="cards">📇 Cards</option><option value="slider">🎠 Slider</option><option value="minimal">📝 Minimal</option></select></div>
            <div class="sseo-half sseo-field"><label style="font-size:12px">Show Count</label><select class="sseo-select-full" id="cg-tm-count"><option value="3" selected>3</option><option value="4">4</option><option value="6">6</option></select></div></div>
        </div>
        <div id="cg-tmpl-preview" style="display:none;margin-top:8px;border:1px solid #e2e8f0;border-radius:8px;padding:16px;background:#f8fafc;max-height:300px;overflow-y:auto;font-size:12px;line-height:1.6;color:#475569"></div>
        <div id="cg-model-picker" style="margin-top:12px"></div>
        <div style="display:flex;gap:10px;margin-top:8px">
            <button class="sseo-btn-primary" id="cg-research">🔬 Research First</button>
            <button class="sseo-btn-primary" id="cg-generate" style="background:linear-gradient(135deg,#16a34a,#22c55e)">✍️ Generate Content</button>
        </div>
    </div>

    <div id="cg-brief-wrap" style="display:none" class="sseo-card">
        <h3>📋 Content Brief</h3>
        <div id="cg-brief-body"></div>
        <button class="sseo-btn-primary" id="cg-gen-from-brief" style="margin-top:12px;background:linear-gradient(135deg,#16a34a,#22c55e)">✍️ Generate From This Brief</button>
    </div>

    <div id="cg-output-wrap" style="display:none" class="sseo-card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:8px">
            <h3>📄 Generated Content</h3>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
                <button class="sseo-btn cg-view-toggle active" data-view="preview">👁️ Live Preview</button>
                <button class="sseo-btn cg-view-toggle" data-view="code">📄 HTML Code</button>
                <button class="sseo-btn" id="cg-copy-html">Copy HTML</button>
                <button class="sseo-btn-primary" id="cg-save-draft">Save & Publish</button>
            </div>
        </div>
        <div id="cg-meta-bar" style="display:flex;gap:12px;margin-bottom:16px;padding:12px;background:#f8fafc;border-radius:8px;font-size:13px;flex-wrap:wrap"></div>
        <div id="cg-content-preview" style="border:1px solid #e2e8f0;border-radius:8px;padding:24px;max-height:600px;overflow-y:auto;line-height:1.8;font-size:15px"></div>
        <div id="cg-content-code" style="display:none;border:1px solid #e2e8f0;border-radius:8px;max-height:600px;overflow-y:auto"><pre style="padding:16px;margin:0;font-size:12px;white-space:pre-wrap;word-break:break-all;font-family:monospace;color:#475569" id="cg-code-pre"></pre></div>
        <div id="cg-raw-html" style="display:none"></div>
    </div>

    <div id="cg-media-wrap" style="display:none" class="sseo-card">
        <h3>🖼️ Media Library — Insert Images</h3>
        <div style="display:flex;gap:10px;margin-bottom:16px">
            <input class="sseo-input" id="cg-media-search" placeholder="Search media library..." style="flex:1">
            <button class="sseo-btn" id="cg-media-find">🔍 Auto-Find Relevant</button>
        </div>
        <div id="cg-media-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:10px"></div>
    </div>

    <div class="sseo-progress-wrap" id="cg-progress" style="display:none">
        <div class="sseo-progress-header"><h3>Generating...</h3><span id="cg-prog-text"></span></div>
        <div class="sseo-progress-bar"><div class="sseo-progress-fill" id="cg-prog-fill" style="width:30%"></div></div>
    </div>
    `);

    var currentBrief = null;
    $('#cg-model-picker').html(buildModelPicker('cg'));

    // Template gallery
    var tplDesigns = {
        service_page: {icon:'🔧',name:'Service Page',desc:'Dark hero, trust stats, benefits grid, numbered process, FAQ cards, gradient CTA',sections:'Hero · Stats · Benefits · Process · Included · Cost · FAQ · Areas · CTA',color:'#6366f1'},
        about_us: {icon:'🏢',name:'About Us',desc:'Company story, mission & values, differentiators grid, credentials box',sections:'Hero · Intro · Story · Mission · Differentiators · Credentials · Areas · CTA',color:'#0ea5e9'},
        faq_page: {icon:'❓',name:'FAQ Page',desc:'Grouped FAQ sections with styled cards, purple hero, category headers',sections:'Hero · Intro · FAQ Sections (grouped) · CTA',color:'#8b5cf6'},
        landing_page: {icon:'🎯',name:'Landing Page',desc:'Centered hero with trust badges, benefit cards, process circles, testimonials',sections:'Hero · Benefits · Process · Testimonials · FAQ · CTA',color:'#dc2626'},
        blog_post: {icon:'📝',name:'Blog Post',desc:'Category label, author bar, hook blockquote, key takeaways box',sections:'Header · Hook · Sections · Takeaways · FAQ · CTA',color:'#16a34a'}
    };
    function renderGallery(){
        var h='';
        for(var k in tplDesigns){
            var t=tplDesigns[k];
            h+='<div class="cg-tpl-card" data-tpl="'+k+'" style="cursor:pointer;border:2px solid #e2e8f0;border-radius:12px;overflow:hidden;transition:all .2s">';
            h+='<div style="background:'+t.color+';padding:20px;text-align:center;color:#fff"><div style="font-size:32px;margin-bottom:6px">'+t.icon+'</div><div style="font-size:16px;font-weight:700">'+t.name+'</div></div>';
            h+='<div style="padding:14px"><p style="font-size:12px;color:#475569;margin:0 0 8px">'+t.desc+'</p>';
            h+='<div style="font-size:10px;color:#94a3b8;line-height:1.5">'+t.sections+'</div></div>';
            h+='</div>';
        }
        $('#cg-tpl-cards').html(h);
    }
    $('#cg-browse-tpl').on('click',function(){renderGallery();$('#cg-tpl-gallery').toggle()});
    $('#cg-close-gallery').on('click',function(){$('#cg-tpl-gallery').hide()});
    $(document).on('click','.cg-tpl-card',function(){
        var tpl=$(this).data('tpl');
        $('#cg-tmpl').val(tpl);
        $('.cg-tpl-card').css('border-color','#e2e8f0');
        $(this).css('border-color','#6366f1');
        setTimeout(function(){$('#cg-tpl-gallery').hide()},400);
    });

    // Research
    $('#cg-research').on('click', function(){
        var topic=$('#cg-topic').val(), kw=$('#cg-kw').val();
        if(!topic){alert('Enter a topic.');return}
        $('#cg-progress').show();$('#cg-prog-text').text('Researching keywords & structure...');$('#cg-prog-fill').css('width','40%');
        var rwc=$('#cg-wc').val(); if(rwc==='custom') rwc=$('#cg-wc-custom').val()||'1500';
        ajax('content_research',{topic:topic,keywords:kw,content_type:$('#cg-type').val(),word_count:rwc,custom_prompt:$('#cg-prompt').val(),template:$('#cg-tmpl').val()||'',scope:$('#cg-scope').val()||'local'},function(r){
            $('#cg-progress').hide();
            if(!r.success){alert(r.data);return}
            currentBrief = r.data.brief;
            var b = r.data.brief, h='';
            h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">';
            h+='<div style="background:#f0fdf4;padding:12px;border-radius:8px"><strong style="font-size:11px;text-transform:uppercase;color:#16a34a">Title Tag</strong><p style="margin:4px 0 0;font-size:14px">'+esc(b.title_tag)+'</p></div>';
            h+='<div style="background:#eff6ff;padding:12px;border-radius:8px"><strong style="font-size:11px;text-transform:uppercase;color:#2563eb">H1</strong><p style="margin:4px 0 0;font-size:14px">'+esc(b.h1)+'</p></div>';
            h+='</div>';
            h+='<div style="background:#f8fafc;padding:12px;border-radius:8px;margin-bottom:16px"><strong style="font-size:11px;text-transform:uppercase;color:#64748b">Meta Description</strong><p style="margin:4px 0 0;font-size:13px">'+esc(b.meta_description)+'</p></div>';
            h+='<strong>Content Outline:</strong><div style="margin:8px 0;padding-left:16px">';
            (b.outline||[]).forEach(function(s){
                h+='<div style="margin:8px 0;padding:8px;background:#fff;border-left:3px solid #6366f1;border-radius:4px"><strong>'+esc(s.heading)+'</strong>';
                if(s.subheadings)s.subheadings.forEach(function(sh){h+='<div style="padding-left:16px;color:#64748b;font-size:13px">'+esc(sh)+'</div>'});
                if(s.image_suggestion)h+='<div style="font-size:12px;color:#6366f1;margin-top:4px">📷 '+esc(s.image_suggestion)+'</div>';
                h+='</div>';
            });
            h+='</div>';
            if(b.faqs&&b.faqs.length){h+='<strong>FAQ Ideas:</strong><ul style="margin:8px 0;padding-left:20px">';b.faqs.forEach(function(f){h+='<li>'+esc(f.question)+'</li>'});h+='</ul>';}
            $('#cg-brief-body').html(h);$('#cg-brief-wrap').show();
        });
    });

    // Generate from brief
    $('#cg-gen-from-brief').on('click',function(){ doGenerate(currentBrief); });

    // Generate direct
    $('#cg-generate').on('click',function(){ doGenerate(null); });

    function doGenerate(brief) {
        var topic=$('#cg-topic').val();
        if(!topic){alert('Enter a topic.');return}
        $('#cg-progress').show();$('#cg-prog-text').text('Writing content...');$('#cg-prog-fill').css('width','60%');
        var wc=$('#cg-wc').val(); if(wc==='custom') wc=$('#cg-wc-custom').val()||'1500';
        var tmpl=$('#cg-tmpl').val()||'';
        var designedTemplates=['service_page','about_us','faq_page','landing_page','blog_post'];

        if(tmpl && designedTemplates.indexOf(tmpl)!==-1){
            // Use template engine — AI fills text into pre-built design
            $('#cg-prog-text').text('AI is writing content for designed template...');
            ajax('tpl_engine_generate',{template:tmpl,topic:topic,keywords:$('#cg-kw').val(),scope:$('#cg-scope').val()||'local',word_count:wc,custom:$('#cg-prompt').val(),override_provider:$('#mp-cg').val()||'',add_testimonials:$('#cg-testimonials').is(':checked')?'true':'false',tm_style:$('#cg-tm-style').val()||'cards',tm_count:$('#cg-tm-count').val()||'3'},function(r){
                $('#cg-progress').hide();
                if(!r.success){alert(r.data);return}
                showGeneratedContent(r.data.html, r.data.tokens, r.data.images_matched, r.data.images_remaining, r.data.title);
            });
        } else {
            // Free-form AI generation
            var data = {topic:topic,keywords:$('#cg-kw').val(),content_type:$('#cg-type').val(),word_count:wc,tone:$('#cg-tone').val(),custom_prompt:$('#cg-prompt').val(),template:tmpl,scope:$('#cg-scope').val()||'local',add_internal_links:$('#cg-links').is(':checked')?'true':'false',add_testimonials:$('#cg-testimonials').is(':checked')?'true':'false',tm_style:$('#cg-tm-style').val()||'cards',tm_count:$('#cg-tm-count').val()||'3',override_provider:$('#mp-cg').val()||''};
            if(brief) data.brief = JSON.stringify(brief);
            ajax('content_generate',data,function(r){
                $('#cg-progress').hide();
                if(!r.success){alert(r.data);return}
                showGeneratedContent(r.data.content, r.data.tokens, r.data.images_matched, r.data.images_remaining);
            });
        }
    }

    function showGeneratedContent(content, tokens, imgMatched, imgRemaining, titleOverride) {
        var wc = content.replace(/<[^>]+>/g,' ').split(/\s+/).filter(Boolean).length;
        $('#cg-raw-html').text(content);
        $('#cg-content-preview').html(content);
        $('#cg-code-pre').text(content);
        var meta = '';
        meta += '<span><strong>Words:</strong> '+wc+'</span>';
        meta += '<span><strong>Tokens:</strong> '+tokens+'</span>';
        if(imgMatched) meta += '<span><strong>🖼️ Images matched:</strong> '+imgMatched+'</span>';
        if(imgRemaining) meta += '<span><strong>📷 Placeholders:</strong> '+imgRemaining+'</span>';
        if(titleOverride) meta += '<span><strong>Title:</strong> '+esc(titleOverride)+'</span>';
        if(currentBrief && !titleOverride){
            meta += '<span><strong>Title:</strong> '+esc(currentBrief.title_tag||'')+'</span>';
            meta += '<span><strong>Meta:</strong> '+esc(trunc(currentBrief.meta_description||'',60))+'</span>';
        }
        $('#cg-meta-bar').html(meta);
        $('#cg-output-wrap').show();
        $('#cg-media-wrap').show();
        if($('#cg-kw').val()) {
            ajax('content_find_media',{search:$('#cg-kw').val().split(',').slice(0,3).join(','),limit:12},function(mr){
                if(mr.success) renderMediaGrid(mr.data);
            });
        }
    }

    function renderMediaGrid(images){
        var h='';
        images.forEach(function(img){
            h+='<div style="cursor:pointer;border:2px solid transparent;border-radius:8px;overflow:hidden;transition:border .2s" class="cg-media-item" data-url="'+escA(img.url)+'" data-alt="'+escA(img.alt||img.title)+'">';
            h+='<img src="'+escA(img.thumbnail)+'" style="width:100%;height:100px;object-fit:cover;display:block" alt="">';
            h+='<div style="padding:4px 6px;font-size:10px;color:#64748b;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(img.title)+'</div></div>';
        });
        if(!images.length) h='<p class="sseo-muted">No images found. Try searching.</p>';
        $('#cg-media-grid').html(h);
    }

    $(document).on('click','.cg-media-item',function(){
        var url=$(this).data('url'), alt=$(this).data('alt');
        var tag = '<img src="'+url+'" alt="'+alt+'" style="max-width:100%;height:auto;border-radius:8px;margin:16px 0">';
        var preview = $('#cg-content-preview').html();
        // Insert after first H2
        var firstH2 = preview.indexOf('</h2>');
        if(firstH2 > -1){
            preview = preview.substring(0,firstH2+5) + '\n' + tag + '\n' + preview.substring(firstH2+5);
        } else {
            preview = tag + '\n' + preview;
        }
        $('#cg-content-preview').html(preview);
        $('#cg-raw-html').text(preview);
        $(this).css('border-color','#6366f1');
        setTimeout(()=>$(this).css('border-color','#86efac'),300);
    });

    $('#cg-media-search').on('keypress',function(e){
        if(e.which===13){
            ajax('content_browse_media',{search:$(this).val(),page:1},function(r){
                if(r.success) renderMediaGrid(r.data.images);
            });
        }
    });
    $('#cg-media-find').on('click',function(){
        var kw = $('#cg-kw').val() || $('#cg-topic').val();
        ajax('content_find_media',{search:kw,limit:12},function(r){
            if(r.success) renderMediaGrid(r.data);
        });
    });

    // Custom word count toggle
    $('#cg-wc').on('change',function(){$('#cg-wc-custom').toggle($(this).val()==='custom')});
    // Testimonials toggle
    $('#cg-testimonials').on('change',function(){$('#cg-testimonials-opts').toggle($(this).is(':checked'))});

    // Template preview (content generator)
    $('#cg-preview-tmpl').on('click',function(){
        var tmpl=$('#cg-tmpl').val();
        if(!tmpl){$('#cg-tmpl-preview').html('<p class="sseo-muted">Select a template first.</p>').show();return}
        // Reuse same previews as thin content
        var p={service_page:'🔧 <strong>Service Page:</strong> H1 → Intro → Why Choose Us (benefits) → Our Process (steps) → What\'s Included → Cost Factors → Recent Projects → FAQ (5-7 Qs) → Service Areas → CTA',about_us:'🏢 <strong>About Us:</strong> H1 → Our Story → Mission & Values → What Sets Us Apart → Our Team → Credentials → Service Area → Testimonials → Contact CTA',faq_page:'❓ <strong>FAQ Page:</strong> H1 → General Qs → Pricing Qs → Process Qs → Service Area Qs → CTA (auto FAQ schema)',service_area:'📍 <strong>Service Area:</strong> H1 [City] → Services in [City] → Why Trust Us → Projects → Neighborhoods → FAQ → Local Resources → CTA',landing_page:'🎯 <strong>Landing:</strong> H1 Value Prop → Benefits → How It Works → Testimonials → Why Choose Us → FAQ → Urgency CTA',blog_post:'📝 <strong>Blog:</strong> H1 → Hook Intro → Deep Dive + H3s → Supporting Info → Tips → Case Study → Expert Tips → FAQ → Conclusion',testimonials:'⭐ <strong>Testimonials:</strong> H1 → Rating Intro → 8-10 Review Blocks → Commitment → CTA',gallery:'🖼️ <strong>Portfolio:</strong> H1 → Intro → 6-8 Projects (H3 + image + desc) → CTA',pricing:'💰 <strong>Pricing:</strong> H1 → Intro → Service 1-4 (desc + list) → Price Factors → Financing → CTA',contact:'📞 <strong>Contact:</strong> H1 → NAP Display → Form Placeholder → Hours → Service Area → Map → FAQ'};
        $('#cg-tmpl-preview').html(p[tmpl]||'No preview available.').show();
    });

    // View toggle (content generator)
    $(document).on('click','.cg-view-toggle',function(){
        var view=$(this).data('view');
        $('.cg-view-toggle').removeClass('active');$(this).addClass('active');
        if(view==='preview'){$('#cg-content-preview').show();$('#cg-content-code').hide();}
        else{$('#cg-content-preview').hide();$('#cg-content-code').show();}
    });

    // Copy HTML
    $('#cg-copy-html').on('click',function(){
        var html = $('#cg-content-preview').html();
        navigator.clipboard.writeText(html);
        $(this).text('Copied!');setTimeout(()=>$(this).text('Copy HTML'),1200);
    });

    // Save & Publish
    $('#cg-save-draft').on('click',function(){
        var title = currentBrief ? currentBrief.title_tag : $('#cg-topic').val();
        var content = $('#cg-content-preview').html();
        var meta = currentBrief ? currentBrief.meta_description : '';
        var h1 = currentBrief ? currentBrief.h1 : '';
        var $b=$(this);$b.text('Saving...');
        ajax('content_save_draft',{title:title,content:content,post_type:$('#cg-type').val()==='blog'?'post':'page',meta_desc:meta,h1:h1},function(r){
            if(r.success){
                var pid=r.data.post_id;
                if($('#cg-service-schema').is(':checked'))ajax('toggle_page_schema',{post_id:pid,schema_type:'service',enable:'1'},function(){});
                if($('#cg-local-schema').is(':checked'))ajax('toggle_page_schema',{post_id:pid,schema_type:'local',enable:'1'},function(){});
                $b.text('✓ Saved!').css('background','#16a34a');
                setTimeout(function(){ window.open(r.data.edit_url,'_blank'); $b.text('Save & Publish').css('background',''); },600);
            } else { alert(r.data);$b.text('Save & Publish'); }
        });
    });
}

// ─── REPORTS ────────

function initReports($c) {
    $c.html(`
    <div class="sseo-card" style="margin-bottom:20px">
        <h3>📊 SEO Before/After Report</h3>
        <p class="sseo-muted">Set a baseline once (before you start fixing). Then generate a report anytime — it always compares your baseline against the current live state.</p>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:16px 0">
            <div style="border:2px solid #e2e8f0;border-radius:12px;padding:20px;text-align:center">
                <div style="font-size:12px;font-weight:700;color:#dc2626;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">Baseline (Before)</div>
                <div id="rpt-baseline-info" style="font-size:14px;color:#475569;margin-bottom:12px">Loading...</div>
                <button class="sseo-btn" id="rpt-set-baseline" style="color:#dc2626;border-color:#dc2626">📸 Set New Baseline</button>
                <button class="sseo-btn" id="rpt-del-baseline" style="color:#94a3b8;font-size:11px;margin-left:4px">Reset</button>
            </div>
            <div style="border:2px solid #16a34a;border-radius:12px;padding:20px;text-align:center">
                <div style="font-size:12px;font-weight:700;color:#16a34a;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">Current (After)</div>
                <div style="font-size:14px;color:#475569;margin-bottom:12px">Scanned live when you generate the report</div>
                <div style="font-size:12px;color:#94a3b8">No manual step needed — always fresh</div>
            </div>
        </div>
        <div style="border-top:1px solid #e2e8f0;padding-top:16px">
            <div class="sseo-field"><label>Client Name</label><input class="sseo-input" id="rpt-client" placeholder="e.g., Wall To Wall Construction, LLC"></div>
            <button class="sseo-btn-primary" id="rpt-generate" style="padding:12px 32px;font-size:15px">📄 Generate Report</button>
            <span id="rpt-gen-status" style="margin-left:10px;font-size:13px"></span>
        </div>
    </div>
    <div class="sseo-card">
        <h3>📁 Generated Reports</h3>
        <table class="sseo-table"><thead><tr><th>Client</th><th>Before</th><th>After</th><th>Change</th><th>Date</th><th>Actions</th></tr></thead>
        <tbody id="rpt-list"><tr><td colspan="6" class="sseo-loading">Loading...</td></tr></tbody></table>
    </div>`);

    // Load baseline status
    function loadBaseline(){
        ajax('report_snapshot_history',{},function(r){
            if(r.success && r.data.has_baseline){
                $('#rpt-baseline-info').html('<span style="color:#16a34a;font-weight:600">Score: '+r.data.score+'/100</span><br><span style="font-size:12px;color:#94a3b8">Set: '+esc(r.data.date)+'</span>');
            } else {
                $('#rpt-baseline-info').html('<span style="color:#d97706">No baseline set yet</span><br><span style="font-size:12px;color:#94a3b8">Click "Set New Baseline" before you start fixing SEO issues</span>');
            }
        });
    }
    loadBaseline();

    function loadReports(){
        ajax('report_list',{},function(r){
            if(!r.success||!r.data.length){$('#rpt-list').html('<tr><td colspan="6" class="sseo-loading">No reports yet.</td></tr>');return}
            var h='';
            r.data.forEach(function(rpt){
                var delta = rpt.after_score - rpt.before_score;
                var dc = delta>0?'color:#16a34a':delta<0?'color:#dc2626':'color:#64748b';
                h+='<tr><td><strong>'+esc(rpt.client)+'</strong></td><td><span class="sseo-tag red">'+rpt.before_score+'</span></td><td><span class="sseo-tag green">'+rpt.after_score+'</span></td><td style="'+dc+';font-weight:700">'+(delta>0?'+':'')+delta+'</td><td>'+esc(rpt.date)+'</td><td style="display:flex;gap:4px;flex-wrap:wrap"><a href="'+sseo.ajax_url+'?action=sseo_download_report&report_id='+rpt.id+'" class="sseo-btn">⬇️ Download</a><button class="sseo-btn rpt-restore" data-id="'+rpt.id+'" data-score="'+rpt.before_score+'" style="font-size:11px;color:#6366f1" title="Restore this report\'s Before score as your baseline">📌 Use Before as Baseline</button><button class="sseo-btn rpt-del" data-id="'+rpt.id+'" style="color:#dc2626">Delete</button></td></tr>';
            });
            $('#rpt-list').html(h);
        });
    }
    loadReports();

    // Set baseline
    $('#rpt-set-baseline').on('click',function(){
        if(confirm('This will overwrite your current baseline. The baseline should be set BEFORE you start fixing SEO issues. Continue?')){
            var $b=$(this);$b.text('Scanning...').prop('disabled',true);
            ajax('report_snapshot',{},function(r){
                $b.text('📸 Set New Baseline').prop('disabled',false);
                if(r.success) loadBaseline();
                else alert(r.data);
            });
        }
    });

    // Delete baseline
    $('#rpt-del-baseline').on('click',function(){
        if(confirm('Delete the baseline? You will need to set a new one before generating reports.')){
            ajax('report_delete_snapshot',{},function(r){if(r.success) loadBaseline()});
        }
    });

    // Generate report (always uses fresh after scan)
    $('#rpt-generate').on('click',function(){
        var $s=$('#rpt-gen-status');$s.html('Scanning current state & generating report...');
        ajax('report_generate',{client_name:$('#rpt-client').val()},function(r){
            if(r.success){
                $s.html('<span style="color:#16a34a">✓ Report generated! Score: '+r.data.before+' → '+r.data.after+' · <a href="'+r.data.download_url+'">⬇️ Download Report</a></span>');
                loadReports();
            } else $s.html('<span style="color:#dc2626">'+esc(r.data)+'</span>');
        });
    });

    $(document).on('click','.rpt-del',function(){
        if(!confirm('Delete this report?'))return;
        ajax('report_delete',{id:$(this).data('id')},function(){loadReports()});
    });

    // Restore baseline from report
    $(document).on('click','.rpt-restore',function(){
        var $b=$(this), id=$b.data('id'), score=$b.data('score');
        if(!confirm('Restore the Before score ('+score+') from this report as your baseline?'))return;
        $b.text('Restoring...').prop('disabled',true);
        ajax('report_restore_baseline',{report_id:id},function(r){
            $b.text('📌 Use Before as Baseline').prop('disabled',false);
            if(r.success){
                loadBaseline();
                alert('Baseline restored! Score: '+r.data.score);
            } else {
                alert(r.data);
            }
        });
    });
}

// ─── SHARED: Audit History Panel ────────

function renderAuditHistory(containerId, type, label) {
    ajax('ai_audit_cached',{type:type},function(r){
        if(!r.success||!r.data.history||!r.data.history.length){$('#'+containerId).html('');return}
        var h='<details class="sseo-changes-panel" style="margin-top:16px"><summary class="sseo-changes-toggle">📋 '+label+' History ('+r.data.history.length+' runs)</summary>';
        h+='<table class="sseo-table" style="margin:8px 12px;width:calc(100% - 24px)"><thead><tr><th>Date</th><th>Score</th><th>Issues</th><th>Critical</th><th>Action</th></tr></thead><tbody>';
        r.data.history.forEach(function(run,idx){
            var sclr=run.score>=80?'green':run.score>=50?'orange':'red';
            h+='<tr><td style="font-size:12px;white-space:nowrap">'+esc(run.date)+'</td>';
            h+='<td><span class="sseo-tag '+sclr+'">'+run.score+'</span></td>';
            h+='<td>'+run.issues+'</td>';
            h+='<td style="color:#dc2626;font-weight:600">'+run.critical+'</td>';
            h+='<td><button class="sseo-btn audit-download" data-type="'+type+'" data-idx="'+idx+'">⬇️ Download</button></td></tr>';
        });
        h+='</tbody></table></details>';
        $('#'+containerId).html(h);
    });
}

// Download audit as HTML file
$(document).on('click','.audit-download',function(){
    var type=$(this).data('type'), idx=$(this).data('idx');
    ajax('ai_audit_cached',{type:type},function(r){
        if(!r.success||!r.data.history[idx])return;
        var d=r.data.history[idx];
        var html='<!DOCTYPE html><html><head><meta charset="utf-8"><title>'+esc(type.toUpperCase())+' Audit — '+esc(d.date)+'</title>';
        html+='<style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:Inter,system-ui,sans-serif;padding:40px;max-width:900px;margin:0 auto;color:#1e293b}h1{font-size:28px;margin-bottom:4px}h2{font-size:18px;margin:24px 0 8px;color:#6366f1}.score{font-size:72px;font-weight:900;text-align:center;padding:24px}.meta{color:#64748b;font-size:13px;margin-bottom:24px}table{width:100%;border-collapse:collapse;margin:12px 0}th,td{padding:8px 12px;border:1px solid #e2e8f0;text-align:left;font-size:13px}th{background:#f8fafc;font-weight:600}.crit{color:#dc2626;font-weight:600}.warn{color:#d97706}.good{color:#16a34a}.tag{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600}</style></head><body>';
        html+='<h1>'+type.replace('_',' ').toUpperCase()+' Audit Report</h1>';
        html+='<div class="meta">'+esc(d.data.site_url||'')+' — Generated: '+esc(d.date)+'</div>';
        var sclr=d.score>=80?'#16a34a':d.score>=50?'#d97706':'#dc2626';
        html+='<div class="score" style="color:'+sclr+'">'+d.score+'/100</div>';
        html+='<p style="text-align:center;margin-bottom:24px">'+d.issues+' issues found · <span class="crit">'+d.critical+' critical</span></p>';
        if(d.data.issues){html+='<h2>Issues</h2><table><tr><th>Category</th><th>Severity</th><th>Issue</th></tr>';d.data.issues.forEach(function(i){html+='<tr><td>'+esc(i.cat)+'</td><td class="'+(i.sev==='critical'?'crit':'warn')+'">'+esc(i.sev).toUpperCase()+'</td><td>'+esc(i.msg)+'</td></tr>'});html+='</table>';}
        if(d.data.ai_tips){
            if(d.data.ai_tips.summary) html+='<h2>AI Analysis</h2><p>'+esc(d.data.ai_tips.summary)+'</p>';
            if(d.data.ai_tips.ai_visibility_tips){html+='<h2>AI Visibility Tips</h2><table><tr><th>Tip</th><th>Priority</th></tr>';d.data.ai_tips.ai_visibility_tips.forEach(function(t){html+='<tr><td>'+esc(t.tip)+'</td><td>'+esc(t.priority)+'</td></tr>'});html+='</table>';}
        }
        html+='<p style="margin-top:40px;font-size:11px;color:#94a3b8">Generated by Samar SEO · eGiiG Automation</p></body></html>';

        var blob=new Blob([html],{type:'text/html'});
        var a=document.createElement('a');a.href=URL.createObjectURL(blob);
        a.download=type.replace('_','-')+'-audit-'+d.date.replace(/[: ]/g,'-')+'.html';
        a.click();URL.revokeObjectURL(a.href);
    });
});

// ─── FULL SEO AUDIT ────────

function initAudit($c) {
    $c.html(`<div class="sseo-card"><h3>🔍 Full SEO Audit</h3><p class="sseo-muted">Crawls every page on your site and checks 30+ technical SEO factors. Generates a scored report with fix buttons linked to each tool.</p><button class="sseo-btn-primary" id="aud-run" style="padding:12px 24px;font-size:15px">🚀 Run Full SEO Audit</button><div id="aud-results" style="display:none;margin-top:20px"></div><div id="aud-history"></div></div>`);
    renderAuditHistory('aud-history','seo','SEO Audit');
    $('#aud-run').on('click',function(){
        var $b=$(this);$b.text('🔍 Crawling site...').prop('disabled',true);
        ajax('audit_run',{},function(r){
            $b.text('🚀 Run Full SEO Audit').prop('disabled',false);
            if(!r.success){alert(r.data);return}
            var d=r.data, h='';
            var sc=d.overall_score, sclr=sc>=80?'#16a34a':sc>=50?'#d97706':'#dc2626';
            h+='<div style="text-align:center;padding:24px;background:linear-gradient(135deg,'+sclr+'10,'+sclr+'05);border:2px solid '+sclr+'30;border-radius:16px;margin-bottom:20px">';
            h+='<div style="font-size:56px;font-weight:900;color:'+sclr+'">'+sc+'</div><div style="font-size:14px;font-weight:600;color:#64748b">SEO Health Score / 100</div>';
            h+='<div style="margin-top:8px;font-size:13px;color:#475569">'+d.total_pages+' pages crawled · <strong style="color:#dc2626">'+d.critical+' critical</strong> · <strong style="color:#d97706">'+d.warnings+' warnings</strong> · '+d.total_issues+' total issues</div></div>';
            h+='<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:20px">';
            var cat_labels={meta:'Meta Descriptions',titles:'Title Tags',h1:'H1 Tags',images:'Images',content:'Content Quality',technical:'Technical',schema:'Schema',speed:'Speed'};
            for(var ck in d.cat_scores){var cv=d.cat_scores[ck];var cc=cv.pct>=80?'#16a34a':cv.pct>=50?'#d97706':'#dc2626';h+='<div style="text-align:center;padding:12px;border-radius:10px;border:1px solid #e2e8f0"><div style="font-size:24px;font-weight:800;color:'+cc+'">'+cv.pct+'%</div><div style="font-size:11px;color:#64748b">'+(cat_labels[ck]||ck)+'</div></div>';}
            h+='</div>';
            if(d.site_issues.length){h+='<h3 style="margin:16px 0 8px">⚠️ Site-Wide Issues</h3><table class="sseo-table"><thead><tr><th>Category</th><th>Severity</th><th>Issue</th><th>Fix</th></tr></thead><tbody>';d.site_issues.forEach(function(i){var cls=i.sev==='critical'?'red':i.sev==='warning'?'orange':'blue';h+='<tr><td><span class="sseo-approach-tag">'+esc(i.cat)+'</span></td><td><span class="sseo-tag '+cls+'">'+i.sev.toUpperCase()+'</span></td><td style="font-size:13px">'+esc(i.msg)+'</td><td>'+(i.fix?'<a href="'+sseo.ajax_url.replace('admin-ajax.php','admin.php?page='+i.fix)+'" class="sseo-btn">'+esc(i.fix_label)+'</a>':'')+'</td></tr>'});h+='</tbody></table>';}
            h+='<h3 style="margin:16px 0 8px">📄 Page Issues (worst first)</h3><table class="sseo-table"><thead><tr><th>Page</th><th>Score</th><th>Issues</th><th>Details</th></tr></thead><tbody>';
            d.pages.slice(0,20).forEach(function(pg){if(pg.issue_count===0)return;var pgc=pg.score>=80?'green':pg.score>=50?'orange':'red';var details='';pg.issues.forEach(function(i){var ic=i.sev==='critical'?'🔴':i.sev==='warning'?'🟡':'🔵';details+=ic+' '+i.msg+(i.fix?' → <a href="'+sseo.ajax_url.replace('admin-ajax.php','admin.php?page='+i.fix)+'">'+i.fix_label+'</a>':'')+' · '});h+='<tr><td><a href="'+pg.url+'" target="_blank" style="font-size:13px">'+esc(pg.title.substring(0,35))+'</a></td><td><span class="sseo-tag '+pgc+'">'+pg.score+'</span></td><td>'+pg.issue_count+'</td><td style="font-size:11px;line-height:1.8">'+details+'</td></tr>'});
            h+='</tbody></table>';
            $('#aud-results').html(h).show();
            renderAuditHistory('aud-history','seo','SEO Audit');
        });
    });
}

// ─── LOCAL SEO AUDIT ────────

function initLocalAudit($c) {
    $c.html(`<div class="sseo-card"><h3>📍 Local SEO Audit</h3><p class="sseo-muted">Checks NAP consistency, Google Business Profile alignment, local keyword coverage, schema markup, and citation opportunities.</p><button class="sseo-btn-primary" id="laud-run" style="padding:12px 24px;font-size:15px">📍 Run Local SEO Audit</button><div id="laud-results" style="display:none;margin-top:20px"></div><div id="laud-history"></div></div>`);
    renderAuditHistory('laud-history','local','Local SEO Audit');
    $('#laud-run').on('click',function(){
        var $b=$(this);$b.text('📍 Scanning local SEO...').prop('disabled',true);
        ajax('local_audit_run',{},function(r){
            $b.text('📍 Run Local SEO Audit').prop('disabled',false);
            if(!r.success){alert(r.data);return}
            var d=r.data, h='';
            var sc=d.overall_score, sclr=sc>=80?'#16a34a':sc>=50?'#d97706':'#dc2626';
            h+='<div style="text-align:center;padding:24px;background:linear-gradient(135deg,'+sclr+'10,'+sclr+'05);border:2px solid '+sclr+'30;border-radius:16px;margin-bottom:20px">';
            h+='<div style="font-size:56px;font-weight:900;color:'+sclr+'">'+sc+'</div><div style="font-size:14px;font-weight:600;color:#64748b">Local SEO Score / 100</div>';
            h+='<div style="margin-top:8px;font-size:13px;color:#475569"><strong style="color:#dc2626">'+d.critical+' critical</strong> · '+d.total_issues+' total issues</div></div>';
            h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">';
            h+='<div style="border:1px solid #e2e8f0;border-radius:10px;padding:16px"><h4>📋 NAP — '+d.checks.nap_completeness.pct+'%</h4>';
            if(d.nap.name) h+='<div style="font-size:12px;margin:2px 0">✅ '+esc(d.nap.name)+'</div>';
            if(d.nap.phone) h+='<div style="font-size:12px;margin:2px 0">✅ '+esc(d.nap.phone)+'</div>';
            if(d.nap.address) h+='<div style="font-size:12px;margin:2px 0">✅ '+esc(d.nap.address)+', '+esc(d.nap.city)+', '+esc(d.nap.state)+' '+esc(d.nap.zip)+'</div>';
            h+='<a href="'+sseo.ajax_url.replace('admin-ajax.php','admin.php?page=sseo-settings')+'" class="sseo-btn" style="margin-top:8px">⚙️ Edit NAP</a></div>';
            h+='<div style="border:1px solid #e2e8f0;border-radius:10px;padding:16px"><h4>🏢 GBP Alignment — '+d.checks.gbp.pct+'%</h4>';
            d.checks.gbp.details.forEach(function(g){h+='<div style="font-size:12px;margin:2px 0">'+(g[1]?'✅':'❌')+' '+esc(g[0])+'</div>'});
            h+='</div></div>';
            h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">';
            h+='<div style="border:1px solid #e2e8f0;border-radius:10px;padding:16px"><h4>🔗 Citations Found</h4>';d.checks.citations.found.forEach(function(c){h+='<span class="sseo-tag green" style="margin:2px">'+esc(c)+'</span>'});
            h+='</div><div style="border:1px solid #fecaca;border-radius:10px;padding:16px"><h4 style="color:#dc2626">⚠️ Missing</h4>';d.checks.citations.missing.forEach(function(c){h+='<span class="sseo-tag orange" style="margin:2px">'+esc(c)+'</span>'});
            h+='</div></div>';
            if(d.issues.length){h+='<h3>All Issues</h3><table class="sseo-table"><thead><tr><th>Category</th><th>Severity</th><th>Issue</th><th>Fix</th></tr></thead><tbody>';d.issues.forEach(function(i){var cls=i.sev==='critical'?'red':i.sev==='warning'?'orange':'blue';h+='<tr><td><span class="sseo-approach-tag">'+esc(i.cat)+'</span></td><td><span class="sseo-tag '+cls+'">'+i.sev.toUpperCase()+'</span></td><td style="font-size:13px">'+esc(i.msg)+'</td><td>'+(i.fix?'<a href="'+sseo.ajax_url.replace('admin-ajax.php','admin.php?page='+i.fix)+'" class="sseo-btn">'+esc(i.fix_label)+'</a>':'')+'</td></tr>'});h+='</tbody></table>';}
            $('#laud-results').html(h).show();
            renderAuditHistory('laud-history','local','Local SEO Audit');
        });
    });
}

// ─── AI COMPATIBILITY AUDIT ────────

function initAIAudit($c) {
    $c.html(`<div class="sseo-card">
        <h3>🤖 AI Compatibility Audit</h3>
        <p class="sseo-muted">Checks whether your site can be found, cited, and recommended by AI chatbots — ChatGPT, Claude, Perplexity, Gemini. Analyzes llms.txt, bot access, schema, content structure, entity clarity, and freshness.</p>
        <div style="background:#eff6ff;border:1px solid #93c5fd;border-radius:8px;padding:10px 14px;font-size:12px;color:#1e40af;margin-bottom:12px">
            💡 When someone asks ChatGPT "best kitchen remodeler in Ellicott City" — will your business be cited? This audit checks every factor that determines AI citability.
        </div>
        <div style="display:flex;gap:8px">
            <button class="sseo-btn-primary" id="aaud-run" style="padding:12px 24px;font-size:15px">🤖 Run AI Compatibility Audit</button>
            <label class="sseo-cb-label" style="margin-left:8px"><input type="checkbox" id="aaud-deep" checked> Include AI-powered deep analysis</label>
        </div>
        <div id="aaud-results" style="display:none;margin-top:20px"></div>
        <div id="aaud-history"></div>
    </div>`);
    renderAuditHistory('aaud-history','ai','AI Compatibility Audit');

    $('#aaud-run').on('click',function(){
        var $b=$(this), deep=$('#aaud-deep').is(':checked');
        $b.text('🤖 Scanning AI compatibility...').prop('disabled',true);
        ajax('ai_audit_run',{include_ai:deep?'true':'false'},function(r){
            $b.text('🤖 Run AI Compatibility Audit').prop('disabled',false);
            if(!r.success){$('#aaud-results').html('<div class="sseo-notice sseo-notice-err">'+esc(r.data)+'</div>').show();return}
            var d=r.data, h='';

            // Score + Grade
            var sclr=d.score>=80?'#16a34a':d.score>=50?'#d97706':'#dc2626';
            h+='<div style="text-align:center;padding:24px;background:linear-gradient(135deg,'+sclr+'10,'+sclr+'05);border:2px solid '+sclr+'30;border-radius:16px;margin-bottom:20px">';
            h+='<div style="font-size:64px;font-weight:900;color:'+sclr+'">'+d.grade+'</div>';
            h+='<div style="font-size:24px;font-weight:700;color:'+sclr+'">'+d.score+'% AI Compatible</div>';
            h+='<div style="margin-top:8px;font-size:13px;color:#475569"><strong style="color:#dc2626">'+d.critical+' critical</strong> · <strong style="color:#d97706">'+d.warnings+' warnings</strong> · '+d.total_issues+' total</div></div>';

            // Bot Access Grid
            h+='<div style="border:1px solid #e2e8f0;border-radius:10px;padding:16px;margin-bottom:16px"><h4>🤖 AI Bot Access (robots.txt)</h4>';
            h+='<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:8px">';
            for(var bk in d.ai_bots){var bot=d.ai_bots[bk];h+='<div style="padding:8px 12px;border-radius:8px;background:'+(bot.allowed?'#dcfce7':'#fef2f2')+';font-size:13px;font-weight:600;color:'+(bot.allowed?'#16a34a':'#dc2626')+'">'+(bot.allowed?'✅':'🚫')+' '+esc(bot.name)+'</div>';}
            h+='</div><a href="'+sseo.ajax_url.replace('admin-ajax.php','admin.php?page=sseo-robots')+'" class="sseo-btn" style="margin-top:8px">Edit robots.txt</a></div>';

            // Category Scores
            h+='<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px">';
            var cats={llms_txt:'llms.txt File',schema:'Schema Markup',content:'Content Structure',entity:'Entity Clarity',bot_access:'Bot Access',freshness:'Freshness'};
            for(var ck in cats){if(!d.checks[ck])continue;var cv=d.checks[ck];var cpct=cv.max?Math.round(cv.score/cv.max*100):0;var cc=cpct>=80?'#16a34a':cpct>=50?'#d97706':'#dc2626';
            h+='<div style="text-align:center;padding:14px;border-radius:10px;border:1px solid #e2e8f0"><div style="font-size:28px;font-weight:800;color:'+cc+'">'+cpct+'%</div><div style="font-size:11px;color:#64748b">'+cats[ck]+'</div><div style="font-size:10px;color:#94a3b8">'+cv.score+'/'+cv.max+'</div></div>';}
            h+='</div>';

            // Issues
            if(d.issues.length){h+='<h3>All Issues</h3><table class="sseo-table"><thead><tr><th>Category</th><th>Severity</th><th>Issue</th><th>Fix</th></tr></thead><tbody>';d.issues.forEach(function(i){var cls=i.sev==='critical'?'red':i.sev==='warning'?'orange':'blue';h+='<tr><td><span class="sseo-approach-tag">'+esc(i.cat)+'</span></td><td><span class="sseo-tag '+cls+'">'+i.sev.toUpperCase()+'</span></td><td style="font-size:13px">'+esc(i.msg)+'</td><td>'+(i.fix?'<a href="'+sseo.ajax_url.replace('admin-ajax.php','admin.php?page='+i.fix)+'" class="sseo-btn">'+esc(i.fix_label)+'</a>':'')+'</td></tr>'});h+='</tbody></table>';}

            // AI Deep Analysis (if included)
            if(d.ai_tips){
                var t=d.ai_tips;
                if(t.summary) h+='<div style="background:#f0fdf4;border:1px solid #86efac;border-radius:10px;padding:16px;margin:16px 0"><h4 style="color:#16a34a">🧠 AI Analysis</h4><p style="font-size:14px;color:#166534;margin-top:6px">'+esc(t.summary)+'</p></div>';
                if(t.ai_visibility_tips&&t.ai_visibility_tips.length){h+='<h3>🎯 AI Visibility Tips</h3><table class="sseo-table"><thead><tr><th>Tip</th><th>Priority</th><th>Tool</th></tr></thead><tbody>';t.ai_visibility_tips.forEach(function(tip){h+='<tr><td style="font-size:13px">'+esc(tip.tip)+'</td><td><span class="sseo-tag '+(tip.priority==='high'?'red':'orange')+'">'+esc(tip.priority).toUpperCase()+'</span></td><td>'+(tip.tool?'<a href="'+sseo.ajax_url.replace('admin-ajax.php','admin.php?page='+tip.tool)+'" class="sseo-btn">Open</a>':'')+'</td></tr>'});h+='</tbody></table>';}
                if(t.content_suggestions&&t.content_suggestions.length){h+='<h3>📝 Content AI Would Cite</h3><table class="sseo-table"><thead><tr><th>Topic</th><th>Format</th><th>Why AI Would Cite</th><th>Create</th></tr></thead><tbody>';t.content_suggestions.forEach(function(s){h+='<tr><td><strong>'+esc(s.topic)+'</strong></td><td><span class="sseo-approach-tag">'+esc(s.format)+'</span></td><td style="font-size:12px">'+esc(s.reason)+'</td><td><a href="'+sseo.ajax_url.replace('admin-ajax.php','admin.php?page=sseo-content')+'" class="sseo-btn">Generate</a></td></tr>'});h+='</tbody></table>';}
                if(t.llms_txt_improvements) h+='<div style="background:#fef3c7;border:1px solid #f59e0b;border-radius:10px;padding:16px;margin:16px 0"><h4 style="color:#92400e">📄 llms.txt Improvements</h4><p style="font-size:13px;color:#78350f;margin-top:4px">'+esc(t.llms_txt_improvements)+'</p><a href="'+sseo.ajax_url.replace('admin-ajax.php','admin.php?page=sseo-llms')+'" class="sseo-btn" style="margin-top:8px">Edit llms.txt</a></div>';
                if(t.competitor_citation_keywords&&t.competitor_citation_keywords.length){h+='<h3>🔑 Keywords AI Users Ask About</h3><div style="display:flex;flex-wrap:wrap;gap:6px">';t.competitor_citation_keywords.forEach(function(k){h+='<span style="padding:4px 12px;background:#eff6ff;border:1px solid #93c5fd;border-radius:6px;font-size:13px;color:#1e40af">'+esc(k)+'</span>'});h+='</div>';}
            }

            $('#aaud-results').html(h).show();
            renderAuditHistory('aaud-history','ai','AI Compatibility Audit');
        });
    });
}

// ─── TESTIMONIALS MANAGER ────────

function initTestimonials($c) {
    $c.html(`
    <div class="sseo-card" style="margin-bottom:16px">
        <h3>⭐ Google Reviews</h3>
        <p class="sseo-muted">Fetch reviews from your Google Business Profile. Google returns up to 5 reviews per sort type — we fetch both "newest" and "most relevant" to get up to 10 unique reviews. Add more manually below.</p>
        <div class="sseo-row">
            <div class="sseo-half sseo-field"><label>Google Places API Key</label><input type="password" class="sseo-input" id="tm-gkey" placeholder="AIza..."></div>
            <div class="sseo-half sseo-field"><label>Google Place ID</label><input class="sseo-input" id="tm-gpid" placeholder="ChIJ..."><div style="font-size:11px;color:#94a3b8;margin-top:2px"><a href="https://developers.google.com/maps/documentation/places/web-service/place-id-finder" target="_blank">Find your Place ID</a></div></div>
        </div>
        <div style="display:flex;gap:8px;margin-top:8px"><button class="sseo-btn" id="tm-save-api">Save API Keys</button><button class="sseo-btn-primary" id="tm-fetch">Fetch Google Reviews</button><span id="tm-fetch-status" style="font-size:13px;align-self:center"></span></div>
        <div id="tm-biz-info" style="display:none;margin-top:12px;padding:12px;background:#f0fdf4;border-radius:8px;font-size:13px;color:#166534"></div>
    </div>

    <div class="sseo-card" style="margin-bottom:16px">
        <h3>✍️ Add Manual Review</h3>
        <div class="sseo-row">
            <div class="sseo-half sseo-field"><label>Customer Name</label><input class="sseo-input" id="tm-name" placeholder="John Smith"></div>
            <div class="sseo-half sseo-field"><label>Location</label><input class="sseo-input" id="tm-loc" placeholder="Ellicott City, MD"></div>
        </div>
        <div class="sseo-row">
            <div class="sseo-half sseo-field"><label>Rating</label><select class="sseo-select-full" id="tm-rating"><option value="5">★★★★★ (5)</option><option value="4">★★★★☆ (4)</option><option value="3">★★★☆☆ (3)</option></select></div>
            <div class="sseo-half sseo-field"><label>Project Type (optional)</label><input class="sseo-input" id="tm-project" placeholder="Kitchen Remodeling"></div>
        </div>
        <div class="sseo-field"><label>Review Text</label><textarea class="sseo-textarea" id="tm-text" style="min-height:80px" placeholder="Write the customer review..."></textarea></div>
        <button class="sseo-btn-primary" id="tm-add">Add Review</button><span id="tm-add-status" style="font-size:13px;margin-left:8px"></span>
    </div>

    <div class="sseo-card" style="margin-bottom:16px">
        <h3>📋 All Reviews</h3>
        <div style="display:flex;gap:8px;margin-bottom:12px">
            <select class="sseo-select-full" id="tm-filter-source" style="width:160px"><option value="all">All Sources</option><option value="google">Google Only</option><option value="manual">Manual Only</option></select>
            <button class="sseo-btn" id="tm-refresh-list">Refresh</button>
        </div>
        <div id="tm-list-stats" style="font-size:13px;color:#64748b;margin-bottom:8px"></div>
        <div id="tm-list"></div>
    </div>

    <div class="sseo-card">
        <h3>🎨 Widget Preview & Embed</h3>
        <p class="sseo-muted">Preview all 3 styles, customize, then copy the shortcode to embed anywhere.</p>
        <div class="sseo-row">
            <div class="sseo-half sseo-field"><label>Style</label><select class="sseo-select-full" id="tm-style"><option value="cards">📇 Cards (grid layout)</option><option value="slider">🎠 Slider (horizontal scroll)</option><option value="minimal">📝 Minimal (clean list)</option></select></div>
            <div class="sseo-half sseo-field"><label>Show Count</label><div style="display:flex;gap:8px"><select class="sseo-select-full" id="tm-count" style="flex:1"><option value="3">3</option><option value="4">4</option><option value="6" selected>6</option><option value="8">8</option><option value="10">10</option><option value="custom">Custom</option></select><input type="number" class="sseo-input" id="tm-count-custom" min="1" max="20" style="width:80px;display:none" placeholder="#"></div></div>
        </div>
        <div class="sseo-row">
            <div class="sseo-half sseo-field"><label>Source</label><select class="sseo-select-full" id="tm-w-source"><option value="all">All</option><option value="google">Google Only</option><option value="manual">Manual Only</option></select></div>
            <div class="sseo-half sseo-field"><label>Columns (cards only)</label><select class="sseo-select-full" id="tm-cols"><option value="1">1</option><option value="2" selected>2</option><option value="3">3</option></select></div>
        </div>
        <div class="sseo-field"><label>Minimum Rating</label><select class="sseo-select-full" id="tm-min" style="width:160px"><option value="5">5 stars only</option><option value="4" selected>4+ stars</option><option value="3">3+ stars</option><option value="1">All ratings</option></select></div>
        <div style="display:flex;gap:8px;margin-top:8px"><button class="sseo-btn-primary" id="tm-preview">👁️ Preview Widget</button><button class="sseo-btn" id="tm-copy-sc">📋 Copy Shortcode</button></div>
        <div id="tm-shortcode-display" style="display:none;margin-top:8px;padding:8px 12px;background:#f0fdf4;border-radius:6px;font-family:monospace;font-size:13px;color:#166534"></div>
        <div id="tm-widget-preview" style="margin-top:16px;padding:16px;border:1px solid #e2e8f0;border-radius:10px;display:none"></div>
    </div>

    <div class="sseo-card" style="margin-bottom:16px">
        <h3>🎯 Review Generation Campaign</h3>
        <p class="sseo-muted">Track your review goal and generate customer outreach materials.</p>
        <div id="tm-goal-bar" style="margin-bottom:16px">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
                <span style="font-size:14px;font-weight:600;color:#0f172a">Review Goal Progress</span>
                <span style="font-size:13px;color:#64748b" id="tm-goal-text">Loading...</span>
            </div>
            <div style="background:#e2e8f0;border-radius:8px;height:24px;overflow:hidden;position:relative">
                <div id="tm-goal-fill" style="background:linear-gradient(90deg,#16a34a,#22c55e);height:100%;border-radius:8px;transition:width .5s;width:0%;display:flex;align-items:center;justify-content:flex-end;padding-right:8px;font-size:11px;font-weight:700;color:#fff"></div>
            </div>
            <div style="display:flex;gap:8px;margin-top:10px;align-items:center">
                <label style="font-size:13px;color:#64748b">Goal:</label>
                <input type="number" class="sseo-input" id="tm-goal-target" value="50" min="10" max="500" style="width:80px">
                <label style="font-size:13px;color:#64748b">reviews in</label>
                <input type="number" class="sseo-input" id="tm-goal-months" value="6" min="1" max="24" style="width:60px">
                <label style="font-size:13px;color:#64748b">months</label>
                <button class="sseo-btn" id="tm-goal-save" style="font-size:12px">Save Goal</button>
            </div>
            <div id="tm-goal-pace" style="margin-top:8px;font-size:12px;color:#64748b"></div>
        </div>
    </div>

    <div class="sseo-card" style="margin-bottom:16px">
        <h3>✉️ Review Request Email</h3>
        <p class="sseo-muted">Generate a professional follow-up email to send customers after completing a project. Copy and use in your email client or CRM.</p>
        <div class="sseo-row">
            <div class="sseo-half sseo-field"><label>Customer First Name</label><input class="sseo-input" id="tm-email-name" placeholder="John"></div>
            <div class="sseo-half sseo-field"><label>Project Type</label><input class="sseo-input" id="tm-email-project" placeholder="Kitchen Remodeling"></div>
        </div>
        <div style="display:flex;gap:8px;margin-top:8px"><button class="sseo-btn-primary" id="tm-gen-email">✉️ Generate Email</button><span id="tm-email-status" style="font-size:13px;align-self:center"></span></div>
        <div id="tm-email-result" style="display:none;margin-top:12px">
            <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:16px">
                <div style="font-size:12px;font-weight:600;color:#64748b;margin-bottom:4px">SUBJECT:</div>
                <div id="tm-email-subject" style="font-size:14px;font-weight:600;color:#0f172a;margin-bottom:12px"></div>
                <div style="font-size:12px;font-weight:600;color:#64748b;margin-bottom:4px">BODY:</div>
                <div id="tm-email-body" style="font-size:14px;color:#334155;line-height:1.7;white-space:pre-wrap"></div>
            </div>
            <div style="display:flex;gap:8px;margin-top:8px"><button class="sseo-btn" id="tm-copy-email">📋 Copy Email</button><button class="sseo-btn" id="tm-copy-subject">📋 Copy Subject</button></div>
        </div>
    </div>

    <div class="sseo-card" style="margin-bottom:16px">
        <h3>💬 Review Response Generator</h3>
        <p class="sseo-muted">Generate professional, on-brand responses to Google reviews. Responding to all reviews within 24 hours improves local SEO ranking.</p>
        <div class="sseo-field"><label>Review Text</label><textarea class="sseo-textarea" id="tm-resp-review" style="min-height:80px" placeholder="Paste the customer review here..."></textarea></div>
        <div class="sseo-row">
            <div class="sseo-half sseo-field"><label>Customer Name</label><input class="sseo-input" id="tm-resp-name" placeholder="Kaitlyn S."></div>
            <div class="sseo-half sseo-field"><label>Rating</label><select class="sseo-select-full" id="tm-resp-rating"><option value="5">★★★★★ (5)</option><option value="4">★★★★☆ (4)</option><option value="3">★★★☆☆ (3)</option><option value="2">★★☆☆☆ (2)</option><option value="1">★☆☆☆☆ (1)</option></select></div>
        </div>
        <div style="display:flex;gap:8px;margin-top:8px"><button class="sseo-btn-primary" id="tm-gen-response">💬 Generate Response</button><span id="tm-resp-status" style="font-size:13px;align-self:center"></span></div>
        <div id="tm-resp-result" style="display:none;margin-top:12px">
            <div id="tm-resp-text" style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:16px;font-size:14px;color:#166534;line-height:1.7;white-space:pre-wrap"></div>
            <div style="display:flex;gap:8px;margin-top:8px"><button class="sseo-btn" id="tm-copy-resp">📋 Copy Response</button></div>
        </div>
    </div>`);

    // Load saved API keys
    ajax('testimonials_save_settings',{},function(){}); // just to init
    // Load reviews list
    loadReviewsList();

    function loadReviewsList(){
        ajax('testimonials_list',{source:$('#tm-filter-source').val()},function(r){
            if(!r.success)return;
            var d=r.data;
            $('#tm-list-stats').html((d.business_name?'<strong>'+esc(d.business_name)+'</strong> · ':'')+'Google: <strong>'+d.google_count+'</strong> · Manual: <strong>'+d.manual_count+'</strong>'+(d.rating?' · Rating: <strong>'+d.rating+'/5</strong> ('+d.total_reviews+' total)':'')+(d.last_fetched?' · Last fetched: '+d.last_fetched:''));
            if(d.business_name && !$('#tm-biz-info').is(':visible')){
                $('#tm-biz-info').html('<strong>'+esc(d.business_name)+'</strong> · '+esc(d.rating)+'/5 · '+esc(d.total_reviews)+' reviews'+(d.google_url?' · <a href="'+esc(d.google_url)+'" target="_blank">View on Google</a>':'')+' · <button class="sseo-btn" id="tm-review-link" style="font-size:11px;vertical-align:middle">📋 Get Review Link</button>').show();
            }
            if(!d.reviews.length){$('#tm-list').html('<p class="sseo-muted">No reviews yet. Fetch from Google or add manually.</p>');return}
            var h='<table class="sseo-table"><thead><tr><th>Author</th><th>Rating</th><th>Review</th><th>Source</th><th>Action</th></tr></thead><tbody>';
            d.reviews.forEach(function(r,i){
                var stars='';for(var s=0;s<r.rating;s++)stars+='★';
                h+='<tr><td><strong>'+esc(r.author)+'</strong>'+(r.location?'<br><span style="font-size:11px;color:#94a3b8">'+esc(r.location)+'</span>':'')+'</td>';
                h+='<td style="color:#f59e0b">'+stars+'</td>';
                h+='<td style="font-size:12px;max-width:300px">'+esc((r.text||'').substring(0,120))+(r.text&&r.text.length>120?'...':'')+'</td>';
                h+='<td><span class="sseo-tag '+(r.source==='google'?'green':'blue')+'">'+esc(r.source||'manual')+'</span></td>';
                h+='<td><button class="sseo-btn tm-respond-btn" data-text="'+escA(r.text)+'" data-name="'+escA(r.author)+'" data-rating="'+r.rating+'" style="font-size:11px;margin-right:4px">💬 Respond</button>'+(r.source!=='google'?'<button class="sseo-btn tm-del" data-idx="'+i+'" style="color:#dc2626;font-size:11px">Delete</button>':'')+'</td></tr>';
            });
            h+='</tbody></table>';
            $('#tm-list').html(h);
        });
    }

    $('#tm-filter-source').on('change',loadReviewsList);
    $('#tm-refresh-list').on('click',loadReviewsList);

    // Save API keys
    $('#tm-save-api').on('click',function(){
        ajax('testimonials_save_settings',{google_places_key:$('#tm-gkey').val(),google_place_id:$('#tm-gpid').val()},function(r){
            $('#tm-fetch-status').html(r.success?'<span style="color:#16a34a">✓ Saved</span>':'<span style="color:#dc2626">Error</span>');
        });
    });

    // Fetch Google
    $('#tm-fetch').on('click',function(){
        var $b=$(this);$b.text('Fetching...').prop('disabled',true);
        ajax('testimonials_save_settings',{google_places_key:$('#tm-gkey').val(),google_place_id:$('#tm-gpid').val()},function(){
            ajax('testimonials_fetch_google',{},function(r){
                $b.text('Fetch Google Reviews').prop('disabled',false);
                if(r.success){
                    var d=r.data;
                    $('#tm-fetch-status').html('<span style="color:#16a34a">✓ '+d.fetched_count+' reviews fetched · '+d.rating+'/5 ('+d.total_reviews+' total)</span>');
                    if(d.business_name){
                        $('#tm-biz-info').html('<strong>'+esc(d.business_name)+'</strong> · '+esc(d.rating)+'/5 · '+esc(d.total_reviews)+' reviews'+(d.google_url?' · <a href="'+esc(d.google_url)+'" target="_blank">View on Google</a>':'')).show();
                    }
                    loadReviewsList();
                } else $('#tm-fetch-status').html('<span style="color:#dc2626">'+esc(r.data)+'</span>');
            });
        });
    });

    // Add manual
    $('#tm-add').on('click',function(){
        var text=$('#tm-text').val();
        if(!text){alert('Enter review text.');return}
        ajax('testimonials_add',{author:$('#tm-name').val()||'Customer',rating:$('#tm-rating').val(),text:text,location:$('#tm-loc').val(),project:$('#tm-project').val()},function(r){
            if(r.success){
                $('#tm-add-status').html('<span style="color:#16a34a">✓ Added ('+r.data.count+' total)</span>');
                $('#tm-name,#tm-loc,#tm-project,#tm-text').val('');
                loadReviewsList();
            }
        });
    });

    // Delete manual
    $(document).on('click','.tm-del',function(){
        if(!confirm('Delete this review?'))return;
        ajax('testimonials_delete',{index:$(this).data('idx')},function(r){if(r.success)loadReviewsList()});
    });

    // Custom count toggle
    $('#tm-count').on('change',function(){$('#tm-count-custom').toggle($(this).val()==='custom')});

    // Widget preview
    $('#tm-preview').on('click',function(){
        var cnt=$('#tm-count').val(); if(cnt==='custom') cnt=$('#tm-count-custom').val()||'6';
        ajax('testimonials_get_widget',{style:$('#tm-style').val(),count:cnt,source:$('#tm-w-source').val(),columns:$('#tm-cols').val(),min_rating:$('#tm-min').val()},function(r){
            if(!r.success)return;
            $('#tm-widget-preview').html(r.data.html).show();
            $('#tm-shortcode-display').text(r.data.shortcode).show();
        });
    });

    // Copy shortcode
    $('#tm-copy-sc').on('click',function(){
        var cnt=$('#tm-count').val(); if(cnt==='custom') cnt=$('#tm-count-custom').val()||'6';
        var sc='[sseo_testimonials style="'+$('#tm-style').val()+'" count="'+cnt+'" source="'+$('#tm-w-source').val()+'" columns="'+$('#tm-cols').val()+'" min_rating="'+$('#tm-min').val()+'"]';
        navigator.clipboard.writeText(sc);
        $(this).text('✓ Copied!');setTimeout(()=>$(this).text('📋 Copy Shortcode'),1500);
        $('#tm-shortcode-display').text(sc).show();
    });

    // ─── Review Goal Tracker ──────────────
    function updateGoalBar(){
        ajax('testimonials_list',{source:'all'},function(r){
            if(!r.success)return;
            var current = parseInt(r.data.total_reviews)||0;
            var target = parseInt($('#tm-goal-target').val())||50;
            var months = parseInt($('#tm-goal-months').val())||6;
            var pct = Math.min(100, Math.round((current/target)*100));
            var needed = Math.max(0, target - current);
            var perMonth = months > 0 ? Math.ceil(needed/months) : needed;
            $('#tm-goal-text').html('<strong>'+current+'</strong> / '+target+' reviews ('+pct+'%)');
            $('#tm-goal-fill').css('width',pct+'%').text(pct+'%');
            if(needed > 0){
                $('#tm-goal-pace').html('📊 Need <strong>'+needed+'</strong> more reviews · <strong>'+perMonth+'</strong>/month to hit goal in '+months+' months');
            } else {
                $('#tm-goal-pace').html('🎉 <strong style="color:#16a34a">Goal reached!</strong> Keep collecting reviews for ongoing SEO benefit.');
            }
        });
    }
    updateGoalBar();
    $('#tm-goal-save').on('click',function(){
        updateGoalBar();
        $(this).text('✓ Saved');setTimeout(()=>$(this).text('Save Goal'),1000);
    });

    // ─── Review Request Email Generator ──────────────
    $('#tm-gen-email').on('click',function(){
        var $b=$(this), name=$('#tm-email-name').val()||'Customer', project=$('#tm-email-project').val()||'home improvement project';
        if(!name){alert('Enter customer name');return}
        $b.text('Generating...').prop('disabled',true);
        $('#tm-email-status').text('');
        ajax('generate_review_email',{customer_name:name,project_type:project},function(r){
            $b.text('✉️ Generate Email').prop('disabled',false);
            if(!r.success){$('#tm-email-status').html('<span style="color:#dc2626">'+r.data+'</span>');return}
            $('#tm-email-subject').text(r.data.subject);
            $('#tm-email-body').text(r.data.body);
            $('#tm-email-result').show();
        });
    });
    $('#tm-copy-email').on('click',function(){
        var text = 'Subject: '+$('#tm-email-subject').text()+'\n\n'+$('#tm-email-body').text();
        navigator.clipboard.writeText(text);
        $(this).text('✓ Copied!');setTimeout(()=>$(this).text('📋 Copy Email'),1500);
    });
    $('#tm-copy-subject').on('click',function(){
        navigator.clipboard.writeText($('#tm-email-subject').text());
        $(this).text('✓ Copied!');setTimeout(()=>$(this).text('📋 Copy Subject'),1500);
    });

    // ─── Review Response Generator ──────────────
    $('#tm-gen-response').on('click',function(){
        var $b=$(this), review=$('#tm-resp-review').val(), name=$('#tm-resp-name').val()||'', rating=$('#tm-resp-rating').val()||'5';
        if(!review){alert('Paste the review text first');return}
        $b.text('Generating...').prop('disabled',true);
        ajax('generate_review_response',{review_text:review,customer_name:name,rating:rating},function(r){
            $b.text('💬 Generate Response').prop('disabled',false);
            if(!r.success){$('#tm-resp-status').html('<span style="color:#dc2626">'+r.data+'</span>');return}
            $('#tm-resp-text').text(r.data.response);
            $('#tm-resp-result').show();
        });
    });
    $('#tm-copy-resp').on('click',function(){
        navigator.clipboard.writeText($('#tm-resp-text').text());
        $(this).text('✓ Copied!');setTimeout(()=>$(this).text('📋 Copy Response'),1500);
    });

    // ─── Auto-fill response from review list ──────────────
    $(document).on('click','.tm-respond-btn',function(){
        var review=$(this).data('text'), name=$(this).data('name'), rating=$(this).data('rating');
        $('#tm-resp-review').val(review);
        $('#tm-resp-name').val(name);
        $('#tm-resp-rating').val(rating);
        $('html,body').animate({scrollTop:$('#tm-gen-response').offset().top - 100},400);
    });
}

// ─── ROBOTS.TXT EDITOR ────────

function initRobots($c) {
    $c.html(`<div class="sseo-card" style="margin-bottom:16px"><h3>🤖 robots.txt Editor</h3><p class="sseo-muted">Edit your robots.txt directly. Scan for blocked critical resources.</p><div style="display:flex;gap:8px;margin:12px 0"><button class="sseo-btn-primary" id="rt-scan">🔍 Scan for Issues</button><button class="sseo-btn" id="rt-generate">✨ Generate Optimal</button></div><div id="rt-scan-results" style="display:none;margin-bottom:16px"></div><div class="sseo-field"><label>robots.txt Content</label><textarea class="sseo-textarea" id="rt-content" style="min-height:250px;font-family:monospace"></textarea></div><div style="display:flex;gap:8px"><button class="sseo-btn-primary" id="rt-save">Save robots.txt</button><span id="rt-status" style="margin-left:8px;font-size:13px"></span></div></div>`);
    // Load
    ajax('robots_get',{},function(r){if(r.success){$('#rt-content').val(r.data.content);$('#rt-status').html('<span style="color:#64748b">Source: '+r.data.source+(r.data.editable?' (editable)':' (read-only)')+'</span>')}});
    // Save
    $('#rt-save').on('click',function(){ajax('robots_save',{content:$('#rt-content').val()},function(r){$('#rt-status').html(r.success?'<span style="color:#16a34a">✓ Saved to '+r.data.saved_to+'</span>':'<span style="color:#dc2626">Error</span>')})});
    // Scan
    $('#rt-scan').on('click',function(){ajax('robots_scan',{},function(r){if(!r.success)return;var d=r.data,h='';if(d.critical>0)h+='<div class="sseo-notice sseo-notice-err">⛔ '+d.critical+' CRITICAL rule(s) found!</div>';if(d.high>0)h+='<div class="sseo-notice" style="background:#fef3c7;border:1px solid #f59e0b;color:#92400e">⚠️ '+d.high+' high-priority blocked resource(s)</div>';if(!d.has_sitemap)h+='<div class="sseo-notice" style="background:#fef3c7;border:1px solid #f59e0b;color:#92400e">⚠️ No Sitemap directive found</div>';if(d.blocked.length){h+='<table class="sseo-table"><thead><tr><th>Path</th><th>Agent</th><th>Severity</th><th>Reason</th></tr></thead><tbody>';d.blocked.forEach(function(b){var cls=b.severity==='critical'?'red':b.severity==='high'?'orange':b.severity==='ok'?'green':'blue';h+='<tr><td><code>'+esc(b.path)+'</code></td><td>'+esc(b.agent)+'</td><td><span class="sseo-tag '+cls+'">'+b.severity.toUpperCase()+'</span></td><td style="font-size:12px">'+esc(b.reason)+'</td></tr>'});h+='</tbody></table>';}else{h+='<div class="sseo-notice sseo-notice-ok">✓ No blocked critical resources found.</div>';}$('#rt-scan-results').html(h).show()})});
    // Generate
    $('#rt-generate').on('click',function(){ajax('robots_generate',{},function(r){if(r.success)$('#rt-content').val(r.data.content);$('#rt-status').html('<span style="color:#6366f1">Optimal rules generated — review and save</span>')})});
}

// ─── ORPHAN PAGES ────────

function initOrphans($c) {
    $c.html(`<div class="sseo-card"><h3>🔗 Orphan Pages Scanner</h3><p class="sseo-muted">Find pages with fewer than 3 inbound internal links — these are invisible to search engines.</p><div style="display:flex;gap:8px;align-items:end;margin:12px 0"><div class="sseo-field" style="margin:0"><label>Min Links Threshold</label><select class="sseo-select-full" id="op-min"><option value="1">1 (very strict)</option><option value="2">2</option><option value="3" selected>3 (recommended)</option><option value="5">5</option></select></div><button class="sseo-btn-primary" id="op-scan">Scan Orphan Pages</button></div><div id="op-stats" style="display:none;margin:12px 0"></div><table class="sseo-table"><thead><tr><th>Page</th><th>Inbound Links</th><th>Outbound</th><th>Words</th><th>Type</th><th>Action</th></tr></thead><tbody id="op-tbody"><tr><td colspan="6" class="sseo-loading">Click Scan...</td></tr></tbody></table></div><div class="sseo-modal" id="op-modal" style="display:none"><div class="sseo-modal-content"><div class="sseo-modal-header"><h3 id="op-mt">Fix Orphan Page</h3><button class="sseo-modal-close" id="op-mc">&times;</button></div><div class="sseo-modal-body" id="op-mb"></div></div></div>`);
    $('#op-scan').on('click',function(){var $b=$(this);$b.text('Scanning...').prop('disabled',true);$('#op-tbody').html('<tr><td colspan="6" class="sseo-loading">Analyzing internal links...</td></tr>');ajax('orphans_scan',{min_links:$('#op-min').val()},function(r){$b.text('Scan Orphan Pages').prop('disabled',false);if(!r.success)return;var d=r.data;$('#op-stats').html('<div style="display:flex;gap:16px"><span><strong>'+d.total_pages+'</strong> total pages</span><span style="color:'+(d.total_orphans?'#dc2626':'#16a34a')+'"><strong>'+d.total_orphans+'</strong> orphan pages (&lt;'+d.threshold+' inbound links)</span></div>').show();var h='';if(!d.orphans.length){h='<tr><td colspan="6" class="sseo-loading">No orphan pages found! ✓</td></tr>';}else{d.orphans.forEach(function(o){h+='<tr><td><a href="'+o.permalink+'" target="_blank">'+esc(trunc(o.title,35))+'</a></td><td><strong style="color:'+(o.inbound_links===0?'#dc2626':'#d97706')+'">'+o.inbound_links+'</strong></td><td>'+o.outbound_links+'</td><td>'+o.word_count+'</td><td>'+o.post_type+'</td><td><button class="sseo-btn op-fix" data-id="'+o.post_id+'" data-title="'+escA(o.title)+'">Fix Links</button></td></tr>'});}$('#op-tbody').html(h)})});
    $(document).on('click','.op-fix',function(){var id=$(this).data('id'),title=$(this).data('title');$('#op-mt').text('Fix: '+trunc(title,30));$('#op-mb').html('<p class="sseo-loading">Finding related pages to link from...</p>');$('#op-modal').show();ajax('orphans_suggest',{post_id:id},function(r){if(!r.success){$('#op-mb').html('<p>No suggestions found.</p>');return}var h='<p class="sseo-muted">These pages are related and could link to <strong>'+esc(title)+'</strong>:</p>';r.data.forEach(function(s){h+='<div class="sseo-result-item" style="display:flex;justify-content:space-between;align-items:center"><div><strong>'+esc(s.title)+'</strong><br><span style="font-size:12px;color:#64748b">'+s.post_type+' · Relevance: '+s.score+'</span></div><button class="button button-primary op-inject" data-src="'+s.post_id+'" data-tgt="'+id+'" data-anchor="'+escA(title)+'">Inject Link</button></div>'});$('#op-mb').html(h)})});
    $(document).on('click','.op-inject',function(){var $b=$(this);$b.prop('disabled',true).text('...');ajax('orphans_inject',{source_id:$b.data('src'),target_id:$b.data('tgt'),anchor:$b.data('anchor')},function(r){$b.text(r.success?'✓ Injected':'Error');if(!r.success)$b.prop('disabled',false)})});
    $('#op-mc').on('click',function(){$('#op-modal').hide()});$('#op-modal').on('click',function(e){if(e.target===this)$(this).hide()});
}

// ─── CRAWL DEPTH ────────

function initCrawl($c) {
    $c.html(`<div class="sseo-card"><h3>📊 Crawl Depth Analyzer</h3><p class="sseo-muted">Maps how many clicks each page is from the homepage. Pages at 5+ clicks depth get poor SEO value.</p><button class="sseo-btn-primary" id="cd-analyze">Analyze Crawl Depth</button><div id="cd-stats" style="display:none;margin:16px 0"></div><table class="sseo-table"><thead><tr><th>Page</th><th>Depth</th><th>Outbound Links</th><th>In Menu?</th><th>Type</th><th>Action</th></tr></thead><tbody id="cd-tbody"><tr><td colspan="6" class="sseo-loading">Click Analyze...</td></tr></tbody></table></div>`);
    $('#cd-analyze').on('click',function(){var $b=$(this);$b.text('Analyzing...').prop('disabled',true);$('#cd-tbody').html('<tr><td colspan="6" class="sseo-loading">Building link graph from homepage (BFS)...</td></tr>');ajax('crawl_analyze',{},function(r){$b.text('Analyze Crawl Depth').prop('disabled',false);if(!r.success){alert(r.data);return}var d=r.data;var h2='<div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:8px">';h2+='<span><strong>'+d.total+'</strong> pages · Avg depth: <strong>'+d.avg_depth+'</strong> · <strong style="color:'+(d.deep_pages?'#dc2626':'#16a34a')+'">'+d.deep_pages+'</strong> deep/unreachable</span></div>';h2+='<div style="display:flex;gap:8px;margin-bottom:8px">';var dist=d.distribution;for(var k in dist){var clr=k==='5+'||k==='unreachable'?'red':(parseInt(k)>=4?'orange':'green');h2+='<span class="sseo-tag '+clr+'">Depth '+k+': '+dist[k]+'</span>';}h2+='</div>';$('#cd-stats').html(h2).show();var h='';d.pages.forEach(function(p){if(p.depth!=='unreachable'&&p.depth<4)return;var dc=p.depth==='unreachable'?'#dc2626':p.depth>=5?'#dc2626':'#d97706';h+='<tr><td><a href="'+p.permalink+'" target="_blank">'+esc(trunc(p.title,35))+'</a></td><td><strong style="color:'+dc+'">'+p.depth+'</strong></td><td>'+p.outbound_links+'</td><td>'+(p.in_menu?'<span class="sseo-tag green">Yes</span>':'<span class="sseo-tag orange">No</span>')+'</td><td>'+p.post_type+'</td><td><button class="sseo-btn cd-related" data-id="'+p.post_id+'">Add Related</button></td></tr>'});if(!h)h='<tr><td colspan="6" class="sseo-loading">All pages are within healthy crawl depth! ✓</td></tr>';$('#cd-tbody').html(h)})});
    $(document).on('click','.cd-related',function(){var $b=$(this);$b.text('...').prop('disabled',true);ajax('crawl_add_related',{post_id:$b.data('id'),count:3},function(r){$b.text(r.success?'✓ '+r.data.links_added+' added':'Error').prop('disabled',!r.success?false:true);if(!r.success)alert(r.data)})});
}

// ─── ANCHOR TEXT FIXER ────────

function initAnchors($c) {
    $c.html(`<div class="sseo-card"><h3>🔗 Anchor Text Fixer</h3><p class="sseo-muted">Find generic anchors like "click here" and "read more", then AI-rewrite them with keyword-rich descriptive text.</p><button class="sseo-btn-primary" id="at-scan">Scan for Generic Anchors</button><div id="at-stats" style="display:none;margin:12px 0"></div><table class="sseo-table"><thead><tr><th>Page</th><th>Current Anchor</th><th>Links To</th><th>AI Suggestion</th><th>Action</th></tr></thead><tbody id="at-tbody"><tr><td colspan="5" class="sseo-loading">Click Scan...</td></tr></tbody></table><div style="margin-top:12px;display:none" id="at-bulk-wrap"><button class="sseo-btn-primary" id="at-bulk-ai">🤖 AI Rewrite All</button><span id="at-bulk-status" style="margin-left:8px;font-size:13px"></span></div></div>`);
    var scanData=[];
    $('#at-scan').on('click',function(){var $b=$(this);$b.text('Scanning...').prop('disabled',true);ajax('anchors_scan',{},function(r){$b.text('Scan for Generic Anchors').prop('disabled',false);if(!r.success)return;scanData=r.data.issues;$('#at-stats').html('<span style="color:'+(r.data.total?'#dc2626':'#16a34a')+'"><strong>'+r.data.total+'</strong> generic anchors found</span>').show();var h='';if(!r.data.total){h='<tr><td colspan="5" class="sseo-loading">No generic anchors found! ✓</td></tr>';}else{r.data.issues.forEach(function(a,i){h+='<tr data-idx="'+i+'"><td><a href="'+a.permalink+'" target="_blank">'+esc(trunc(a.post_title,25))+'</a></td><td><code style="color:#dc2626">'+esc(a.anchor_text)+'</code></td><td style="font-size:12px">'+esc(trunc(a.target_title||a.href,30))+'</td><td class="at-sug-cell" data-idx="'+i+'"><span class="sseo-muted">—</span></td><td class="at-act-cell" data-idx="'+i+'"></td></tr>'});$('#at-bulk-wrap').show();}$('#at-tbody').html(h)})});
    // Bulk AI rewrite
    $('#at-bulk-ai').on('click',function(){var $b=$(this);if(!scanData.length){alert('Scan first.');return;}$b.text('Generating...').prop('disabled',true);var batch=scanData.slice(0,50);ajax('anchors_ai_rewrite',{items:JSON.stringify(batch)},function(r){$b.text('🤖 AI Rewrite All').prop('disabled',false);if(!r.success){alert(r.data);return}$('#at-bulk-status').html('<span style="color:#16a34a">✓ '+r.data.suggestions.length+' suggestions generated</span>');r.data.suggestions.forEach(function(s){var i=s.index;var $sug=$('.at-sug-cell[data-idx="'+i+'"]');var $act=$('.at-act-cell[data-idx="'+i+'"]');$sug.html('<input class="sseo-input at-new-anchor" data-idx="'+i+'" value="'+escA(s.new)+'" style="font-size:12px;padding:4px 8px">');$act.html('<button class="sseo-btn at-apply" data-idx="'+i+'">Apply</button>')})})});
    // Apply single
    $(document).on('click','.at-apply',function(){var $b=$(this),i=$b.data('idx'),item=scanData[i];if(!item)return;var newAnc=$('.at-new-anchor[data-idx="'+i+'"]').val();if(!newAnc){alert('Enter new anchor text.');return}$b.prop('disabled',true).text('...');ajax('anchors_apply',{post_id:item.post_id,old_anchor:item.anchor_text,new_anchor:newAnc,href:item.href},function(r){$b.text(r.success?'✓ Applied':'Error')})});
}

// ─── SMART INTERNAL LINKER ────────

function initLinker($c) {
    $c.html(`
    <div class="sseo-card" style="margin-bottom:16px">
        <h3>🔗 Smart Internal Linker</h3>
        <p class="sseo-muted">Scans all pages for multi-word phrase matches and suggests contextual internal links. Uses 2-5 word anchor text — never single words.</p>
        <div style="display:flex;gap:8px;margin-top:12px">
            <button class="sseo-btn-primary" id="lnk-scan">⚡ Quick Scan (phrase matching)</button>
            <button class="sseo-btn-primary" id="lnk-ai" style="background:linear-gradient(135deg,#6366f1,#8b5cf6)">🤖 AI Deep Scan (semantic)</button>
        </div>
        <div id="lnk-status" style="margin-top:8px;font-size:13px"></div>
    </div>
    <div id="lnk-results" style="display:none">
        <div class="sseo-card">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
                <h3 id="lnk-title">Linking Opportunities</h3>
                <div style="display:flex;gap:8px"><button class="sseo-btn" id="lnk-select-all">Select All</button><button class="sseo-btn-primary" id="lnk-apply-selected">🔗 Apply Selected Links</button></div>
            </div>
            <div id="lnk-stats" style="font-size:13px;color:#64748b;margin-bottom:12px"></div>
            <table class="sseo-table"><thead><tr><th style="width:30px"><input type="checkbox" id="lnk-check-all"></th><th>Source Page</th><th>Anchor Text</th><th>Links To</th><th>Match</th><th>Action</th></tr></thead>
            <tbody id="lnk-tbody"></tbody></table>
        </div>
    </div>`);

    var allOpps = [];

    function renderResults(opps, stats_html, title) {
        allOpps = opps;
        $('#lnk-title').text(title || 'Linking Opportunities');
        $('#lnk-stats').html(stats_html);
        if (!opps.length) { $('#lnk-tbody').html('<tr><td colspan="6" class="sseo-loading">No opportunities found.</td></tr>'); $('#lnk-results').show(); return; }
        var h = '';
        opps.forEach(function(o, i) {
            var wbadge = o.word_count >= 3 ? 'green' : (o.word_count >= 2 ? 'blue' : 'orange');
            h += '<tr>';
            h += '<td><input type="checkbox" class="lnk-cb" data-idx="' + i + '"></td>';
            h += '<td style="font-size:13px"><strong>' + esc(trunc(o.source_title, 30)) + '</strong></td>';
            h += '<td><input class="sseo-input lnk-anchor" data-idx="' + i + '" value="' + escA(o.anchor) + '" style="font-size:13px;padding:4px 8px;min-width:180px;font-weight:600;color:#6366f1"></td>';
            h += '<td style="font-size:12px"><a href="' + esc(o.target_url) + '" target="_blank">' + esc(trunc(o.target_title, 28)) + '</a></td>';
            h += '<td><span class="sseo-tag ' + wbadge + '">' + (o.word_count || '?') + ' words</span>' + (o.ai_suggested ? ' <span class="sseo-tag" style="background:#eff6ff;color:#6366f1">AI</span>' : '') + (o.reason ? '<div style="font-size:10px;color:#94a3b8;margin-top:2px">' + esc(o.reason) + '</div>' : '') + '</td>';
            h += '<td><button class="sseo-btn lnk-apply-one" data-idx="' + i + '">Apply</button></td>';
            h += '</tr>';
        });
        $('#lnk-tbody').html(h);
        $('#lnk-results').show();
    }

    // Quick scan
    $('#lnk-scan').on('click', function() {
        var $b = $(this); $b.text('Scanning...').prop('disabled', true);
        $('#lnk-status').html('<span style="color:#6366f1">Scanning all pages for phrase matches...</span>');
        ajax('linker_scan', {}, function(r) {
            $b.text('⚡ Quick Scan (phrase matching)').prop('disabled', false);
            if (!r.success) { $('#lnk-status').html('<span style="color:#dc2626">' + esc(r.data) + '</span>'); return; }
            var d = r.data;
            $('#lnk-status').html('<span style="color:#16a34a">✓ Found ' + d.total + ' opportunities across ' + d.pages_with_opportunities + ' pages (' + d.pages_scanned + ' scanned)</span>');
            renderResults(d.opportunities, d.pages_scanned + ' pages scanned · ' + d.total + ' link opportunities · ' + d.pages_with_opportunities + ' pages need links', 'Phrase-Matched Opportunities (' + d.total + ')');
        });
    });

    // AI scan
    $('#lnk-ai').on('click', function() {
        var $b = $(this); $b.text('AI analyzing...').prop('disabled', true);
        $('#lnk-status').html('<span style="color:#6366f1">AI is analyzing content relationships (15-30 sec)...</span>');
        ajax('linker_ai_scan', { limit: 20 }, function(r) {
            $b.text('🤖 AI Deep Scan (semantic)').prop('disabled', false);
            if (!r.success) { $('#lnk-status').html('<span style="color:#dc2626">' + esc(r.data) + '</span>'); return; }
            var d = r.data;
            $('#lnk-status').html('<span style="color:#16a34a">✓ AI suggested ' + d.suggestions.length + ' links (' + d.tokens + ' tokens)</span>');
            renderResults(d.suggestions, 'AI-powered semantic analysis · ' + d.suggestions.length + ' suggestions · ' + d.tokens + ' tokens used', 'AI-Suggested Links (' + d.suggestions.length + ')');
        });
    });

    // Apply single
    $(document).on('click', '.lnk-apply-one', function() {
        var idx = $(this).data('idx'), $b = $(this);
        var o = allOpps[idx];
        var anchor = $('.lnk-anchor[data-idx="' + idx + '"]').val() || o.anchor;
        $b.text('Applying...').prop('disabled', true);
        ajax('linker_apply', { source_id: o.source_id, anchor: anchor, target_url: o.target_url }, function(r) {
            if (r.success) {
                $b.text('✓ Done').css('color', '#16a34a');
                $b.closest('tr').css('opacity', '0.5');
            } else {
                $b.text('Failed').css('color', '#dc2626').prop('disabled', false);
                alert(r.data);
            }
        });
    });

    // Select all / check all
    $('#lnk-check-all').on('change', function() { $('.lnk-cb').prop('checked', $(this).is(':checked')); });
    $('#lnk-select-all').on('click', function() { $('.lnk-cb').prop('checked', true); $('#lnk-check-all').prop('checked', true); });

    // Apply selected
    $('#lnk-apply-selected').on('click', function() {
        var links = [];
        $('.lnk-cb:checked').each(function() {
            var idx = $(this).data('idx');
            var o = allOpps[idx];
            var anchor = $('.lnk-anchor[data-idx="' + idx + '"]').val() || o.anchor;
            links.push({ source_id: o.source_id, anchor: anchor, target_url: o.target_url });
        });
        if (!links.length) { alert('Select some links first.'); return; }
        if (!confirm('Apply ' + links.length + ' internal links?')) return;
        var $b = $(this); $b.text('Applying ' + links.length + ' links...').prop('disabled', true);
        ajax('linker_apply_bulk', { links: JSON.stringify(links) }, function(r) {
            $b.text('🔗 Apply Selected Links').prop('disabled', false);
            if (r.success) {
                var d = r.data;
                alert(d.applied + ' of ' + d.total + ' links applied successfully.');
                // Dim applied rows
                d.results.forEach(function(res, i) {
                    if (res.applied) {
                        var $row = $('.lnk-cb:checked').eq(i).closest('tr');
                        $row.css('opacity', '0.5');
                        $row.find('.lnk-apply-one').text('✓ Done').css('color', '#16a34a');
                    }
                });
            } else alert(r.data);
        });
    });
}

// ─── REDIRECT CHAINS ────────

function initChains($c) {
    $c.html(`<div class="sseo-card"><h3>🔄 Redirect Chain Detector</h3><p class="sseo-muted">Find redirect chains (A→B→C) and flatten them to direct A→C for better crawl efficiency.</p><button class="sseo-btn-primary" id="rc-scan">Scan for Chains</button><div id="rc-stats" style="display:none;margin:12px 0"></div><table class="sseo-table"><thead><tr><th>Chain</th><th>Length</th><th>Source</th><th>Current Target</th><th>Final Destination</th><th>Action</th></tr></thead><tbody id="rc-tbody"><tr><td colspan="6" class="sseo-loading">Click Scan...</td></tr></tbody></table><div style="margin-top:12px;display:flex;gap:8px"><button class="sseo-btn-primary" id="rc-flatten-all" style="display:none">⚡ Flatten All Chains</button><button class="sseo-btn" id="rc-fix-content" style="display:none">🔗 Update Content Links Too</button><span id="rc-status" style="margin-left:8px;font-size:13px"></span></div></div>`);
    $('#rc-scan').on('click',function(){var $b=$(this);$b.text('Scanning...').prop('disabled',true);ajax('chains_scan',{},function(r){$b.text('Scan for Chains').prop('disabled',false);if(!r.success)return;var d=r.data;$('#rc-stats').html('<span><strong>'+d.total+'</strong> redirect chains found · <strong>'+d.total_refs+'</strong> content links affected</span>').show();var h='';if(!d.total){h='<tr><td colspan="6" class="sseo-loading">No redirect chains found! ✓</td></tr>';}else{$('#rc-flatten-all,#rc-fix-content').show();d.chains.forEach(function(c){h+='<tr><td style="font-size:11px">'+c.chain.map(function(p){return '<code>'+esc(p)+'</code>'}).join(' → ')+'</td><td><span class="sseo-tag '+(c.chain_length>2?'red':'orange')+'">'+c.chain_length+' hops</span></td><td><code>'+esc(c.source)+'</code></td><td><code style="color:#d97706">'+esc(c.current_target)+'</code></td><td><code style="color:#16a34a">'+esc(c.final)+'</code></td><td><button class="sseo-btn rc-fix" data-id="'+c.id+'" data-final="'+escA(c.final)+'">Flatten</button></td></tr>'});}$('#rc-tbody').html(h)})});
    $(document).on('click','.rc-fix',function(){var $b=$(this);$b.prop('disabled',true).text('...');ajax('chains_flatten',{id:$b.data('id'),final:$b.data('final')},function(r){$b.text(r.success?'✓ Flattened':'Error')})});
    $('#rc-flatten-all').on('click',function(){if(!confirm('Flatten all redirect chains?'))return;var $b=$(this);$b.text('Flattening...').prop('disabled',true);ajax('chains_flatten_all',{},function(r){$b.text('⚡ Flatten All Chains').prop('disabled',false);$('#rc-status').html(r.success?'<span style="color:#16a34a">✓ '+r.data.fixed+'/'+r.data.total_chains+' chains flattened</span>':'Error');if(r.success)$('#rc-scan').click()})});
    $('#rc-fix-content').on('click',function(){if(!confirm('Update all content links that point to redirect sources → point to final destinations?'))return;var $b=$(this);$b.text('Fixing...').prop('disabled',true);ajax('chains_fix_content',{},function(r){$b.text('🔗 Update Content Links Too').prop('disabled',false);$('#rc-status').html(r.success?'<span style="color:#16a34a">✓ '+r.data.links_fixed+' links updated across '+r.data.posts_fixed+' posts</span>':'Error')})});
}

// ─── IMAGE OPTIMIZER ────────

function initImgOpt($c) {
    $c.html(`
    <div id="io-pagespeed" class="sseo-card" style="margin-bottom:20px">
        <h3>🚀 PageSpeed Insights</h3>
        <p class="sseo-muted">Check your site's performance score directly from Google.</p>
        <div style="display:flex;gap:10px;align-items:end;margin:12px 0">
            <div class="sseo-field" style="flex:1;margin:0"><label>URL</label><input class="sseo-input" id="io-ps-url" placeholder="Leave blank for homepage"></div>
            <div class="sseo-field" style="margin:0"><label>Device</label><select class="sseo-select-full" id="io-ps-strategy"><option value="mobile">Mobile</option><option value="desktop">Desktop</option></select></div>
            <button class="sseo-btn-primary" id="io-ps-run">Run Test</button>
        </div>
        <div id="io-ps-results" style="display:none"></div>
    </div>

    <div class="sseo-card" style="margin-bottom:20px">
        <h3>🔍 Image Scan</h3>
        <p class="sseo-muted">Scan your media library and content for optimization opportunities.</p>
        <button class="sseo-btn-primary" id="io-scan">Scan All Images</button>
        <div id="io-scan-results" style="display:none;margin-top:16px"></div>
    </div>

    <div id="io-webp-section" style="display:none" class="sseo-card" style="margin-bottom:20px">
        <h3>🖼️ WebP Conversion</h3>
        <div style="display:flex;gap:10px;align-items:center;margin-bottom:12px">
            <div class="sseo-field" style="margin:0"><label>Quality (1-100)</label><input type="number" class="sseo-input" id="io-webp-quality" value="80" min="1" max="100" style="width:80px"></div>
            <button class="sseo-btn" id="io-webp-all">Select All</button>
            <button class="sseo-btn-primary" id="io-webp-convert" disabled>Convert Selected to WebP</button>
            <label class="sseo-cb-label"><input type="checkbox" id="io-serve-webp" checked> Auto-serve WebP on frontend</label>
        </div>
        <table class="sseo-table"><thead><tr><th class="sseo-check-col"><input type="checkbox" id="io-webp-ca"></th><th>Thumb</th><th>Filename</th><th>Size</th><th>Type</th></tr></thead>
        <tbody id="io-webp-tbody"></tbody></table>
    </div>

    <div id="io-fixes-section" style="display:none" class="sseo-card">
        <h3>⚡ Quick Fixes</h3>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
            <div style="border:1px solid #e2e8f0;border-radius:10px;padding:16px">
                <h4 style="margin:0 0 6px;font-size:14px">📐 Missing Dimensions</h4>
                <p class="sseo-muted" id="io-dims-count">— images missing width/height</p>
                <p style="font-size:12px;color:#64748b;margin:4px 0 10px">Adds explicit width="" height="" to prevent CLS layout shifts.</p>
                <button class="sseo-btn-primary" id="io-fix-dims">Fix All Dimensions</button>
                <span id="io-dims-status" style="margin-left:8px;font-size:13px"></span>
            </div>
            <div style="border:1px solid #e2e8f0;border-radius:10px;padding:16px">
                <h4 style="margin:0 0 6px;font-size:14px">💤 Smart Lazy Loading</h4>
                <p class="sseo-muted" id="io-lazy-count">— images missing lazy loading</p>
                <p style="font-size:12px;color:#64748b;margin:4px 0 10px">Adds loading="lazy" to below-fold images, removes it from LCP image, adds fetchpriority="high" to first image.</p>
                <button class="sseo-btn-primary" id="io-fix-lazy">Fix All Lazy Loading</button>
                <span id="io-lazy-status" style="margin-left:8px;font-size:13px"></span>
            </div>
        </div>
        <div style="border:1px solid #e2e8f0;border-radius:10px;padding:16px">
            <h4 style="margin:0 0 6px;font-size:14px">🎯 LCP Preload</h4>
            <p style="font-size:12px;color:#64748b;margin:4px 0 10px">Adds &lt;link rel="preload"&gt; for your hero/banner image in &lt;head&gt; to speed up LCP.</p>
            <div style="display:flex;gap:10px;align-items:end">
                <div class="sseo-field" style="flex:1;margin:0"><label>LCP Image URL (leave blank to auto-detect)</label><input class="sseo-input" id="io-lcp-url" placeholder="https://yoursite.com/wp-content/uploads/hero.jpg"></div>
                <label class="sseo-cb-label"><input type="checkbox" id="io-lcp-enable" checked> Enable</label>
                <button class="sseo-btn-primary" id="io-lcp-save">Save</button>
            </div>
            <span id="io-lcp-status" style="font-size:13px"></span>
        </div>
    </div>

    <div class="sseo-progress-wrap" id="io-progress" style="display:none">
        <div class="sseo-progress-header"><h3>Converting...</h3><span id="io-prog-text"></span></div>
        <div class="sseo-progress-bar"><div class="sseo-progress-fill" id="io-prog-fill"></div></div>
        <div class="sseo-progress-log" id="io-prog-log"></div>
    </div>
    `);

    // ── PageSpeed ──
    $('#io-ps-run').on('click',function(){
        var $b=$(this);$b.text('Testing...').prop('disabled',true);
        var url = $('#io-ps-url').val() || '';
        ajax('imgopt_pagespeed',{url:url,strategy:$('#io-ps-strategy').val()},function(r){
            $b.text('Run Test').prop('disabled',false);
            if(!r.success){$('#io-ps-results').html('<div class="sseo-notice sseo-notice-err">'+esc(r.data)+'</div>').show();return}
            var d=r.data, h='';
            // Score cards
            h+='<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:16px 0">';
            for(var k in d.scores){
                var s=d.scores[k]; var clr=s.score>=90?'#16a34a':s.score>=50?'#d97706':'#dc2626';
                h+='<div style="text-align:center;padding:16px;border-radius:10px;border:2px solid '+clr+'20;background:'+clr+'08">';
                h+='<div style="font-size:32px;font-weight:900;color:'+clr+'">'+s.score+'</div>';
                h+='<div style="font-size:11px;font-weight:600;color:#64748b;text-transform:uppercase;letter-spacing:1px">'+esc(s.title)+'</div></div>';
            }
            h+='</div>';
            // Core Web Vitals
            if(d.cwv&&d.cwv.length){
                h+='<h4 style="margin:16px 0 8px;font-size:14px">Core Web Vitals</h4><table class="sseo-table"><thead><tr><th>Metric</th><th>Value</th><th>Score</th><th>Status</th></tr></thead><tbody>';
                d.cwv.forEach(function(v){
                    var clr=v.rating==='good'?'green':v.rating==='needs_work'?'orange':'red';
                    h+='<tr><td><strong>'+esc(v.label)+'</strong></td><td>'+esc(v.value)+'</td><td>'+v.score+'</td><td><span class="sseo-tag '+clr+'">'+v.rating.replace('_',' ').toUpperCase()+'</span></td></tr>';
                });
                h+='</tbody></table>';
            }
            // Image opportunities
            if(d.img_opps&&d.img_opps.length){
                h+='<h4 style="margin:16px 0 8px;font-size:14px;color:#d97706">Image Optimization Opportunities</h4>';
                d.img_opps.forEach(function(o){
                    h+='<div style="padding:8px 12px;margin:4px 0;background:#fef3c7;border-radius:6px;font-size:13px"><strong>'+esc(o.title)+'</strong>';
                    if(o.savings) h+=' — <span style="color:#d97706">'+esc(o.savings)+'</span>';
                    h+='</div>';
                });
            }
            h+='<p style="font-size:11px;color:#94a3b8;margin-top:8px">Tested: '+esc(d.date)+' · '+esc(d.strategy)+' · '+esc(d.url)+'</p>';
            $('#io-ps-results').html(h).show();
        });
    });

    // ── Scan ──
    $('#io-scan').on('click',function(){
        var $b=$(this);$b.text('Scanning...').prop('disabled',true);
        ajax('imgopt_scan',{},function(r){
            $b.text('Scan All Images').prop('disabled',false);
            if(!r.success){alert(r.data);return}
            var d=r.data, h='';
            // Summary cards
            h+='<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px">';
            h+='<div style="text-align:center;padding:14px;border-radius:8px;border:1px solid #e2e8f0"><div style="font-size:24px;font-weight:800;color:'+(d.webp_needed.length?'#dc2626':'#16a34a')+'">'+d.webp_needed.length+'</div><div style="font-size:11px;color:#64748b">Need WebP</div></div>';
            h+='<div style="text-align:center;padding:14px;border-radius:8px;border:1px solid #e2e8f0"><div style="font-size:24px;font-weight:800;color:'+(d.missing_dims.length?'#d97706':'#16a34a')+'">'+d.missing_dims.length+'</div><div style="font-size:11px;color:#64748b">Missing Dimensions</div></div>';
            h+='<div style="text-align:center;padding:14px;border-radius:8px;border:1px solid #e2e8f0"><div style="font-size:24px;font-weight:800;color:'+(d.missing_lazy.length?'#d97706':'#16a34a')+'">'+d.missing_lazy.length+'</div><div style="font-size:11px;color:#64748b">Missing Lazy Load</div></div>';
            h+='<div style="text-align:center;padding:14px;border-radius:8px;border:1px solid #e2e8f0"><div style="font-size:24px;font-weight:800;color:#2563eb">'+(d.gd_webp_support?'✓':'✗')+'</div><div style="font-size:11px;color:#64748b">GD WebP Support</div></div>';
            h+='</div>';
            if(!d.gd_webp_support) h+='<div class="sseo-notice sseo-notice-err">Your server PHP ('+esc(d.php_version)+') does not have GD WebP support. Ask your host to enable it.</div>';
            $('#io-scan-results').html(h).show();

            // Show WebP section
            if(d.webp_needed.length){
                var th='';
                d.webp_needed.forEach(function(img){
                    th+='<tr><td class="sseo-check-col"><input type="checkbox" class="io-webp-cb" value="'+img.id+'"></td>';
                    th+='<td><img class="sseo-thumb" src="'+escA(img.thumbnail)+'" alt=""></td>';
                    th+='<td>'+esc(img.filename)+'</td>';
                    th+='<td>'+esc(img.size_human)+'</td>';
                    th+='<td><span class="sseo-tag orange">'+esc(img.mime.replace('image/','').toUpperCase())+'</span></td></tr>';
                });
                $('#io-webp-tbody').html(th);
                $('#io-webp-section').show();
            }

            // Show fixes section
            $('#io-dims-count').text(d.missing_dims.length+' images missing width/height');
            $('#io-lazy-count').text(d.missing_lazy.length+' images missing lazy loading');
            if(d.lcp_status.image) $('#io-lcp-url').val(d.lcp_status.image);
            $('#io-lcp-enable').prop('checked',d.lcp_status.enabled);
            $('#io-fixes-section').show();
        });
    });

    // ── WebP checkboxes ──
    $('#io-webp-ca').on('change',function(){$('.io-webp-cb').prop('checked',this.checked);updWebp()});
    $('#io-webp-all').on('click',function(){$('.io-webp-cb').prop('checked',true);updWebp()});
    $(document).on('change','.io-webp-cb',updWebp);
    function updWebp(){var n=$('.io-webp-cb:checked').length;$('#io-webp-convert').prop('disabled',!n).text(n?'Convert '+n+' to WebP':'Convert Selected to WebP');}

    // ── WebP Convert ──
    $('#io-webp-convert').on('click',function(){
        var ids=[];$('.io-webp-cb:checked').each(function(){ids.push($(this).val())});
        if(!ids.length)return;
        if(!confirm('Convert '+ids.length+' images to WebP?'))return;
        var quality=parseInt($('#io-webp-quality').val())||80;
        $('#io-progress').show();$('#io-prog-log').html('');$('#io-prog-fill').css('width','0%');
        var done=0,totalSaved=0;
        function next(i){
            if(i>=ids.length){
                $('#io-prog-text').text('✅ Done! '+done+'/'+ids.length+' converted, saved '+formatBytes(totalSaved));
                $('#io-prog-fill').css('width','100%');
                // Enable auto-serve
                if($('#io-serve-webp').is(':checked')){
                    ajax('imgopt_save_lcp',{serve_webp:1,enabled:$('#io-lcp-enable').is(':checked')?1:0,lcp_url:$('#io-lcp-url').val()},function(){});
                }
                return;
            }
            $('#io-prog-text').text((i+1)+'/'+ids.length);
            $('#io-prog-fill').css('width',((i+1)/ids.length*100)+'%');
            ajax('imgopt_convert_webp',{attachment_id:ids[i],quality:quality},function(r){
                if(r.success){
                    done++;
                    totalSaved += r.data.original_size - r.data.webp_size;
                    $('#io-prog-log').append('<div class="sseo-log-ok">✓ #'+ids[i]+' — saved '+r.data.savings_pct+'% ('+r.data.sizes_converted.length+' sizes)</div>');
                } else {
                    $('#io-prog-log').append('<div class="sseo-log-err">✗ #'+ids[i]+': '+esc(r.data)+'</div>');
                }
                $('#io-prog-log').scrollTop($('#io-prog-log')[0].scrollHeight);
                next(i+1);
            });
        }
        next(0);
    });

    // ── Fix Dimensions ──
    $('#io-fix-dims').on('click',function(){
        var $b=$(this);$b.text('Fixing...').prop('disabled',true);
        ajax('imgopt_fix_dims',{},function(r){
            $b.text('Fix All Dimensions').prop('disabled',false);
            if(r.success) $('#io-dims-status').html('<span style="color:#16a34a">✓ '+r.data.images_fixed+' images fixed across '+r.data.posts_scanned+' posts</span>');
            else $('#io-dims-status').html('<span style="color:#dc2626">Error</span>');
        });
    });

    // ── Fix Lazy ──
    $('#io-fix-lazy').on('click',function(){
        var $b=$(this);$b.text('Fixing...').prop('disabled',true);
        ajax('imgopt_fix_lazy',{},function(r){
            $b.text('Fix All Lazy Loading').prop('disabled',false);
            if(r.success) $('#io-lazy-status').html('<span style="color:#16a34a">✓ '+r.data.images_fixed+' images fixed across '+r.data.posts_scanned+' posts + smart lazy enabled</span>');
            else $('#io-lazy-status').html('<span style="color:#dc2626">Error</span>');
        });
    });

    // ── LCP Save ──
    $('#io-lcp-save').on('click',function(){
        ajax('imgopt_save_lcp',{enabled:$('#io-lcp-enable').is(':checked')?1:0,lcp_url:$('#io-lcp-url').val(),serve_webp:$('#io-serve-webp').is(':checked')?1:0},function(r){
            $('#io-lcp-status').html(r.success?'<span style="color:#16a34a;margin-left:8px">✓ Saved</span>':'<span style="color:#dc2626;margin-left:8px">Error</span>');
        });
    });

    function formatBytes(b){if(b<1024)return b+' B';if(b<1048576)return (b/1024).toFixed(1)+' KB';return (b/1048576).toFixed(1)+' MB';}
}

// ─── GLOBAL: Edit / Cancel / Char Counter ────────

// Edit button — toggle text to textarea
$(document).on('click','.sseo-edit-btn',function(){
    var $item = $(this).closest('.sseo-result-item');
    $item.find('.sseo-editable-text').hide();
    $item.find('.sseo-edit-area').show().focus();
    $(this).hide();
    $item.find('.sseo-cancel-edit').show();
    // Trigger char count update
    $item.find('.sseo-edit-area').trigger('input');
});

// Cancel edit — revert to text
$(document).on('click','.sseo-cancel-edit',function(){
    var $item = $(this).closest('.sseo-result-item');
    $item.find('.sseo-edit-area').hide();
    $item.find('.sseo-editable-text').show();
    $(this).hide();
    $item.find('.sseo-edit-btn').show();
});

// Live char counter on edit areas
$(document).on('input','.sseo-edit-area',function(){
    var len = $(this).val().length;
    var $item = $(this).closest('.sseo-result-item');
    var $cc = $item.find('.sseo-charcount');
    if($cc.length){
        $cc.text(len+' chars');
        $cc.removeClass('sseo-char-ok sseo-char-warn sseo-char-bad');
        // Detect which range based on context
        var min=50,max=160;
        if($item.find('.sseo-apply-meta').length){min=150;max=160;}
        else if($item.find('.sseo-apply-alt').length){min=80;max=125;}
        else if($item.find('.sseo-apply-title').length){min=50;max=60;}
        else{min=40;max=70;} // H1
        $cc.addClass(charCls(len,min,max));
    }
    // Update copy button data
    var $copy = $item.find('.sseo-copy');
    if($copy.length) $copy.data('text',$(this).val());
});

// Inline edit meta from table — opens a quick modal
$(document).on('click','.sseo-inline-edit-meta',function(){
    var id=$(this).data('id'), meta=$(this).data('meta')||'';
    var isNew = !meta;
    var charCount = meta.length;
    var h='<div class="sseo-result-item">';
    h+='<div class="sseo-field"><label>'+(isNew?'Write New Meta Description':'Edit Meta Description')+'</label>';
    h+='<textarea class="sseo-edit-area" id="sseo-inline-meta-area" style="width:100%;min-height:80px;padding:10px;border:2px solid #6366f1;border-radius:6px;font-size:14px;line-height:1.5" placeholder="Write a compelling 150-160 character meta description...">'+escA(meta)+'</textarea></div>';
    h+='<div style="display:flex;justify-content:space-between;align-items:center"><span class="sseo-charcount '+charCls(charCount,150,160)+'">'+(charCount||0)+' chars</span>';
    h+='<div class="sseo-result-actions"><button class="button button-primary" id="sseo-inline-meta-save" data-pid="'+id+'">Save</button> <button class="button sseo-gen-meta" data-id="'+id+'" style="margin-left:4px">🤖 Generate AI</button> <button class="button" id="sseo-inline-meta-cancel">Cancel</button></div></div>';
    h+='</div>';
    $('#sseo-mmb').html(h);
    $('#sseo-mmt').text(isNew?'Write Meta Description':'Edit Meta Description');
    $('#sseo-mm').show();
    $('#sseo-inline-meta-area').focus();
    // Live counter
    $('#sseo-inline-meta-area').on('input',function(){
        var len=$(this).val().length;
        $(this).closest('.sseo-result-item').find('.sseo-charcount').text(len+' chars').removeClass('sseo-char-ok sseo-char-warn sseo-char-bad').addClass(charCls(len,150,160));
    });
});
$(document).on('click','#sseo-inline-meta-save',function(){
    var $b=$(this), pid=$b.data('pid'), desc=$('#sseo-inline-meta-area').val();
    if(!desc.trim()){alert('Please enter a meta description.');return;}
    $b.prop('disabled',true).text('Saving...');
    ajax('apply_meta',{post_id:pid,description:desc},function(r){
        $b.text(r.success?'✓ Saved':'Error');
        if(r.success) setTimeout(function(){
            $('#sseo-mm').hide();
            // Refresh the table — find the load function via refresh button
            $('#sseo-mr').click();
        },600);
        else $b.prop('disabled',false).text('Save');
    });
});
$(document).on('click','#sseo-inline-meta-cancel',function(){$('#sseo-mm').hide()});

// ─── SHARED: Recent Changes Panel ────────

function loadRecentChanges(containerId, type, label) {
    ajax('get_recent_changes',{type:type,limit:30},function(r){
        if(!r.success||!r.data.changes.length){$('#'+containerId).html('<p class="sseo-muted">No changes yet.</p>');return}
        var h='<details class="sseo-changes-panel"><summary class="sseo-changes-toggle">📋 Recent '+label+' Changes ('+r.data.total+')</summary>';
        h+='<table class="sseo-table" style="margin-top:8px"><thead><tr><th>Image</th><th>Before</th><th>After</th><th>Date</th></tr></thead><tbody>';
        r.data.changes.forEach(function(c){
            h+='<tr>';
            h+='<td style="display:flex;align-items:center;gap:8px">'+(c.thumbnail?'<img src="'+escA(c.thumbnail)+'" style="width:32px;height:32px;border-radius:4px;object-fit:cover">':'')+'<span style="font-size:12px">'+esc(c.item_name||'#'+c.post_id)+'</span></td>';
            h+='<td style="font-size:12px;color:#dc2626;max-width:200px;overflow:hidden;text-overflow:ellipsis">'+(c.old_value?'<code>'+esc(c.old_value.substring(0,60))+'</code>':'<span class="sseo-muted">— empty —</span>')+'</td>';
            h+='<td style="font-size:12px;color:#16a34a;max-width:200px;overflow:hidden;text-overflow:ellipsis"><code>'+esc(c.new_value.substring(0,60))+'</code></td>';
            h+='<td style="font-size:11px;color:#94a3b8;white-space:nowrap">'+esc(c.created_at||'')+'</td>';
            h+='</tr>';
        });
        h+='</tbody></table></details>';
        $('#'+containerId).html(h);
    });
}

// ─── Copy ────────

$(document).on('click','.sseo-copy',function(){var $b=$(this),t=$b.data('text');if(navigator.clipboard)navigator.clipboard.writeText(t);else{var $t=$('<textarea>').val(t).appendTo('body').select();document.execCommand('copy');$t.remove();}$b.text('Copied!');setTimeout(function(){$b.text('Copy')},1200)});

// ─── Shared Ignore ────────
$(document).on('click','.sseo-thin-ignore',function(){var $b=$(this),id=$b.data('id');$b.text('...').prop('disabled',true);ajax('thin_ignore',{post_id:id},function(r){if(r.success){$b.closest('tr').fadeOut(300,function(){$(this).remove()});}else{$b.text('👁').prop('disabled',false);}});});

})(jQuery);
