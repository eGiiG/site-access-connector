<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Content_Generator {
    private $api;

    public function __construct() {
        $this->api = new SSEO_API_Handler();
    }

    private function get_local_context( $scope = 'local' ) {
        if ( $scope !== 'local' ) return '';
        $brand   = get_option('sseo_brand_name','');
        $phone   = get_option('sseo_business_phone','');
        $addr    = get_option('sseo_business_address','');
        $city    = get_option('sseo_business_city','');
        $state   = get_option('sseo_business_state','');
        $zip     = get_option('sseo_business_zip','');
        $email   = get_option('sseo_business_email','');
        $loc     = get_option('sseo_target_location','');
        $services= get_option('sseo_business_services','');
        $hours   = get_option('sseo_business_hours','');
        $founded = get_option('sseo_business_founded','');
        $license = get_option('sseo_business_license','');
        $rating  = get_option('sseo_avg_rating','');
        $reviews = get_option('sseo_review_count','');

        $ctx = "\n\nLOCAL SEO CONTEXT (weave naturally throughout):\n";
        $ctx .= "Business: {$brand}\n";
        if ($phone) $ctx .= "Phone: {$phone}\n";
        if ($addr) $ctx .= "Address: {$addr}, {$city}, {$state} {$zip}\n";
        if ($email) $ctx .= "Email: {$email}\n";
        if ($loc) $ctx .= "Service Areas: {$loc}\n";
        if ($services) $ctx .= "Services: {$services}\n";
        if ($hours) $ctx .= "Hours: {$hours}\n";
        if ($founded) $ctx .= "Founded: {$founded}\n";
        if ($license) $ctx .= "License: {$license}\n";
        if ($rating && $reviews) $ctx .= "Rating: {$rating}/5 from {$reviews} reviews\n";

        $ctx .= "\nLOCAL SEO RULES:\n";
        $ctx .= "- Mention the primary city/area 4-8 times naturally\n";
        $ctx .= "- Use geo-modified keywords (e.g. 'kitchen remodeling {$city}')\n";
        $ctx .= "- Include the full NAP (Name, Address, Phone) at least once\n";
        $ctx .= "- Add a Service Areas section listing all cities served\n";
        $ctx .= "- Include CTAs with the phone number\n";
        $ctx .= "- Mention years of experience, license numbers, ratings when relevant\n";
        $ctx .= "- For FAQ sections, include location-specific questions\n";

        return $ctx;
    }

    private function get_template_structure( $template, $word_count = 1200 ) {
        if ( empty($template) ) return '';
        $structures = [
            'service_page' => "TEMPLATE: SERVICE PAGE\n1. H1: [Service] in [City]\n2. Intro: Hook, mention city, establish expertise (150-200 words)\n3. H2: Why Choose [Brand] for [Service] — 4-5 detailed benefits (200-300 words)\n4. H2: Our [Service] Process — numbered steps with descriptions (200-300 words)\n5. H2: What Is Included — comprehensive checklist with explanations (150-200 words)\n6. H2: [Service] Cost Factors in [City] — realistic ranges, factors, financing (150-200 words)\n7. H2: Recent Projects — 2-3 descriptions with IMAGE placeholders (150-200 words)\n8. H2: Frequently Asked Questions — 5-7 H3 questions ending with ? (300-400 words)\n9. H2: Areas We Serve — city list with descriptions (100-150 words)\n10. H2: Ready to Start? — CTA with phone and next steps (100-150 words)",

            'about_us' => "TEMPLATE: ABOUT US PAGE\n1. H1: About [Brand]\n2. Intro: Brand story hook (150 words)\n3. H2: Our Story — milestones, founding (200-300 words)\n4. H2: Our Mission and Values (150-200 words)\n5. H2: What Sets Us Apart — 4-5 differentiators (250-300 words)\n6. H2: Our Team — expertise, certifications (150-200 words)\n7. H2: Credentials — license, insurance, awards (100-150 words)\n8. H2: Our Service Area (150-200 words)\n9. H2: What Our Customers Say — testimonial quotes (150 words)\n10. H2: Contact Us Today — CTA with full NAP (100 words)",

            'contact' => "TEMPLATE: CONTACT PAGE\n1. H1: Contact [Brand]\n2. Intro (100 words)\n3. H2: Get In Touch — NAP display (100 words)\n4. H2: Request a Free Estimate — form placeholder (100 words)\n5. H2: Business Hours (50 words)\n6. H2: Our Service Area — all cities (150-200 words)\n7. H2: Visit Our Location — MAP PLACEHOLDER (100 words)\n8. H2: FAQ — 3-4 contact FAQs (200 words)",

            'faq_page' => "TEMPLATE: FAQ PAGE\n1. H1: Frequently Asked Questions\n2. Intro (100-150 words)\n3. H2: General Questions — 4-5 H3 questions ENDING WITH ? (400-500 words)\n4. H2: Pricing Questions — 3-4 H3 questions (300 words)\n5. H2: Process Questions — 3-4 H3 questions (300 words)\n6. H2: Service Area Questions — 2-3 H3 questions (200 words)\n7. H2: Still Have Questions? — CTA (100 words)\nCRITICAL: Every H3 must be a question ending with ? for FAQ schema",

            'service_area' => "TEMPLATE: SERVICE AREA PAGE\n1. H1: [Service] in [Target City], [State]\n2. Intro: Why residents choose [Brand] (150-200 words)\n3. H2: Our Services in [City] (250-300 words)\n4. H2: Why [City] Homeowners Trust [Brand] (200-250 words)\n5. H2: Recent Projects in [City] — IMAGE placeholders (200 words)\n6. H2: [City] Neighborhoods We Serve — 6-10 neighborhoods (200 words)\n7. H2: FAQ for [City] Residents — 4-5 H3 questions (300 words)\n8. H2: Local Resources — permits, codes (100-150 words)\n9. H2: Get Started in [City] — CTA (100 words)",

            'landing_page' => "TEMPLATE: LANDING PAGE\n1. H1: Compelling value proposition headline\n2. Intro: Pain point, solution, credibility (150-200 words)\n3. H2: Benefits — 4-5 detailed (250-300 words)\n4. H2: How It Works — 3-4 steps (200 words)\n5. H2: What Customers Say — 3 testimonials (200 words)\n6. H2: Why Choose Us — credentials, stats (150-200 words)\n7. H2: Common Questions — 3-4 FAQ items (200-250 words)\n8. H2: CTA with urgency (150 words)",

            'blog_post' => "TEMPLATE: BLOG POST\n1. H1: Engaging keyword-rich headline\n2. Intro: Hook with question/statistic (150-200 words)\n3. H2: Main topic deep dive with H3 subsections (300-400 words)\n4. H2: Supporting information, data, examples (300-400 words)\n5. H2: Practical advice, tips (250-300 words)\n6. H2: Case study or real example (200-250 words)\n7. H2: Expert Tips (150-200 words)\n8. H2: FAQ — 3-5 H3 questions (250-300 words)\n9. H2: Conclusion with CTA (100-150 words)",

            'testimonials' => "TEMPLATE: TESTIMONIALS PAGE\n1. H1: What Our Customers Say\n2. Intro: Rating average, review count (100 words)\n3. 8-10 testimonial blocks with H3 project title, star rating, blockquote review (50-80 words each), reviewer name and city\n4. H2: Our Commitment to Satisfaction (150 words)\n5. H2: Ready to Join Our Happy Customers? — CTA (100 words)",

            'gallery' => "TEMPLATE: PORTFOLIO PAGE\n1. H1: Our Work\n2. Intro (100-150 words)\n3. 6-8 project entries: H3 title + location, IMAGE placeholder, description (80-120 words each), details\n4. H2: Start Your Project — CTA (100 words)",

            'pricing' => "TEMPLATE: PRICING PAGE\n1. H1: Our Services and Pricing\n2. Intro: Pricing philosophy (100-150 words)\n3. H2: Service 1 — description, included list, Contact for pricing (200 words)\n4. H2: Service 2 — same (200 words)\n5. H2: Service 3 — same (200 words)\n6. H2: Factors That Affect Pricing (150-200 words)\n7. H2: Financing Options (100 words)\n8. H2: Get a Free Estimate — CTA (100 words)",
        ];

        $tmpl = $structures[$template] ?? '';
        return $tmpl ? "\n\nTEMPLATE STRUCTURE (follow this layout):\n{$tmpl}\n" : '';
    }

    public function research( $topic, $keywords = '', $content_type = 'blog', $word_count = 1500, $custom_prompt = '', $template = '', $scope = 'local' ) {
        $brand = get_option('sseo_brand_name','');
        $local_ctx = $this->get_local_context($scope);
        $tmpl_struct = $this->get_template_structure($template, $word_count);
        $custom_section = $custom_prompt ? "\n\nADDITIONAL INSTRUCTIONS:\n{$custom_prompt}\n" : '';

        $prompt = "You are an expert SEO content strategist. Research and create a detailed content brief.

Topic: {$topic}
Target Keywords: {$keywords}
Content Type: {$content_type}
Target Word Count: {$word_count}
" . ($brand ? "Brand: {$brand}\n" : '') . $local_ctx . $tmpl_struct . $custom_section . "

Provide a comprehensive brief. Return ONLY JSON:
{
  \"title_tag\": \"50-60 chars\",
  \"meta_description\": \"150-160 chars\",
  \"h1\": \"...\",
  \"outline\": [
    {\"heading\": \"H2: ...\", \"subheadings\": [\"H3: ...\"], \"key_points\": [\"...\"], \"image_suggestion\": \"description\"}
  ],
  \"faqs\": [{\"question\": \"...\", \"answer_brief\": \"...\"}],
  \"internal_links\": [\"suggest linking to: ...\"],
  \"target_word_count\": {$word_count}
}
No markdown, no fences.";

        $r = $this->api->complete($prompt);
        if (is_wp_error($r)) return $r;
        $parsed = SSEO_API_Handler::parse_json($r['content']);
        if (is_wp_error($parsed)) return $parsed;
        return ['brief'=>$parsed,'tokens'=>$r['tokens']];
    }

    private function get_internal_links_context( $add_links = true, $exclude_id = 0 ) {
        if ( ! $add_links ) return '';
        $types = get_option('sseo_post_types', ['post','page']);
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>50,'exclude'=>$exclude_id ? [$exclude_id] : []]);
        if ( empty($posts) ) return '';
        $links = "\n\nINTERNAL LINKING (insert 3-8 contextual links to these existing pages):\n";
        foreach ($posts as $p) {
            $url = get_permalink($p->ID);
            $path = wp_parse_url($url, PHP_URL_PATH);
            $links .= "- \"{$p->post_title}\" → {$url}\n";
        }
        $links .= "\nRULES FOR INTERNAL LINKS:\n";
        $links .= "- Use natural anchor text that describes the target page\n";
        $links .= "- Insert links within paragraph text, not as standalone lists\n";
        $links .= "- Use full <a href=\"URL\">anchor text</a> tags\n";
        $links .= "- Link to 3-8 relevant pages, not every page\n";
        $links .= "- Place links where they add context for the reader\n";
        return $links;
    }

    public function generate_content( $topic, $keywords = '', $content_type = 'blog', $word_count = 1500, $brief = null, $tone = '', $custom_prompt = '', $template = '', $scope = 'local', $add_links = true ) {
        $brand = get_option('sseo_brand_name','');
        if (!$tone) $tone = get_option('sseo_default_tone','professional');

        $local_ctx = $this->get_local_context($scope);
        $tmpl_struct = $this->get_template_structure($template, $word_count);
        $custom_section = $custom_prompt ? "\n\nADDITIONAL USER INSTRUCTIONS:\n{$custom_prompt}\n" : '';

        $brief_text = '';
        if ($brief) {
            $brief_text = "\n\nFollow this content outline:\n";
            if (!empty($brief['outline'])) {
                foreach ($brief['outline'] as $section) {
                    $brief_text .= "- {$section['heading']}\n";
                    if (!empty($section['subheadings'])) {
                        foreach ($section['subheadings'] as $sub) $brief_text .= "  - {$sub}\n";
                    }
                }
            }
            if (!empty($brief['faqs'])) {
                $brief_text .= "- FAQ Section:\n";
                foreach ($brief['faqs'] as $faq) $brief_text .= "  - {$faq['question']}\n";
            }
        }

        $links_ctx = $this->get_internal_links_context($add_links);

        $prompt = "You are an expert SEO content writer creating a publish-ready page.

Topic: {$topic}
Keywords: {$keywords}
Type: {$content_type}
Length: {$word_count} words (MUST hit this target)
Tone: {$tone}
" . ($brand ? "Brand: {$brand}\n" : '') . $local_ctx . $tmpl_struct . $brief_text . $links_ctx . $custom_section . "

CRITICAL RULES:
1. Output clean semantic HTML: h1, h2, h3, p, ul, ol, li, strong, em, blockquote, a
2. No html/head/body/style/script tags. No inline styles. No CSS classes.
3. Start with ONE h1 tag
4. H2 for major sections, H3 for subsections
5. Write {$word_count}+ words of REAL detailed content
6. Each paragraph: 3-5 sentences minimum, no stubs
7. Include <!-- IMAGE: descriptive caption --> placeholders (5-8)
8. FAQ H3s MUST end with ? for schema detection
9. Include strong CTAs with contact info
10. Insert 3-8 real internal <a href=\"URL\"> links using the page URLs provided. Use 2-4 word anchor text — NEVER single words like \"here\" or \"floor\"
11. Write like a human expert — specific, authoritative, engaging

Return ONLY the HTML content.";

        $r = $this->api->complete($prompt, 0.75, 16384);
        if (is_wp_error($r)) return $r;
        $content = preg_replace('/^```(?:html)?\s*/i','',trim($r['content']));
        $content = preg_replace('/\s*```$/i','',$content);

        // Auto-match images from media library
        $match_result = $this->auto_match_images($content, $keywords ?: $topic);
        $content = $match_result['content'];

        // Post-process: inject real internal links if AI missed them
        if ($add_links) {
            $content = $this->inject_real_links($content);
        }

        return ['content'=>$content,'tokens'=>$r['tokens'],'images_matched'=>$match_result['matched'],'images_remaining'=>$match_result['remaining']];
    }

    public function enhance_content( $post_id, $target_words = 800, $keywords = '', $custom_prompt = '', $template = '', $scope = 'local', $add_links = true ) {
        $post = get_post($post_id);
        if (!$post) return new WP_Error('no_post','Post not found.');

        $current = $post->post_content;
        $wc = str_word_count(wp_strip_all_tags($current));
        $seo = new SSEO_SEO_Integration();
        $focus = $seo->get_focus_keyword($post_id);
        if ($keywords) $focus = $keywords . ($focus ? ', '.$focus : '');

        $local_ctx = $this->get_local_context($scope);
        $tmpl_struct = $this->get_template_structure($template, $target_words);
        $custom_section = $custom_prompt ? "\n\nADDITIONAL INSTRUCTIONS:\n{$custom_prompt}\n" : '';
        $links_ctx = $this->get_internal_links_context($add_links, $post_id);

        if ($template) {
            $prompt = "You are an SEO expert. This page has thin content ({$wc} words). REBUILD it using the template below, targeting {$target_words}+ words.

Page Title: {$post->post_title}
Keywords: {$focus}
Current Content (preserve useful info):
{$current}
{$local_ctx}{$tmpl_struct}{$links_ctx}{$custom_section}

RULES:
1. CREATE a new full page using the template structure
2. Keep useful facts from the existing content
3. Output clean semantic HTML: h1, h2, h3, p, ul, ol, li, strong, em, blockquote, a
4. No html/head/body/style/script tags. No inline styles. No CSS classes.
5. Start with ONE h1 tag
6. Write {$target_words}+ words — each section 150-300 words
7. Include <!-- IMAGE: caption --> placeholders (5-8)
8. FAQ H3s must end with ?
9. Include strong CTAs with contact info
10. Insert 3-8 real internal <a href> links using 2-4 word anchor text

Return ONLY the HTML.";
        } else {
            $prompt = "You are an SEO expert. This page has thin content ({$wc} words). Expand to {$target_words}+ words.

Page Title: {$post->post_title}
Keywords: {$focus}
Current Content:
{$current}
{$local_ctx}{$links_ctx}{$custom_section}

RULES:
1. KEEP existing content and structure intact
2. EXPAND each section with more detail, examples, value
3. ADD new H2/H3 sections: benefits, process, cost factors, FAQ, service area, CTA
4. Output clean semantic HTML. No inline styles. No markdown.
5. Include <!-- IMAGE: caption --> placeholders (3-5)
6. Write {$target_words}+ words total
7. Keep same tone and style
8. Insert 3-8 real internal <a href> links using 2-4 word anchor text

Return ONLY the full enhanced HTML.";
        }

        $r = $this->api->complete($prompt, 0.7, 16384);
        if (is_wp_error($r)) return $r;
        $content = preg_replace('/^```(?:html)?\s*/i','',trim($r['content']));
        $content = preg_replace('/\s*```$/i','',$content);

        // Auto-match images
        $match_result = $this->auto_match_images($content, $keywords ?: $post->post_title);
        $content = $match_result['content'];

        // Inject real internal links if AI missed them
        if ($add_links) {
            $content = $this->inject_real_links($content, $post_id);
        }

        return ['content'=>$content,'original_words'=>$wc,'new_words'=>str_word_count(wp_strip_all_tags($content)),'tokens'=>$r['tokens'],'post_id'=>$post_id,'post_title'=>$post->post_title,'images_matched'=>$match_result['matched'],'images_remaining'=>$match_result['remaining']];
    }

    /**
     * Auto-match <!-- IMAGE: description --> placeholders with real media library images
     * Searches by description keywords, filename, ALT text, caption
     */
    public function auto_match_images( $content, $fallback_keywords = '' ) {
        $matched = 0;
        $remaining = 0;
        $used_ids = [];
        $used_urls = []; // Track actual image URLs to prevent same file appearing twice

        // Also handle [IMAGE: description] format
        $content = preg_replace('/\[IMAGE:\s*([^\]]+)\]/i', '<!-- IMAGE: $1 -->', $content);

        // Find all image placeholders
        if ( ! preg_match_all('/<!--\s*IMAGE:\s*(.+?)\s*-->/i', $content, $matches, PREG_SET_ORDER) ) {
            return ['content' => $content, 'matched' => 0, 'remaining' => 0];
        }

        // Build a pool — topic-aware: search for relevant images first
        $pool = $this->build_image_pool($fallback_keywords);

        foreach ( $matches as $idx => $m ) {
            $placeholder = $m[0];
            $description = $m[1];
            $search_words = $this->extract_search_words($description);

            // Score each image — skip used IDs AND used URLs
            $scored = [];
            foreach ( $pool as $img ) {
                if ( in_array($img['id'], $used_ids) ) continue;
                if ( in_array($img['large'], $used_urls) ) continue; // Same file check
                $score = $this->score_image_match($img, $search_words, $description);
                if ( $score >= 4 ) {
                    $scored[] = ['img' => $img, 'score' => $score];
                }
            }

            usort($scored, function($a, $b) { return $b['score'] - $a['score']; });

            $placed = false;
            if ( !empty($scored) ) {
                $pick = $scored[0]['img'];
                $replacement = $this->build_img_tag($pick, $description);
                $content = preg_replace('/' . preg_quote($placeholder, '/') . '/', addcslashes($replacement, '\\$'), $content, 1);
                $used_ids[] = $pick['id'];
                $used_urls[] = $pick['large'];
                $matched++;
                $placed = true;
            }

            if ( !$placed ) {
                $vision_match = $this->vision_match_image($pool, $used_ids, $used_urls, $search_words, $description);
                if ( $vision_match ) {
                    $replacement = $this->build_img_tag($vision_match, $description);
                    $content = preg_replace('/' . preg_quote($placeholder, '/') . '/', addcslashes($replacement, '\\$'), $content, 1);
                    $used_ids[] = $vision_match['id'];
                    $used_urls[] = $vision_match['large'];
                    $matched++;
                    $placed = true;
                }
            }

            if ( !$placed ) {
                $hint = '<div style="background:#fef3c7;border:1px dashed #f59e0b;border-radius:8px;padding:16px;margin:24px 0;text-align:center;font-size:13px;color:#92400e">';
                $hint .= '📷 <strong>Image needed:</strong> ' . esc_html($description);
                $hint .= '</div>';
                $content = preg_replace('/' . preg_quote($placeholder, '/') . '/', $hint, $content, 1);
                $remaining++;
            }
        }

        return ['content' => $content, 'matched' => $matched, 'remaining' => $remaining, 'matched_ids' => $used_ids];
    }

    private function build_image_pool($topic = '') {
        $pool = [];
        $loaded_ids = [];

        // FIRST: Search by ALT text (meta query) — this is where most good metadata lives
        if ($topic) {
            $search_terms = array_map('trim', explode(',', $topic));
            foreach ($search_terms as $term) {
                if (empty($term) || strlen($term) < 3) continue;

                // Search ALT text via meta_query
                $alt_query = new WP_Query([
                    'post_type'      => 'attachment',
                    'post_mime_type' => 'image',
                    'post_status'    => 'inherit',
                    'posts_per_page' => 30,
                    'meta_query'     => [
                        'relation' => 'OR',
                        ['key' => '_wp_attachment_image_alt', 'value' => $term, 'compare' => 'LIKE'],
                        ['key' => '_sseo_vision_desc', 'value' => $term, 'compare' => 'LIKE'],
                    ],
                ]);
                foreach ($alt_query->posts as $img) {
                    if (isset($loaded_ids[$img->ID])) continue;
                    $this->add_to_pool($pool, $img);
                    $loaded_ids[$img->ID] = true;
                }

                // Also search title/filename via WP search
                $tq = new WP_Query([
                    'post_type'      => 'attachment',
                    'post_mime_type' => 'image',
                    'post_status'    => 'inherit',
                    'posts_per_page' => 30,
                    's'              => $term,
                    'orderby'        => 'relevance',
                ]);
                foreach ($tq->posts as $img) {
                    if (isset($loaded_ids[$img->ID])) continue;
                    $this->add_to_pool($pool, $img);
                    $loaded_ids[$img->ID] = true;
                }

                // Also search by individual words in the term
                $words = preg_split('/\s+/', $term);
                foreach ($words as $word) {
                    if (strlen($word) < 4) continue;
                    $wq = new WP_Query([
                        'post_type'      => 'attachment',
                        'post_mime_type' => 'image',
                        'post_status'    => 'inherit',
                        'posts_per_page' => 15,
                        'meta_query'     => [
                            ['key' => '_wp_attachment_image_alt', 'value' => $word, 'compare' => 'LIKE'],
                        ],
                    ]);
                    foreach ($wq->posts as $img) {
                        if (isset($loaded_ids[$img->ID])) continue;
                        $this->add_to_pool($pool, $img);
                        $loaded_ids[$img->ID] = true;
                    }
                }
            }
        }

        // THEN: Fill with recent images (skip already loaded)
        $query = new WP_Query([
            'post_type'      => 'attachment',
            'post_mime_type' => 'image',
            'post_status'    => 'inherit',
            'posts_per_page' => 200,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'post__not_in'   => array_keys($loaded_ids),
        ]);
        foreach ($query->posts as $img) {
            $this->add_to_pool($pool, $img);
        }

        return $pool;
    }

    private function add_to_pool(&$pool, $img) {
        $alt    = get_post_meta($img->ID, '_wp_attachment_image_alt', true);
        $vision = get_post_meta($img->ID, '_sseo_vision_desc', true);
        $meta   = wp_get_attachment_metadata($img->ID);
        $file   = $meta['file'] ?? '';
        $fname  = pathinfo($file, PATHINFO_FILENAME);
        $fname_clean = preg_replace('/^(IMG|DSC|Screenshot|Photo|Image|pic)[-_]?\d*/i', '', $fname);
        $fname_clean = str_replace(['-','_','.'], ' ', $fname_clean);

        // FILTER: Skip logos, headshots, person photos, icons, and irrelevant images
        $check_text = strtolower($img->post_title . ' ' . $alt . ' ' . $fname_clean . ' ' . $img->post_excerpt);
        $exclude_patterns = ['logo', 'headshot', 'portrait', 'avatar', 'team photo', 'staff', 'icon', 'favicon', 'badge', 'award', 'certificate', 'seal', 'ribbon', 'accredit', 'bbb', 'nari', 'nahb', 'placeholder', 'screenshot'];
        foreach ($exclude_patterns as $pattern) {
            if (strpos($check_text, $pattern) !== false) return;
        }

        // FILTER: Skip very small images (likely logos/icons) — under 200x200
        $width = $meta['width'] ?? 0;
        $height = $meta['height'] ?? 0;
        if ($width > 0 && $height > 0 && $width < 200 && $height < 200) return;

        // FILTER: Skip images with extreme aspect ratios (likely banners/logos)
        if ($width > 0 && $height > 0) {
            $ratio = max($width, $height) / max(1, min($width, $height));
            if ($ratio > 5) return; // Very wide/tall = likely a banner or logo strip
        }

        $large  = wp_get_attachment_image_src($img->ID, 'large');
        $medium = wp_get_attachment_image_src($img->ID, 'medium');

        // Include Vision-cached description in searchable text
        $searchable = strtolower(
            $img->post_title . ' ' .
            $alt . ' ' .
            $img->post_excerpt . ' ' .
            $fname_clean . ' ' .
            $img->post_content . ' ' .
            ($vision ?: '')
        );

        $pool[$img->ID] = [
            'id'         => $img->ID,
            'title'      => $img->post_title,
            'alt'        => $alt,
            'caption'    => $img->post_excerpt,
            'filename'   => $fname_clean,
            'large'      => $large ? $large[0] : ($medium ? $medium[0] : wp_get_attachment_url($img->ID)),
            'searchable' => $searchable,
            'has_vision'  => !empty($vision),
        ];
    }

    private function build_img_tag($img_data, $description) {
        $alt = esc_attr($img_data['alt'] ?: $description);
        $src = esc_url($img_data['large']);
        $tag = '<figure style="margin:24px 0">';
        $tag .= '<img src="' . $src . '" alt="' . $alt . '" loading="lazy" style="width:100%;height:auto;border-radius:8px">';
        if ( !empty($img_data['caption']) ) {
            $tag .= '<figcaption style="font-size:13px;color:#64748b;margin-top:6px;text-align:center">' . esc_html($img_data['caption']) . '</figcaption>';
        }
        $tag .= '</figure>';
        return $tag;
    }

    /**
     * Vision-powered image matching — AI actually LOOKS at the image
     * Uses cached descriptions to avoid repeated API calls
     */
    private function vision_match_image($pool, $used_ids, $used_urls, $search_words, $description) {
        $candidates = [];
        $uncached_first = [];
        $cached_second = [];

        foreach ($pool as $img) {
            if (in_array($img['id'], $used_ids)) continue;
            if (in_array($img['large'], $used_urls)) continue;
            if (empty($img['has_vision'])) {
                $uncached_first[] = $img;
            } else {
                $cached_second[] = $img;
            }
            if (count($uncached_first) + count($cached_second) >= 20) break;
        }
        $candidates = array_merge($uncached_first, $cached_second);
        if (empty($candidates)) return null;

        $api = new SSEO_API_Handler();
        $topic = implode(' ', $search_words);

        foreach ($candidates as $img) {
            // Check cached vision description first
            $cached = get_post_meta($img['id'], '_sseo_vision_desc', true);

            if (empty($cached)) {
                // Use Vision API to describe the image — use medium size for speed
                $medium = wp_get_attachment_image_src($img['id'], 'medium');
                $img_url = $medium ? $medium[0] : wp_get_attachment_url($img['id']);
                if (!$img_url) continue;

                $r = $api->complete_vision(
                    'What is the main subject of this image? Reply with ONLY 5-10 specific descriptive words. Examples: "kitchen cabinets granite countertop modern renovation" or "bathroom tile shower glass door remodel". No sentences, just keywords.',
                    $img_url,
                    0.3
                );

                if (is_wp_error($r)) continue;
                $cached = strtolower(trim($r['content'] ?? ''));
                if (empty($cached)) continue;

                // Cache permanently
                update_post_meta($img['id'], '_sseo_vision_desc', $cached);
            }

            // Score vision description against ALL search words
            $vision_score = 0;
            foreach ($search_words as $i => $word) {
                if (strpos($cached, $word) !== false) {
                    $vision_score += ($i < 3) ? 5 : 2; // Primary words worth more
                }
            }

            // If vision description matches topic, use this image
            if ($vision_score >= 5) {
                return $img;
            }
        }

        return null;
    }

    private function extract_search_words( $description ) {
        $stop = ['a','an','the','of','in','on','at','to','for','and','or','with','by','from','is','are','was','were','be','been','being','this','that','image','photo','picture','showing','shows','depicting','professional','service','example','completed','project','work','team','expert','quality','best','top','great','new','our'];
        $words = preg_split('/[\s,.\-\/]+/', strtolower($description));
        $words = array_filter($words, function($w) use ($stop) {
            return strlen($w) > 2 && !in_array($w, $stop);
        });
        return array_values($words);
    }

    private function score_image_match( $img, $search_words, $full_desc ) {
        $score = 0;
        $searchable = $img['searchable'];
        $alt_lower = strtolower($img['alt']);
        $title_lower = strtolower($img['title']);

        // Primary topic words are the first 2-3 meaningful words (most important)
        $primary = array_slice($search_words, 0, 3);
        $primary_hits = 0;

        foreach ( $primary as $word ) {
            if ( strpos($searchable, $word) !== false ) {
                $primary_hits++;
                $score += 4; // Primary words worth more
                if ( strpos($alt_lower, $word) !== false ) $score += 5;
                if ( strpos($title_lower, $word) !== false ) $score += 3;
            }
        }

        // If NONE of the primary topic words match, this image is irrelevant
        if ( $primary_hits === 0 ) return 0;

        // Secondary words (lesser weight)
        $secondary = array_slice($search_words, 3);
        foreach ( $secondary as $word ) {
            if ( strpos($searchable, $word) !== false ) $score += 1;
        }

        // Bonus for phrase match (consecutive words in order)
        $desc_lower = strtolower($full_desc);
        for ($i = 0; $i < count($search_words) - 1; $i++) {
            $phrase = $search_words[$i] . ' ' . $search_words[$i+1];
            if ( strpos($searchable, $phrase) !== false ) $score += 8;
        }

        // Before/After boost: when searching for BA photos, heavily prioritize images
        // that have "before" and/or "after" in their metadata
        $is_ba_search = (strpos($desc_lower, 'before') !== false && strpos($desc_lower, 'after') !== false);
        if ($is_ba_search) {
            $has_ba = (strpos($searchable, 'before') !== false || strpos($searchable, 'after') !== false);
            if ($has_ba) {
                $score += 15; // Strong boost for actual before/after photos
            } else {
                $score -= 5; // Penalize non-BA photos when BA is requested
            }
        }

        return $score;
    }

    private function search_single_image( $keywords, $used_ids = [] ) {
        $terms = array_map('trim', explode(',', $keywords));
        foreach ( $terms as $term ) {
            if ( empty($term) ) continue;
            $query = new WP_Query([
                'post_type'      => 'attachment',
                'post_mime_type' => 'image',
                'post_status'    => 'inherit',
                'posts_per_page' => 5,
                's'              => $term,
                'orderby'        => 'relevance',
                'post__not_in'   => $used_ids,
            ]);
            foreach ( $query->posts as $img ) {
                if ( in_array($img->ID, $used_ids) ) continue;
                $large = wp_get_attachment_image_src($img->ID, 'large');
                $medium = wp_get_attachment_image_src($img->ID, 'medium');
                return [
                    'id'    => $img->ID,
                    'alt'   => get_post_meta($img->ID, '_wp_attachment_image_alt', true),
                    'large' => $large ? $large[0] : ($medium ? $medium[0] : wp_get_attachment_url($img->ID)),
                ];
            }
        }
        return null;
    }

    /**
     * Post-process: inject real internal links into content if AI didn't include enough
     */
    /**
     * Post-process: inject real internal links into content if AI didn't include enough
     * Public wrapper for template engine access
     */
    public function inject_real_links_public($content, $exclude_id = 0) {
        return $this->inject_real_links($content, $exclude_id);
    }

    private function inject_real_links($content, $exclude_id = 0) {
        // Count existing internal links
        $host = wp_parse_url(home_url('/'), PHP_URL_HOST);
        $existing = 0;
        if (preg_match_all('/href=["\']([^"\']+)["\']/i', $content, $hm)) {
            foreach ($hm[1] as $href) {
                $h = wp_parse_url($href, PHP_URL_HOST);
                if (empty($h) || $h === $host) $existing++;
            }
        }

        // If already has 3+ internal links, skip
        if ($existing >= 3) return $content;

        $brand = strtolower(get_option('sseo_brand_name', ''));
        $brand_words = array_filter(preg_split('/\s+/', $brand), function($w){ return strlen($w) > 2; });

        // Get candidate pages
        $types = get_option('sseo_post_types', ['post','page']);
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>30,'exclude'=>$exclude_id ? [$exclude_id] : []]);
        $text_lower = strtolower(wp_strip_all_tags($content));
        $links_added = 0;
        $used_urls = [];

        foreach ($posts as $p) {
            if ($links_added >= (5 - $existing)) break;
            $url = get_permalink($p->ID);
            if (in_array($url, $used_urls)) continue;
            if (strpos($content, $url) !== false) continue;

            // Extract 2-3 word phrases from target title
            $title_words = preg_split('/[\s,.\-–|&:;!?]+/', $p->post_title);
            $title_words = array_filter($title_words, function($w) { return strlen($w) > 2; });
            $title_words = array_values($title_words);

            // Try 3-word, then 2-word matches
            for ($len = min(3, count($title_words)); $len >= 2; $len--) {
                for ($i = 0; $i <= count($title_words) - $len; $i++) {
                    $phrase = implode(' ', array_slice($title_words, $i, $len));
                    if (strlen($phrase) < 6) continue;
                    $phrase_lower = strtolower($phrase);

                    // Skip if phrase contains ANY brand word
                    $skip = false;
                    foreach ($brand_words as $bw) {
                        if (strpos($phrase_lower, $bw) !== false) { $skip = true; break; }
                    }
                    if ($skip) continue;

                    $pos = strpos($text_lower, $phrase_lower);
                    if ($pos !== false) {
                        $link_tag = '<a href="' . esc_url($url) . '">' . esc_html($phrase) . '</a>';
                        // Match with word boundaries, not inside links or headings
                        $pattern = '/(?<=[\s>])(' . preg_quote($phrase, '/') . ')(?=[\s<.,;:!?)])/i';
                        $new_content = preg_replace($pattern, $link_tag, $content, 1, $count);
                        if ($count > 0) {
                            $content = $new_content;
                            $text_lower = strtolower(wp_strip_all_tags($content));
                            $used_urls[] = $url;
                            $links_added++;
                            break 2;
                        }
                    }
                }
            }
        }

        return $content;
    }

    public function find_media_images( $search_terms, $limit = 12 ) {
        $terms = array_map('trim',explode(',',$search_terms));
        $all = []; $seen = [];
        foreach ($terms as $term) {
            $query = new WP_Query(['post_type'=>'attachment','post_mime_type'=>'image','post_status'=>'inherit','posts_per_page'=>$limit,'s'=>$term,'orderby'=>'relevance']);
            foreach ($query->posts as $img) {
                if (isset($seen[$img->ID])) continue;
                $seen[$img->ID] = true;
                $src = wp_get_attachment_image_src($img->ID,'medium');
                $full = wp_get_attachment_url($img->ID);
                $thumb = wp_get_attachment_image_src($img->ID,'thumbnail');
                $all[] = ['id'=>$img->ID,'title'=>$img->post_title,'alt'=>get_post_meta($img->ID,'_wp_attachment_image_alt',true),'url'=>$full,'medium'=>$src?$src[0]:$full,'thumbnail'=>$thumb?$thumb[0]:($src?$src[0]:$full),'width'=>$src?$src[1]:0,'height'=>$src?$src[2]:0,'caption'=>$img->post_excerpt];
            }
        }
        return array_slice($all,0,$limit);
    }

    public function get_media_library( $page = 1, $per_page = 24, $search = '' ) {
        $args = ['post_type'=>'attachment','post_mime_type'=>'image','post_status'=>'inherit','posts_per_page'=>$per_page,'paged'=>$page,'orderby'=>'date','order'=>'DESC'];
        if ($search) $args['s'] = $search;
        $query = new WP_Query($args);
        $images = [];
        foreach ($query->posts as $img) {
            $src = wp_get_attachment_image_src($img->ID,'medium');
            $full = wp_get_attachment_url($img->ID);
            $thumb = wp_get_attachment_image_src($img->ID,'thumbnail');
            $images[] = ['id'=>$img->ID,'title'=>$img->post_title,'alt'=>get_post_meta($img->ID,'_wp_attachment_image_alt',true),'url'=>$full,'medium'=>$src?$src[0]:$full,'thumbnail'=>$thumb?$thumb[0]:$full];
        }
        return ['images'=>$images,'total'=>$query->found_posts,'total_pages'=>$query->max_num_pages];
    }

    public function save_as_draft( $title, $content, $post_type = 'post', $meta_desc = '', $h1 = '' ) {
        if ($h1) $content = '<h1>' . esc_html($h1) . '</h1>' . "\n" . $content;

        // Strip AI template artifacts before publishing
        $content = self::clean_for_publish($content);

        // Admins can save full HTML including <style>/<script> from templates
        $safe_content = current_user_can('unfiltered_html') ? $content : wp_kses_post($content);

        $post_id = wp_insert_post(['post_title'=>sanitize_text_field($title),'post_content'=>$safe_content,'post_status'=>'publish','post_type'=>$post_type]);
        if (is_wp_error($post_id)) return $post_id;
        if ($meta_desc) { $seo = new SSEO_SEO_Integration(); $seo->set_meta($post_id,$meta_desc); }

        // Auto-set featured image from first image in content
        $this->set_featured_from_content($post_id, $content);

        return ['post_id'=>$post_id,'edit_url'=>get_edit_post_link($post_id,'raw')];
    }

    /**
     * Extract the first image from HTML content and set it as the post's featured image
     */
    /**
     * Expand a page IN-PLACE: keep existing content, append styled sections below.
     * Modes: 'intro' = short styled intro, 'full' = comprehensive expansion
     */
    public function expand_inplace( $post_id, $target_words = 800, $keywords = '', $add_links = true, $mode = 'full' ) {
        $post = get_post($post_id);
        if (!$post) return new WP_Error('no_post', 'Post not found.');

        $current = $post->post_content;
        $current_wc = str_word_count(wp_strip_all_tags($current));

        $seo = new SSEO_SEO_Integration();
        $focus = $seo->get_focus_keyword($post_id);
        if ($keywords) $focus = $keywords . ($focus ? ', ' . $focus : '');

        $local_ctx = $this->get_local_context('local');
        $links_ctx = $this->get_internal_links_context($add_links, $post_id);

        $brand = get_option('sseo_brand_name', get_bloginfo('name'));
        $phone = get_option('sseo_business_phone', '');
        $color = get_option('sseo_brand_color', '#2563eb');

        $existing_summary = wp_trim_words(wp_strip_all_tags($current), 200);

        if ($mode === 'intro') {
            $prompt = "You are an SEO content expert. Write a {$target_words}-word styled introduction for this page.

Page Title: {$post->post_title}
URL: " . get_permalink($post_id) . "
Keywords: {$focus}
Brand: {$brand}
Phone: {$phone}
Existing Content (DO NOT REPEAT): {$existing_summary}
{$local_ctx}{$links_ctx}

Write a compelling {$target_words}-word introduction that:
- Introduces the topic/category this page covers
- Mentions the brand name and location naturally
- Includes 1-2 internal links to relevant pages
- Has a brief call-to-action at the end
- Write in 2-3 short paragraphs (2-3 sentences each)
- Include one <!-- IMAGE: descriptive search --> placeholder

Return ONLY clean HTML: p, strong, em, a tags. NO headings, NO lists, NO styles.";
        } else {
            $words_needed = max(400, $target_words - $current_wc);
            $prompt = "You are an SEO content expert. A page has only {$current_wc} words and needs to be expanded to {$target_words}+ words.

CRITICAL: I will APPEND your output BELOW the existing page content. Do NOT rewrite or repeat anything from the existing content.

Page Title: {$post->post_title}
URL: " . get_permalink($post_id) . "
Keywords: {$focus}
Brand: {$brand}
Phone: {$phone}
Existing Content (DO NOT REPEAT): {$existing_summary}
{$local_ctx}{$links_ctx}

Write {$words_needed}+ words of NEW content. Return a JSON object with these keys:
{
  \"sections\": [
    {\"heading\": \"H2 heading text\", \"content\": \"2-3 short paragraphs (80-120 words total). Write specific, detailed content about this sub-topic. Include brand name, location, and details.\"},
    {\"heading\": \"Our [Service] Process\", \"content\": \"Describe 3-4 steps: consultation, planning, construction, walkthrough. 100-150 words.\"},
    {\"heading\": \"Why Choose [Brand] for [Service]\", \"content\": \"3-4 compelling reasons with specifics. 100-150 words.\"},
    {\"heading\": \"What Is Included\", \"content\": \"List 6-8 specific items included in the service. Format as: Item 1 | Item 2 | Item 3 etc.\"},
    {\"heading\": \"[Service] Cost in [City]\", \"content\": \"Realistic price ranges, factors affecting cost, ROI info. 80-100 words.\"}
  ],
  \"faqs\": [
    {\"question\": \"specific question?\", \"answer\": \"4-5 sentence answer (60-80 words)\"},
    {\"question\": \"question?\", \"answer\": \"answer\"},
    {\"question\": \"question?\", \"answer\": \"answer\"},
    {\"question\": \"question?\", \"answer\": \"answer\"}
  ],
  \"areas\": [\"City 1\", \"City 2\", \"City 3\", \"City 4\", \"City 5\", \"City 6\"],
  \"cta_text\": \"1-2 sentence call to action with phone number\",
  \"image_1_search\": \"2-3 word image search for this service\",
  \"image_2_search\": \"different 2-3 word image search\"
}

RULES:
- Write in short 2-3 sentence paragraphs, NEVER long walls of text
- Be specific to the business, location, and services — NOT generic
- Do NOT use double quotes inside string values
- Return ONLY valid JSON, start with { end with }";
        }

        // Use higher token limit for full expansions to prevent truncation
        $max_tokens = ($mode === 'intro') ? 8000 : 32000;
        $r = $this->api->complete($prompt, 0.7, $max_tokens);
        if (is_wp_error($r)) return $r;

        $raw = preg_replace('/^```(?:json|html)?\s*/i', '', trim($r['content']));
        $raw = preg_replace('/\s*```$/i', '', $raw);

        // Ensure we have some content to work with
        if (empty(trim($raw))) {
            return new WP_Error('empty_response', 'AI returned empty content. Please try again.');
        }

        if ($mode === 'intro') {
            $new_content = $this->style_intro($raw, $color);
        } else {
            // Try parsing as JSON first
            $data = SSEO_API_Handler::parse_json($raw);
            if (!is_wp_error($data) && is_array($data)) {
                // Valid JSON - render structured output
                $new_content = $this->style_expansion($data, $color, $brand, $phone);
            } else {
                // JSON failed OR returned non-array - treat as raw HTML and style it
                // This is NOT an error condition - we just fall back to HTML mode
                $new_content = $this->style_expansion_raw($raw, $color, $brand, $phone);
            }
        }

        // Final safety check
        if (empty(trim($new_content))) {
            return new WP_Error('no_content', 'Content generation produced no output. Please try again with different settings.');
        }

        // Auto-match images
        $match_result = $this->auto_match_images($new_content, $keywords ?: $post->post_title);
        $new_content = $match_result['content'];

        // Inject links if needed
        $link_count = substr_count($new_content, '<a href');
        if ($link_count < 3 && $add_links) {
            $new_content = $this->inject_real_links_public($new_content);
        }

        $new_wc = str_word_count(wp_strip_all_tags($new_content));

        return [
            'content'          => $new_content,
            'existing_words'   => $current_wc,
            'new_words'        => $new_wc,
            'total_words'      => $current_wc + $new_wc,
            'tokens'           => $r['tokens'] ?? 0,
            'images_matched'   => $match_result['matched'] ?? 0,
            'images_remaining' => $match_result['remaining'] ?? 0,
            'mode'             => $mode,
        ];
    }

    /**
     * Style a short intro with a clean design box
     */
    private function style_intro($html, $color) {
        return '<div style="padding:28px 32px;margin:24px 0;background:linear-gradient(135deg,#f8fafc,#f1f5f9);border-left:4px solid ' . esc_attr($color) . ';border-radius:0 12px 12px 0;font-size:16px;line-height:1.8;color:#334155">' . $html . '</div>';
    }

    /**
     * Style a full expansion from structured JSON data
     */
    private function style_expansion($data, $color, $brand, $phone) {
        $html = '<div class="sseo-expand" style="margin:40px 0;font-family:system-ui,-apple-system,sans-serif;color:#1e293b;line-height:1.7">';

        // Sections
        if (!empty($data['sections'])) {
            foreach ($data['sections'] as $i => $sec) {
                $heading = $sec['heading'] ?? '';
                $content = $sec['content'] ?? '';

                // Check if this is an "included" section with pipe-separated items
                if (strpos($content, '|') !== false && substr_count($content, '|') >= 3) {
                    $items = array_map('trim', explode('|', $content));
                    $html .= '<div style="margin:32px 0"><h2 style="font-size:22px;font-weight:700;color:#0f172a;margin:0 0 16px;padding-bottom:10px;border-bottom:3px solid ' . esc_attr($color) . '">' . esc_html($heading) . '</h2>';
                    $html .= '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">';
                    foreach ($items as $item) {
                        $html .= '<div style="display:flex;align-items:center;gap:8px;padding:10px 14px;background:#f0fdf4;border-radius:8px;font-size:14px;color:#166534"><span style="color:#16a34a;font-weight:700">✓</span> ' . esc_html($item) . '</div>';
                    }
                    $html .= '</div></div>';
                } else {
                    // Regular section: split content into paragraphs
                    $sentences = preg_split('/(?<=[.!?])\s+/', trim($content), -1, PREG_SPLIT_NO_EMPTY);
                    $paragraphs = [];
                    $chunk = [];
                    foreach ($sentences as $s) {
                        $chunk[] = $s;
                        if (count($chunk) >= 3) {
                            $paragraphs[] = implode(' ', $chunk);
                            $chunk = [];
                        }
                    }
                    if (!empty($chunk)) $paragraphs[] = implode(' ', $chunk);

                    $html .= '<div style="margin:32px 0"><h2 style="font-size:22px;font-weight:700;color:#0f172a;margin:0 0 16px;padding-bottom:10px;border-bottom:3px solid ' . esc_attr($color) . '">' . esc_html($heading) . '</h2>';
                    foreach ($paragraphs as $p) {
                        $html .= '<p style="font-size:15px;color:#475569;line-height:1.8;margin:0 0 14px">' . $p . '</p>';
                    }
                    $html .= '</div>';
                }

                // Insert image placeholder after first and third sections
                if ($i === 0 && !empty($data['image_1_search'])) {
                    $html .= '<!-- IMAGE: ' . esc_html($data['image_1_search']) . ' -->';
                }
                if ($i === 2 && !empty($data['image_2_search'])) {
                    $html .= '<!-- IMAGE: ' . esc_html($data['image_2_search']) . ' -->';
                }
            }
        }

        // FAQs
        if (!empty($data['faqs'])) {
            $html .= '<div style="margin:32px 0"><h2 style="font-size:22px;font-weight:700;color:#0f172a;margin:0 0 16px;padding-bottom:10px;border-bottom:3px solid ' . esc_attr($color) . '">Frequently Asked Questions</h2>';
            foreach ($data['faqs'] as $faq) {
                $q = $faq['question'] ?? '';
                $a = $faq['answer'] ?? '';
                $html .= '<div style="border:1px solid #e2e8f0;border-radius:10px;margin-bottom:10px;overflow:hidden">';
                $html .= '<div style="padding:14px 18px;font-size:15px;font-weight:600;color:#0f172a;background:#f8fafc">' . esc_html($q) . '</div>';
                $html .= '<div style="padding:12px 18px;font-size:14px;color:#475569;line-height:1.7">' . esc_html($a) . '</div>';
                $html .= '</div>';
            }
            $html .= '</div>';
        }

        // Service areas
        if (!empty($data['areas'])) {
            $html .= '<div style="margin:32px 0"><h2 style="font-size:22px;font-weight:700;color:#0f172a;margin:0 0 16px;padding-bottom:10px;border-bottom:3px solid ' . esc_attr($color) . '">Areas We Serve</h2>';
            $html .= '<div style="display:flex;flex-wrap:wrap;gap:8px">';
            foreach ($data['areas'] as $area) {
                $html .= '<span style="padding:6px 16px;background:#eff6ff;border:1px solid #93c5fd;border-radius:20px;font-size:13px;font-weight:500;color:#1e40af">' . esc_html($area) . '</span>';
            }
            $html .= '</div></div>';
        }

        // CTA
        $cta = $data['cta_text'] ?? "Contact {$brand} today at {$phone} for a free consultation.";
        $contact_url = home_url('/contact/');
        $contact_page = get_page_by_path('contact');
        if ($contact_page) $contact_url = get_permalink($contact_page->ID);

        $html .= '<div style="margin:32px 0;padding:32px;background:linear-gradient(135deg,' . esc_attr($color) . ',#0f172a);border-radius:14px;text-align:center">';
        $html .= '<p style="font-size:16px;color:rgba(255,255,255,.9);margin:0 0 18px;line-height:1.6">' . esc_html($cta) . '</p>';
        $html .= '<a href="' . esc_url($contact_url) . '" style="display:inline-block;padding:14px 32px;background:#fff;color:' . esc_attr($color) . ';border-radius:10px;font-weight:700;font-size:15px;text-decoration:none">Get a Free Estimate</a>';
        $html .= '</div>';

        $html .= '</div>';
        return $html;
    }

    /**
     * Fallback: style raw HTML expansion when JSON parsing fails
     */
    private function style_expansion_raw($raw, $color, $brand, $phone) {
        // Wrap in styled container and style headings/paragraphs
        $html = '<div class="sseo-expand" style="margin:40px 0;font-family:system-ui,-apple-system,sans-serif;color:#1e293b;line-height:1.7">';

        // Style h2 tags
        $raw = preg_replace('/<h2([^>]*)>(.*?)<\/h2>/i',
            '<h2 style="font-size:22px;font-weight:700;color:#0f172a;margin:32px 0 16px;padding-bottom:10px;border-bottom:3px solid ' . esc_attr($color) . '">$2</h2>', $raw);

        // Style h3 tags
        $raw = preg_replace('/<h3([^>]*)>(.*?)<\/h3>/i',
            '<h3 style="font-size:18px;font-weight:600;color:#1e293b;margin:20px 0 10px">$2</h3>', $raw);

        // Style p tags
        $raw = preg_replace('/<p>(.*?)<\/p>/s',
            '<p style="font-size:15px;color:#475569;line-height:1.8;margin:0 0 14px">$1</p>', $raw);

        // Style ul/li
        $raw = preg_replace('/<ul>/i', '<ul style="padding-left:20px;margin:12px 0">', $raw);
        $raw = preg_replace('/<li>/i', '<li style="font-size:14px;color:#475569;margin:6px 0;line-height:1.7">', $raw);

        $html .= $raw . '</div>';
        return $html;
    }

    /**
     * Clean content for publishing — remove all AI template artifacts
     * Call this before saving content to post_content
     */
    public static function clean_for_publish( $content ) {
        // Remove yellow "📷 Image needed:" hint divs
        $content = preg_replace('/<div[^>]*>[\s\S]*?📷[\s\S]*?Image needed:[\s\S]*?<\/div>/i', '', $content);

        // Remove leftover <!-- IMAGE: ... --> comments
        $content = preg_replace('/<!--\s*IMAGE:\s*.+?\s*-->/i', '', $content);

        // Remove any empty paragraphs left behind
        $content = preg_replace('/<p>\s*<\/p>/', '', $content);

        // Clean up excessive whitespace
        $content = preg_replace('/\n{3,}/', "\n\n", $content);

        return $content;
    }

    public function set_featured_from_content( $post_id, $content ) {
        // Skip if post already has a featured image
        if ( get_post_thumbnail_id( $post_id ) ) return false;

        // Find the first <img> src in the content
        if ( ! preg_match( '/<img[^>]+src=["\']([^"\']+)["\']/', $content, $m ) ) return false;

        $img_url = $m[1];

        // Try to find the attachment ID from the URL
        $attach_id = attachment_url_to_postid( $img_url );

        // If not found directly, try without size suffix (e.g. -1024x768)
        if ( ! $attach_id ) {
            $clean_url = preg_replace( '/-\d+x\d+(?=\.\w+$)/', '', $img_url );
            $attach_id = attachment_url_to_postid( $clean_url );
        }

        if ( $attach_id ) {
            set_post_thumbnail( $post_id, $attach_id );
            return $attach_id;
        }

        return false;
    }
}
