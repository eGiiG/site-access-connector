<?php
/**
 * Plugin updates from the agency platform. [tracking-v28]
 *
 * The plugin is not on wordpress.org, so WordPress never offered updates and every site stayed on the version it
 * was installed with. Now the platform it is connected to (or the default one) tells WordPress about new versions:
 * they appear on the Plugins screen like any other update, work with WordPress auto-updates, and the agency can
 * apply them with its update tool.
 *
 *   GET {platform}/api/wp-plugin/info  ->  { version, download_url, requires?, tested?, requires_php?, changelog? }
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Updater {

    const SLUG  = 'samar-seo';
    const CACHE = 'sseo_update_info';

    public static function init() {
        add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject' ) );
        add_filter( 'plugins_api', array( __CLASS__, 'info' ), 20, 3 );
        add_action( 'upgrader_process_complete', array( __CLASS__, 'flush' ), 10, 0 );
    }

    private static function base() {
        return function_exists( 'sseo_api_base' ) ? rtrim( (string) sseo_api_base(), '/' ) : 'https://api.egiig.com';
    }

    /** What the platform offers, cached 12 h (1 h after a failed check). Null when unknown. */
    public static function remote() {
        $c = get_site_transient( self::CACHE );
        if ( is_array( $c ) ) {
            return $c ? $c : null;
        }
        $url = self::base() . '/api/wp-plugin/info?' . http_build_query( array( 'v' => SSEO_VERSION ) );
        $r   = wp_remote_get( $url, array( 'timeout' => 8, 'headers' => array( 'Accept' => 'application/json' ) ) );
        $d   = ( ! is_wp_error( $r ) && 200 === (int) wp_remote_retrieve_response_code( $r ) ) ? json_decode( wp_remote_retrieve_body( $r ), true ) : null;
        $ok  = is_array( $d ) && ! empty( $d['version'] ) && preg_match( '/^\d+(\.\d+){1,3}$/', (string) $d['version'] )
            && ! empty( $d['download_url'] ) && 0 === strpos( (string) $d['download_url'], 'https://' );
        set_site_transient( self::CACHE, $ok ? $d : array(), $ok ? 12 * HOUR_IN_SECONDS : HOUR_IN_SECONDS );
        return $ok ? $d : null;
    }

    private static function item( $d ) {
        return (object) array(
            'id'           => self::base() . '/' . self::SLUG,
            'slug'         => self::SLUG,
            'plugin'       => SSEO_BASENAME,
            'new_version'  => (string) $d['version'],
            'url'          => '',
            'package'      => (string) $d['download_url'],
            'requires'     => isset( $d['requires'] ) ? (string) $d['requires'] : '',
            'tested'       => isset( $d['tested'] ) ? (string) $d['tested'] : '',
            'requires_php' => isset( $d['requires_php'] ) ? (string) $d['requires_php'] : '',
            'icons'        => array(),
            'banners'      => array(),
        );
    }

    public static function inject( $t ) {
        if ( ! is_object( $t ) ) {
            return $t;
        }
        $d = self::remote();
        if ( ! $d ) {
            return $t;
        }
        $file = SSEO_BASENAME;
        if ( ! isset( $t->response ) || ! is_array( $t->response ) ) $t->response = array();
        if ( ! isset( $t->no_update ) || ! is_array( $t->no_update ) ) $t->no_update = array();
        if ( version_compare( (string) $d['version'], SSEO_VERSION, '>' ) ) {
            $t->response[ $file ] = self::item( $d );
            unset( $t->no_update[ $file ] );
        } else {
            $t->no_update[ $file ] = self::item( $d );   // also lets WordPress offer the auto-update toggle
            unset( $t->response[ $file ] );
        }
        return $t;
    }

    public static function info( $res, $action, $args ) {
        if ( 'plugin_information' !== $action || empty( $args->slug ) || self::SLUG !== $args->slug ) {
            return $res;
        }
        $d = self::remote();
        if ( ! $d ) {
            return $res;
        }
        return (object) array(
            'name'          => function_exists( 'sseo_product_name' ) ? sseo_product_name() : 'SEO Suite',
            'slug'          => self::SLUG,
            'version'       => (string) $d['version'],
            'download_link' => (string) $d['download_url'],
            'requires'      => isset( $d['requires'] ) ? (string) $d['requires'] : '',
            'tested'        => isset( $d['tested'] ) ? (string) $d['tested'] : '',
            'requires_php'  => isset( $d['requires_php'] ) ? (string) $d['requires_php'] : '',
            'sections'      => array( 'changelog' => wpautop( esc_html( isset( $d['changelog'] ) ? (string) $d['changelog'] : '' ) ) ),
        );
    }

    public static function flush() {
        delete_site_transient( self::CACHE );
    }
}

SSEO_Updater::init();
