<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Full Technical SEO Audit — Semrush-level site crawl
 * Checks 30+ factors per page, generates scores, links to fix tools
 */
class SSEO_SEO_Audit {

    public function run() {
        $types = get_option('sseo_post_types', ['post','page']);
        $seo   = new SSEO_SEO_Integration();
        $site  = home_url('/');

        $issues = [];
        $pages  = [];
        $scores = ['meta'=>0,'titles'=>0,'h1'=>0,'images'=>0,'content'=>0,'technical'=>0,'schema'=>0,'speed'=>0];
        $totals = ['meta'=>0,'titles'=>0,'h1'=>0,'images'=>0,'content'=>0,'technical'=>0,'schema'=>0,'speed'=>0];

        // ── Crawl all pages ──
        $all_posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>-1]);
        $total_pages = count($all_posts);

        foreach ($all_posts as $p) {
            $url   = get_permalink($p->ID);
            $title = $p->post_title;
            $content = $p->post_content;
            $text  = wp_strip_all_tags($content);
            $words = str_word_count($text);
            $page_issues = [];

            // 1. META DESCRIPTION
            $meta = $seo->get_meta($p->ID);
            $totals['meta']++;
            if (empty(trim($meta))) {
                $page_issues[] = ['cat'=>'meta','sev'=>'critical','msg'=>'Missing meta description','fix'=>'sseo-meta','fix_label'=>'Generate Meta'];
            } elseif (mb_strlen($meta) < 120) {
                $page_issues[] = ['cat'=>'meta','sev'=>'warning','msg'=>'Meta too short ('.mb_strlen($meta).' chars, min 120)','fix'=>'sseo-meta','fix_label'=>'Edit Meta'];
                $scores['meta']++;
            } elseif (mb_strlen($meta) > 160) {
                $page_issues[] = ['cat'=>'meta','sev'=>'warning','msg'=>'Meta too long ('.mb_strlen($meta).' chars, max 160)','fix'=>'sseo-meta','fix_label'=>'Edit Meta'];
                $scores['meta']++;
            } else { $scores['meta']++; }

            // 2. TITLE TAG
            $seo_title = $seo->get_title($p->ID);
            $t = $seo_title ?: $title;
            $tlen = mb_strlen($t);
            $totals['titles']++;
            if (empty(trim($t))) {
                $page_issues[] = ['cat'=>'titles','sev'=>'critical','msg'=>'Missing title tag','fix'=>'sseo-titles','fix_label'=>'Optimize Title'];
            } elseif ($tlen > 60) {
                $page_issues[] = ['cat'=>'titles','sev'=>'warning','msg'=>'Title too long ('.$tlen.' chars, max 60)','fix'=>'sseo-titles','fix_label'=>'Fix Title'];
                $scores['titles']++;
            } elseif ($tlen < 30) {
                $page_issues[] = ['cat'=>'titles','sev'=>'warning','msg'=>'Title too short ('.$tlen.' chars, min 30)','fix'=>'sseo-titles','fix_label'=>'Fix Title'];
                $scores['titles']++;
            } else { $scores['titles']++; }

            // 3. H1 TAG
            preg_match_all('/<h1[^>]*>(.*?)<\/h1>/is', $content, $h1m);
            $h1_count = count($h1m[1]??[]);
            $totals['h1']++;
            if ($h1_count === 0) {
                $page_issues[] = ['cat'=>'h1','sev'=>'critical','msg'=>'Missing H1 tag','fix'=>'sseo-h1','fix_label'=>'Fix H1'];
            } elseif ($h1_count > 1) {
                $page_issues[] = ['cat'=>'h1','sev'=>'warning','msg'=>'Multiple H1 tags ('.$h1_count.')','fix'=>'sseo-h1','fix_label'=>'Fix H1'];
                $scores['h1']++;
            } else { $scores['h1']++; }

            // 4. IMAGES
            if (preg_match_all('/<img[^>]+>/i', $content, $imgs)) {
                foreach ($imgs[0] as $img_tag) {
                    $totals['images']++;
                    $has_alt = preg_match('/alt=["\'][^"\']+["\']/i', $img_tag);
                    $has_dims = preg_match('/width\s*=/', $img_tag) && preg_match('/height\s*=/', $img_tag);
                    $has_lazy = preg_match('/loading\s*=\s*["\']lazy/i', $img_tag);
                    $src = ''; if(preg_match('/src=["\']([^"\']+)["\']/i',$img_tag,$sm)) $src=basename($sm[1]);

                    if (!$has_alt) {
                        $page_issues[] = ['cat'=>'images','sev'=>'critical','msg'=>'Image missing ALT: '.substr($src,0,30),'fix'=>'sseo-alts','fix_label'=>'Fix ALT Tags'];
                    } else { $scores['images']++; }

                    if (!$has_dims) {
                        $page_issues[] = ['cat'=>'images','sev'=>'warning','msg'=>'Image missing dimensions: '.substr($src,0,30),'fix'=>'sseo-imgopt','fix_label'=>'Fix Dimensions'];
                    }
                }
            }

            // 5. CONTENT QUALITY
            $totals['content']++;
            if ($words < 100) {
                $page_issues[] = ['cat'=>'content','sev'=>'critical','msg'=>'Very thin content ('.$words.' words)','fix'=>'sseo-thin','fix_label'=>'Enhance Content'];
            } elseif ($words < 300) {
                $page_issues[] = ['cat'=>'content','sev'=>'warning','msg'=>'Thin content ('.$words.' words, aim 500+)','fix'=>'sseo-thin','fix_label'=>'Enhance Content'];
                $scores['content']++;
            } else { $scores['content']++; }

            // Readability (simple Flesch approximation)
            $sentences = max(1, preg_match_all('/[.!?]+/', $text));
            $avg_sentence = $words / $sentences;
            if ($avg_sentence > 25) {
                $page_issues[] = ['cat'=>'content','sev'=>'info','msg'=>'Long sentences (avg '.round($avg_sentence).' words) — harder to read'];
            }

            // Check for internal links
            $internal_links = 0;
            if (preg_match_all('/href=["\']([^"\']+)["\']/i', $content, $hrefs)) {
                $host = wp_parse_url($site, PHP_URL_HOST);
                foreach ($hrefs[1] as $href) {
                    $h = wp_parse_url($href, PHP_URL_HOST);
                    if (empty($h) || $h === $host) $internal_links++;
                }
            }
            if ($internal_links === 0 && $words > 200) {
                $page_issues[] = ['cat'=>'content','sev'=>'warning','msg'=>'No internal links — add links to related pages','fix'=>'sseo-orphans','fix_label'=>'Fix Orphan Pages'];
            }

            // 6. TECHNICAL
            $totals['technical']++;
            // Check canonical
            // Check for duplicate content (same meta on multiple pages tracked later)
            if (has_post_thumbnail($p->ID)) {
                $scores['technical']++;
            } else {
                $page_issues[] = ['cat'=>'technical','sev'=>'info','msg'=>'No featured image set'];
            }

            // Heading hierarchy
            $has_h2 = preg_match('/<h2/i', $content);
            if ($words > 300 && !$has_h2) {
                $page_issues[] = ['cat'=>'technical','sev'=>'warning','msg'=>'No H2 subheadings in long content — add structure'];
            }

            $pages[] = [
                'post_id' => $p->ID, 'title' => $title, 'url' => $url, 'type' => $p->post_type,
                'words' => $words, 'issues' => $page_issues, 'issue_count' => count($page_issues),
                'score' => $this->page_score($page_issues),
            ];
        }

        // ── Site-wide checks ──
        $site_issues = [];

        // Schema
        $totals['schema'] = 1;
        if (get_option('sseo_schema_enabled', 1)) { $scores['schema']++; }
        else { $site_issues[] = ['cat'=>'schema','sev'=>'critical','msg'=>'Schema markup disabled','fix'=>'sseo-schema','fix_label'=>'Enable Schema']; }

        if (!get_option('sseo_og_enabled', 1)) {
            $site_issues[] = ['cat'=>'schema','sev'=>'warning','msg'=>'Open Graph tags disabled','fix'=>'sseo-schema','fix_label'=>'Enable OG'];
        }

        $brand = get_option('sseo_brand_name','');
        if (empty($brand)) { $site_issues[] = ['cat'=>'schema','sev'=>'warning','msg'=>'Business name not set for schema','fix'=>'sseo-settings','fix_label'=>'Settings']; }
        $phone = get_option('sseo_business_phone','');
        if (empty($phone)) { $site_issues[] = ['cat'=>'schema','sev'=>'warning','msg'=>'Business phone not set for schema','fix'=>'sseo-settings','fix_label'=>'Settings']; }
        $addr = get_option('sseo_business_address','');
        if (empty($addr)) { $site_issues[] = ['cat'=>'schema','sev'=>'warning','msg'=>'Business address not set for schema','fix'=>'sseo-settings','fix_label'=>'Settings']; }

        // robots.txt
        $robots = new SSEO_Robots_Txt();
        $rb_scan = $robots->scan_blocked();
        if ($rb_scan['critical'] > 0) { $site_issues[] = ['cat'=>'technical','sev'=>'critical','msg'=>$rb_scan['critical'].' critical robots.txt rules blocking crawlers','fix'=>'sseo-robots','fix_label'=>'Fix robots.txt']; }
        if ($rb_scan['high'] > 0) { $site_issues[] = ['cat'=>'technical','sev'=>'warning','msg'=>$rb_scan['high'].' resources blocked in robots.txt','fix'=>'sseo-robots','fix_label'=>'Fix robots.txt']; }
        if (!$rb_scan['has_sitemap']) { $site_issues[] = ['cat'=>'technical','sev'=>'warning','msg'=>'No sitemap referenced in robots.txt','fix'=>'sseo-robots','fix_label'=>'Fix robots.txt']; }

        // SSL
        if (strpos($site, 'https') !== 0) {
            $site_issues[] = ['cat'=>'technical','sev'=>'critical','msg'=>'Site not using HTTPS','fix'=>'','fix_label'=>''];
        }

        // llms.txt
        $llms = get_option('sseo_llms_txt_content','');
        if (empty($llms)) { $site_issues[] = ['cat'=>'technical','sev'=>'info','msg'=>'No llms.txt file for AI crawlers','fix'=>'sseo-llms','fix_label'=>'Generate llms.txt']; }

        // Duplicate metas
        $meta_dupes = $this->find_duplicate_metas($all_posts, $seo);
        foreach ($meta_dupes as $d) {
            $site_issues[] = ['cat'=>'meta','sev'=>'warning','msg'=>'Duplicate meta on: '.implode(', ', array_slice($d['pages'],0,3)),'fix'=>'sseo-meta','fix_label'=>'Fix Metas'];
        }

        // ── Calculate overall score ──
        $cat_scores = [];
        foreach ($scores as $k => $v) {
            $max = max(1, $totals[$k]);
            $cat_scores[$k] = ['score'=>$v, 'total'=>$max, 'pct'=>round($v/$max*100)];
        }

        $total_issues = count($site_issues);
        foreach ($pages as $pg) $total_issues += $pg['issue_count'];

        $critical = count(array_filter($site_issues, function($i){ return $i['sev']==='critical'; }));
        $warnings = count(array_filter($site_issues, function($i){ return $i['sev']==='warning'; }));
        foreach ($pages as $pg) {
            $critical += count(array_filter($pg['issues'], function($i){ return $i['sev']==='critical'; }));
            $warnings += count(array_filter($pg['issues'], function($i){ return $i['sev']==='warning'; }));
        }

        $overall = $this->overall_score($cat_scores, $critical, $warnings);

        // Sort pages by issue count (worst first)
        usort($pages, function($a,$b){ return $b['issue_count'] - $a['issue_count']; });

        return [
            'overall_score' => $overall,
            'total_pages'   => $total_pages,
            'total_issues'  => $total_issues,
            'critical'      => $critical,
            'warnings'      => $warnings,
            'cat_scores'    => $cat_scores,
            'site_issues'   => $site_issues,
            'pages'         => array_slice($pages, 0, 50), // Top 50 worst pages
            'meta_dupes'    => count($meta_dupes),
        ];
    }

    private function page_score($issues) {
        $score = 100;
        foreach ($issues as $i) {
            if ($i['sev']==='critical') $score -= 15;
            elseif ($i['sev']==='warning') $score -= 5;
            else $score -= 1;
        }
        return max(0, $score);
    }

    private function overall_score($cats, $critical, $warnings) {
        $sum = 0; $n = 0;
        foreach ($cats as $c) { if($c['total']>0){ $sum += $c['pct']; $n++; } }
        $base = $n > 0 ? $sum / $n : 50;
        $base -= min(30, $critical * 3);
        $base -= min(15, $warnings * 0.5);
        return max(0, min(100, round($base)));
    }

    private function find_duplicate_metas($posts, $seo) {
        $map = [];
        foreach ($posts as $p) {
            $m = trim($seo->get_meta($p->ID));
            if (empty($m) || mb_strlen($m) < 20) continue;
            $key = strtolower(substr($m, 0, 80));
            $map[$key][] = $p->post_title;
        }
        $dupes = [];
        foreach ($map as $k => $pages) {
            if (count($pages) > 1) $dupes[] = ['meta_prefix'=>$k,'pages'=>$pages,'count'=>count($pages)];
        }
        return $dupes;
    }
}
