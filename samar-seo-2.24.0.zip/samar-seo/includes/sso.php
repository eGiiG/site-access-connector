<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Secure one-click sign-in for the agency — same mechanism as the standalone Site Access Connector, but
 * keyed to THIS plugin's reporting secret. So a single SEO Suite install gives the agency both SEO
 * reporting AND 1-click admin access — no separate connector plugin needed.
 *
 *   URL: {site}/?sseo_sso=1&exp=…&nonce=…&role=…&sig=HMAC(secret, exp.nonce.role)
 *   60-second expiry, single-use nonce, HTTPS only, dedicated 'site-access' user.
 */
add_action( 'init', function () {
    if ( ! isset( $_GET['sseo_sso'] ) ) return;
    if ( ! function_exists( 'sseo_connect_secret' ) ) return;

    $secret = sseo_connect_secret();
    if ( $secret === '' || ! get_option( 'sseo_connect_paired' ) ) return;

    $exp   = intval( $_GET['exp'] ?? 0 );
    $nonce = sanitize_text_field( $_GET['nonce'] ?? '' );
    $role  = sanitize_text_field( $_GET['role'] ?? 'administrator' );
    $sig   = sanitize_text_field( $_GET['sig'] ?? '' );

    if ( ! is_ssl() )         wp_die( 'A secure (HTTPS) connection is required.' );
    if ( $exp < time() )      wp_die( 'This access link has expired.' );
    if ( ! $nonce || ! $sig ) wp_die( 'Invalid access link.' );

    $used = (array) get_option( 'sseo_sso_used_nonces', [] );
    if ( in_array( $nonce, $used, true ) ) wp_die( 'This access link was already used.' );

    $expected = hash_hmac( 'sha256', $exp . '.' . $nonce . '.' . $role, $secret );
    if ( ! hash_equals( $expected, $sig ) ) wp_die( 'Invalid access link.' );

    $role  = in_array( $role, [ 'editor', 'administrator' ], true ) ? $role : 'editor';
    $login = 'site-access';
    $user  = get_user_by( 'login', $login );
    if ( ! $user ) {
        $uid = wp_insert_user( [
            'user_login'   => $login,
            'user_pass'    => wp_generate_password( 64 ),
            'role'         => $role,
            'display_name' => ( get_option( 'sseo_whitelabel_name' ) ?: 'Site Access' ),
        ] );
        if ( is_wp_error( $uid ) ) wp_die( 'Could not create the access user.' );
        $user = get_user_by( 'id', $uid );
    }

    $used[] = $nonce;
    update_option( 'sseo_sso_used_nonces', array_slice( $used, -300 ) );

    wp_set_auth_cookie( $user->ID, false );
    wp_set_current_user( $user->ID );
    wp_safe_redirect( admin_url() );
    exit;
} );
