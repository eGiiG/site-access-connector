<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Broken_Links {

    public function scan( $limit = 100 ) {
        $types = get_option( 'sseo_post_types', ['post','page'] );
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>$limit]);
        $broken = [];
        $checked = [];

        foreach ( $posts as $post ) {
            preg_match_all( '/href=["\']([^"\'#]+)["\']/i', $post->post_content, $matches );
            if ( empty($matches[1]) ) continue;

            foreach ( $matches[1] as $url ) {
                // Only check internal links
                $parsed = wp_parse_url( $url );
                $host   = $parsed['host'] ?? '';
                $site_host = wp_parse_url( home_url(), PHP_URL_HOST );

                // Relative URLs or matching host
                $is_internal = empty( $host ) || $host === $site_host || $host === 'www.' . $site_host;
                if ( ! $is_internal ) continue;

                // Normalize
                $path = $parsed['path'] ?? $url;
                if ( isset( $checked[$path] ) ) {
                    if ( $checked[$path] === 'broken' ) {
                        $broken[] = ['source_id'=>$post->ID,'source_title'=>$post->post_title,'broken_url'=>$url,'source_url'=>get_permalink($post->ID)];
                    }
                    continue;
                }

                // Check if URL resolves to a real post/page
                $post_id = url_to_postid( home_url( $path ) );
                if ( $post_id > 0 ) {
                    $checked[$path] = 'ok';
                    continue;
                }

                // Check if it's a real file or known URL
                $full_url = home_url( $path );
                $response = wp_remote_head( $full_url, ['timeout'=>5,'redirection'=>0,'sslverify'=>false] );
                $code = is_wp_error($response) ? 0 : wp_remote_retrieve_response_code($response);

                if ( $code === 404 || $code === 0 ) {
                    $checked[$path] = 'broken';
                    $broken[] = [
                        'source_id'    => $post->ID,
                        'source_title' => $post->post_title,
                        'broken_url'   => $url,
                        'http_code'    => $code,
                        'source_url'   => get_permalink( $post->ID ),
                    ];
                } else {
                    $checked[$path] = 'ok';
                }
            }
        }

        return $broken;
    }
}
