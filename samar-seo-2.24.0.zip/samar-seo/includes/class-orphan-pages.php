<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Orphan_Pages {

    /**
     * Scan all pages for internal link count, find orphans (<3 inbound links)
     */
    public function scan( $min_links = 3 ) {
        $types = get_option( 'sseo_post_types', ['post','page'] );
        $all   = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>-1]);

        // Build URL→ID map and count inbound links per page
        $url_map   = [];
        $inbound   = [];
        $outbound  = [];
        $site_host = wp_parse_url( home_url(), PHP_URL_HOST );

        foreach ( $all as $p ) {
            $url = get_permalink( $p->ID );
            $path = wp_parse_url( $url, PHP_URL_PATH );
            $url_map[ $path ] = $p->ID;
            $inbound[ $p->ID ]  = 0;
            $outbound[ $p->ID ] = 0;
        }

        // Count links
        foreach ( $all as $p ) {
            if ( preg_match_all( '/href=["\']([^"\'#]+)["\']/i', $p->post_content, $matches ) ) {
                foreach ( $matches[1] as $href ) {
                    $parsed = wp_parse_url( $href );
                    $host   = $parsed['host'] ?? '';
                    $path   = $parsed['path'] ?? $href;

                    $is_internal = empty($host) || $host === $site_host || $host === 'www.'.$site_host;
                    if ( ! $is_internal ) continue;

                    $outbound[ $p->ID ]++;

                    // Find target post
                    $clean = rtrim( $path, '/' ) . '/';
                    $clean2 = rtrim( $path, '/' );
                    foreach ( $url_map as $up => $uid ) {
                        if ( $up === $clean || $up === $clean2 || rtrim($up,'/') === $clean2 ) {
                            if ( $uid !== $p->ID ) $inbound[ $uid ]++;
                            break;
                        }
                    }
                }
            }
        }

        // Find orphans
        $orphans = [];
        foreach ( $all as $p ) {
            $ib = $inbound[ $p->ID ] ?? 0;
            if ( $ib < $min_links ) {
                $orphans[] = [
                    'post_id'       => $p->ID,
                    'title'         => $p->post_title,
                    'permalink'     => get_permalink( $p->ID ),
                    'post_type'     => $p->post_type,
                    'inbound_links' => $ib,
                    'outbound_links'=> $outbound[ $p->ID ] ?? 0,
                    'word_count'    => str_word_count( wp_strip_all_tags( $p->post_content ) ),
                ];
            }
        }

        usort( $orphans, function($a,$b){ return $a['inbound_links'] - $b['inbound_links']; });

        return [
            'orphans'     => $orphans,
            'total_pages' => count($all),
            'total_orphans'=> count($orphans),
            'threshold'   => $min_links,
        ];
    }

    /**
     * Suggest related pages to link FROM to fix an orphan
     */
    public function suggest_links_for( $post_id, $limit = 5 ) {
        $post  = get_post( $post_id );
        if ( ! $post ) return [];

        $types   = get_option( 'sseo_post_types', ['post','page'] );
        $target  = strtolower( $post->post_title );
        $words   = array_filter( explode(' ', $target), function($w){ return strlen($w) > 3; } );
        $cats    = wp_get_post_categories( $post_id, ['fields'=>'ids'] );
        $tags    = wp_get_post_tags( $post_id, ['fields'=>'ids'] );

        $candidates = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>100,'exclude'=>[$post_id]]);
        $scored = [];

        foreach ( $candidates as $c ) {
            $score = 0;
            $c_title   = strtolower( $c->post_title );
            $c_content = strtolower( wp_strip_all_tags( $c->post_content ) );

            // Title word overlap
            foreach ( $words as $w ) {
                if ( strpos( $c_title, $w ) !== false ) $score += 3;
                if ( strpos( $c_content, $w ) !== false ) $score += 1;
            }

            // Same category
            $c_cats = wp_get_post_categories( $c->ID, ['fields'=>'ids'] );
            if ( array_intersect( $cats, $c_cats ) ) $score += 5;

            // Same tags
            $c_tags = wp_get_post_tags( $c->ID, ['fields'=>'ids'] );
            if ( array_intersect( $tags, $c_tags ) ) $score += 3;

            // Already links to orphan? Skip
            if ( strpos( $c->post_content, get_permalink($post_id) ) !== false ) continue;

            if ( $score > 0 ) {
                $scored[] = [
                    'post_id'   => $c->ID,
                    'title'     => $c->post_title,
                    'permalink' => get_permalink( $c->ID ),
                    'post_type' => $c->post_type,
                    'score'     => $score,
                ];
            }
        }

        usort( $scored, function($a,$b){ return $b['score'] - $a['score']; });
        return array_slice( $scored, 0, $limit );
    }

    /**
     * Inject a link into a source post pointing to target
     * Finds a relevant paragraph and appends the link naturally
     */
    public function inject_link( $source_post_id, $target_post_id, $anchor_text = '' ) {
        $source = get_post( $source_post_id );
        $target = get_post( $target_post_id );
        if ( ! $source || ! $target ) return new WP_Error('no_post','Post not found.');

        $target_url = get_permalink( $target_post_id );
        if ( ! $anchor_text ) $anchor_text = $target->post_title;
        $anchor_text = sanitize_text_field( $anchor_text );

        // Check if link already exists
        if ( strpos( $source->post_content, $target_url ) !== false ) {
            return new WP_Error('exists','Link already exists in this post.');
        }

        $link_html = '<a href="' . esc_url($target_url) . '">' . esc_html($anchor_text) . '</a>';

        // Try to find a good spot — before the last </p> in content
        $content = $source->post_content;
        $last_p = strrpos( $content, '</p>' );
        if ( $last_p !== false ) {
            $sentence = ' For more information, see our guide on ' . $link_html . '.';
            $content = substr_replace( $content, $sentence, $last_p, 0 );
        } else {
            $content .= "\n<p>Related: {$link_html}</p>";
        }

        wp_update_post(['ID'=>$source_post_id,'post_content'=>$content]);

        global $wpdb;
        $wpdb->insert($wpdb->prefix.'sseo_log',['post_id'=>$source_post_id,'type'=>'link','old_value'=>'orphan fix: '.$target->post_title,'new_value'=>$anchor_text.' → '.$target_url]);

        return ['source'=>$source_post_id,'target'=>$target_post_id,'anchor'=>$anchor_text];
    }
}
