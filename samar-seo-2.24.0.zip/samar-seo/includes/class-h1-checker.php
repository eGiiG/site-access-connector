<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_H1_Checker {
    private $api;
    public function __construct() { $this->api = new SSEO_API_Handler(); }

    public function scan() {
        $types = get_option( 'sseo_post_types', ['post','page'] );
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>-1]);
        $ignored = get_option( 'sseo_thin_ignored', [] );
        $issues = [];
        foreach ( $posts as $p ) {
            if ( in_array( $p->ID, $ignored ) ) continue;
            $content = $p->post_content;
            preg_match_all( '/<h1[^>]*>(.*?)<\/h1>/is', $content, $matches );
            $h1s = $matches[1] ?? [];
            $count = count( $h1s );
            $issue = '';
            if ( $count === 0 ) $issue = 'missing';
            elseif ( $count > 1 ) $issue = 'multiple';
            if ( $issue ) {
                $issues[] = [
                    'post_id'   => $p->ID,
                    'title'     => $p->post_title,
                    'h1_count'  => $count,
                    'h1_tags'   => array_map( 'wp_strip_all_tags', $h1s ),
                    'issue'     => $issue,
                    'permalink' => get_permalink( $p->ID ),
                    'post_type' => $p->post_type,
                ];
            }
        }
        return $issues;
    }

    public function suggest( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) return new WP_Error( 'no_post', 'Not found.' );
        $brand = get_option( 'sseo_brand_name', '' );
        $loc   = get_option( 'sseo_target_location', '' );
        $content = wp_trim_words( wp_strip_all_tags($post->post_content), 100 );

        $prompt = "Generate 3 SEO-optimized H1 heading suggestions for this page.
Page title: {$post->post_title}
Content: {$content}
" . ($brand?"Brand: {$brand}\n":'') . ($loc?"Location: {$loc}\n":'') . "
Rules:
- Include primary keyword + geographic modifier if relevant
- 40-70 characters
- Complementary to but different from the title tag
- Compelling and descriptive

Return ONLY JSON: [{\"h1\":\"...\",\"charCount\":55}]
No markdown.";
        $r = $this->api->complete( $prompt );
        if ( is_wp_error($r) ) return $r;
        $p = SSEO_API_Handler::parse_json( $r['content'] );
        if ( is_wp_error($p) ) return $p;
        return [ 'suggestions'=>$p, 'post_id'=>$post_id, 'post_title'=>$post->post_title ];
    }

    /**
     * Apply an H1 tag to post content.
     * - If missing: prepend <h1> before the first block of content
     * - If multiple: replace first H1 with new text, convert rest to H2
     */
    public function apply( $post_id, $h1_text ) {
        $post = get_post( $post_id );
        if ( ! $post ) return new WP_Error( 'no_post', 'Post not found.' );

        $h1_text = sanitize_text_field( $h1_text );
        if ( empty( $h1_text ) ) return new WP_Error( 'empty_h1', 'H1 text cannot be empty.' );

        $content = $post->post_content;
        $old_h1s = [];
        preg_match_all( '/<h1[^>]*>(.*?)<\/h1>/is', $content, $matches, PREG_SET_ORDER );
        $h1_count = count( $matches );

        if ( $h1_count === 0 ) {
            // Missing H1 — prepend before first content block
            $new_h1 = '<h1>' . esc_html( $h1_text ) . '</h1>';

            // Try to insert after any initial <!-- wp: --> comment block
            if ( preg_match( '/^(\s*<!--\s*wp:[^>]*-->.*?<!--\s*\/wp:[^>]*-->\s*)/s', $content, $wp_m ) ) {
                $content = $wp_m[1] . "\n" . $new_h1 . "\n" . substr( $content, strlen( $wp_m[0] ) );
            } else {
                $content = $new_h1 . "\n\n" . $content;
            }
            $old_h1s = ['(missing)'];
        } elseif ( $h1_count >= 1 ) {
            // Replace FIRST H1 with new text, convert subsequent H1s to H2
            $replaced_first = false;
            $content = preg_replace_callback( '/<h1([^>]*)>(.*?)<\/h1>/is', function( $m ) use ( $h1_text, &$replaced_first, &$old_h1s ) {
                $old_h1s[] = wp_strip_all_tags( $m[2] );
                if ( ! $replaced_first ) {
                    $replaced_first = true;
                    return '<h1>' . esc_html( $h1_text ) . '</h1>';
                }
                // Convert subsequent H1s to H2 to preserve content structure
                return '<h2' . $m[1] . '>' . $m[2] . '</h2>';
            }, $content );
        }

        // Update post
        $result = wp_update_post([
            'ID'           => $post_id,
            'post_content' => $content,
        ], true);

        if ( is_wp_error( $result ) ) return $result;

        // Log the change
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'sseo_log', [
            'post_id'   => $post_id,
            'type'      => 'h1',
            'old_value' => implode( ' | ', $old_h1s ),
            'new_value' => $h1_text,
        ]);

        return [
            'post_id'  => $post_id,
            'h1'       => $h1_text,
            'old_h1s'  => $old_h1s,
            'action'   => $h1_count === 0 ? 'inserted' : 'replaced',
        ];
    }
}