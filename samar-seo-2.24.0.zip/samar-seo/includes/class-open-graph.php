<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Open_Graph {
    public function __construct() {
        if ( get_option('sseo_og_enabled', 1) ) {
            add_action( 'wp_head', [ $this, 'output' ], 5 );
        }
    }

    public function output() {
        // Don't output if Yoast or RankMath handles it
        $seo = new SSEO_SEO_Integration();
        $active = $seo->get_active();
        if ( in_array( $active, ['yoast','rankmath','aioseo'] ) ) return;

        $title = $this->get_title();
        $desc  = $this->get_description();
        $image = $this->get_image();
        $url   = $this->get_url();
        $type  = is_single() ? 'article' : 'website';
        $site  = get_bloginfo('name');

        echo "<!-- " . sseo_product_name() . " Open Graph -->\n";
        echo '<meta property="og:type" content="' . esc_attr($type) . '" />' . "\n";
        echo '<meta property="og:title" content="' . esc_attr($title) . '" />' . "\n";
        if ( $desc ) echo '<meta property="og:description" content="' . esc_attr($desc) . '" />' . "\n";
        echo '<meta property="og:url" content="' . esc_url($url) . '" />' . "\n";
        echo '<meta property="og:site_name" content="' . esc_attr($site) . '" />' . "\n";
        if ( $image ) echo '<meta property="og:image" content="' . esc_url($image) . '" />' . "\n";

        // Twitter Card
        echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr($title) . '" />' . "\n";
        if ( $desc ) echo '<meta name="twitter:description" content="' . esc_attr($desc) . '" />' . "\n";
        if ( $image ) echo '<meta name="twitter:image" content="' . esc_url($image) . '" />' . "\n";
        echo "<!-- /" . sseo_product_name() . " -->\n";
    }

    /* [og-overrides v2] The page whose settings apply: the singular page/post, or the
       "Posts page" when the blog index is a static page (is_home() is not singular, so
       get_the_ID() there returns the first post in the loop, not the blog page). */
    private function context_id() {
        if ( is_singular() ) return (int) get_queried_object_id();
        if ( is_home() && ! is_front_page() ) return (int) get_option( 'page_for_posts', 0 );
        return 0;
    }

    private function get_title() {
        $id = $this->context_id();
        if ( $id ) {
            $o = $this->override( 'og_title' );
            if ( $o ) return $o;
            $seo = new SSEO_SEO_Integration();
            $t = $seo->get_title( $id );
            return $t ?: get_the_title( $id );
        }
        return wp_title( '–', false, 'right' ) . get_bloginfo('name');
    }

    private function get_description() {
        $id = $this->context_id();
        if ( $id ) {
            $o = $this->override( 'og_description' );
            if ( $o ) return $o;
            $seo = new SSEO_SEO_Integration();
            $d = $seo->get_meta( $id );
            if ( $d ) return $d;
            if ( is_singular() ) return wp_trim_words( get_the_excerpt(), 25 );
        }
        return get_bloginfo('description');
    }

    /* Fallback order: page override -> featured image -> site default share image -> site icon. */
    private function get_image() {
        $id = $this->context_id();
        if ( $id ) {
            $o = $this->override( 'og_image' );
            if ( $o ) return $o;
            if ( has_post_thumbnail( $id ) ) {
                $u = get_the_post_thumbnail_url( $id, 'large' );
                if ( $u ) return $u;
            }
        }
        $d = $this->default_image();
        if ( $d ) return $d;
        return get_site_icon_url();
    }

    private function default_image() {
        if ( class_exists( 'EGSM_SEO_Settings' ) ) {
            $u = EGSM_SEO_Settings::get( 'default_og_image' );
            if ( is_string( $u ) && '' !== trim( $u ) ) return trim( $u );
        }
        return '';
    }

    /* Per-page Open Graph fields saved by Site Manager (wp_set_seo og_title/og_description/og_image). */
    private function override( $field ) {
        $id = $this->context_id();
        if ( ! $id ) return '';
        $meta = get_post_meta( $id, '_egsm_seo', true );
        if ( is_array( $meta ) && ! empty( $meta[ $field ] ) && is_string( $meta[ $field ] ) ) {
            return trim( $meta[ $field ] );
        }
        return '';
    }

    private function get_url() {
        $id = $this->context_id();
        if ( $id ) return get_permalink( $id );
        return home_url( $_SERVER['REQUEST_URI'] ?? '/' );
    }
}
