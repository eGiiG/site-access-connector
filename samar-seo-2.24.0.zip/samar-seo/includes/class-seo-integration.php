<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_SEO_Integration {
    private $plugin;
    private static $hooks_registered = false;

    public function __construct() {
        $this->plugin = $this->detect();

        // Register standalone frontend hooks ONCE (only if no SEO plugin handles it)
        if ( ! self::$hooks_registered && $this->plugin === 'standalone' && ! is_admin() ) {
            add_filter( 'pre_get_document_title', [ __CLASS__, 'override_document_title' ], 99 );
            add_filter( 'document_title_parts',   [ __CLASS__, 'override_title_parts' ], 99 );
            add_action( 'wp_head',                 [ __CLASS__, 'output_standalone_meta' ], 1 );
            self::$hooks_registered = true;
        }
    }

    public function detect() {
        $s = get_option( 'sseo_seo_plugin', 'auto' );
        if ( $s !== 'auto' ) return $s;
        if ( defined( 'WPSEO_VERSION' ) ) return 'yoast';
        if ( defined( 'RANK_MATH_VERSION' ) ) return 'rankmath';
        if ( defined( 'AIOSEO_VERSION' ) ) return 'aioseo';
        return 'standalone';
    }

    // ─── Standalone Frontend: <title> tag override ─────────
    public static function override_document_title( $title ) {
        if ( ! is_singular() ) return $title;
        $custom = get_post_meta( get_the_ID(), '_sseo_title', true );
        if ( $custom ) return $custom;
        return $title;
    }

    public static function override_title_parts( $parts ) {
        if ( ! is_singular() ) return $parts;
        $custom = get_post_meta( get_the_ID(), '_sseo_title', true );
        if ( $custom ) {
            $parts['title'] = $custom;
            // Remove site name suffix so the optimized title renders exactly as set
            unset( $parts['site'] );
            unset( $parts['tagline'] );
        }
        return $parts;
    }

    // ─── Standalone Frontend: <meta name="description"> ────
    public static function output_standalone_meta() {
        if ( ! is_singular() ) return;
        $desc = get_post_meta( get_the_ID(), '_sseo_meta_description', true );
        if ( $desc ) {
            echo '<meta name="description" content="' . esc_attr( $desc ) . '" />' . "\n";
        }
    }

    // ─── Meta Description CRUD ─────────
    public function get_meta( $id ) {
        switch ( $this->plugin ) {
            case 'yoast':     return get_post_meta( $id, '_yoast_wpseo_metadesc', true );
            case 'rankmath':  return get_post_meta( $id, 'rank_math_description', true );
            case 'aioseo':
                global $wpdb;
                $t = $wpdb->prefix . 'aioseo_posts';
                if ( $wpdb->get_var("SHOW TABLES LIKE '{$t}'") === $t )
                    return $wpdb->get_var( $wpdb->prepare("SELECT description FROM {$t} WHERE post_id=%d", $id) );
                return '';
            default: return get_post_meta( $id, '_sseo_meta_description', true );
        }
    }

    public function set_meta( $id, $desc ) {
        $desc = sanitize_text_field( $desc );
        update_post_meta( $id, '_sseo_meta_description', $desc );
        switch ( $this->plugin ) {
            case 'yoast':    update_post_meta( $id, '_yoast_wpseo_metadesc', $desc ); break;
            case 'rankmath': update_post_meta( $id, 'rank_math_description', $desc ); break;
            case 'aioseo':
                global $wpdb;
                $t = $wpdb->prefix . 'aioseo_posts';
                if ( $wpdb->get_var("SHOW TABLES LIKE '{$t}'") === $t ) {
                    $exists = $wpdb->get_var( $wpdb->prepare("SELECT id FROM {$t} WHERE post_id=%d", $id) );
                    $exists ? $wpdb->update($t,['description'=>$desc],['post_id'=>$id]) : $wpdb->insert($t,['post_id'=>$id,'description'=>$desc]);
                }
                break;
        }
    }

    // ─── Title CRUD ─────────
    public function get_title( $id ) {
        switch ( $this->plugin ) {
            case 'yoast':    return get_post_meta( $id, '_yoast_wpseo_title', true );
            case 'rankmath': return get_post_meta( $id, 'rank_math_title', true );
            case 'aioseo':
                global $wpdb;
                $t = $wpdb->prefix . 'aioseo_posts';
                if ( $wpdb->get_var("SHOW TABLES LIKE '{$t}'") === $t ) {
                    $val = $wpdb->get_var( $wpdb->prepare("SELECT title FROM {$t} WHERE post_id=%d", $id) );
                    if ( $val ) return $val;
                }
                return get_post_meta( $id, '_sseo_title', true );
            default: return get_post_meta( $id, '_sseo_title', true );
        }
    }

    public function set_title( $id, $title ) {
        $title = sanitize_text_field( $title );
        update_post_meta( $id, '_sseo_title', $title );
        switch ( $this->plugin ) {
            case 'yoast':    update_post_meta( $id, '_yoast_wpseo_title', $title ); break;
            case 'rankmath': update_post_meta( $id, 'rank_math_title', $title ); break;
            case 'aioseo':
                global $wpdb;
                $t = $wpdb->prefix . 'aioseo_posts';
                if ( $wpdb->get_var("SHOW TABLES LIKE '{$t}'") === $t ) {
                    $exists = $wpdb->get_var( $wpdb->prepare("SELECT id FROM {$t} WHERE post_id=%d", $id) );
                    $exists ? $wpdb->update($t,['title'=>$title],['post_id'=>$id]) : $wpdb->insert($t,['post_id'=>$id,'title'=>$title]);
                }
                break;
        }
    }

    public function get_name() {
        $n = [ 'yoast'=>'Yoast SEO','rankmath'=>'Rank Math','aioseo'=>'All in One SEO','standalone'=>'Standalone' ];
        return $n[ $this->plugin ] ?? 'Unknown';
    }

    public function get_active() { return $this->plugin; }

    public function get_focus_keyword( $id ) {
        $kw = get_post_meta( $id, '_yoast_wpseo_focuskw', true );
        if ( ! $kw ) $kw = get_post_meta( $id, 'rank_math_focus_keyword', true );
        return $kw ?: '';
    }
}