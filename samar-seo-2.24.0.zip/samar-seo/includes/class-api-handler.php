<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_API_Handler {
    private $provider;

    // Provider configs: endpoint, key_option, model_option, auth_type
    private static $providers = [
        'openai'     => ['url'=>'https://api.openai.com/v1/chat/completions','key'=>'sseo_openai_api_key','model'=>'sseo_openai_model','default_model'=>'gpt-4o-mini','label'=>'OpenAI','type'=>'openai'],
        'azure'      => ['url'=>'','key'=>'sseo_azure_api_key','model'=>'','default_model'=>'','label'=>'Azure OpenAI','type'=>'azure'],
        'anthropic'  => ['url'=>'https://api.anthropic.com/v1/messages','key'=>'sseo_anthropic_api_key','model'=>'sseo_anthropic_model','default_model'=>'claude-sonnet-4-20250514','label'=>'Anthropic Claude','type'=>'anthropic'],
        'deepseek'   => ['url'=>'https://api.deepseek.com/v1/chat/completions','key'=>'sseo_deepseek_api_key','model'=>'sseo_deepseek_model','default_model'=>'deepseek-chat','label'=>'DeepSeek','type'=>'openai'],
        'groq'       => ['url'=>'https://api.groq.com/openai/v1/chat/completions','key'=>'sseo_groq_api_key','model'=>'sseo_groq_model','default_model'=>'llama-3.3-70b-versatile','label'=>'Groq (Free)','type'=>'openai'],
        'gemini'     => ['url'=>'','key'=>'sseo_gemini_api_key','model'=>'sseo_gemini_model','default_model'=>'gemini-2.0-flash','label'=>'Google Gemini','type'=>'gemini'],
        'openrouter' => ['url'=>'https://openrouter.ai/api/v1/chat/completions','key'=>'sseo_openrouter_api_key','model'=>'sseo_openrouter_model','default_model'=>'meta-llama/llama-3.3-70b-instruct:free','label'=>'OpenRouter','type'=>'openai'],
        'platform'   => ['url'=>'','key'=>'','model'=>'','default_model'=>'','label'=>'Platform AI (via your agency)','type'=>'platform'],
    ];

    public function __construct() {
        $this->provider = get_option( 'sseo_provider', 'openai' );
    }

    public function complete( $prompt, $temperature = 0.7, $max_tokens = 4096 ) {
        $cfg = self::$providers[$this->provider] ?? self::$providers['openai'];
        switch ( $cfg['type'] ) {
            case 'platform':  return $this->call_platform( $prompt, $temperature, $max_tokens );
            case 'azure':     return $this->call_azure( $prompt, $temperature, $max_tokens );
            case 'anthropic': return $this->call_anthropic( $prompt, $temperature, $max_tokens );
            case 'gemini':    return $this->call_gemini( $prompt, $temperature, $max_tokens );
            default:          return $this->call_openai_compat( $cfg, $prompt, $temperature, $max_tokens );
        }
    }

    private function call_platform( $prompt, $temp, $max_tokens = 4096 ) {
        if ( ! function_exists('sseo_is_connected') || ! sseo_is_connected() ) {
            return new WP_Error( 'not_connected', 'Platform AI needs the reporting connection. Connect to your agency in Settings first.' );
        }
        $r = wp_remote_post( trailingslashit( sseo_api_base() ) . 'api/wp-plugin/ai', [
            'timeout' => 120,
            'headers' => [ 'Content-Type' => 'application/json', 'Accept' => 'application/json' ],
            'body'    => wp_json_encode( [
                'token'       => sseo_connect_secret(),
                'prompt'      => $prompt,
                'temperature' => max( 0.01, $temp ),
                'max_tokens'  => $max_tokens,
            ] ),
        ] );
        if ( is_wp_error( $r ) ) return $r;
        $code = wp_remote_retrieve_response_code( $r );
        $body = json_decode( wp_remote_retrieve_body( $r ), true );
        if ( $code !== 200 || empty( $body['ok'] ) ) {
            return new WP_Error( 'platform_ai', ! empty( $body['message'] ) ? $body['message'] : ( 'Platform AI error (HTTP ' . $code . ').' ) );
        }
        return [ 'content' => (string) ( $body['content'] ?? '' ) ];
    }

    private function call_openai_compat( $cfg, $prompt, $temp, $max_tokens = 4096 ) {
        $key   = get_option( $cfg['key'], '' );
        $model = get_option( $cfg['model'], $cfg['default_model'] );
        if ( empty($key) ) return new WP_Error( 'no_key', $cfg['label'] . ' API key not set.' );

        $headers = [ 'Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . $key ];

        $body_data = [
            'model'       => $model,
            'messages'    => [ [ 'role' => 'user', 'content' => $prompt ] ],
            'temperature' => max( 0.01, $temp ), // Some providers reject exactly 0
            'max_tokens'  => $max_tokens,
        ];

        // OpenRouter needs extra headers and transforms
        if ( $this->provider === 'openrouter' ) {
            $headers['HTTP-Referer'] = home_url('/');
            $headers['X-Title'] = sseo_product_name();
            // OpenRouter requires these for some free models
            $body_data['transforms'] = ['middle-out'];
            // Some free models need the provider routing
            $body_data['route'] = 'fallback';
        }

        $r = wp_remote_post( $cfg['url'], [
            'timeout' => 120,
            'headers' => $headers,
            'body'    => wp_json_encode( $body_data ),
        ] );
        return $this->parse( $r );
    }

    private function call_azure( $prompt, $temp, $max_tokens = 4096 ) {
        $key = get_option('sseo_azure_api_key'); $ep = get_option('sseo_azure_endpoint'); $dep = get_option('sseo_azure_deployment'); $ver = get_option('sseo_azure_api_version','2025-04-01-preview');
        if (!$key||!$ep||!$dep) return new WP_Error('config','Azure config incomplete. Need: API Key, Endpoint URL, and Deployment Name.');

        // Aggressively clean endpoint — extract just the base URL
        // User might paste: https://xxx.cognitiveservices.azure.com/openai/responses?api-version=2025-04-01-preview
        // We need just: https://xxx.cognitiveservices.azure.com
        $ep = trim($ep);
        // Remove query string
        $ep = preg_replace('/\?.*$/', '', $ep);
        // Remove everything after .azure.com (handles .openai.azure.com and .cognitiveservices.azure.com)
        if (preg_match('#^(https?://[^/]*\.azure\.com)#i', $ep, $m)) {
            $ep = $m[1];
        } else {
            $ep = rtrim($ep, '/');
            $ep = preg_replace('#/openai.*$#i', '', $ep);
        }

        // Extract API version from user's pasted URL if they included it
        $raw_ep = get_option('sseo_azure_endpoint','');
        if (preg_match('/api-version=([0-9\-a-z]+)/i', $raw_ep, $vm)) {
            $ver = $vm[1]; // Auto-detect version from pasted URL
        }

        $url = "{$ep}/openai/deployments/{$dep}/chat/completions?api-version={$ver}";

        $r = wp_remote_post($url,['timeout'=>120,'headers'=>['Content-Type'=>'application/json','api-key'=>$key],'body'=>wp_json_encode(['messages'=>[['role'=>'user','content'=>$prompt]],'max_completion_tokens'=>$max_tokens])]);

        if (is_wp_error($r)) return $r;
        $code = wp_remote_retrieve_response_code($r);
        $body_raw = wp_remote_retrieve_body($r);
        if ($code === 404) {
            return new WP_Error('api', 'Azure 404: Deployment "' . $dep . '" not found at ' . $ep . '. Verify deployment name in Azure Portal → Model Deployments.');
        }
        if ($code === 401) {
            return new WP_Error('api', 'Azure 401: Invalid API key. Check Keys in Azure Portal → your resource → Keys and Endpoint.');
        }
        return $this->parse($r);
    }

    private function call_anthropic( $prompt, $temp, $max_tokens = 4096 ) {
        $key = get_option('sseo_anthropic_api_key'); $model = get_option('sseo_anthropic_model','claude-sonnet-4-20250514');
        if (empty($key)) return new WP_Error('no_key','Anthropic API key not set.');
        $r = wp_remote_post('https://api.anthropic.com/v1/messages',['timeout'=>120,'headers'=>['Content-Type'=>'application/json','x-api-key'=>$key,'anthropic-version'=>'2023-06-01'],'body'=>wp_json_encode(['model'=>$model,'max_tokens'=>$max_tokens,'messages'=>[['role'=>'user','content'=>$prompt]],'temperature'=>$temp])]);
        if (is_wp_error($r)) return $r;
        $code = wp_remote_retrieve_response_code($r); $body = json_decode(wp_remote_retrieve_body($r),true);
        if ($code!==200) return new WP_Error('api',$body['error']['message']??"HTTP {$code}");
        return ['content'=>$body['content'][0]['text']??'','tokens'=>($body['usage']['input_tokens']??0)+($body['usage']['output_tokens']??0)];
    }

    private function call_gemini( $prompt, $temp, $max_tokens = 4096 ) {
        $key   = get_option('sseo_gemini_api_key','');
        $model = get_option('sseo_gemini_model','gemini-2.0-flash');
        if (empty($key)) return new WP_Error('no_key','Google Gemini API key not set.');
        $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$key}";
        $r = wp_remote_post($url,['timeout'=>120,'headers'=>['Content-Type'=>'application/json'],'body'=>wp_json_encode(['contents'=>[['parts'=>[['text'=>$prompt]]]],'generationConfig'=>['temperature'=>$temp,'maxOutputTokens'=>$max_tokens]])]);
        if (is_wp_error($r)) return $r;
        $code = wp_remote_retrieve_response_code($r); $body = json_decode(wp_remote_retrieve_body($r),true);
        if ($code!==200) return new WP_Error('api',$body['error']['message']??"HTTP {$code}");
        $text = $body['candidates'][0]['content']['parts'][0]['text']??'';
        $tokens = ($body['usageMetadata']['promptTokenCount']??0)+($body['usageMetadata']['candidatesTokenCount']??0);
        return ['content'=>$text,'tokens'=>$tokens];
    }

    private function parse( $r ) {
        if (is_wp_error($r)) return $r;
        $code = wp_remote_retrieve_response_code($r);
        $raw  = wp_remote_retrieve_body($r);
        $body = json_decode($raw, true);

        if ($code !== 200) {
            // Extract error message from various API formats
            $msg = 'HTTP ' . $code;
            if ($body) {
                if (is_string($body['error'] ?? null)) {
                    $msg = $body['error'];
                } elseif (isset($body['error']['message'])) {
                    $msg = $body['error']['message'];
                } elseif (isset($body['error']['code'])) {
                    $msg = $body['error']['code'];
                } elseif (isset($body['message'])) {
                    $msg = $body['message'];
                }
            }
            // Append raw body snippet for debugging if message is generic
            if ($msg === 'HTTP ' . $code && $raw) {
                $msg .= ' — ' . substr($raw, 0, 200);
            }
            return new WP_Error('api', $msg);
        }

        // Some providers (OpenRouter) may return 200 but with error in body
        if (isset($body['error'])) {
            $emsg = is_string($body['error']) ? $body['error'] : ($body['error']['message'] ?? 'Unknown error');
            return new WP_Error('api', $emsg);
        }

        $content = $body['choices'][0]['message']['content'] ?? '';
        if (empty($content) && isset($body['choices'][0]['text'])) {
            $content = $body['choices'][0]['text']; // Fallback for completion-style responses
        }

        return [
            'content' => $content,
            'tokens'  => $body['usage']['total_tokens'] ?? ($body['usage']['prompt_tokens'] ?? 0) + ($body['usage']['completion_tokens'] ?? 0),
        ];
    }

    public static function parse_json($raw) {
        $c = trim($raw);

        // 1. Strip markdown code fences
        $c = preg_replace('/^```(?:json)?\s*/i', '', $c);
        $c = preg_replace('/\s*```\s*$/', '', $c);

        // 2. Strip any text before the first { or [ and after the last } or ]
        // Detect whether the JSON is an object or array
        $first_brace = strpos($c, '{');
        $first_bracket = strpos($c, '[');

        // Determine which comes first: { or [
        if ($first_brace === false && $first_bracket === false) {
            return new WP_Error('json', 'No JSON found in response.');
        }

        if ($first_bracket !== false && ($first_brace === false || $first_bracket < $first_brace)) {
            // Array format: [...]
            $first = $first_bracket;
            $last = strrpos($c, ']');
            if ($last !== false && $last > $first) {
                $c = substr($c, $first, $last - $first + 1);
            }
        } elseif ($first_brace !== false) {
            // Object format: {...}
            $first = $first_brace;
            $last = strrpos($c, '}');
            if ($last !== false && $last > $first) {
                $c = substr($c, $first, $last - $first + 1);
            }
        }

        // 3. Try parsing as-is first
        $d = json_decode($c, true);
        if (json_last_error() === JSON_ERROR_NONE) return $d;

        // 4. Fix common AI mistakes and retry
        // Remove trailing commas before ] or }
        $c = preg_replace('/,\s*([\]}])/', '$1', $c);

        // Fix unescaped newlines inside JSON string values
        // Replace actual newlines between quotes with \n
        $c = preg_replace_callback('/"(?:[^"\\\\]|\\\\.)*"/s', function($m) {
            return str_replace(["\r\n", "\r", "\n"], '\n', $m[0]);
        }, $c);

        // Fix unescaped tabs
        $c = preg_replace_callback('/"(?:[^"\\\\]|\\\\.)*"/s', function($m) {
            return str_replace("\t", '\t', $m[0]);
        }, $c);

        $d = json_decode($c, true);
        if (json_last_error() === JSON_ERROR_NONE) return $d;

        // 5. More aggressive: try to fix unescaped double quotes inside values
        // This handles cases like: "content": "We offer "premium" service"
        $c2 = preg_replace_callback('/:\s*"((?:[^"\\\\]|\\\\.)*)"/s', function($m) {
            // Re-escape any unescaped quotes inside the value
            $val = $m[1];
            // Find sequences of unescaped quotes that aren't at boundaries
            $val = preg_replace('/(?<!\\\\)"(?![\s,}\]:])/', '\\"', $val);
            return ': "' . $val . '"';
        }, $c);

        $d = json_decode($c2, true);
        if (json_last_error() === JSON_ERROR_NONE) return $d;

        // 6. Last resort: try to extract just the top-level keys we need
        // If the JSON is truncated (AI ran out of tokens), try to recover partial data
        // Add missing closing brackets
        $c3 = $c;
        $open_braces  = substr_count($c3, '{') - substr_count($c3, '}');
        $open_brackets = substr_count($c3, '[') - substr_count($c3, ']');

        // If there are unclosed strings, close them
        // Count unescaped quotes
        $quote_count = preg_match_all('/(?<!\\\\)"/', $c3);
        if ($quote_count % 2 !== 0) {
            $c3 .= '"';
        }

        // Close any open brackets/braces
        $c3 .= str_repeat(']', max(0, $open_brackets));
        $c3 .= str_repeat('}', max(0, $open_braces));

        // Remove trailing commas again after our additions
        $c3 = preg_replace('/,\s*([\]}])/', '$1', $c3);

        $d = json_decode($c3, true);
        if (json_last_error() === JSON_ERROR_NONE) return $d;

        // Log the raw content for debugging
        error_log('[Samar SEO] JSON parse failed. Raw content (first 300 chars): ' . substr($raw, 0, 300));
        return new WP_Error('json', 'JSON parse failed: ' . json_last_error_msg() . ' (check server error log for details)');
    }

    public function test_connection() {
        $r = $this->complete('Say hello in one word.', 0.1);
        if (is_wp_error($r)) return $r;
        return ($r['content'] ?? '') ? true : new WP_Error('empty','Connected but got empty response.');
    }

    public function get_provider_name() {
        $cfg = self::$providers[$this->provider] ?? null;
        return $cfg ? $cfg['label'] : 'Unknown';
    }

    public function get_model_name() {
        $cfg = self::$providers[$this->provider] ?? self::$providers['openai'];
        if ($cfg['type']==='platform') return 'agency default';
        if ($cfg['type']==='azure') return get_option('sseo_azure_deployment','');
        return get_option($cfg['model'],$cfg['default_model']);
    }

    public static function get_all_providers() { return self::$providers; }

    /**
     * Vision API — send image + text prompt to AI that can SEE the image
     * $image_source: URL string or ['base64' => data, 'media_type' => 'image/jpeg']
     */
    public function complete_vision( $prompt, $image_source, $temperature = 0.7 ) {
        switch ( $this->provider ) {
            case 'anthropic': return $this->vision_anthropic( $prompt, $image_source, $temperature );
            case 'azure':     return $this->vision_openai( $prompt, $image_source, $temperature, true );
            default:          return $this->vision_openai( $prompt, $image_source, $temperature, false );
        }
    }

    private function vision_openai( $prompt, $image_source, $temp, $is_azure = false ) {
        $key   = $is_azure ? get_option('sseo_azure_api_key') : get_option('sseo_openai_api_key');
        $model = $is_azure ? '' : get_option('sseo_openai_model', 'gpt-4o-mini');
        if ( empty($key) ) return new WP_Error('no_key', 'API key not set.');

        // Build image content part
        if ( is_array($image_source) && isset($image_source['base64']) ) {
            $img_part = ['type'=>'image_url','image_url'=>['url'=>'data:'.$image_source['media_type'].';base64,'.$image_source['base64'],'detail'=>'low']];
        } else {
            $img_part = ['type'=>'image_url','image_url'=>['url'=>$image_source,'detail'=>'low']];
        }

        $messages = [['role'=>'user','content'=>[
            $img_part,
            ['type'=>'text','text'=>$prompt],
        ]]];

        if ( $is_azure ) {
            $ep  = get_option('sseo_azure_endpoint');
            // Clean endpoint
            $ep = preg_replace('/\?.*$/', '', trim($ep));
            if (preg_match('#^(https?://[^/]*\.azure\.com)#i', $ep, $m)) $ep = $m[1];
            else { $ep = rtrim($ep, '/'); $ep = preg_replace('#/openai.*$#i', '', $ep); }
            $dep = get_option('sseo_azure_deployment');
            $ver = get_option('sseo_azure_api_version','2025-04-01-preview');
            $raw_ep = get_option('sseo_azure_endpoint','');
            if (preg_match('/api-version=([0-9\-a-z]+)/i', $raw_ep, $vm)) $ver = $vm[1];
            $url = "{$ep}/openai/deployments/{$dep}/chat/completions?api-version={$ver}";
            $headers = ['Content-Type'=>'application/json','api-key'=>$key];
            $body = ['messages'=>$messages,'max_completion_tokens'=>500];
        } else {
            $url = 'https://api.openai.com/v1/chat/completions';
            $headers = ['Content-Type'=>'application/json','Authorization'=>'Bearer '.$key];
            $body = ['model'=>$model,'messages'=>$messages,'temperature'=>$temp,'max_tokens'=>500];
        }

        $r = wp_remote_post($url, ['timeout'=>90,'headers'=>$headers,'body'=>wp_json_encode($body)]);
        return $this->parse($r);
    }

    private function vision_anthropic( $prompt, $image_source, $temp ) {
        $key   = get_option('sseo_anthropic_api_key');
        $model = get_option('sseo_anthropic_model', 'claude-sonnet-4-20250514');
        if ( empty($key) ) return new WP_Error('no_key', 'Anthropic API key not set.');

        // Build image content
        if ( is_array($image_source) && isset($image_source['base64']) ) {
            $img_part = ['type'=>'image','source'=>['type'=>'base64','media_type'=>$image_source['media_type'],'data'=>$image_source['base64']]];
        } else {
            // Anthropic supports URL images
            $img_part = ['type'=>'image','source'=>['type'=>'url','url'=>$image_source]];
        }

        $messages = [['role'=>'user','content'=>[
            $img_part,
            ['type'=>'text','text'=>$prompt],
        ]]];

        $r = wp_remote_post('https://api.anthropic.com/v1/messages', [
            'timeout'=>90,
            'headers'=>['Content-Type'=>'application/json','x-api-key'=>$key,'anthropic-version'=>'2023-06-01'],
            'body'=>wp_json_encode(['model'=>$model,'max_tokens'=>500,'messages'=>$messages,'temperature'=>$temp]),
        ]);

        if ( is_wp_error($r) ) return $r;
        $code = wp_remote_retrieve_response_code($r);
        $body = json_decode(wp_remote_retrieve_body($r), true);
        if ( $code !== 200 ) return new WP_Error('api', $body['error']['message'] ?? "HTTP {$code}");
        return ['content'=>$body['content'][0]['text']??'','tokens'=>($body['usage']['input_tokens']??0)+($body['usage']['output_tokens']??0)];
    }

    /**
     * Helper: get image as base64 from a local WordPress attachment
     */
    public static function image_to_base64( $attachment_id, $size = 'medium' ) {
        $file = get_attached_file( $attachment_id );
        if ( ! $file || ! file_exists($file) ) return null;

        // Use a smaller size if available to reduce tokens
        $meta = wp_get_attachment_metadata( $attachment_id );
        $upload_dir = wp_upload_dir();
        $base_dir = trailingslashit( $upload_dir['basedir'] );

        // Try to find the medium or large intermediate size
        if ( $meta && isset($meta['sizes'][$size]) ) {
            $dir = trailingslashit( dirname($file) );
            $sized_file = $dir . $meta['sizes'][$size]['file'];
            if ( file_exists($sized_file) ) $file = $sized_file;
        }

        // Limit to 1MB to avoid API limits
        if ( filesize($file) > 1048576 ) {
            // Try thumbnail instead
            if ( $meta && isset($meta['sizes']['thumbnail']) ) {
                $dir = trailingslashit( dirname( get_attached_file($attachment_id) ) );
                $thumb = $dir . $meta['sizes']['thumbnail']['file'];
                if ( file_exists($thumb) ) $file = $thumb;
            }
        }

        $data = file_get_contents( $file );
        if ( ! $data ) return null;

        $mime = wp_check_filetype( $file );
        $media_type = $mime['type'] ?: 'image/jpeg';

        return [
            'base64'     => base64_encode( $data ),
            'media_type' => $media_type,
        ];
    }
}
