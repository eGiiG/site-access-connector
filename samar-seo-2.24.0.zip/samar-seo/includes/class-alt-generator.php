<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * AI Vision-powered ALT tag generator
 * Actually LOOKS at each image using GPT-4o/Claude vision, then generates
 * SEO-optimized ALT text based on what it sees + page context + keywords.
 */
class SSEO_Alt_Generator {
    private $api;

    public function __construct() {
        $this->api = new SSEO_API_Handler();
    }

    public function count_missing() {
        global $wpdb;
        return (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} pm ON p.ID=pm.post_id AND pm.meta_key='_wp_attachment_image_alt'
             WHERE p.post_type='attachment' AND p.post_mime_type LIKE 'image/%'
             AND (pm.meta_value IS NULL OR pm.meta_value='')"
        );
    }

    public function get_missing( $limit = 50, $offset = 0 ) {
        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, p.post_title, p.guid, p.post_parent, p.post_mime_type
             FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} pm ON p.ID=pm.post_id AND pm.meta_key='_wp_attachment_image_alt'
             WHERE p.post_type='attachment' AND p.post_mime_type LIKE 'image/%%'
             AND (pm.meta_value IS NULL OR pm.meta_value='')
             ORDER BY p.ID DESC LIMIT %d OFFSET %d",
            $limit, $offset
        ) );

        $images = [];
        foreach ( $rows as $r ) {
            $src   = wp_get_attachment_url( $r->ID );
            $pt    = $r->post_parent ? get_the_title( $r->post_parent ) : '';
            $thumb = wp_get_attachment_image_src( $r->ID, 'thumbnail' );
            $images[] = [
                'attachment_id' => $r->ID,
                'title'         => $r->post_title,
                'src'           => $src,
                'filename'      => basename( $src ),
                'parent_title'  => $pt,
                'parent_id'     => $r->post_parent,
                'thumbnail'     => $thumb ? $thumb[0] : $src,
                'mime_type'     => $r->post_mime_type,
            ];
        }
        return $images;
    }

    /**
     * Generate ALT tags using AI Vision — actually looks at the image
     * Processes ONE image at a time for vision accuracy
     */
    public function generate_single_vision( $attachment_id ) {
        $src       = wp_get_attachment_url( $attachment_id );
        $title     = get_the_title( $attachment_id );
        $filename  = basename( $src );
        $parent_id = get_post_field( 'post_parent', $attachment_id );
        $parent_title = $parent_id ? get_the_title( $parent_id ) : '';
        $parent_content = '';
        if ( $parent_id ) {
            $parent = get_post( $parent_id );
            if ( $parent ) {
                $parent_content = wp_trim_words( wp_strip_all_tags( $parent->post_content ), 50 );
            }
        }

        $brand = get_option( 'sseo_brand_name', '' );
        $loc   = get_option( 'sseo_target_location', '' );

        // Try to get image as base64 for vision
        $image_data = SSEO_API_Handler::image_to_base64( $attachment_id, 'medium' );

        $context = "Website: " . get_bloginfo('name');
        if ( $brand )        $context .= " ({$brand})";
        if ( $loc )          $context .= "\nLocation: {$loc}";
        if ( $parent_title ) $context .= "\nThis image is on the page: \"{$parent_title}\"";
        if ( $parent_content ) $context .= "\nPage content summary: {$parent_content}";
        $context .= "\nFilename: {$filename}";
        if ( $title && $title !== $filename ) $context .= "\nImage title: {$title}";

        $prompt = "Look at this image carefully. Generate 3 SEO-optimized ALT text options.

{$context}

Rules:
- DESCRIBE what you actually SEE in the image (people, objects, setting, action, colors, materials)
- Each ALT text: 80-125 characters
- Include relevant keywords naturally (based on the page context)
- Be specific and descriptive for screen reader accessibility
- Don't start with 'Image of' or 'Photo of'
- If it's a construction/remodeling image, mention the specific work type and any visible details

Return ONLY JSON: [{\"text\":\"...\",\"charCount\":95},{\"text\":\"...\",\"charCount\":102},{\"text\":\"...\",\"charCount\":110}]
No markdown, no code fences.";

        // Use vision if we have the image data
        if ( $image_data ) {
            $r = $this->api->complete_vision( $prompt, $image_data );
        } else {
            // Fallback: try URL-based vision
            $r = $this->api->complete_vision( $prompt, $src );
        }

        // If vision fails entirely, fall back to text-only with context
        if ( is_wp_error( $r ) ) {
            $fallback_prompt = "Generate 3 SEO-optimized ALT text options for an image.
I cannot show you the image, so use the context below to write descriptive ALT text.

{$context}

Rules: 80-125 characters each, descriptive, include relevant keywords naturally.
Return ONLY JSON: [{\"text\":\"...\",\"charCount\":95},{\"text\":\"...\",\"charCount\":102},{\"text\":\"...\",\"charCount\":110}]
No markdown.";
            $r = $this->api->complete( $fallback_prompt );
            if ( is_wp_error( $r ) ) return $r;
        }

        $parsed = SSEO_API_Handler::parse_json( $r['content'] );
        if ( is_wp_error( $parsed ) ) return $parsed;

        return [
            'attachment_id' => $attachment_id,
            'filename'      => $filename,
            'alts'          => $parsed,
            'tokens'        => $r['tokens'],
            'used_vision'   => ! is_wp_error( $r ),
        ];
    }

    /**
     * Batch generate — still text-based for speed when doing many at once
     * (vision is used for single-image Generate button)
     */
    public function generate( $images ) {
        if ( empty( $images ) ) return new WP_Error( 'empty', 'No images.' );
        $brand = get_option( 'sseo_brand_name', '' );
        $loc   = get_option( 'sseo_target_location', '' );
        $list  = '';
        foreach ( $images as $i => $img ) {
            $ctx = $img['filename'];
            if ( ! empty($img['title']) && $img['title'] !== $img['filename'] ) $ctx .= " (title: {$img['title']})";
            if ( ! empty($img['parent_title']) ) $ctx .= " — page: \"{$img['parent_title']}\"";
            $list .= "Image " . ($i+1) . ": {$ctx}\n";
        }
        $prompt = "Generate SEO-optimized ALT tags for these images.
Site: " . get_bloginfo('name') . ($brand?" ({$brand})":'') . ($loc?"\nLocation: {$loc}":'') . "

{$list}
Rules: 80-125 chars, descriptive for accessibility, natural keywords, 2 options each.
Return ONLY JSON: [{\"imageIndex\":0,\"alts\":[{\"text\":\"...\",\"charCount\":95},{\"text\":\"...\",\"charCount\":102}]}]
No markdown.";
        $r = $this->api->complete( $prompt );
        if ( is_wp_error($r) ) return $r;
        $p = SSEO_API_Handler::parse_json( $r['content'] );
        if ( is_wp_error($p) ) return $p;
        return [ 'results'=>$p, 'tokens'=>$r['tokens'] ];
    }

    /**
     * Batch generate with vision — processes each image individually
     * Slower but much more accurate since AI sees each image
     */
    public function generate_batch_vision( $image_ids ) {
        $results = [];
        $total_tokens = 0;

        foreach ( $image_ids as $id ) {
            $r = $this->generate_single_vision( (int) $id );
            if ( is_wp_error( $r ) ) {
                $results[] = [
                    'attachment_id' => $id,
                    'filename'      => basename( wp_get_attachment_url( $id ) ),
                    'error'         => $r->get_error_message(),
                    'alts'          => [],
                ];
                continue;
            }
            $total_tokens += $r['tokens'];
            $results[] = $r;

            // Rate limit
            $delay = (int) get_option( 'sseo_rate_limit_delay', 2 );
            if ( $delay > 0 ) sleep( $delay );
        }

        return [
            'results' => $results,
            'tokens'  => $total_tokens,
        ];
    }

    public function apply( $id, $alt ) {
        global $wpdb;
        $old = get_post_meta( $id, '_wp_attachment_image_alt', true );
        update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );

        // Also update the image title if it's generic (IMG_, DSC_, etc.)
        $current_title = get_the_title( $id );
        if ( $this->is_generic_title( $current_title ) ) {
            $clean_title = wp_trim_words( $alt, 8, '' );
            wp_update_post( [ 'ID' => $id, 'post_title' => $clean_title ] );
        }

        // Clear ALL caches so plugin UI sees the change immediately
        clean_post_cache( $id );
        wp_cache_delete( $id, 'post_meta' );
        wp_cache_delete( $id, 'posts' );

        $wpdb->insert( $wpdb->prefix . 'sseo_log', [
            'post_id'   => $id,
            'type'      => 'alt',
            'old_value' => $old,
            'new_value' => $alt,
        ] );
        return true;
    }

    // ════════════════════════════════════════════
    // IMAGE TITLE MANAGEMENT
    // ════════════════════════════════════════════

    /**
     * Scan for all images with generic/unhelpful titles
     */
    public function get_generic_titles( $limit = 200, $offset = 0 ) {
        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_title, guid, post_parent, post_mime_type
             FROM {$wpdb->posts}
             WHERE post_type='attachment' AND post_mime_type LIKE 'image/%%'
             ORDER BY ID DESC LIMIT %d OFFSET %d",
            $limit, $offset
        ) );

        $generic = [];
        foreach ( $rows as $r ) {
            if ( ! $this->is_generic_title( $r->post_title ) ) continue;

            $src   = wp_get_attachment_url( $r->ID );
            $thumb = wp_get_attachment_image_src( $r->ID, 'thumbnail' );
            $alt   = get_post_meta( $r->ID, '_wp_attachment_image_alt', true );
            $parent_title = $r->post_parent ? get_the_title( $r->post_parent ) : '';

            $generic[] = [
                'id'            => $r->ID,
                'current_title' => $r->post_title,
                'filename'      => basename( $src ),
                'src'           => $src,
                'thumbnail'     => $thumb ? $thumb[0] : $src,
                'alt'           => $alt,
                'parent_title'  => $parent_title,
                'parent_id'     => $r->post_parent,
            ];
        }
        return $generic;
    }

    /**
     * Count images with generic titles
     */
    public function count_generic_titles() {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT ID, post_title FROM {$wpdb->posts}
             WHERE post_type='attachment' AND post_mime_type LIKE 'image/%'
             ORDER BY ID DESC LIMIT 1000"
        );
        $count = 0;
        foreach ( $rows as $r ) {
            if ( $this->is_generic_title( $r->post_title ) ) $count++;
        }
        return $count;
    }

    /**
     * Generate title for a single image using AI Vision
     */
    public function generate_title_vision( $attachment_id, $append_brand = false ) {
        $src       = wp_get_attachment_url( $attachment_id );
        $filename  = basename( $src );
        $alt       = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
        $parent_id = get_post_field( 'post_parent', $attachment_id );
        $parent_title = $parent_id ? get_the_title( $parent_id ) : '';
        $brand     = get_option( 'sseo_brand_name', get_bloginfo('name') );
        $loc       = get_option( 'sseo_target_location', '' );

        $image_data = SSEO_API_Handler::image_to_base64( $attachment_id, 'medium' );

        $context = "Website: " . get_bloginfo('name');
        if ( $brand )        $context .= " ({$brand})";
        if ( $loc )          $context .= "\nLocation: {$loc}";
        if ( $parent_title ) $context .= "\nUsed on page: \"{$parent_title}\"";
        if ( $alt )          $context .= "\nCurrent ALT text: \"{$alt}\"";
        $context .= "\nFilename: {$filename}";

        $brand_instruction = '';
        if ( $append_brand && $brand ) {
            $brand_instruction = "\n- Append \" — {$brand}\" at the end of each title";
        }

        $prompt = "Look at this image. Generate 3 SEO-friendly image TITLE options.

{$context}

Rules:
- Describe what the image shows in 5-10 words
- Use Title Case
- Include relevant keywords for SEO
- Be specific: mention materials, colors, rooms, work type if visible
- Don't use generic words like 'image', 'photo', 'picture'{$brand_instruction}

Return ONLY JSON: [{\"title\":\"...\"}]
No markdown.";

        if ( $image_data ) {
            $r = $this->api->complete_vision( $prompt, $image_data );
        } else {
            $r = $this->api->complete_vision( $prompt, $src );
        }

        // Fallback to text-only
        if ( is_wp_error( $r ) ) {
            $fallback = "Generate 3 SEO-friendly image titles based on context.
{$context}
Rules: 5-10 words, Title Case, descriptive, keywords.{$brand_instruction}
Return ONLY JSON: [{\"title\":\"...\"}]";
            $r = $this->api->complete( $fallback );
            if ( is_wp_error( $r ) ) return $r;
        }

        $parsed = SSEO_API_Handler::parse_json( $r['content'] );
        if ( is_wp_error( $parsed ) ) return $parsed;

        return [
            'attachment_id' => $attachment_id,
            'filename'      => $filename,
            'current_title' => get_the_title( $attachment_id ),
            'suggestions'   => $parsed,
            'tokens'        => $r['tokens'],
        ];
    }

    /**
     * Batch generate titles from ALT text + context (fast, no vision)
     */
    public function generate_titles_batch( $image_ids, $append_brand = false ) {
        $brand = get_option( 'sseo_brand_name', get_bloginfo('name') );
        $loc   = get_option( 'sseo_target_location', '' );

        $list = '';
        $images_data = [];
        foreach ( $image_ids as $i => $id ) {
            $id = (int) $id;
            $alt   = get_post_meta( $id, '_wp_attachment_image_alt', true );
            $fname = basename( wp_get_attachment_url( $id ) );
            $parent_id = get_post_field( 'post_parent', $id );
            $ptitle = $parent_id ? get_the_title( $parent_id ) : '';

            $ctx = "Filename: {$fname}";
            if ( $alt ) $ctx .= ", ALT: \"{$alt}\"";
            if ( $ptitle ) $ctx .= ", Page: \"{$ptitle}\"";
            $list .= ($i+1) . ". {$ctx}\n";
            $images_data[] = [ 'id' => $id, 'filename' => $fname ];
        }

        $brand_instruction = '';
        if ( $append_brand && $brand ) {
            $brand_instruction = "\n- Append \" — {$brand}\" at the end of each title";
        }

        $prompt = "Generate SEO-friendly image titles for these images.
Website: " . get_bloginfo('name') . ($brand?" ({$brand})":'') . ($loc?"\nLocation: {$loc}":'') . "

Images:
{$list}

Rules:
- 5-10 words each, Title Case
- Descriptive and keyword-rich
- Based on ALT text, filename, and page context{$brand_instruction}

Return ONLY JSON: [{\"index\":0,\"title\":\"...\"}]
No markdown.";

        $r = $this->api->complete( $prompt );
        if ( is_wp_error($r) ) return $r;
        $parsed = SSEO_API_Handler::parse_json( $r['content'] );
        if ( is_wp_error($parsed) ) return $parsed;

        $results = [];
        foreach ( $parsed as $p ) {
            $idx = $p['index'] ?? 0;
            if ( isset($images_data[$idx]) ) {
                $results[] = [
                    'attachment_id' => $images_data[$idx]['id'],
                    'filename'      => $images_data[$idx]['filename'],
                    'title'         => $p['title'],
                ];
            }
        }

        return [ 'results' => $results, 'tokens' => $r['tokens'] ];
    }

    /**
     * Apply a title to an image
     */
    public function apply_title( $attachment_id, $new_title ) {
        $old = get_the_title( $attachment_id );
        $new_title = sanitize_text_field( $new_title );
        wp_update_post( [ 'ID' => $attachment_id, 'post_title' => $new_title ] );

        // Clear caches so plugin UI sees the change immediately
        clean_post_cache( $attachment_id );
        wp_cache_delete( $attachment_id, 'posts' );

        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'sseo_log', [
            'post_id'   => $attachment_id,
            'type'      => 'img_title',
            'old_value' => $old,
            'new_value' => $new_title,
        ] );
        return true;
    }

    /**
     * Bulk apply titles — auto-generate from ALT text with optional brand
     */
    public function bulk_auto_title( $image_ids, $append_brand = false ) {
        $brand = get_option( 'sseo_brand_name', get_bloginfo('name') );
        $fixed = 0;

        foreach ( $image_ids as $id ) {
            $id = (int) $id;
            $alt = get_post_meta( $id, '_wp_attachment_image_alt', true );
            $current = get_the_title( $id );

            if ( ! $this->is_generic_title( $current ) ) continue;

            // Build title from ALT text or filename
            if ( $alt ) {
                $title = ucwords( strtolower( wp_trim_words( $alt, 8, '' ) ) );
            } else {
                // Clean up filename
                $fname = pathinfo( basename( wp_get_attachment_url( $id ) ), PATHINFO_FILENAME );
                $title = ucwords( str_replace( ['-','_','.'], ' ', $fname ) );
                $title = preg_replace( '/\b(img|dsc|dscn|dcim|photo|image|screenshot|wp)\b/i', '', $title );
                $title = preg_replace( '/\d{4,}/', '', $title );
                $title = trim( preg_replace( '/\s+/', ' ', $title ) );
            }

            if ( empty($title) || strlen($title) < 3 ) continue;

            if ( $append_brand && $brand ) {
                $title .= ' — ' . $brand;
            }

            $this->apply_title( $id, $title );
            $fixed++;
        }

        return [ 'fixed' => $fixed, 'total' => count($image_ids) ];
    }

    /**
     * Detect generic/unhelpful image titles
     */
    private function is_generic_title( $title ) {
        if ( empty( $title ) ) return true;
        // Common camera/phone naming patterns
        $patterns = [
            '/^IMG[_-]?\d+/i',
            '/^DSC[_-]?\d+/i',
            '/^DSCN?\d+/i',
            '/^P\d{4,}/i',
            '/^DCIM/i',
            '/^photo[_-]?\d*/i',
            '/^image[_-]?\d*/i',
            '/^screenshot[_-]?\d*/i',
            '/^Screen\s?Shot/i',
            '/^\d{8}[_-]\d+/',     // 20240315_001
            '/^[A-F0-9]{8,}/i',     // hex hashes
            '/^[a-f0-9-]{36}$/i',   // UUIDs
            '/^wp-image/i',
            '/^cropped-/i',
            '/^untitled/i',
        ];
        foreach ( $patterns as $p ) {
            if ( preg_match( $p, $title ) ) return true;
        }
        // If title is just the filename extension stripped
        $ext_stripped = preg_replace('/\.(jpe?g|png|gif|webp|avif|svg|bmp)$/i', '', $title);
        if ( preg_match( '/^[A-Za-z0-9_-]+$/', $ext_stripped ) && strlen( $ext_stripped ) < 15 ) return true;
        return false;
    }
}
