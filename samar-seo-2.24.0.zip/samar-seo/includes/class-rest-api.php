<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SSEO_Rest_Api — exposes a compact, cached SEO health summary over the WP REST API so an
 * external reporting platform can pull it for client reports using the site's
 * Application Password (Basic auth). Only aggregates + the same 0-100 health score the plugin
 * shows in wp-admin are returned; the full per-page snapshot stays local.
 *
 * Route:  GET /wp-json/site-seo/v1/snapshot
 *   ?days=30   activity window (in days) for the "work done this period" counts (clamped 1..365)
 *   ?fresh=1   bypass the cache and recompute the scan now
 * Auth:   Application Password (Basic) for a user with the `edit_posts` capability (author+).
 *
 * The heavy scan is cached in the sseo_snapshot_summary_cache option for 6h so repeated report
 * pulls stay cheap; the activity counts are cheap and period-specific, so they are always fresh.
 */
class SSEO_Rest_Api {

    const CACHE_OPTION = 'sseo_snapshot_summary_cache';
    const CACHE_TTL    = 21600; // 6 hours

    public function __construct() {
        add_action( 'rest_api_init', [ $this, 'register' ] );
    }

    public function register() {
        register_rest_route( 'site-seo/v1', '/snapshot', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'snapshot' ],
            'permission_callback' => function ( $req ) { return sseo_rest_token_ok( $req ) || current_user_can( 'edit_posts' ); },
            'args'                => [
                'days'  => [ 'default' => 30 ],
                'fresh' => [ 'default' => 0 ],
            ],
        ] );

        register_rest_route( 'site-seo/v1', '/brand', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'set_brand' ],
            'permission_callback' => function ( $req ) { return sseo_rest_token_ok( $req ) || current_user_can( 'manage_options' ); },
            'args'                => [
                'name'    => [ 'default' => '' ],
                'stealth' => [ 'default' => null ],
            ],
        ] );
    }

    public function snapshot( WP_REST_Request $req ) {
        $days  = max( 1, min( 365, (int) $req->get_param( 'days' ) ?: 30 ) );
        $fresh = (int) $req->get_param( 'fresh' ) === 1;

        $summary = $fresh ? null : $this->cached();
        if ( ! $summary ) {
            $summary = $this->compute();
            update_option( self::CACHE_OPTION, [ 'computed_at' => time(), 'data' => $summary ], false );
            $summary['cached'] = false;
        } else {
            $summary['cached'] = true;
        }

        // Activity counts are cheap + period-specific → always computed fresh for the requested window.
        $summary['activity'] = $this->activity( $days );

        return rest_ensure_response( $summary );
    }

    /**
     * Set (or clear) the white-label product name. Used by the connected reporting platform to push
     * the agency's brand at connect time. Requires manage_options. An empty name clears the option,
     * reverting to the wp-config SEO_SUITE_NAME constant or the built-in default.
     */
    public function set_brand( WP_REST_Request $req ) {
        $name = sanitize_text_field( (string) $req->get_param( 'name' ) );
        if ( $name === '' ) {
            delete_option( 'sseo_whitelabel_name' );
        } else {
            update_option( 'sseo_whitelabel_name', $name );
        }
        // Optional: flip stealth from the platform. null (key omitted) leaves it as it is.
        $stealth = $req->get_param( 'stealth' );
        if ( $stealth !== null ) update_option( 'sseo_stealth', $stealth ? 1 : 0 );
        return rest_ensure_response( [
            'ok'      => true,
            'name'    => function_exists( 'sseo_product_name' ) ? sseo_product_name() : $name,
            'stealth' => function_exists( 'sseo_stealth' ) ? (int) sseo_stealth() : 0,
        ] );
    }

    private function cached() {
        $c = get_option( self::CACHE_OPTION );
        if ( is_array( $c ) && ! empty( $c['computed_at'] ) && ! empty( $c['data'] )
            && ( time() - (int) $c['computed_at'] ) < self::CACHE_TTL ) {
            return $c['data'];
        }
        return null;
    }

    /**
     * Compute the compact summary. The score uses the SAME formula as
     * SSEO_Report_Generator::take_snapshot() so it matches the wp-admin number exactly.
     * A single post loop accumulates the meta / title / H1 / internal-link counters; the
     * remaining aggregates reuse the plugin's existing count helpers so numbers never diverge.
     */
    private function compute() {
        $seo     = new SSEO_SEO_Integration();
        $types   = get_option( 'sseo_post_types', [ 'post', 'page' ] );
        $ignored = get_option( 'sseo_thin_ignored', [] );
        $host    = wp_parse_url( home_url( '/' ), PHP_URL_HOST );

        $pages_total = 0;
        $meta_total = 0; $meta_missing = 0;
        $title_issues = 0; $h1_issues = 0;
        $internal_links_total = 0; $pages_no_links = 0;

        foreach ( (array) $types as $pt ) {
            foreach ( get_posts( [ 'post_type' => $pt, 'post_status' => 'publish', 'numberposts' => -1 ] ) as $p ) {
                $pages_total++;

                // Meta description (matches take_snapshot: NOT ignored-filtered)
                $m = $seo->get_meta( $p->ID );
                $meta_total++;
                if ( empty( trim( (string) $m ) ) ) $meta_missing++;

                // Title + H1 (matches take_snapshot: ignored-filtered)
                if ( ! in_array( $p->ID, $ignored ) ) {
                    $st  = $seo->get_title( $p->ID );
                    $t   = $st ?: $p->post_title;
                    $len = mb_strlen( $t );
                    if ( $len > 60 || ( $len < 30 && $len > 0 ) || empty( trim( $t ) ) ) $title_issues++;

                    preg_match_all( '/<h1[^>]*>(.*?)<\/h1>/is', $p->post_content, $mm );
                    $cnt = count( $mm[1] ?? [] );
                    if ( $cnt === 0 || $cnt > 1 ) $h1_issues++;
                }

                // Internal links (matches take_snapshot)
                $lc = 0;
                if ( preg_match_all( '/href=["\']([^"\']+)["\']/i', $p->post_content, $hm ) ) {
                    foreach ( $hm[1] as $href ) {
                        $h = wp_parse_url( $href, PHP_URL_HOST );
                        if ( empty( $h ) || $h === $host ) $lc++;
                    }
                }
                $internal_links_total += $lc;
                if ( $lc === 0 ) $pages_no_links++;
            }
        }

        $alt              = new SSEO_Alt_Generator();
        $alt_missing      = (int) $alt->count_missing();
        $imgtitle_generic = (int) $alt->count_generic_titles();

        $thin_stats = ( new SSEO_Thin_Content() )->get_stats();
        $thin       = (int) ( $thin_stats['thin'] ?? 0 );

        $broken    = count( (array) ( new SSEO_Broken_Links() )->scan( 50 ) );
        $redirects = (int) ( new SSEO_Redirect_Manager() )->count();

        $schema_on = (bool) get_option( 'sseo_schema_enabled', 1 );
        $og_on     = (bool) get_option( 'sseo_og_enabled', 1 );
        $llms      = get_option( 'sseo_llms_txt_content', '' );

        // ── Score — identical to SSEO_Report_Generator::take_snapshot() ──
        $score = 100;
        if ( $meta_missing > 0 )     $score -= min( 30, $meta_missing * 0.5 );
        if ( $alt_missing > 0 )      $score -= min( 15, $alt_missing * 0.3 );
        if ( $imgtitle_generic > 0 ) $score -= min( 5, $imgtitle_generic * 0.1 );
        if ( $title_issues > 0 )     $score -= min( 10, $title_issues );
        if ( $h1_issues > 0 )        $score -= min( 10, $h1_issues * 1.5 );
        if ( ! $schema_on )          $score -= 5;
        if ( ! $og_on )              $score -= 3;
        if ( empty( $llms ) )        $score -= 5;
        if ( $thin > 0 )             $score -= min( 15, $thin * 0.5 );
        if ( $broken > 0 )           $score -= min( 7, $broken * 0.5 );
        $score = max( 0, round( $score ) );

        return [
            'ok'             => true,
            'score'          => $score,
            'generated_at'   => current_time( 'mysql' ),
            'seo_plugin'     => $seo->get_active(),
            'plugin_version' => defined( 'SSEO_VERSION' ) ? SSEO_VERSION : null,
            'site'           => [
                'name'     => get_bloginfo( 'name' ),
                'url'      => home_url( '/' ),
                'brand'    => get_option( 'sseo_brand_name', '' ),
                'location' => get_option( 'sseo_target_location', '' ),
            ],
            'counts'         => [
                'pages_total'                  => $pages_total,
                'meta_total'                   => $meta_total,
                'meta_missing'                 => $meta_missing,
                'title_issues'                 => $title_issues,
                'h1_issues'                    => $h1_issues,
                'alt_missing'                  => $alt_missing,
                'image_titles_generic'         => $imgtitle_generic,
                'thin_pages'                   => $thin,
                'broken_links'                 => $broken,
                'redirects'                    => $redirects,
                'internal_links_total'         => $internal_links_total,
                'pages_without_internal_links' => $pages_no_links,
            ],
            'flags'          => [
                'schema'   => $schema_on,
                'og'       => $og_on,
                'llms_txt' => ! empty( $llms ),
            ],
        ];
    }

    /** Work done in the last N days from the activity log, grouped by type. Fails soft to empty. */
    private function activity( $days ) {
        global $wpdb;
        $table = $wpdb->prefix . 'sseo_log';
        $out   = [ 'window_days' => (int) $days, 'total' => 0, 'by_type' => new stdClass() ];
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) !== $table ) return $out;

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT type, COUNT(*) AS n FROM {$table} WHERE created_at >= ( NOW() - INTERVAL %d DAY ) GROUP BY type",
            $days
        ), ARRAY_A );

        $by = []; $total = 0;
        foreach ( (array) $rows as $r ) {
            $by[ $r['type'] ] = (int) $r['n'];
            $total += (int) $r['n'];
        }
        $out['total']   = $total;
        $out['by_type'] = $by ?: new stdClass();
        return $out;
    }
}
