<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Image Optimizer — WebP conversion, missing dimensions, lazy load, LCP preload, PageSpeed
 * No third-party dependencies — uses PHP GD + WordPress core + Google PageSpeed API (free)
 */
class SSEO_Image_Optimizer {

    public function __construct() {
        // LCP preload hook
        if ( get_option( 'sseo_lcp_preload', 0 ) ) {
            add_action( 'wp_head', [ $this, 'inject_lcp_preload' ], 1 );
        }
        // Lazy load management
        if ( get_option( 'sseo_smart_lazy', 0 ) ) {
            add_filter( 'wp_get_attachment_image_attributes', [ $this, 'smart_lazy_attrs' ], 99, 3 );
            add_filter( 'the_content', [ $this, 'smart_lazy_content' ], 99 );
        }
        // Serve WebP if available
        if ( get_option( 'sseo_serve_webp', 0 ) ) {
            add_filter( 'the_content', [ $this, 'rewrite_to_webp' ], 99 );
            add_filter( 'post_thumbnail_html', [ $this, 'rewrite_to_webp' ], 99 );
        }
    }

    // ════════════════════════════════════════════
    // SCAN: Find all image issues
    // ════════════════════════════════════════════

    public function scan_all() {
        $results = [
            'webp_needed'      => $this->scan_non_webp(),
            'missing_dims'     => $this->scan_missing_dimensions(),
            'missing_lazy'     => $this->scan_missing_lazy(),
            'lcp_status'       => $this->get_lcp_status(),
            'gd_webp_support'  => function_exists('imagewebp'),
            'gd_avif_support'  => function_exists('imageavif'),
            'php_version'      => PHP_VERSION,
        ];
        $results['total_issues'] = count($results['webp_needed']) + count($results['missing_dims']) + count($results['missing_lazy']);
        return $results;
    }

    /**
     * Find all images that don't have a WebP version
     */
    public function scan_non_webp() {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT ID, post_title, guid FROM {$wpdb->posts}
             WHERE post_type='attachment' AND post_mime_type IN ('image/jpeg','image/png')
             ORDER BY ID DESC LIMIT 500"
        );
        $need_convert = [];
        foreach ( $rows as $r ) {
            $file = get_attached_file( $r->ID );
            if ( ! $file || ! file_exists($file) ) continue;
            $webp_path = $this->get_webp_path( $file );
            if ( ! file_exists( $webp_path ) ) {
                $src = wp_get_attachment_url( $r->ID );
                $thumb = wp_get_attachment_image_src( $r->ID, 'thumbnail' );
                $size = filesize( $file );
                $need_convert[] = [
                    'id'        => $r->ID,
                    'title'     => $r->post_title,
                    'filename'  => basename( $file ),
                    'src'       => $src,
                    'thumbnail' => $thumb ? $thumb[0] : $src,
                    'size'      => $size,
                    'size_human'=> size_format( $size ),
                    'mime'      => get_post_mime_type( $r->ID ),
                ];
            }
        }
        return $need_convert;
    }

    /**
     * Find all <img> tags in content missing width/height
     */
    public function scan_missing_dimensions() {
        $types = get_option( 'sseo_post_types', ['post','page'] );
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>200]);
        $issues = [];

        foreach ( $posts as $p ) {
            if ( preg_match_all( '/<img[^>]+>/i', $p->post_content, $matches ) ) {
                foreach ( $matches[0] as $tag ) {
                    $has_width  = preg_match( '/\bwidth\s*=\s*["\']?\d+/i', $tag );
                    $has_height = preg_match( '/\bheight\s*=\s*["\']?\d+/i', $tag );
                    if ( ! $has_width || ! $has_height ) {
                        $src = '';
                        if ( preg_match( '/src=["\']([^"\']+)["\']/i', $tag, $m ) ) $src = $m[1];
                        $issues[] = [
                            'post_id'    => $p->ID,
                            'post_title' => $p->post_title,
                            'img_src'    => $src,
                            'filename'   => basename( $src ),
                            'missing'    => ( !$has_width && !$has_height ) ? 'both' : ( !$has_width ? 'width' : 'height' ),
                        ];
                    }
                }
            }
        }
        return $issues;
    }

    /**
     * Find images that should have lazy loading but don't
     */
    public function scan_missing_lazy() {
        $types = get_option( 'sseo_post_types', ['post','page'] );
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>200]);
        $issues = [];

        foreach ( $posts as $p ) {
            if ( preg_match_all( '/<img[^>]+>/i', $p->post_content, $matches ) ) {
                $img_count = 0;
                foreach ( $matches[0] as $tag ) {
                    $img_count++;
                    // Skip first image (likely LCP)
                    if ( $img_count <= 1 ) continue;
                    if ( ! preg_match( '/loading\s*=\s*["\']lazy["\']/i', $tag ) ) {
                        $src = '';
                        if ( preg_match( '/src=["\']([^"\']+)["\']/i', $tag, $m ) ) $src = $m[1];
                        $issues[] = [
                            'post_id'    => $p->ID,
                            'post_title' => $p->post_title,
                            'img_src'    => $src,
                            'filename'   => basename( $src ),
                        ];
                    }
                }
            }
        }
        return $issues;
    }

    // ════════════════════════════════════════════
    // FIX: WebP Conversion
    // ════════════════════════════════════════════

    /**
     * Convert a single image to WebP
     */
    public function convert_to_webp( $attachment_id, $quality = 80 ) {
        if ( ! function_exists('imagewebp') ) {
            return new WP_Error( 'no_gd', 'PHP GD library does not support WebP. Ask your host to enable it.' );
        }

        $file = get_attached_file( $attachment_id );
        if ( ! $file || ! file_exists($file) ) {
            return new WP_Error( 'no_file', 'Source file not found.' );
        }

        $mime = get_post_mime_type( $attachment_id );
        $webp_path = $this->get_webp_path( $file );
        $original_size = filesize( $file );

        // Create image resource
        switch ( $mime ) {
            case 'image/jpeg': $img = @imagecreatefromjpeg( $file ); break;
            case 'image/png':
                $img = @imagecreatefrompng( $file );
                if ( $img ) { imagepalettetotruecolor( $img ); imagealphablending($img,true); imagesavealpha($img,true); }
                break;
            default: return new WP_Error( 'unsupported', 'Only JPEG and PNG are supported.' );
        }

        if ( ! $img ) return new WP_Error( 'gd_fail', 'Failed to read image with GD.' );

        // Convert to WebP
        $success = imagewebp( $img, $webp_path, $quality );
        imagedestroy( $img );

        if ( ! $success || ! file_exists($webp_path) ) {
            return new WP_Error( 'convert_fail', 'WebP conversion failed.' );
        }

        // Also convert intermediate sizes (thumbnail, medium, large)
        $meta = wp_get_attachment_metadata( $attachment_id );
        $dir  = trailingslashit( dirname( $file ) );
        $converted_sizes = ['original'];

        if ( $meta && ! empty($meta['sizes']) ) {
            foreach ( $meta['sizes'] as $size_name => $size_data ) {
                $size_file = $dir . $size_data['file'];
                if ( ! file_exists($size_file) ) continue;

                $size_webp = $this->get_webp_path( $size_file );
                $size_mime = $size_data['mime-type'] ?? $mime;

                switch ( $size_mime ) {
                    case 'image/jpeg': $simg = @imagecreatefromjpeg($size_file); break;
                    case 'image/png':
                        $simg = @imagecreatefrompng($size_file);
                        if($simg){imagepalettetotruecolor($simg);imagealphablending($simg,true);imagesavealpha($simg,true);}
                        break;
                    default: $simg = null;
                }
                if ( $simg ) {
                    imagewebp( $simg, $size_webp, $quality );
                    imagedestroy( $simg );
                    if ( file_exists($size_webp) ) $converted_sizes[] = $size_name;
                }
            }
        }

        $webp_size = filesize( $webp_path );
        $savings   = $original_size > 0 ? round( (1 - $webp_size / $original_size) * 100 ) : 0;

        return [
            'attachment_id'  => $attachment_id,
            'original_size'  => $original_size,
            'webp_size'      => $webp_size,
            'savings_pct'    => $savings,
            'sizes_converted'=> $converted_sizes,
            'webp_path'      => $webp_path,
        ];
    }

    /**
     * Batch convert multiple images
     */
    public function batch_convert_webp( $ids, $quality = 80 ) {
        $results = [];
        $total_saved = 0;
        foreach ( $ids as $id ) {
            $r = $this->convert_to_webp( (int) $id, $quality );
            if ( is_wp_error($r) ) {
                $results[] = [ 'id' => $id, 'error' => $r->get_error_message() ];
            } else {
                $total_saved += $r['original_size'] - $r['webp_size'];
                $results[] = $r;
            }
        }
        return [ 'results' => $results, 'total_saved' => $total_saved, 'total_saved_human' => size_format($total_saved) ];
    }

    // ════════════════════════════════════════════
    // FIX: Add Missing Dimensions
    // ════════════════════════════════════════════

    /**
     * Fix missing width/height on all <img> tags in a post
     */
    public function fix_dimensions( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) return new WP_Error( 'no_post', 'Post not found.' );

        $content = $post->post_content;
        $fixed   = 0;

        $content = preg_replace_callback( '/<img([^>]+)>/i', function( $m ) use ( &$fixed ) {
            $tag = $m[0];
            $attrs = $m[1];

            $has_w = preg_match( '/\bwidth\s*=\s*["\']?\d+/i', $attrs );
            $has_h = preg_match( '/\bheight\s*=\s*["\']?\d+/i', $attrs );
            if ( $has_w && $has_h ) return $tag;

            // Extract src
            if ( ! preg_match( '/src=["\']([^"\']+)["\']/i', $attrs, $sm ) ) return $tag;
            $src = $sm[1];

            // Try to get dimensions
            $dims = $this->get_image_dimensions( $src );
            if ( ! $dims ) return $tag;

            // Inject dimensions
            $inject = '';
            if ( ! $has_w ) $inject .= ' width="' . $dims[0] . '"';
            if ( ! $has_h ) $inject .= ' height="' . $dims[1] . '"';

            $fixed++;
            return '<img' . $attrs . $inject . '>';
        }, $content );

        if ( $fixed > 0 ) {
            wp_update_post( [ 'ID' => $post_id, 'post_content' => $content ] );
        }

        return [ 'post_id' => $post_id, 'fixed' => $fixed ];
    }

    /**
     * Fix dimensions on ALL posts
     */
    public function fix_all_dimensions() {
        $types = get_option( 'sseo_post_types', ['post','page'] );
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>200,'fields'=>'ids']);
        $total = 0;
        foreach ( $posts as $pid ) {
            $r = $this->fix_dimensions( $pid );
            if ( ! is_wp_error($r) ) $total += $r['fixed'];
        }
        return [ 'posts_scanned' => count($posts), 'images_fixed' => $total ];
    }

    // ════════════════════════════════════════════
    // FIX: Smart Lazy Loading
    // ════════════════════════════════════════════

    /**
     * Fix lazy loading in all post content — add to below-fold, remove from first image
     */
    public function fix_lazy_loading( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) return new WP_Error( 'no_post', 'Post not found.' );

        $content = $post->post_content;
        $img_num = 0;
        $fixed   = 0;

        $content = preg_replace_callback( '/<img([^>]+)>/i', function( $m ) use ( &$img_num, &$fixed ) {
            $img_num++;
            $attrs = $m[1];

            $has_lazy = preg_match( '/loading\s*=\s*["\']lazy["\']/i', $attrs );

            if ( $img_num <= 1 ) {
                // First image: REMOVE lazy (it's likely LCP)
                if ( $has_lazy ) {
                    $attrs = preg_replace( '/\s*loading\s*=\s*["\']lazy["\']/i', '', $attrs );
                    // Add fetchpriority="high" for LCP
                    if ( ! preg_match( '/fetchpriority/i', $attrs ) ) {
                        $attrs .= ' fetchpriority="high"';
                    }
                    $fixed++;
                }
            } else {
                // Below-fold: ADD lazy if missing
                if ( ! $has_lazy ) {
                    $attrs .= ' loading="lazy"';
                    $fixed++;
                }
            }

            return '<img' . $attrs . '>';
        }, $content );

        if ( $fixed > 0 ) {
            wp_update_post( [ 'ID' => $post_id, 'post_content' => $content ] );
        }
        return [ 'post_id' => $post_id, 'fixed' => $fixed ];
    }

    /**
     * Fix lazy loading across ALL posts
     */
    public function fix_all_lazy() {
        $types = get_option( 'sseo_post_types', ['post','page'] );
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>200,'fields'=>'ids']);
        $total = 0;
        foreach ( $posts as $pid ) {
            $r = $this->fix_lazy_loading( $pid );
            if ( ! is_wp_error($r) ) $total += $r['fixed'];
        }
        return [ 'posts_scanned' => count($posts), 'images_fixed' => $total ];
    }

    // Runtime smart lazy (filter-based, no content edit needed)
    public function smart_lazy_attrs( $attrs, $attachment, $size ) {
        // Featured images and LCP candidates: no lazy, add fetchpriority
        if ( is_singular() && has_post_thumbnail() && $attachment && get_post_thumbnail_id() === $attachment->ID ) {
            unset( $attrs['loading'] );
            $attrs['fetchpriority'] = 'high';
        }
        return $attrs;
    }

    public function smart_lazy_content( $content ) {
        $img_num = 0;
        return preg_replace_callback( '/<img([^>]+)>/i', function($m) use (&$img_num) {
            $img_num++;
            $attrs = $m[1];
            if ( $img_num <= 1 ) {
                $attrs = preg_replace('/\s*loading\s*=\s*["\']lazy["\']/i', '', $attrs);
                if (!preg_match('/fetchpriority/i',$attrs)) $attrs .= ' fetchpriority="high"';
            } else {
                if (!preg_match('/loading\s*=/i',$attrs)) $attrs .= ' loading="lazy"';
            }
            return '<img'.$attrs.'>';
        }, $content );
    }

    // ════════════════════════════════════════════
    // FIX: LCP Preload
    // ════════════════════════════════════════════

    public function get_lcp_status() {
        return [
            'enabled'  => (bool) get_option( 'sseo_lcp_preload', 0 ),
            'image'    => get_option( 'sseo_lcp_image_url', '' ),
        ];
    }

    /**
     * Detect LCP image for homepage
     */
    public function detect_lcp_image() {
        // Check custom setting first
        $custom = get_option( 'sseo_lcp_image_url', '' );
        if ( $custom ) return $custom;

        // Try site logo
        $logo_id = get_theme_mod('custom_logo');
        if ( $logo_id ) {
            $src = wp_get_attachment_image_src( $logo_id, 'full' );
            if ( $src ) return $src[0];
        }

        // Try homepage featured image
        $front = get_option('page_on_front');
        if ( $front && has_post_thumbnail($front) ) {
            return get_the_post_thumbnail_url( $front, 'full' );
        }

        return '';
    }

    public function inject_lcp_preload() {
        $url = get_option( 'sseo_lcp_image_url', '' );
        if ( ! $url ) $url = $this->detect_lcp_image();
        if ( ! $url ) return;

        // Determine format for type attribute
        $ext = strtolower( pathinfo( parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION ) );
        $types = ['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','avif'=>'image/avif','gif'=>'image/gif','svg'=>'image/svg+xml'];
        $type = $types[$ext] ?? 'image/jpeg';

        echo '<link rel="preload" as="image" href="' . esc_url($url) . '" type="' . esc_attr($type) . '" fetchpriority="high">' . "\n";
    }

    // ════════════════════════════════════════════
    // WebP serving (rewrite content)
    // ════════════════════════════════════════════

    public function rewrite_to_webp( $content ) {
        if ( empty($content) ) return $content;

        return preg_replace_callback( '/(<img[^>]+)src=["\']([^"\']+\.(jpe?g|png))["\']([^>]*>)/i', function($m) {
            $src = $m[2];
            $upload_dir = wp_upload_dir();
            $base_url = $upload_dir['baseurl'];

            // Only process our uploads
            if ( strpos($src, $base_url) === false ) return $m[0];

            $relative = str_replace( $base_url, '', $src );
            $abs_path = $upload_dir['basedir'] . $relative;
            $webp_path = $this->get_webp_path( $abs_path );

            if ( file_exists($webp_path) ) {
                $webp_url = str_replace( $upload_dir['basedir'], $base_url, $webp_path );
                return $m[1] . 'src="' . $webp_url . '"' . $m[4];
            }
            return $m[0];
        }, $content );
    }

    // ════════════════════════════════════════════
    // PageSpeed Insights
    // ════════════════════════════════════════════

    public function check_pagespeed( $url = '', $strategy = 'mobile' ) {
        if ( ! $url ) $url = home_url('/');

        $api_url = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=' . urlencode($url) . '&strategy=' . $strategy . '&category=PERFORMANCE&category=ACCESSIBILITY&category=BEST_PRACTICES&category=SEO';

        $r = wp_remote_get( $api_url, [ 'timeout' => 60 ] );
        if ( is_wp_error($r) ) return $r;

        $code = wp_remote_retrieve_response_code($r);
        $body = json_decode( wp_remote_retrieve_body($r), true );
        if ( $code !== 200 ) return new WP_Error('api', 'PageSpeed API error: HTTP ' . $code);

        $cats = $body['lighthouseResult']['categories'] ?? [];
        $audits = $body['lighthouseResult']['audits'] ?? [];

        $scores = [];
        foreach ( $cats as $key => $cat ) {
            $scores[ $key ] = [
                'title' => $cat['title'] ?? $key,
                'score' => round( ($cat['score'] ?? 0) * 100 ),
            ];
        }

        // Extract Core Web Vitals
        $cwv = [];
        $vital_keys = [
            'first-contentful-paint'   => 'FCP',
            'largest-contentful-paint'  => 'LCP',
            'total-blocking-time'      => 'TBT',
            'cumulative-layout-shift'   => 'CLS',
            'speed-index'              => 'Speed Index',
        ];
        foreach ( $vital_keys as $k => $label ) {
            if ( isset($audits[$k]) ) {
                $cwv[] = [
                    'key'     => $k,
                    'label'   => $label,
                    'value'   => $audits[$k]['displayValue'] ?? '—',
                    'score'   => round( ($audits[$k]['score'] ?? 0) * 100 ),
                    'rating'  => $audits[$k]['score'] >= 0.9 ? 'good' : ($audits[$k]['score'] >= 0.5 ? 'needs_work' : 'poor'),
                ];
            }
        }

        // Image-specific opportunities
        $img_opps = [];
        $img_keys = ['uses-webp-images','offscreen-images','uses-responsive-images','uses-optimized-images','unsized-images','preload-lcp-element'];
        foreach ( $img_keys as $k ) {
            if ( isset($audits[$k]) && ($audits[$k]['score'] ?? 1) < 1 ) {
                $img_opps[] = [
                    'key'   => $k,
                    'title' => $audits[$k]['title'] ?? $k,
                    'desc'  => $audits[$k]['description'] ?? '',
                    'savings' => $audits[$k]['displayValue'] ?? '',
                    'score' => round(($audits[$k]['score'] ?? 0) * 100),
                ];
            }
        }

        // Cache result
        $result = [
            'url'      => $url,
            'strategy' => $strategy,
            'scores'   => $scores,
            'cwv'      => $cwv,
            'img_opps' => $img_opps,
            'date'     => current_time('mysql'),
        ];
        update_option( 'sseo_pagespeed_' . $strategy, $result );

        return $result;
    }

    // ════════════════════════════════════════════
    // Helpers
    // ════════════════════════════════════════════

    private function get_webp_path( $file ) {
        return preg_replace( '/\.(jpe?g|png)$/i', '.webp', $file );
    }

    private function get_image_dimensions( $src ) {
        // Try to find local file
        $upload_dir = wp_upload_dir();
        if ( strpos($src, $upload_dir['baseurl']) !== false ) {
            $rel  = str_replace( $upload_dir['baseurl'], '', $src );
            $file = $upload_dir['basedir'] . $rel;
            if ( file_exists($file) ) {
                $info = @getimagesize( $file );
                if ( $info ) return [ $info[0], $info[1] ];
            }
        }
        // Try attachment ID lookup
        $id = attachment_url_to_postid( $src );
        if ( $id ) {
            $meta = wp_get_attachment_metadata( $id );
            if ( $meta && isset($meta['width'], $meta['height']) ) {
                return [ $meta['width'], $meta['height'] ];
            }
        }
        return null;
    }

    /**
     * Get summary stats for dashboard
     */
    public function get_stats() {
        $non_webp = count( $this->scan_non_webp() );
        $missing_dims = count( $this->scan_missing_dimensions() );
        $missing_lazy = count( $this->scan_missing_lazy() );
        $lcp = $this->get_lcp_status();
        return compact('non_webp','missing_dims','missing_lazy','lcp');
    }
}
