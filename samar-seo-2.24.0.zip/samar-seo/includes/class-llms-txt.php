<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_LLMS_Txt {
    public function __construct() {
        add_action( 'init', [ $this, 'register_rewrite' ] );
        add_action( 'template_redirect', [ $this, 'serve' ] );
    }

    public function register_rewrite() {
        add_rewrite_rule( '^llms\.txt$', 'index.php?sseo_llms_txt=1', 'top' );
        add_filter( 'query_vars', function( $vars ) { $vars[] = 'sseo_llms_txt'; return $vars; } );
    }

    public function serve() {
        if ( ! get_query_var('sseo_llms_txt') ) return;
        $content = get_option( 'sseo_llms_txt_content', '' );
        if ( empty( $content ) ) $content = $this->generate_default();
        header( 'Content-Type: text/plain; charset=utf-8' );
        header( 'Cache-Control: public, max-age=86400' );
        echo $content;
        exit;
    }

    public function generate_default() {
        $name    = get_option( 'sseo_brand_name', get_bloginfo('name') );
        $desc    = get_bloginfo( 'description' );
        $url     = home_url('/');
        $loc     = get_option( 'sseo_target_location', '' );
        $phone   = get_option( 'sseo_business_phone', '' );
        $address = get_option( 'sseo_business_address', '' );

        $txt = "# {$name}\n";
        $txt .= "> {$desc}\n\n";
        $txt .= "## Website\n{$url}\n\n";
        if ( $loc )     $txt .= "## Service Areas\n{$loc}\n\n";
        if ( $address ) $txt .= "## Address\n{$address}\n\n";
        if ( $phone )   $txt .= "## Phone\n{$phone}\n\n";

        // Services from pages
        $pages = get_pages(['sort_column'=>'menu_order','parent'=>0]);
        $txt .= "## Pages\n";
        foreach ( $pages as $p ) {
            $txt .= "- [{$p->post_title}](" . get_permalink($p->ID) . ")\n";
        }

        return $txt;
    }

    public function generate_ai() {
        $api = new SSEO_API_Handler();
        $name = get_option('sseo_brand_name', get_bloginfo('name'));
        $loc  = get_option('sseo_target_location','');
        $addr = get_option('sseo_business_address','');
        $type = get_option('sseo_business_type','');

        // Get all page titles
        $pages = get_posts(['post_type'=>['page','post'],'post_status'=>'publish','numberposts'=>50,'fields'=>'']);
        $page_list = '';
        foreach ($pages as $p) $page_list .= "- {$p->post_title} ({$p->post_type}): ".get_permalink($p->ID)."\n";

        $prompt = "Create a comprehensive llms.txt file for AI models to understand this website.
Business: {$name}
Type: {$type}
Location: {$loc}
Address: {$addr}
URL: ".home_url('/')."

Pages:
{$page_list}

Follow the llms.txt specification format with: business description, services, areas served, key pages with URLs.
Return ONLY the raw llms.txt content, no markdown fences.";

        $r = $api->complete($prompt);
        if (is_wp_error($r)) return $r;
        return $r['content'];
    }
}
