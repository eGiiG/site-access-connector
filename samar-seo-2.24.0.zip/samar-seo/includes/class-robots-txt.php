<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Robots_Txt {

    /**
     * Get current robots.txt content
     */
    public function get_content() {
        // Check for physical file first
        $file = ABSPATH . 'robots.txt';
        if ( file_exists( $file ) ) {
            return [ 'source' => 'file', 'content' => file_get_contents( $file ), 'editable' => is_writable( $file ) ];
        }
        // WP virtual robots.txt
        $virtual = get_option( 'sseo_robots_txt', '' );
        if ( $virtual ) {
            return [ 'source' => 'option', 'content' => $virtual, 'editable' => true ];
        }
        // Generate default
        $default = "User-agent: *\nAllow: /\n\nSitemap: " . home_url('/sitemap.xml') . "\nSitemap: " . home_url('/sitemap_index.xml');
        return [ 'source' => 'default', 'content' => $default, 'editable' => true ];
    }

    /**
     * Save robots.txt
     */
    public function save( $content ) {
        $file = ABSPATH . 'robots.txt';
        if ( file_exists( $file ) && is_writable( $file ) ) {
            file_put_contents( $file, $content );
            return [ 'saved_to' => 'file' ];
        }
        update_option( 'sseo_robots_txt', $content );
        return [ 'saved_to' => 'option' ];
    }

    /**
     * Scan for blocked critical resources
     */
    public function scan_blocked() {
        $data = $this->get_content();
        $content = $data['content'];
        $blocked = [];

        // Parse disallow rules
        $lines = explode( "\n", $content );
        $current_agent = '*';
        foreach ( $lines as $line ) {
            $line = trim( $line );
            if ( preg_match( '/^User-agent:\s*(.+)/i', $line, $m ) ) {
                $current_agent = trim( $m[1] );
            }
            if ( preg_match( '/^Disallow:\s*(.+)/i', $line, $m ) ) {
                $path = trim( $m[1] );
                if ( empty( $path ) ) continue;
                $severity = 'low';
                $reason = '';

                // Check if it blocks critical resources
                if ( preg_match( '/\.(css|js)$/i', $path ) || strpos($path, '/wp-content/themes/') !== false || strpos($path, '/wp-content/plugins/') !== false ) {
                    $severity = 'high';
                    $reason = 'Blocks CSS/JS — Google cannot render your pages properly';
                } elseif ( strpos($path, '/wp-includes/') !== false ) {
                    $severity = 'high';
                    $reason = 'Blocks WordPress core resources needed for rendering';
                } elseif ( $path === '/' ) {
                    $severity = 'critical';
                    $reason = 'Blocks ENTIRE site from crawling!';
                } elseif ( strpos($path, '/wp-admin/') !== false ) {
                    $severity = 'ok';
                    $reason = 'Correctly blocks admin area';
                } elseif ( strpos($path, '/wp-json/') !== false ) {
                    $severity = 'medium';
                    $reason = 'May block API endpoints needed by plugins';
                } elseif ( preg_match( '/\/(tag|author|date|archive)/i', $path ) ) {
                    $severity = 'ok';
                    $reason = 'Correctly blocks low-value archive pages';
                } else {
                    $severity = 'medium';
                    $reason = 'Review whether this path should be crawlable';
                }

                $blocked[] = [
                    'agent'    => $current_agent,
                    'path'     => $path,
                    'severity' => $severity,
                    'reason'   => $reason,
                    'line'     => $line,
                ];
            }
        }

        // Check for missing sitemap
        $has_sitemap = preg_match( '/^Sitemap:/im', $content );

        return [
            'blocked'      => $blocked,
            'has_sitemap'  => (bool) $has_sitemap,
            'total_rules'  => count( $blocked ),
            'critical'     => count( array_filter( $blocked, function($b){ return $b['severity']==='critical'; } ) ),
            'high'         => count( array_filter( $blocked, function($b){ return $b['severity']==='high'; } ) ),
        ];
    }

    /**
     * Generate optimal robots.txt
     */
    public function generate_optimal() {
        $sitemap_urls = [];
        // Try common sitemap paths
        $paths = ['/sitemap.xml', '/sitemap_index.xml', '/wp-sitemap.xml'];
        foreach ( $paths as $p ) {
            $r = wp_remote_head( home_url($p), ['timeout'=>5,'sslverify'=>false,'redirection'=>0] );
            if ( ! is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200 ) {
                $sitemap_urls[] = home_url($p);
            }
        }

        $txt = "User-agent: *\n";
        $txt .= "Allow: /\n\n";
        $txt .= "# Block admin and login\n";
        $txt .= "Disallow: /wp-admin/\n";
        $txt .= "Allow: /wp-admin/admin-ajax.php\n\n";
        $txt .= "# Block low-value pages\n";
        $txt .= "Disallow: /wp-login.php\n";
        $txt .= "Disallow: /xmlrpc.php\n";
        $txt .= "Disallow: /?s=\n";
        $txt .= "Disallow: /search/\n\n";
        $txt .= "# Allow all critical resources\n";
        $txt .= "Allow: /wp-content/uploads/\n";
        $txt .= "Allow: /wp-content/themes/\n";
        $txt .= "Allow: /wp-content/plugins/\n";
        $txt .= "Allow: /wp-includes/\n\n";

        if ( ! empty($sitemap_urls) ) {
            $txt .= "# Sitemaps\n";
            foreach ( $sitemap_urls as $s ) $txt .= "Sitemap: {$s}\n";
        }

        return $txt;
    }
}
