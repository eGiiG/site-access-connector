<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Ajax_Handler {
    public function __construct() {
        $actions = ['connect_pair','connect_unpair','connect_key','connect_status','test_api','save_settings','get_settings','switch_provider','ai_scan_business','get_posts','generate_meta','apply_meta','get_missing_alts','generate_alts','apply_alt',
            'scan_titles','optimize_title','apply_title','bulk_fix_titles','scan_h1','suggest_h1','apply_h1','bulk_fix_h1','scan_broken','scan_thin','thin_ignore','bulk_auto_ignore',
            'get_redirects','add_redirect','delete_redirect','save_schema','schema_validate','schema_bulk_preview','schema_bulk_apply','cleanup_published','save_llms','generate_llms','get_log',
            'bulk_meta','bulk_alts',
            'imgtitle_scan','imgtitle_generate','imgtitle_generate_batch','imgtitle_apply','imgtitle_bulk_auto','get_recent_changes',
            'content_research','content_generate','content_enhance','content_expand','content_apply_expand','clear_archive_intro','find_matching_service','content_save_draft','content_find_media','content_browse_media','content_apply_enhanced','content_versions','content_revert',
            'report_snapshot','report_snapshot_history','report_set_snapshot','report_delete_snapshot','report_generate','report_list','report_delete','report_restore_baseline',
            'imgopt_scan','imgopt_convert_webp','imgopt_batch_webp','imgopt_fix_dims','imgopt_fix_lazy','imgopt_save_lcp','imgopt_pagespeed',
            'robots_get','robots_save','robots_scan','robots_generate',
            'orphans_scan','orphans_suggest','orphans_inject',
            'crawl_analyze','crawl_add_related',
            'anchors_scan','anchors_ai_rewrite','anchors_apply',
            'chains_scan','chains_flatten','chains_flatten_all','chains_fix_content',
            'linker_scan','linker_ai_scan','linker_apply','linker_apply_bulk',
            'audit_run','local_audit_run','ai_audit_run','ai_audit_cached',
            'template_list','template_generate','template_save',
            'tpl_engine_list','tpl_engine_generate',
            'toggle_page_schema','get_page_schema','get_review_link','generate_review_email','generate_review_response','testimonials_fetch_google','testimonials_add','testimonials_delete','testimonials_list','testimonials_get_widget','testimonials_save_settings'];
        foreach ( $actions as $a ) add_action( 'wp_ajax_sseo_'.$a, [$this, $a] );
    }

    private function v() { check_ajax_referer('sseo_nonce','nonce'); if(!current_user_can('manage_options')) wp_send_json_error('Unauthorized.',403); }

    private function maybe_override_provider() {
        $ov = sanitize_text_field($_POST['override_provider'] ?? '');
        if (empty($ov)) return null;
        $valid = ['platform','openai','azure','anthropic','deepseek','groq','gemini','openrouter'];
        if (!in_array($ov, $valid)) return null;
        $orig = get_option('sseo_provider', 'openai');
        if ($ov === $orig) return null;
        update_option('sseo_provider', $ov);
        return $orig;
    }
    private function restore_provider($orig) { if ($orig !== null) update_option('sseo_provider', $orig); }

    // ─── Settings ──────────────
    public function test_api() {
        $this->v();
        $api = new SSEO_API_Handler();
        $r = $api->test_connection();
        if (is_wp_error($r)) {
            wp_send_json_error($api->get_provider_name() . ' (' . $api->get_model_name() . '): ' . $r->get_error_message());
        }
        wp_send_json_success($api->get_provider_name() . ' — ' . $api->get_model_name() . ' ✓ Connected!');
    }

    public function switch_provider() {
        $this->v();
        $provider = sanitize_text_field($_POST['provider'] ?? '');
        $valid = ['platform','openai','azure','anthropic','deepseek','groq','gemini','openrouter'];
        if (!in_array($provider, $valid)) wp_send_json_error('Invalid provider.');
        update_option('sseo_provider', $provider);
        $api = new SSEO_API_Handler();
        wp_send_json_success(['provider'=>$provider,'label'=>$api->get_provider_name(),'model'=>$api->get_model_name()]);
    }

    public function save_settings() {
        $this->v();
        $fields = ['whitelabel_name','provider','openai_api_key','openai_model','azure_api_key','azure_endpoint','azure_deployment','azure_api_version',
            'anthropic_api_key','anthropic_model','deepseek_api_key','deepseek_model','groq_api_key','groq_model',
            'gemini_api_key','gemini_model','openrouter_api_key','openrouter_model',
            'default_tone','brand_name','target_location','business_type','business_phone',
            'business_address','business_city','business_state','business_zip','business_country','business_lat','business_lng',
            'business_email','business_hours','business_founded','business_license','business_services','business_website',
            'social_profiles','seo_plugin','batch_size','rate_limit_delay','schema_enabled','og_enabled','review_count','avg_rating',
            'brand_color_1','brand_color_2','hero_bg_color','content_width','lock_enabled'];
        foreach ($fields as $f) if(isset($_POST[$f])) update_option('sseo_'.$f, sanitize_text_field(wp_unslash($_POST[$f])));
        if(isset($_POST['post_types'])) update_option('sseo_post_types', array_map('sanitize_text_field',(array)$_POST['post_types']));
        // Password change — requires old password verification
        $pass_msg = '';
        if(!empty($_POST['new_password'])){
            $old_input = sanitize_text_field($_POST['old_password'] ?? '');
            $stored = get_option('sseo_plugin_password','');
            if (empty($old_input)) {
                $pass_msg = ' ⚠️ Password NOT changed — current password is required.';
            } elseif (!wp_check_password($old_input, $stored)) {
                $pass_msg = ' ⚠️ Password NOT changed — current password is incorrect.';
            } else {
                update_option('sseo_plugin_password', wp_hash_password(sanitize_text_field($_POST['new_password'])));
                $pass_msg = ' 🔑 Password updated successfully.';
            }
        }
        wp_send_json_success('Settings saved.' . $pass_msg);
    }

    public function connect_pair() {
        $this->v();
        $r = sseo_do_connect( isset($_POST['code']) ? wp_unslash($_POST['code']) : '' );
        if ( is_wp_error( $r ) ) wp_send_json_error( $r->get_error_message() );
        wp_send_json_success( [
            'brand'         => get_option('sseo_whitelabel_name',''),
            'paired'        => true,
            'lock_password' => is_array($r) && ! empty($r['lock_password']) ? $r['lock_password'] : '',
        ] );
    }
    /** [connection-key v1] Create a connection key (only while the site is not connected). Replaces any earlier key. */
    public function connect_key() {
        $this->v();
        if ( function_exists('sseo_is_connected') && sseo_is_connected() ) wp_send_json_error( 'This site is already connected to an agency.' );
        if ( ! class_exists('EGSM_Auth') ) wp_send_json_error( 'Site management is not available in this build of the plugin.' );
        wp_send_json_success( [ 'key' => EGSM_Auth::generate_key() ] );
    }
    public function connect_status() {
        $this->v();
        wp_send_json_success( [ 'connected' => function_exists('sseo_is_connected') && sseo_is_connected() ] );
    }
    public function connect_unpair() {
        $this->v();
        sseo_do_disconnect();
        wp_send_json_success( [ 'paired' => false ] );
    }
    public function get_settings() {
        $this->v();
        $fields = ['whitelabel_name','connect_paired','provider','openai_model','azure_endpoint','azure_deployment','azure_api_version',
            'anthropic_model','deepseek_model','groq_model','gemini_model','openrouter_model',
            'default_tone','brand_name','target_location','business_type','business_phone',
            'business_address','business_city','business_state','business_zip','business_country','business_lat','business_lng',
            'business_email','business_hours','business_founded','business_license','business_services','business_website',
            'social_profiles','seo_plugin','batch_size','rate_limit_delay','schema_enabled','og_enabled','review_count','avg_rating','lock_enabled',
            'brand_color_1','brand_color_2','hero_bg_color','content_width','google_places_key','google_place_id'];
        $data = [];
        foreach ($fields as $f) $data[$f] = get_option('sseo_'.$f, '');
        // Mask API keys — show last 4 chars only
        $key_fields = ['openai_api_key','azure_api_key','anthropic_api_key','deepseek_api_key','groq_api_key','gemini_api_key','openrouter_api_key'];
        foreach ($key_fields as $kf) {
            $val = get_option('sseo_'.$kf, '');
            $data[$kf] = $val ? str_repeat('•', max(0, strlen($val)-4)) . substr($val, -4) : '';
            $data[$kf.'_set'] = !empty($val);
        }
        $data['post_types'] = get_option('sseo_post_types', ['post','page']);
        wp_send_json_success($data);
    }

    public function ai_scan_business() {
        $this->v();
        $url = sanitize_url($_POST['website_url'] ?? home_url('/'));
        if (empty($url)) $url = home_url('/');
        $base = rtrim($url, '/');

        // ── Step 1: Fetch homepage ──
        $response = wp_remote_get($url, ['timeout'=>15,'sslverify'=>false,'redirection'=>3]);
        if (is_wp_error($response)) wp_send_json_error('Could not fetch website: '.$response->get_error_message());
        $html = wp_remote_retrieve_body($response);

        // ── Step 2: Extract existing JSON-LD schema (most reliable source!) ──
        $schema_data = '';
        $all_schemas = [];
        if (preg_match_all('/<script[^>]*type=["\']application\/ld\+json["\'][^>]*>(.*?)<\/script>/is', $html, $schema_matches)) {
            foreach ($schema_matches[1] as $json) {
                $decoded = json_decode(trim($json), true);
                if ($decoded) {
                    $all_schemas[] = $decoded;
                    $schema_data .= "\n\nExisting JSON-LD Schema on homepage:\n" . json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
                }
            }
        }

        // ── Step 3: Extract structured content from homepage ──
        $text = '';
        if (preg_match('/<title[^>]*>(.*?)<\/title>/is', $html, $m)) $text .= "Page Title: ".trim(strip_tags($m[1]))."\n";
        if (preg_match('/<meta[^>]*name=["\']description["\'][^>]*content=["\']([^"\']+)["\']/i', $html, $m)) $text .= "Meta: ".trim($m[1])."\n";
        if (preg_match_all('/<h[1-3][^>]*>(.*?)<\/h[1-3]>/is', $html, $m)) {
            $text .= "Headings: ".implode(' | ', array_map('strip_tags', array_slice($m[1],0,20)))."\n";
        }

        // Footer
        if (preg_match('/<footer[^>]*>(.*?)<\/footer>/is', $html, $m)) {
            $text .= "\nFooter content: ".substr(wp_strip_all_tags($m[1]), 0, 800);
        }

        // Google Maps embed
        if (preg_match_all('/(?:maps\.google\.com|google\.com\/maps)[^"\']*?(?:q=|query=|place\/)([^"\'&]+)/i', $html, $maps)) {
            $text .= "\nGoogle Maps address: " . urldecode($maps[1][0]);
        }

        // Address patterns
        if (preg_match_all('/\d{1,5}\s+[A-Z][a-zA-Z\s]+(?:St|Street|Ave|Avenue|Blvd|Boulevard|Dr|Drive|Rd|Road|Ln|Lane|Way|Ct|Court|Pl|Place|Pkwy|Parkway|Hwy|Highway)[.,]?\s*(?:#\s*\d+|Suite\s*\d+|Ste\s*\d+)?/i', wp_strip_all_tags($html), $addr_matches)) {
            $text .= "\nAddress patterns: " . implode(' | ', array_unique(array_slice($addr_matches[0], 0, 5)));
        }

        // Phone patterns
        if (preg_match_all('/(?:\+1[\s.-]?)?(?:\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4})/i', wp_strip_all_tags($html), $phone_matches)) {
            $text .= "\nPhones: " . implode(' | ', array_unique(array_slice($phone_matches[0], 0, 3)));
        }

        // Email patterns
        if (preg_match_all('/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/i', $html, $email_matches)) {
            $emails = array_filter(array_unique($email_matches[0]), function($e){ return !preg_match('/\.(png|jpg|gif|css|js)$/i', $e); });
            if ($emails) $text .= "\nEmails: " . implode(' | ', array_slice($emails, 0, 3));
        }

        // Hours patterns (look for common hour formats)
        $hours_text = '';
        if (preg_match_all('/(?:Mon(?:day)?|Tue(?:sday)?|Wed(?:nesday)?|Thu(?:rsday)?|Fri(?:day)?|Sat(?:urday)?|Sun(?:day)?)\s*[-–:]\s*(?:Mon(?:day)?|Tue(?:sday)?|Wed(?:nesday)?|Thu(?:rsday)?|Fri(?:day)?|Sat(?:urday)?|Sun(?:day)?)?\s*[:.]?\s*\d{1,2}(?::\d{2})?\s*(?:am|pm|AM|PM)?\s*[-–to]+\s*\d{1,2}(?::\d{2})?\s*(?:am|pm|AM|PM)?/i', wp_strip_all_tags($html), $hrs)) {
            $hours_text = implode(' | ', array_unique(array_slice($hrs[0], 0, 5)));
            $text .= "\nHours patterns found: " . $hours_text;
        }
        // Also try "Open/Closed" patterns
        if (preg_match_all('/(?:hours|schedule|open)\s*[:\s]+([^<\n]{10,80}(?:\d{1,2}(?::\d{2})?\s*(?:am|pm|AM|PM)))/i', wp_strip_all_tags($html), $hrs2)) {
            $hours_text .= ' | ' . implode(' | ', array_slice($hrs2[0], 0, 3));
            $text .= "\nHours context: " . implode(' | ', array_slice($hrs2[0], 0, 3));
        }

        // Social links
        $social_found = [];
        if (preg_match_all('/href=["\']([^"\']*(?:facebook\.com|instagram\.com|twitter\.com|x\.com|linkedin\.com|youtube\.com|yelp\.com|bbb\.org|nextdoor\.com|houzz\.com|angi\.com|thumbtack\.com|google\.com\/maps)[^"\']*)["\']/', $html, $social_m)) {
            $social_found = array_unique($social_m[1]);
            $text .= "\nSocial links: " . implode("\n", $social_found);
        }

        // Body text
        $body_text = wp_strip_all_tags(preg_replace('/<(script|style|nav)[^>]*>.*?<\/\1>/is', '', $html));
        $text .= "\n\nBody:\n" . substr(preg_replace('/\s+/', ' ', $body_text), 0, 1500);

        // ── Step 4: Fetch services pages (CRITICAL for proper service names) ──
        $services_text = '';
        $services_pages = ['/services/','/our-services/','/what-we-do/','/service/'];
        foreach ($services_pages as $sp) {
            $sr = wp_remote_get($base.$sp, ['timeout'=>8,'sslverify'=>false,'redirection'=>2]);
            if (is_wp_error($sr) || wp_remote_retrieve_response_code($sr) !== 200) continue;
            $sh = wp_remote_retrieve_body($sr);

            // Get all headings (these ARE the service names)
            if (preg_match_all('/<h[1-4][^>]*>(.*?)<\/h[1-4]>/is', $sh, $svc_headings)) {
                $clean_headings = array_map(function($h){ return trim(strip_tags($h)); }, $svc_headings[1]);
                $clean_headings = array_filter($clean_headings, function($h){ return strlen($h)>3 && strlen($h)<80; });
                $services_text .= "\n\nService page ({$sp}) headings: " . implode(' | ', array_slice($clean_headings, 0, 20));
            }

            // Get all internal links on service page (sub-service pages)
            if (preg_match_all('/href=["\']([^"\']*(?:service|remodel|install|repair|build|construct|addition|renovation|restoration|plumb|electri|roof|hvac|paint|floor|deck|patio|bathroom|kitchen|basement)[^"\']*)["\'][^>]*>([^<]+)/i', $sh, $svc_links)) {
                $link_texts = array_map('trim', $svc_links[2]);
                $services_text .= "\nService links found: " . implode(' | ', array_unique(array_slice($link_texts, 0, 20)));
            }

            // JSON-LD on service pages
            if (preg_match_all('/<script[^>]*type=["\']application\/ld\+json["\'][^>]*>(.*?)<\/script>/is', $sh, $svc_schema)) {
                foreach ($svc_schema[1] as $sj) {
                    $sd = json_decode(trim($sj), true);
                    if ($sd) $schema_data .= "\n\nJSON-LD on {$sp}:\n" . json_encode($sd, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
                }
            }
        }

        // ── Step 5: Fetch contact/about pages ──
        $extra_pages_text = '';
        $pages_to_try = ['/contact/','/contact-us/','/about/','/about-us/','/location/','/locations/','/service-area/'];
        foreach ($pages_to_try as $page_path) {
            $pr = wp_remote_get($base.$page_path, ['timeout'=>8,'sslverify'=>false,'redirection'=>2]);
            if (is_wp_error($pr) || wp_remote_retrieve_response_code($pr) !== 200) continue;
            $ph = wp_remote_retrieve_body($pr);

            if (preg_match_all('/<script[^>]*type=["\']application\/ld\+json["\'][^>]*>(.*?)<\/script>/is', $ph, $sub_schema)) {
                foreach ($sub_schema[1] as $sj) {
                    $sd = json_decode(trim($sj), true);
                    if ($sd) $schema_data .= "\n\nJSON-LD on {$page_path}:\n" . json_encode($sd, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
                }
            }
            if (preg_match('/(?:maps\.google\.com|google\.com\/maps)[^"\']*?(?:q=|query=|place\/)([^"\'&]+)/i', $ph, $maps2)) {
                $extra_pages_text .= "\nGoogle Maps on {$page_path}: " . urldecode($maps2[1]);
            }
            // Hours on contact/about pages
            if (preg_match_all('/(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)[a-z]*\s*[-–:]\s*(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)?[a-z]*\s*[:.]?\s*\d{1,2}(?::\d{2})?\s*(?:am|pm|AM|PM)?\s*[-–to]+\s*\d{1,2}(?::\d{2})?\s*(?:am|pm|AM|PM)?/i', wp_strip_all_tags($ph), $pg_hrs)) {
                $extra_pages_text .= "\nHours on {$page_path}: " . implode(' | ', array_slice($pg_hrs[0], 0, 5));
            }

            $page_clean = wp_strip_all_tags(preg_replace('/<(script|style|nav|header)[^>]*>.*?<\/\1>/is', '', $ph));
            $extra_pages_text .= "\n\n--- {$page_path} ---\n" . substr(preg_replace('/\s+/', ' ', $page_clean), 0, 1200);
        }

        // ── Step 6: Try Google Business Profile via Places API ──
        $gbp_data = '';
        // Extract business name from title for GBP search
        $biz_name = '';
        if (preg_match('/<title[^>]*>(.*?)<\/title>/is', $html, $title_m)) {
            $biz_name = trim(strip_tags($title_m[1]));
            $biz_name = preg_replace('/\s*[-–|·•].*$/', '', $biz_name); // Remove tagline after separator
        }
        if ($biz_name) {
            // Use Google Places Text Search (no API key needed for basic search)
            $search_url = 'https://www.google.com/maps/search/' . urlencode($biz_name . ' ' . wp_parse_url($url, PHP_URL_HOST));
            $gbp_data .= "\nGoogle Maps search URL: {$search_url}";
            $gbp_data .= "\nExtracted business name for GBP: {$biz_name}";
        }

        // ── Step 7: Send to AI with improved prompt ──
        $api = new SSEO_API_Handler();
        $prompt = "You are extracting business details for a Google Business Profile and Schema.org markup. Be thorough and precise.

Website URL: {$url}

=== HOMEPAGE DATA ===
{$text}

=== EXISTING SCHEMA (HIGHEST PRIORITY — use these values when available) ===
{$schema_data}

=== SERVICES PAGES ===
{$services_text}

=== CONTACT/ABOUT PAGES ===
{$extra_pages_text}

=== GOOGLE BUSINESS PROFILE ===
{$gbp_data}

CRITICAL RULES:

ADDRESS — must match Google Business Profile format exactly:
- Street address: include number + street name + suite/unit (e.g. '8500 Timber Falls Dr')
- City: full city name (e.g. 'Ellicott City')
- State: 2-letter USPS code (e.g. 'MD')
- ZIP: 5-digit (e.g. '21043')
- If JSON-LD schema has address, use that EXACTLY
- If Google Maps embed found, use that address

SERVICES — this is critical, write FULL professional service names:
- WRONG: 'additions, kitchens, bathrooms, decks, painting'
- RIGHT: 'Home Additions, Kitchen Remodeling, Bathroom Renovation, Deck Construction, Interior & Exterior Painting'
- Each service must be a complete, professional service name that would appear on a Google Business Profile
- Use Title Case
- Include the specific work type (Remodeling, Installation, Repair, Construction, Renovation, Restoration)
- Get the service names from the /services/ or /what-we-do/ page headings — those are the actual service names
- If no services page found, infer from the homepage content

BUSINESS HOURS — parse carefully:
- Convert 'Mon-Fri 8am-5pm' → 'Mo-Fr 08:00-17:00'
- Convert 'Saturday 9am-2pm' → 'Sa 09:00-14:00'
- Convert '24/7' → 'Mo-Su 00:00-23:59'
- Always use 24-hour format with leading zeros
- Separate multiple schedules with commas
- Check contact page, footer, about page for hours
- If you find text like 'Open Monday through Friday' with times, convert it

BUSINESS TYPE — must be exact schema.org value:
LocalBusiness, HomeAndConstructionBusiness, GeneralContractor, Plumber, Electrician, RoofingContractor, ProfessionalService, Store, Restaurant, AutoRepair, LegalService, Dentist, MedicalBusiness, RealEstateAgent, InsuranceAgency, FinancialService, HairSalon, DayCare, Locksmith, MovingCompany, HVACBusiness, Florist, TravelAgency

Return ONLY valid JSON (no markdown, no code fences, no explanation):
{
  \"brand_name\": \"\",
  \"business_type\": \"\",
  \"business_phone\": \"\",
  \"business_email\": \"\",
  \"business_address\": \"street only\",
  \"business_city\": \"\",
  \"business_state\": \"2-letter\",
  \"business_zip\": \"5-digit\",
  \"business_country\": \"US\",
  \"business_lat\": \"\",
  \"business_lng\": \"\",
  \"target_location\": \"service areas comma-separated\",
  \"business_services\": \"Full Service Name 1, Full Service Name 2, Full Service Name 3\",
  \"business_founded\": \"\",
  \"business_license\": \"\",
  \"business_hours\": \"Mo-Fr 08:00-17:00, Sa 09:00-14:00\",
  \"social_profiles\": \"one URL per line\",
  \"review_count\": \"number if found\",
  \"avg_rating\": \"rating if found like 4.9\"
}";

        $r = $api->complete($prompt, 0.15);
        if (is_wp_error($r)) wp_send_json_error($r->get_error_message());
        $parsed = SSEO_API_Handler::parse_json($r['content']);
        if (is_wp_error($parsed)) wp_send_json_error('AI response parsing failed. Try again.');

        // Inject social profiles we found directly
        if (!empty($social_found) && (empty($parsed['social_profiles']) || strlen($parsed['social_profiles']) < 10)) {
            $parsed['social_profiles'] = implode("\n", $social_found);
        }

        // Always include the website URL
        $parsed['business_website'] = $url;

        wp_send_json_success($parsed);
    }

    // ─── Meta Descriptions ──────────────
    public function get_posts() {
        $this->v();
        $types = get_option('sseo_post_types',['post','page']);
        $args = ['post_type'=>$types,'post_status'=>'publish','posts_per_page'=>50,'paged'=>(int)($_POST['paged']??1),'orderby'=>'date','order'=>'DESC'];
        if(!empty($_POST['search'])) $args['s'] = sanitize_text_field($_POST['search']);
        $q = new WP_Query($args);
        $seo = new SSEO_SEO_Integration();
        $posts = [];
        foreach($q->posts as $p){
            $meta = $seo->get_meta($p->ID);
            $has = !empty(trim($meta));
            $filter = $_POST['filter']??'all';
            if($filter==='missing'&&$has) continue;
            if($filter==='has_meta'&&!$has) continue;
            $posts[] = ['id'=>$p->ID,'title'=>$p->post_title,'type'=>$p->post_type,'date'=>get_the_date('M j, Y',$p),'permalink'=>get_permalink($p->ID),'meta'=>$meta,'has_meta'=>$has,'char_count'=>mb_strlen($meta)];
        }
        wp_send_json_success(['posts'=>$posts,'total'=>$q->found_posts,'total_pages'=>$q->max_num_pages,'paged'=>(int)($_POST['paged']??1)]);
    }

    public function generate_meta() {
        $this->v();
        $tone = sanitize_text_field($_POST['tone'] ?? '');
        $r = (new SSEO_Meta_Generator)->generate((int)$_POST['post_id'], min((int)($_POST['count']??3),5), $tone);
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    public function apply_meta() {
        $this->v();
        $r = (new SSEO_Meta_Generator)->apply((int)$_POST['post_id'], sanitize_text_field(wp_unslash($_POST['description']??'')));
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success('Applied!');
    }

    public function bulk_meta() {
        $this->v();
        $ids = array_map('intval',(array)($_POST['post_ids']??[]));
        $auto = ($_POST['auto_apply']??'')=='true';
        $gen = new SSEO_Meta_Generator();
        $results = []; $errors = [];
        foreach($ids as $pid){
            $r = $gen->generate($pid,1);
            if(is_wp_error($r)){ $errors[]=['post_id'=>$pid,'error'=>$r->get_error_message()]; continue; }
            $desc = $r['descriptions'][0]['description']??'';
            if($auto&&$desc) $gen->apply($pid,$desc);
            $results[] = ['post_id'=>$pid,'post_title'=>$r['post_title'],'description'=>$desc,'applied'=>$auto];
            $delay = (int)get_option('sseo_rate_limit_delay',2);
            if($delay>0) sleep($delay);
        }
        wp_send_json_success(['results'=>$results,'errors'=>$errors]);
    }

    // ─── ALT Tags ──────────────
    public function get_missing_alts() {
        $this->v();
        $gen = new SSEO_Alt_Generator();
        $page = (int)($_POST['paged']??1);
        $images = $gen->get_missing(50, ($page-1)*50);
        $total = $gen->count_missing();
        wp_send_json_success(['images'=>$images,'total'=>$total,'total_pages'=>ceil($total/50),'paged'=>$page]);
    }

    public function generate_alts() {
        $this->v();
        $ids = array_map('intval',(array)($_POST['image_ids']??[]));
        $use_vision = ($_POST['use_vision']??'true') === 'true';

        if ( empty($ids) ) wp_send_json_error('No images selected.');

        // Single image — use vision (AI sees the actual image)
        if ( count($ids) === 1 && $use_vision ) {
            $gen = new SSEO_Alt_Generator();
            $r = $gen->generate_single_vision( $ids[0] );
            if ( is_wp_error($r) ) wp_send_json_error( $r->get_error_message() );
            wp_send_json_success([ 'results' => [$r], 'used_vision' => true ]);
        }

        // Multiple images — use text-based batch (faster) unless vision forced
        $gen = new SSEO_Alt_Generator();
        if ( $use_vision && count($ids) <= 10 ) {
            // Vision batch — one at a time but AI sees each image
            $r = $gen->generate_batch_vision( $ids );
            if ( is_wp_error($r) ) wp_send_json_error( $r->get_error_message() );
            wp_send_json_success([ 'results' => $r['results'], 'used_vision' => true ]);
        }

        // Text-based batch (fast, for bulk operations)
        $images = [];
        foreach($ids as $id){
            $src=wp_get_attachment_url($id); $title=get_the_title($id);
            $par=get_post_field('post_parent',$id); $pt=$par?get_the_title($par):'';
            $images[]=['attachment_id'=>$id,'title'=>$title,'filename'=>basename($src),'parent_title'=>$pt];
        }
        $batch = min((int)get_option('sseo_batch_size',10),20);
        $all = [];
        foreach(array_chunk($images,$batch) as $chunk){
            $r=$gen->generate($chunk);
            if(is_wp_error($r)) wp_send_json_error($r->get_error_message());
            foreach($r['results'] as $res){
                $idx=$res['imageIndex']??0;
                if(isset($chunk[$idx])) $all[]=['attachment_id'=>$chunk[$idx]['attachment_id'],'filename'=>$chunk[$idx]['filename'],'alts'=>$res['alts']];
            }
        }
        wp_send_json_success(['results'=>$all, 'used_vision' => false]);
    }

    public function apply_alt() {
        $this->v();
        (new SSEO_Alt_Generator)->apply((int)$_POST['attachment_id'], sanitize_text_field(wp_unslash($_POST['alt_text']??'')));
        wp_send_json_success('Applied!');
    }

    public function bulk_alts() {
        $this->v();
        $ids = array_map('intval',(array)($_POST['image_ids']??[]));
        $auto = ($_POST['auto_apply']??'')=='true';
        $_POST['image_ids'] = $ids;
        // Trigger generate then auto-apply
        $gen = new SSEO_Alt_Generator();
        $images = [];
        foreach($ids as $id){
            $src=wp_get_attachment_url($id);
            $images[]=['attachment_id'=>$id,'title'=>get_the_title($id),'filename'=>basename($src),'parent_title'=>get_post_field('post_parent',$id)?get_the_title(get_post_field('post_parent',$id)):''];
        }
        $batch = min((int)get_option('sseo_batch_size',10),20);
        $all = [];
        foreach(array_chunk($images,$batch) as $chunk){
            $r=$gen->generate($chunk);
            if(is_wp_error($r)) wp_send_json_error($r->get_error_message());
            foreach($r['results'] as $res){
                $idx=$res['imageIndex']??0;
                if(isset($chunk[$idx])){
                    $alt=$res['alts'][0]['text']??'';
                    if($auto&&$alt) $gen->apply($chunk[$idx]['attachment_id'],$alt);
                    $all[]=['attachment_id'=>$chunk[$idx]['attachment_id'],'filename'=>$chunk[$idx]['filename'],'alt_applied'=>$auto?$alt:'','alts'=>$res['alts']];
                }
            }
            $delay=(int)get_option('sseo_rate_limit_delay',2); if($delay>0)sleep($delay);
        }
        wp_send_json_success(['results'=>$all,'auto_apply'=>$auto]);
    }

    // ─── Titles ──────────────
    public function scan_titles() { $this->v(); wp_send_json_success((new SSEO_Title_Optimizer)->scan()); }
    public function optimize_title() {
        $this->v();
        $r=(new SSEO_Title_Optimizer)->optimize((int)$_POST['post_id']);
        is_wp_error($r)?wp_send_json_error($r->get_error_message()):wp_send_json_success($r);
    }
    public function apply_title() {
        $this->v();
        (new SSEO_Title_Optimizer)->apply((int)$_POST['post_id'], sanitize_text_field(wp_unslash($_POST['title']??'')));
        wp_send_json_success('Applied!');
    }

    public function bulk_fix_titles() {
        $this->v();
        $opt = new SSEO_Title_Optimizer();
        $issues = $opt->scan();
        $brand = get_option( 'sseo_brand_name', get_bloginfo( 'name' ) );
        $fixed = 0;
        foreach ( $issues as $t ) {
            $pid = $t['post_id'];
            $title = $t['title'];
            $issue = $t['issue'];
            $new_title = $title;
            if ( $issue === 'too_long' ) {
                $clean = preg_replace( '/\s*[|:]+\s*' . preg_quote( $brand, '/' ) . '.*$/i', '', $title );
                $clean = preg_replace( '/\s*[|:]+\s*Wall to Wall.*$/i', '', $clean );
                $clean = trim( wp_strip_all_tags( $clean ) );
                if ( mb_strlen( $clean ) > 55 ) {
                    $clean = mb_substr( $clean, 0, 55 );
                    $clean = preg_replace( '/\s+\S*$/', '', $clean );
                }
                $new_title = $clean;
            } elseif ( $issue === 'too_short' || $issue === 'missing' ) {
                $post_title = get_the_title( $pid );
                $suffix = ' | ' . $brand;
                $new_title = ( mb_strlen( $post_title . $suffix ) <= 60 ) ? $post_title . $suffix : $post_title;
            }
            if ( $new_title !== $title && mb_strlen( $new_title ) >= 10 ) {
                $opt->apply( $pid, $new_title );
                $fixed++;
            }
        }
        wp_send_json_success( array( 'fixed' => $fixed, 'total' => count( $issues ) ) );
    }

    // ─── H1 ──────────────
    public function scan_h1() { $this->v(); wp_send_json_success((new SSEO_H1_Checker)->scan()); }
    public function suggest_h1() {
        $this->v();
        $r=(new SSEO_H1_Checker)->suggest((int)$_POST['post_id']);
        is_wp_error($r)?wp_send_json_error($r->get_error_message()):wp_send_json_success($r);
    }

    public function apply_h1() {
        $this->v();
        $h1 = sanitize_text_field( wp_unslash( $_POST['h1'] ?? '' ) );
        $r = (new SSEO_H1_Checker)->apply( (int) $_POST['post_id'], $h1 );
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    public function bulk_fix_h1() {
        $this->v();
        $checker = new SSEO_H1_Checker();
        $issues = $checker->scan();
        $fixed = 0;
        foreach ( $issues as $x ) {
            $pid = $x['post_id'];
            $issue = $x['issue'];
            $post = get_post( $pid );
            if ( ! $post ) continue;
            if ( $issue === 'missing' ) {
                $h1_tag = '<h1>' . esc_html( $post->post_title ) . '</h1>';
                $updated = $h1_tag . "\n" . $post->post_content;
                wp_update_post( array( 'ID' => $pid, 'post_content' => $updated ) );
                $fixed++;
            } elseif ( $issue === 'multiple' ) {
                $content = $post->post_content;
                $cnt = 0;
                $content = preg_replace_callback( '/<h1([^>]*)>(.*?)<\/h1>/is', function( $m ) use ( &$cnt ) {
                    $cnt++;
                    return ( $cnt === 1 ) ? $m[0] : '<h2' . $m[1] . '>' . $m[2] . '</h2>';
                }, $content );
                wp_update_post( array( 'ID' => $pid, 'post_content' => $content ) );
                $fixed++;
            }
        }
        wp_send_json_success( array( 'fixed' => $fixed, 'total' => count( $issues ) ) );
    }

    public function thin_ignore() {
        $this->v();
        $post_id = (int) $_POST['post_id'];
        $ignored = get_option( 'sseo_thin_ignored', array() );
        if ( ! in_array( $post_id, $ignored ) ) {
            $ignored[] = $post_id;
            update_option( 'sseo_thin_ignored', $ignored );
        }
        wp_send_json_success( array( 'ignored_count' => count( $ignored ) ) );
    }

    public function bulk_auto_ignore() {
        $this->v();
        $types = get_option( 'sseo_post_types', array( 'post', 'page' ) );
        $posts = get_posts( array( 'post_type' => $types, 'post_status' => 'publish', 'numberposts' => -1 ) );
        $ignored = get_option( 'sseo_thin_ignored', array() );
        $count = 0;
        foreach ( $posts as $p ) {
            if ( in_array( $p->ID, $ignored ) ) continue;
            $path = wp_parse_url( get_permalink( $p->ID ), PHP_URL_PATH );
            $tl = strtolower( $p->post_title );
            $dominated = false;
            if ( strpos( $path, '/gallery/' ) !== false || preg_match( '/gallery$/i', $p->post_name ) ) {
                $dominated = true;
            } elseif ( preg_match( '/\b(award|houzz|angie|certainteed|nari|nahb|celebrates|nominated|earns|wins|donates|sponsors|volunteers|super service|best of|before and after)\b/i', $tl ) ) {
                $dominated = true;
            } elseif ( preg_match( '/\b(have plans|need plans|get started|tax|online payment|check out)\b/i', $tl ) ) {
                $dominated = true;
            }
            if ( $dominated ) {
                $ignored[] = $p->ID;
                $count++;
            }
        }
        update_option( 'sseo_thin_ignored', array_values( array_unique( $ignored ) ) );
        wp_send_json_success( array( 'count' => $count, 'total_ignored' => count( $ignored ) ) );
    }

    // ─── Broken Links ──────────────
    public function scan_broken() { $this->v(); wp_send_json_success((new SSEO_Broken_Links)->scan()); }

    // ─── Thin Content ──────────────
    public function scan_thin() { $this->v(); wp_send_json_success(['pages'=>(new SSEO_Thin_Content)->scan(),'stats'=>(new SSEO_Thin_Content)->get_stats()]); }

    // ─── Redirects ──────────────
    public function get_redirects() { $this->v(); wp_send_json_success((new SSEO_Redirect_Manager)->get_all()); }
    public function add_redirect() {
        $this->v();
        $r=(new SSEO_Redirect_Manager)->add($_POST['source']??'',$_POST['target']??'',(int)($_POST['type']??301));
        is_wp_error($r)?wp_send_json_error($r->get_error_message()):wp_send_json_success(['id'=>$r]);
    }
    public function delete_redirect() { $this->v(); (new SSEO_Redirect_Manager)->delete((int)$_POST['id']); wp_send_json_success('Deleted.'); }

    // ─── Schema ──────────────
    public function save_schema() {
        $this->v();
        if(isset($_POST['schema_enabled'])) update_option('sseo_schema_enabled',(int)$_POST['schema_enabled']);
        if(isset($_POST['og_enabled'])) update_option('sseo_og_enabled',(int)$_POST['og_enabled']);
        wp_send_json_success('Saved.');
    }

    public function schema_validate() {
        $this->v();
        $sg = new SSEO_Schema_Generator();
        wp_send_json_success($sg->validate_site());
    }

    // ─── Cleanup Published Pages ──────────────
    public function cleanup_published() {
        $this->v();
        $posts = get_posts(["post_type"=>["post","page"],"post_status"=>"publish","numberposts"=>-1]);
        $cleaned = 0;
        foreach ($posts as $p) {
            $original = $p->post_content;
            $clean = SSEO_Content_Generator::clean_for_publish($original);
            if ($clean !== $original) {
                wp_update_post(["ID"=>$p->ID,"post_content"=>$clean]);
                $cleaned++;
            }
        }
        wp_send_json_success(["cleaned"=>$cleaned,"total_scanned"=>count($posts)]);
    }

    // ─── Schema Bulk Preview ──────────────
    public function schema_bulk_preview() {
        $this->v();
        $pages = get_posts(['post_type'=>['page','post'],'post_status'=>'publish','numberposts'=>-1]);
        $preview = [];
        $front_id = (int) get_option('page_on_front');

        foreach ($pages as $p) {
            $path = wp_parse_url(get_permalink($p->ID), PHP_URL_PATH) ?: '';
            $slug = $p->post_name;
            $schemas = [];
            $already = [];

            // Check what's already applied
            if (get_post_meta($p->ID, '_sseo_is_service_page', true)) $already[] = 'Service';
            if (get_post_meta($p->ID, '_sseo_local_schema', true)) $already[] = 'LocalBusiness';

            // What WILL be applied
            $is_service = (
                strpos($path, '/services/') !== false ||
                strpos($path, '/what-we-do/') !== false ||
                strpos($path, '/service/') !== false
            );
            if ($is_service && !in_array('Service', $already)) {
                $schemas[] = 'Service';
            }

            $is_local = (
                $p->ID === $front_id ||
                in_array($slug, ['contact','contact-us','about','about-us'])
            );
            if ($is_local && !in_array('LocalBusiness', $already)) {
                $schemas[] = 'LocalBusiness';
            }

            // BreadcrumbList is sitewide for all singular pages — always on
            $has_breadcrumb = true;

            // Only include pages that have schema (existing or new)
            if (!empty($schemas) || !empty($already) || $is_service || $is_local) {
                $preview[] = [
                    'post_id'    => $p->ID,
                    'title'      => $p->post_title,
                    'url'        => $path,
                    'post_type'  => $p->post_type,
                    'existing'   => $already,
                    'new'        => $schemas,
                    'breadcrumb' => $has_breadcrumb,
                ];
            }
        }

        // Also show all /services/ and /what-we-do/ pages that already have schema
        // Plus count totals
        $service_new = 0; $local_new = 0; $service_existing = 0; $local_existing = 0;
        $all_pages = [];
        foreach ($pages as $p) {
            $path = wp_parse_url(get_permalink($p->ID), PHP_URL_PATH) ?: '';
            $slug = $p->post_name;
            $existing = [];
            $new_schemas = [];

            if (get_post_meta($p->ID, '_sseo_is_service_page', true)) { $existing[] = 'Service'; $service_existing++; }
            if (get_post_meta($p->ID, '_sseo_local_schema', true)) { $existing[] = 'LocalBusiness'; $local_existing++; }

            $is_service = strpos($path, '/services/') !== false || strpos($path, '/what-we-do/') !== false || strpos($path, '/service/') !== false;
            $is_local = $p->ID === $front_id || in_array($slug, ['contact','contact-us','about','about-us']);

            if ($is_service && !in_array('Service', $existing)) { $new_schemas[] = 'Service'; $service_new++; }
            if ($is_local && !in_array('LocalBusiness', $existing)) { $new_schemas[] = 'LocalBusiness'; $local_new++; }

            if (!empty($existing) || !empty($new_schemas)) {
                $all_pages[] = [
                    'post_id'   => $p->ID,
                    'title'     => $p->post_title,
                    'url'       => $path,
                    'post_type' => $p->post_type,
                    'existing'  => $existing,
                    'new'       => $new_schemas,
                ];
            }
        }

        wp_send_json_success([
            'pages'             => $all_pages,
            'total_scanned'     => count($pages),
            'service_existing'  => $service_existing,
            'service_new'       => $service_new,
            'local_existing'    => $local_existing,
            'local_new'         => $local_new,
            'breadcrumb'        => 'sitewide (all pages)',
        ]);
    }

    // ─── Schema Bulk Apply ──────────────
    public function schema_bulk_apply() {
        $this->v();
        // 1. Enable schema globally
        update_option('sseo_schema_enabled', 1);
        update_option('sseo_og_enabled', 1);

        // 2. Find and tag all service pages
        $service_count = 0;
        $local_count = 0;
        $pages = get_posts(['post_type'=>'page','post_status'=>'publish','numberposts'=>-1]);
        foreach ($pages as $p) {
            $path = wp_parse_url(get_permalink($p->ID), PHP_URL_PATH) ?: '';
            $slug = $p->post_name;

            // Tag service pages
            if (strpos($path, '/services/') !== false || strpos($path, '/what-we-do/') !== false || strpos($path, '/service/') !== false) {
                if (!get_post_meta($p->ID, '_sseo_is_service_page', true)) {
                    update_post_meta($p->ID, '_sseo_is_service_page', 1);
                    $service_count++;
                }
            }

            // Tag homepage and contact for LocalBusiness
            if ($p->ID == get_option('page_on_front') || in_array($slug, ['contact','contact-us','about','about-us'])) {
                if (!get_post_meta($p->ID, '_sseo_local_schema', true)) {
                    update_post_meta($p->ID, '_sseo_local_schema', 1);
                    $local_count++;
                }
            }
        }

        wp_send_json_success([
            'service_pages_tagged' => $service_count,
            'local_pages_tagged'   => $local_count,
            'total_pages_scanned'  => count($pages),
            'schema_enabled'       => true,
            'og_enabled'           => true,
        ]);
    }

    // ─── Content Expand In-Place ──────────────
    public function content_expand() {
        $this->v();
        $orig = $this->maybe_override_provider();
        $gen = new SSEO_Content_Generator();
        $r = $gen->expand_inplace(
            (int) $_POST['post_id'],
            (int) ($_POST['target_words'] ?? 800),
            sanitize_text_field($_POST['keywords'] ?? ''),
            ($_POST['add_internal_links'] ?? 'true') === 'true',
            sanitize_text_field($_POST['mode'] ?? 'full')
        );
        $this->restore_provider($orig);
        if (!is_wp_error($r) && ($_POST['add_testimonials'] ?? '') === 'true') {
            $r['content'] = $this->inject_testimonials($r['content'], $_POST);
        }
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    public function find_matching_service() {
        $this->v();
        $post_id = (int) ($_POST['post_id'] ?? 0);
        $post = get_post($post_id);
        if (!$post) wp_send_json_error('Post not found.');

        // Extract keywords from the page title and slug
        $title = strtolower($post->post_title);
        $slug = $post->post_name;

        // Get all published pages
        $pages = get_posts(['post_type'=>'page','post_status'=>'publish','numberposts'=>-1]);
        $best_match = '';
        $best_score = 0;

        // Keywords to match from the title
        $stop_words = ['the','a','an','in','of','and','for','our','we','do','what','services','service','work'];
        $title_words = array_diff(preg_split('/[\s\-_]+/', $title), $stop_words);
        $slug_words = array_diff(explode('-', $slug), $stop_words);
        $keywords = array_unique(array_merge($title_words, $slug_words));

        foreach ($pages as $p) {
            // Skip self
            if ($p->ID === $post_id) continue;

            $p_path = wp_parse_url(get_permalink($p->ID), PHP_URL_PATH) ?: '';
            $p_title = strtolower($p->post_title);
            $p_slug = $p->post_name;

            // Prefer pages under /services/
            $is_service = (strpos($p_path, '/services/') !== false);

            // Score based on keyword matches in title and slug
            $score = 0;
            foreach ($keywords as $kw) {
                if (strlen($kw) < 3) continue;
                if (strpos($p_title, $kw) !== false) $score += 2;
                if (strpos($p_slug, $kw) !== false) $score += 2;
            }

            // Bonus for being under /services/
            if ($is_service) $score += 3;

            if ($score > $best_score) {
                $best_score = $score;
                $best_match = $p_path;
            }
        }

        wp_send_json_success([
            'service_url' => $best_match ?: '/services/',
            'score' => $best_score,
        ]);
    }

    public function clear_archive_intro() {
        $this->v();
        $post_id = (int) $_POST['post_id'];
        delete_post_meta($post_id, '_sseo_archive_intro');
        wp_send_json_success(['post_id' => $post_id, 'cleared' => true]);
    }

    public function content_apply_expand() {
        $this->v();
        $post_id = (int) $_POST['post_id'];
        $new_content = wp_unslash($_POST['content'] ?? '');
        if (!current_user_can('unfiltered_html')) {
            $new_content = wp_kses_post($new_content);
        }

        $post = get_post($post_id);
        if (!$post) wp_send_json_error('Post not found.');

        // Detect if this is the blog/posts page or a similar archive page
        $is_posts_page = ((int) get_option('page_for_posts') === $post_id);
        $is_archive = $is_posts_page || (isset($_POST['is_archive']) && $_POST['is_archive'] === 'true');

        if ($is_archive) {
            // Save as archive intro meta — rendered by loop_start hook
            update_post_meta($post_id, '_sseo_archive_intro', $new_content);
            $action = 'archive_intro';
            $total_words = str_word_count(wp_strip_all_tags($new_content));
        } else {
            // Regular page: APPEND new content below existing
            $combined = $post->post_content . "\n\n" . $new_content;

            // Strip AI template artifacts
            $combined = SSEO_Content_Generator::clean_for_publish($combined);

            $result = wp_update_post([
                'ID'           => $post_id,
                'post_content' => $combined,
            ]);
            if (is_wp_error($result)) wp_send_json_error($result->get_error_message());

            // Auto-set featured image
            (new SSEO_Content_Generator())->set_featured_from_content($post_id, $combined);

            $action = 'expanded';
            $total_words = str_word_count(wp_strip_all_tags($combined));
        }

        // Apply per-page schema if requested
        if (isset($_POST['service_schema']) && $_POST['service_schema'] === 'true') {
            SSEO_Schema_Generator::toggle_service_schema($post_id, true);
        }
        if (isset($_POST['local_schema']) && $_POST['local_schema'] === 'true') {
            SSEO_Schema_Generator::toggle_local_schema($post_id, true);
        }

        // Log
        global $wpdb;
        $wpdb->insert($wpdb->prefix . 'sseo_log', [
            'post_id'   => $post_id,
            'type'      => $is_archive ? 'archive_intro' : 'expand',
            'old_value' => str_word_count(wp_strip_all_tags($post->post_content)) . ' words',
            'new_value' => $total_words . ' words',
        ]);

        wp_send_json_success([
            'post_id'     => $post_id,
            'action'      => $action,
            'total_words'  => $total_words,
            'edit_url'     => get_edit_post_link($post_id, 'raw'),
            'permalink'    => get_permalink($post_id),
        ]);
    }

    // ─── llms.txt ──────────────
    public function save_llms() { $this->v(); update_option('sseo_llms_txt_content', wp_unslash($_POST['content']??'')); flush_rewrite_rules(); wp_send_json_success('Saved.'); }
    public function generate_llms() {
        $this->v();
        $r=(new SSEO_LLMS_Txt)->generate_ai();
        is_wp_error($r)?wp_send_json_error($r->get_error_message()):wp_send_json_success($r);
    }

    // ─── Log ──────────────
    public function get_log() {
        $this->v();
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sseo_log ORDER BY created_at DESC LIMIT 200");
        $log = [];
        foreach($rows as $r) $log[]=['id'=>$r->id,'post_id'=>$r->post_id,'post_title'=>get_the_title($r->post_id)?:'#'.$r->post_id,'type'=>$r->type,'old_value'=>$r->old_value,'new_value'=>$r->new_value,'tokens'=>$r->tokens_used,'date'=>$r->created_at];
        wp_send_json_success($log);
    }

    // ─── Content Generator ──────────────

    public function imgtitle_scan() {
        $this->v();
        $gen = new SSEO_Alt_Generator();
        $images = $gen->get_generic_titles(200,0);
        $total  = $gen->count_generic_titles();
        wp_send_json_success(['images'=>$images,'total'=>$total]);
    }

    public function imgtitle_generate() {
        $this->v();
        $gen = new SSEO_Alt_Generator();
        $r = $gen->generate_title_vision((int)$_POST['attachment_id'], ($_POST['append_brand']??'')=='true');
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    public function imgtitle_generate_batch() {
        $this->v();
        $gen = new SSEO_Alt_Generator();
        $ids = array_map('intval',(array)($_POST['ids']??[]));
        $r = $gen->generate_titles_batch($ids, ($_POST['append_brand']??'')=='true');
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    public function imgtitle_apply() {
        $this->v();
        $gen = new SSEO_Alt_Generator();
        $gen->apply_title((int)$_POST['attachment_id'], sanitize_text_field(wp_unslash($_POST['title']??'')));
        wp_send_json_success('Applied.');
    }

    public function imgtitle_bulk_auto() {
        $this->v();
        $gen = new SSEO_Alt_Generator();
        $ids = array_map('intval',(array)($_POST['ids']??[]));
        $r = $gen->bulk_auto_title($ids, ($_POST['append_brand']??'')=='true');
        wp_send_json_success($r);
    }

    public function get_recent_changes() {
        $this->v();
        global $wpdb;
        $type = sanitize_text_field($_POST['type'] ?? 'alt');
        $limit = min(50, (int)($_POST['limit'] ?? 30));
        $table = $wpdb->prefix . 'sseo_log';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'") !== $table) wp_send_json_success(['changes'=>[]]);
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT l.*, p.post_title as item_name, p.guid as item_url
             FROM {$table} l
             LEFT JOIN {$wpdb->posts} p ON l.post_id = p.ID
             WHERE l.type = %s
             ORDER BY l.created_at DESC LIMIT %d", $type, $limit
        ), ARRAY_A);
        // Add thumbnail for image types
        foreach ($rows as &$row) {
            if (in_array($type, ['alt','img_title'])) {
                $thumb = wp_get_attachment_image_src((int)$row['post_id'], 'thumbnail');
                $row['thumbnail'] = $thumb ? $thumb[0] : '';
            }
        }
        wp_send_json_success(['changes'=>$rows,'total'=>count($rows)]);
    }

    public function content_research() {
        $this->v();
        $gen = new SSEO_Content_Generator();
        $r = $gen->research(
            sanitize_text_field($_POST['topic']??''),
            sanitize_text_field($_POST['keywords']??''),
            sanitize_text_field($_POST['content_type']??'blog'),
            (int)($_POST['word_count']??1500),
            sanitize_textarea_field(wp_unslash($_POST['custom_prompt']??'')),
            sanitize_text_field($_POST['template']??''),
            sanitize_text_field($_POST['scope']??'local')
        );
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    public function content_generate() {
        $this->v();
        $orig = $this->maybe_override_provider();
        $gen = new SSEO_Content_Generator();
        $brief = null;
        if (!empty($_POST['brief'])) {
            $brief = json_decode(wp_unslash($_POST['brief']), true);
        }
        $r = $gen->generate_content(
            sanitize_text_field($_POST['topic']??''),
            sanitize_text_field($_POST['keywords']??''),
            sanitize_text_field($_POST['content_type']??'blog'),
            (int)($_POST['word_count']??1500),
            $brief,
            sanitize_text_field($_POST['tone']??''),
            sanitize_textarea_field(wp_unslash($_POST['custom_prompt']??'')),
            sanitize_text_field($_POST['template']??''),
            sanitize_text_field($_POST['scope']??'local'),
            ($_POST['add_internal_links']??'true') === 'true'
        );
        $this->restore_provider($orig);
        if (!is_wp_error($r) && ($_POST['add_testimonials']??'') === 'true') {
            $r['content'] = $this->inject_testimonials($r['content'], $_POST);
        }
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    public function content_enhance() {
        $this->v();
        $orig = $this->maybe_override_provider();
        $gen = new SSEO_Content_Generator();
        $r = $gen->enhance_content(
            (int)$_POST['post_id'],
            (int)($_POST['target_words']??800),
            sanitize_text_field($_POST['keywords']??''),
            sanitize_textarea_field(wp_unslash($_POST['custom_prompt']??'')),
            sanitize_text_field($_POST['template']??''),
            sanitize_text_field($_POST['scope']??'local'),
            ($_POST['add_internal_links']??'true') === 'true'
        );
        $this->restore_provider($orig);
        if (!is_wp_error($r) && ($_POST['add_testimonials']??'') === 'true') {
            $r['content'] = $this->inject_testimonials($r['content'], $_POST);
        }
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    public function content_apply_enhanced() {
        $this->v();
        $post_id = (int)$_POST['post_id'];
        $raw = wp_unslash( $_POST['content'] ?? '' );

        // Allow <style> and <script> for designed templates (admin only, already verified by v())
        if ( current_user_can('unfiltered_html') ) {
            $content = $raw; // Admin can save full HTML including style/script
        } else {
            $content = wp_kses_post( $raw );
        }

        if ( ! $post_id || ! $content ) wp_send_json_error('Missing post ID or content.');

        $old_content = get_post_field('post_content', $post_id);
        $old_wc = str_word_count( wp_strip_all_tags( $old_content ) );
        $new_wc = str_word_count( wp_strip_all_tags( $content ) );

        // Save version history (keep last 10 versions per post)
        $versions = get_post_meta($post_id, '_sseo_content_versions', true);
        if (!is_array($versions)) $versions = [];
        array_unshift($versions, [
            'content'    => $old_content,
            'word_count' => $old_wc,
            'date'       => current_time('mysql'),
            'label'      => 'Before edit (' . $old_wc . 'w)',
        ]);
        $versions = array_slice($versions, 0, 10);
        update_post_meta($post_id, '_sseo_content_versions', $versions);

        // Apply per-page schema if requested
        if ( isset($_POST['service_schema']) && $_POST['service_schema'] === 'true' ) {
            SSEO_Schema_Generator::toggle_service_schema( $post_id, true );
        }
        if ( isset($_POST['local_schema']) && $_POST['local_schema'] === 'true' ) {
            SSEO_Schema_Generator::toggle_local_schema( $post_id, true );
        }

        // Strip AI template artifacts before publishing
        $content = SSEO_Content_Generator::clean_for_publish($content);

        $result = wp_update_post([
            'ID'           => $post_id,
            'post_content' => $content,
        ]);
        if ( is_wp_error($result) ) wp_send_json_error($result->get_error_message());

        // Auto-set featured image from first image in content (if not already set)
        (new SSEO_Content_Generator())->set_featured_from_content($post_id, $content);

        global $wpdb;
        $wpdb->insert($wpdb->prefix.'sseo_log', [
            'post_id'   => $post_id,
            'type'      => 'enhance',
            'old_value' => $old_wc . ' words',
            'new_value' => $new_wc . ' words',
        ]);

        wp_send_json_success(['post_id'=>$post_id, 'old_words'=>$old_wc, 'new_words'=>$new_wc, 'versions_saved'=>count($versions)]);
    }

    public function content_versions() {
        $this->v();
        $post_id = (int)($_POST['post_id'] ?? 0);
        if (!$post_id) wp_send_json_error('No post ID.');
        $versions = get_post_meta($post_id, '_sseo_content_versions', true);
        if (!is_array($versions)) $versions = [];
        // Add word counts and previews
        $list = [];
        foreach ($versions as $i => $v) {
            $list[] = [
                'index'      => $i,
                'word_count' => $v['word_count'] ?? str_word_count(wp_strip_all_tags($v['content'] ?? '')),
                'date'       => $v['date'] ?? '',
                'label'      => $v['label'] ?? 'Version ' . ($i + 1),
                'preview'    => substr(wp_strip_all_tags($v['content'] ?? ''), 0, 150) . '...',
            ];
        }
        // Also include current version
        $current = get_post_field('post_content', $post_id);
        $current_wc = str_word_count(wp_strip_all_tags($current));
        wp_send_json_success(['current_words' => $current_wc, 'versions' => $list]);
    }

    public function content_revert() {
        $this->v();
        $post_id = (int)($_POST['post_id'] ?? 0);
        $version_idx = (int)($_POST['version_index'] ?? -1);
        if (!$post_id) wp_send_json_error('No post ID.');

        $versions = get_post_meta($post_id, '_sseo_content_versions', true);
        if (!is_array($versions) || !isset($versions[$version_idx])) wp_send_json_error('Version not found.');

        $old_content = $versions[$version_idx]['content'] ?? '';
        if (empty($old_content)) wp_send_json_error('Version content is empty.');

        // Save current as a new version before reverting
        $current = get_post_field('post_content', $post_id);
        $current_wc = str_word_count(wp_strip_all_tags($current));
        array_unshift($versions, [
            'content'    => $current,
            'word_count' => $current_wc,
            'date'       => current_time('mysql'),
            'label'      => 'Before revert (' . $current_wc . 'w)',
        ]);
        $versions = array_slice($versions, 0, 10);
        update_post_meta($post_id, '_sseo_content_versions', $versions);

        wp_update_post(['ID' => $post_id, 'post_content' => $old_content]);

        $reverted_wc = str_word_count(wp_strip_all_tags($old_content));
        wp_send_json_success(['post_id' => $post_id, 'reverted_words' => $reverted_wc]);
    }

    public function content_save_draft() {
        $this->v();
        $raw = wp_unslash($_POST['content']??'');
        $content = current_user_can('unfiltered_html') ? $raw : wp_kses_post($raw);
        $gen = new SSEO_Content_Generator();
        $r = $gen->save_as_draft(
            sanitize_text_field($_POST['title']??''),
            $content,
            sanitize_text_field($_POST['post_type']??'post'),
            sanitize_text_field($_POST['meta_desc']??''),
            sanitize_text_field($_POST['h1']??'')
        );
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    public function content_find_media() {
        $this->v();
        $gen = new SSEO_Content_Generator();
        $r = $gen->find_media_images( sanitize_text_field($_POST['search']??''), (int)($_POST['limit']??12) );
        wp_send_json_success($r);
    }

    public function content_browse_media() {
        $this->v();
        $gen = new SSEO_Content_Generator();
        $r = $gen->get_media_library( (int)($_POST['page']??1), 24, sanitize_text_field($_POST['search']??'') );
        wp_send_json_success($r);
    }

    // ─── Reports ──────────────

    public function report_snapshot() {
        $this->v();
        $rg = new SSEO_Report_Generator();
        $snap = $rg->take_snapshot('before');
        update_option('sseo_baseline_snapshot', $snap, false);
        update_option('sseo_baseline_date', current_time('mysql'));
        wp_send_json_success([
            'score'        => $snap['score'],
            'date'         => $snap['date'],
            'meta_missing' => $snap['meta_missing'],
            'meta_total'   => $snap['meta_total'],
            'alt_missing'  => $snap['alt_missing'],
            'title_issues' => $snap['title_issues_count'],
            'h1_issues'    => $snap['h1_issues_count'],
            'thin_pages'   => $snap['thin_stats']['thin'],
            'broken_links' => count($snap['broken_links']),
            'redirects'    => $snap['redirect_count'],
            'schema_on'    => $snap['schema_on'],
            'og_on'        => $snap['og_on'],
            'llms_exists'  => $snap['llms_exists'],
            'log_entries'  => count($snap['enhance_log']),
        ]);
    }

    public function report_snapshot_history() {
        $this->v();
        $baseline = get_option('sseo_baseline_snapshot');
        $date = get_option('sseo_baseline_date', '');
        if ($baseline && is_array($baseline)) {
            wp_send_json_success(['has_baseline'=>true, 'score'=>$baseline['score']??0, 'date'=>$date]);
        }
        // Try migrating old transient
        $old = get_transient('sseo_snapshot_before');
        if ($old && is_array($old) && isset($old['score'])) {
            update_option('sseo_baseline_snapshot', $old, false);
            update_option('sseo_baseline_date', $old['date'] ?? 'Earlier');
            wp_send_json_success(['has_baseline'=>true, 'score'=>$old['score'], 'date'=>$old['date']??'Earlier']);
        }
        wp_send_json_success(['has_baseline'=>false]);
    }

    public function report_set_snapshot() {
        $this->v();
        wp_send_json_success('Use Take Baseline instead.');
    }

    public function report_delete_snapshot() {
        $this->v();
        delete_option('sseo_baseline_snapshot');
        delete_option('sseo_baseline_date');
        wp_send_json_success('Baseline deleted.');
    }

    public function report_generate() {
        $this->v();
        $rg = new SSEO_Report_Generator();
        $before = get_option('sseo_baseline_snapshot');
        if (!$before || !is_array($before)) wp_send_json_error('No baseline snapshot found. Click "Set Baseline" first.');
        // Always take a fresh "after" scan
        $after = $rg->take_snapshot('after');
        $client = sanitize_text_field($_POST['client_name']??'');
        $r = $rg->generate_report($before, $after, $client);
        wp_send_json_success($r);
    }

    public function report_list() {
        $this->v();
        $rg = new SSEO_Report_Generator();
        wp_send_json_success($rg->get_reports_list());
    }

    public function report_delete() {
        $this->v();
        $rg = new SSEO_Report_Generator();
        $rg->delete_report(sanitize_text_field($_POST['id']??''));
        wp_send_json_success('Deleted.');
    }

    public function report_restore_baseline() {
        $this->v();
        $report_id = sanitize_text_field($_POST['report_id'] ?? '');
        $report = get_option('sseo_report_' . $report_id);
        if (!$report) wp_send_json_error('Report not found.');

        if (!empty($report['before_data']) && is_array($report['before_data'])) {
            // Full snapshot data available — restore it
            update_option('sseo_baseline_snapshot', $report['before_data'], false);
            update_option('sseo_baseline_date', $report['before_data']['date'] ?? $report['created_at'] ?? '');
            wp_send_json_success(['score' => $report['before_data']['score'] ?? $report['before_score'], 'date' => $report['before_data']['date'] ?? '']);
        } else {
            // Old report without full data — can't restore
            wp_send_json_error('This report was generated before v2.0.3 and does not contain full snapshot data. Future reports will always be restorable.');
        }
    }

    // ─── Image Optimizer ──────────────

    public function imgopt_scan() {
        $this->v();
        $opt = new SSEO_Image_Optimizer();
        wp_send_json_success( $opt->scan_all() );
    }

    public function imgopt_convert_webp() {
        $this->v();
        $opt = new SSEO_Image_Optimizer();
        $id = (int)($_POST['attachment_id']??0);
        $quality = (int)($_POST['quality']??80);
        $r = $opt->convert_to_webp( $id, $quality );
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    public function imgopt_batch_webp() {
        $this->v();
        $opt = new SSEO_Image_Optimizer();
        $ids = array_map('intval', (array)($_POST['ids']??[]));
        $quality = (int)($_POST['quality']??80);
        $r = $opt->batch_convert_webp( $ids, $quality );
        wp_send_json_success($r);
    }

    public function imgopt_fix_dims() {
        $this->v();
        $opt = new SSEO_Image_Optimizer();
        $r = $opt->fix_all_dimensions();
        wp_send_json_success($r);
    }

    public function imgopt_fix_lazy() {
        $this->v();
        $opt = new SSEO_Image_Optimizer();
        $r = $opt->fix_all_lazy();
        // Also enable runtime smart lazy
        update_option('sseo_smart_lazy', 1);
        wp_send_json_success($r);
    }

    public function imgopt_save_lcp() {
        $this->v();
        $enabled = (int)($_POST['enabled']??0);
        $url = esc_url_raw($_POST['lcp_url']??'');
        update_option('sseo_lcp_preload', $enabled);
        update_option('sseo_lcp_image_url', $url);
        // Also enable WebP serving if converting
        if (isset($_POST['serve_webp'])) update_option('sseo_serve_webp', (int)$_POST['serve_webp']);
        wp_send_json_success('Saved.');
    }

    public function imgopt_pagespeed() {
        $this->v();
        $opt = new SSEO_Image_Optimizer();
        $url = sanitize_url($_POST['url']??'');
        $strategy = sanitize_text_field($_POST['strategy']??'mobile');
        $r = $opt->check_pagespeed( $url, $strategy );
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    // ─── robots.txt ──────────────

    public function robots_get() { $this->v(); wp_send_json_success((new SSEO_Robots_Txt)->get_content()); }
    public function robots_save() { $this->v(); wp_send_json_success((new SSEO_Robots_Txt)->save(wp_unslash($_POST['content']??''))); }
    public function robots_scan() { $this->v(); wp_send_json_success((new SSEO_Robots_Txt)->scan_blocked()); }
    public function robots_generate() { $this->v(); wp_send_json_success(['content'=>(new SSEO_Robots_Txt)->generate_optimal()]); }

    // ─── Orphan Pages ──────────────

    public function orphans_scan() { $this->v(); wp_send_json_success((new SSEO_Orphan_Pages)->scan((int)($_POST['min_links']??3))); }
    public function orphans_suggest() {
        $this->v();
        wp_send_json_success((new SSEO_Orphan_Pages)->suggest_links_for((int)$_POST['post_id']));
    }
    public function orphans_inject() {
        $this->v();
        $r = (new SSEO_Orphan_Pages)->inject_link((int)$_POST['source_id'],(int)$_POST['target_id'],sanitize_text_field($_POST['anchor']??''));
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    // ─── Crawl Depth ──────────────

    public function crawl_analyze() { $this->v(); wp_send_json_success((new SSEO_Crawl_Depth)->analyze()); }
    public function crawl_add_related() {
        $this->v();
        $r = (new SSEO_Crawl_Depth)->add_related_section((int)$_POST['post_id'],(int)($_POST['count']??3));
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    // ─── Anchor Text ──────────────

    public function anchors_scan() { $this->v(); wp_send_json_success((new SSEO_Anchor_Text)->scan()); }
    public function anchors_ai_rewrite() {
        $this->v();
        $items = json_decode(wp_unslash($_POST['items']??'[]'),true);
        $r = (new SSEO_Anchor_Text)->ai_rewrite($items);
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }
    public function anchors_apply() {
        $this->v();
        $r = (new SSEO_Anchor_Text)->apply((int)$_POST['post_id'],wp_unslash($_POST['old_anchor']??''),sanitize_text_field(wp_unslash($_POST['new_anchor']??'')),wp_unslash($_POST['href']??''));
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    // ─── Redirect Chains ──────────────

    public function chains_scan() { $this->v(); wp_send_json_success((new SSEO_Redirect_Chains)->scan()); }
    public function chains_flatten() {
        $this->v();
        $r = (new SSEO_Redirect_Chains)->flatten((int)$_POST['id'],sanitize_text_field($_POST['final']??''));
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }
    public function chains_flatten_all() { $this->v(); wp_send_json_success((new SSEO_Redirect_Chains)->flatten_all()); }
    public function chains_fix_content() { $this->v(); wp_send_json_success((new SSEO_Redirect_Chains)->fix_content_links()); }

    // ─── Smart Internal Linker ──────────────

    public function linker_scan() {
        $this->v();
        wp_send_json_success((new SSEO_Internal_Linker)->scan());
    }

    public function linker_ai_scan() {
        $this->v();
        $r = (new SSEO_Internal_Linker)->ai_scan((int)($_POST['limit']??20));
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    public function linker_apply() {
        $this->v();
        $r = (new SSEO_Internal_Linker)->apply_link(
            (int)($_POST['source_id']??0),
            sanitize_text_field(wp_unslash($_POST['anchor']??'')),
            esc_url_raw($_POST['target_url']??'')
        );
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    public function linker_apply_bulk() {
        $this->v();
        $links = json_decode(wp_unslash($_POST['links']??'[]'), true);
        if (!is_array($links) || empty($links)) wp_send_json_error('No links to apply.');
        wp_send_json_success((new SSEO_Internal_Linker)->apply_bulk($links));
    }

    // ─── Audits ──────────────

    public function audit_run() {
        $this->v();
        $result = (new SSEO_SEO_Audit)->run();
        // Save to history
        $history = get_option('sseo_seo_audit_history', []);
        array_unshift($history, ['date'=>current_time('mysql'),'score'=>$result['overall_score'],'issues'=>$result['total_issues'],'critical'=>$result['critical'],'data'=>$result]);
        update_option('sseo_seo_audit_history', array_slice($history, 0, 20));
        wp_send_json_success($result);
    }

    public function local_audit_run() {
        $this->v();
        $result = (new SSEO_Local_Audit)->run();
        $history = get_option('sseo_local_audit_history', []);
        array_unshift($history, ['date'=>current_time('mysql'),'score'=>$result['overall_score'],'issues'=>$result['total_issues'],'critical'=>$result['critical'],'data'=>$result]);
        update_option('sseo_local_audit_history', array_slice($history, 0, 20));
        wp_send_json_success($result);
    }

    public function ai_audit_run() {
        $this->v();
        $audit = new SSEO_AI_Audit();
        $result = $audit->run();
        // Optionally run AI deep analysis
        $ai_tips = null;
        if (($_POST['include_ai']??'true') === 'true') {
            $ai_tips = $audit->run_ai_deep($result);
            if (!is_wp_error($ai_tips)) $result['ai_tips'] = $ai_tips;
        }
        $audit->save_to_history($result);
        wp_send_json_success($result);
    }

    public function ai_audit_cached() {
        $this->v();
        $type = sanitize_text_field($_POST['type'] ?? 'ai');
        switch ($type) {
            case 'seo':   $history = get_option('sseo_seo_audit_history', []); break;
            case 'local': $history = get_option('sseo_local_audit_history', []); break;
            default:      $history = (new SSEO_AI_Audit)->get_history(); break;
        }
        wp_send_json_success(['history'=>$history]);
    }

    // ─── Page Templates ──────────────

    public function template_list() {
        $this->v();
        wp_send_json_success(SSEO_Page_Templates::get_templates());
    }

    public function template_generate() {
        $this->v();
        $tmpl = new SSEO_Page_Templates();
        $r = $tmpl->generate(
            sanitize_text_field($_POST['template'] ?? ''),
            [
                'scope'        => sanitize_text_field($_POST['scope'] ?? 'local'),
                'topic'        => sanitize_text_field(wp_unslash($_POST['topic'] ?? '')),
                'keywords'     => sanitize_text_field(wp_unslash($_POST['keywords'] ?? '')),
                'city'         => sanitize_text_field(wp_unslash($_POST['city'] ?? '')),
                'custom_prompt'=> sanitize_textarea_field(wp_unslash($_POST['custom_prompt'] ?? '')),
                'word_count'   => (int)($_POST['word_count'] ?? 800),
            ]
        );
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    public function template_save() {
        $this->v();
        $raw_html = wp_unslash($_POST['html'] ?? '');
        $html = current_user_can('unfiltered_html') ? $raw_html : wp_kses_post($raw_html);
        $tmpl = new SSEO_Page_Templates();
        $data = [
            'html'     => $html,
            'title'    => sanitize_text_field(wp_unslash($_POST['title'] ?? '')),
            'meta'     => sanitize_text_field(wp_unslash($_POST['meta'] ?? '')),
            'template' => sanitize_text_field($_POST['template'] ?? ''),
            'scope'    => sanitize_text_field($_POST['scope'] ?? 'local'),
        ];
        $r = $tmpl->save_as_draft($data);
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    // ─── Template Engine ──────────────

    public function tpl_engine_list() {
        $this->v();
        wp_send_json_success(SSEO_Template_Engine::get_available());
    }

    public function tpl_engine_generate() {
        $this->v();
        $orig = $this->maybe_override_provider();
        $eng = new SSEO_Template_Engine();
        $r = $eng->generate(
            sanitize_text_field($_POST['template'] ?? 'service_page'),
            sanitize_text_field(wp_unslash($_POST['topic'] ?? '')),
            sanitize_text_field(wp_unslash($_POST['keywords'] ?? '')),
            sanitize_text_field($_POST['scope'] ?? 'local'),
            (int)($_POST['word_count'] ?? 1200),
            sanitize_textarea_field(wp_unslash($_POST['custom'] ?? ''))
        );
        $this->restore_provider($orig);
        if (!is_wp_error($r) && ($_POST['add_testimonials']??'') === 'true') {
            $r['html'] = $this->inject_testimonials($r['html'], $_POST);
        }
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    // ─── Testimonials ──────────────

    // ─── Per-Page Schema Toggle ──────────────
    public function toggle_page_schema() {
        $this->v();
        $post_id = (int) $_POST['post_id'];
        $type    = sanitize_text_field( $_POST['schema_type'] ?? 'service' ); // 'service' or 'local'
        $enable  = ( $_POST['enable'] ?? '1' ) === '1';
        $sg = new SSEO_Schema_Generator();
        if ( $type === 'local' ) {
            $r = SSEO_Schema_Generator::toggle_local_schema( $post_id, $enable );
        } else {
            $r = SSEO_Schema_Generator::toggle_service_schema( $post_id, $enable );
        }
        wp_send_json_success( $r );
    }

    public function get_page_schema() {
        $this->v();
        wp_send_json_success( SSEO_Schema_Generator::get_page_schema( (int) $_POST['post_id'] ) );
    }

    // ─── Google Review Link ──────────────
    // ─── Review Request Email ──────────────
    public function generate_review_email() {
        $this->v();
        $name = sanitize_text_field($_POST['customer_name'] ?? 'Customer');
        $project = sanitize_text_field($_POST['project_type'] ?? 'home improvement project');
        $brand = get_option('sseo_brand_name', get_bloginfo('name'));
        $phone = get_option('sseo_business_phone', '');
        $review_url = '';
        $place_id = get_option('sseo_google_place_id', '');
        if ($place_id) $review_url = 'https://search.google.com/local/writereview?placeid=' . $place_id;

        $api = new SSEO_API_Handler();
        $prompt = "Write a professional follow-up email from {$brand} to a customer named {$name} who just completed a {$project}. The email should:
- Thank them for choosing {$brand}
- Reference the specific project type ({$project})
- Politely ask them to leave a Google review
" . ($review_url ? "- Include this review link: {$review_url}" : '') . "
- Be warm, conversational, NOT corporate
- Phone: {$phone}
- Keep it under 150 words
- End with the owner/team name

Return ONLY a JSON object: {\"subject\": \"email subject line\", \"body\": \"email body text\"}
Do NOT use double quotes inside string values.";

        $r = $api->complete($prompt, 0.7, 2000);
        if (is_wp_error($r)) wp_send_json_error($r->get_error_message());

        $data = SSEO_API_Handler::parse_json($r['content']);
        if (is_wp_error($data)) {
            // Fallback: treat as plain text
            wp_send_json_success(['subject' => "Thank you for choosing {$brand}!", 'body' => trim($r['content'])]);
        }
        wp_send_json_success($data);
    }

    // ─── Review Response Generator ──────────────
    public function generate_review_response() {
        $this->v();
        $review = sanitize_textarea_field($_POST['review_text'] ?? '');
        $name = sanitize_text_field($_POST['customer_name'] ?? '');
        $rating = (int) ($_POST['rating'] ?? 5);
        $brand = get_option('sseo_brand_name', get_bloginfo('name'));

        if (empty($review)) wp_send_json_error('Review text is required.');

        $api = new SSEO_API_Handler();
        $tone = $rating >= 4 ? 'warm and grateful' : ($rating >= 3 ? 'professional and empathetic' : 'empathetic, apologetic, and solution-oriented');
        $prompt = "Write a {$tone} response from {$brand} to this customer review:

Customer: {$name}
Rating: {$rating}/5
Review: \"{$review}\"

Rules:
- Address the customer by first name if available
- Reference specific details from their review
- Be genuine and conversational, NOT corporate template language
- For positive reviews: thank them, mention the project, invite them back
- For negative reviews: apologize, show empathy, offer to make it right with a direct contact
- Include the brand name naturally
- Keep under 100 words
- Do NOT start with 'Dear' — start with 'Hi [Name]' or 'Thank you [Name]'

Return ONLY a JSON object: {\"response\": \"the response text\"}";

        $r = $api->complete($prompt, 0.7, 2000);
        if (is_wp_error($r)) wp_send_json_error($r->get_error_message());

        $data = SSEO_API_Handler::parse_json($r['content']);
        if (is_wp_error($data)) {
            wp_send_json_success(['response' => trim($r['content'])]);
        }
        wp_send_json_success($data);
    }

    public function get_review_link() {
        $this->v();
        $r = SSEO_Testimonials::get_review_link();
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    // ─── Testimonials ──────────────
    public function testimonials_fetch_google() {
        $this->v();
        $t = new SSEO_Testimonials();
        $r = $t->fetch_google_reviews();
        is_wp_error($r) ? wp_send_json_error($r->get_error_message()) : wp_send_json_success($r);
    }

    public function testimonials_add() {
        $this->v();
        $t = new SSEO_Testimonials();
        $count = $t->save_manual_review([
            'author'   => $_POST['author'] ?? '',
            'rating'   => $_POST['rating'] ?? 5,
            'text'     => $_POST['text'] ?? '',
            'location' => $_POST['location'] ?? '',
            'project'  => $_POST['project'] ?? '',
            'date'     => $_POST['date'] ?? '',
        ]);
        wp_send_json_success(['count' => $count]);
    }

    public function testimonials_delete() {
        $this->v();
        $t = new SSEO_Testimonials();
        $reviews = $t->delete_manual_review((int)($_POST['index'] ?? -1));
        wp_send_json_success(['reviews' => $reviews]);
    }

    public function testimonials_list() {
        $this->v();
        $t = new SSEO_Testimonials();
        $source = sanitize_text_field($_POST['source'] ?? 'all');
        $reviews = $t->get_all_reviews(50, $source);
        $google_reviews = get_option('sseo_google_reviews', []);
        $manual_reviews = $t->get_manual_reviews();
        wp_send_json_success([
            'reviews'       => $reviews,
            'google_count'  => count($google_reviews),
            'manual_count'  => count($manual_reviews),
            'rating'        => get_option('sseo_google_rating', ''),
            'total_reviews' => get_option('sseo_google_review_count', ''),
            'business_name' => get_option('sseo_google_business_name', ''),
            'google_url'    => get_option('sseo_google_business_url', ''),
            'last_fetched'  => get_option('sseo_google_reviews_fetched', ''),
        ]);
    }

    public function testimonials_get_widget() {
        $this->v();
        $t = new SSEO_Testimonials();
        $style = sanitize_text_field($_POST['style'] ?? 'cards');
        $count = (int)($_POST['count'] ?? 6);
        $source = sanitize_text_field($_POST['source'] ?? 'all');
        $cols = (int)($_POST['columns'] ?? 2);
        $min = (int)($_POST['min_rating'] ?? 4);

        $html = $t->generate_widget_html($style, $count, $source, $cols, $min);
        $shortcode = $t->get_shortcode($style, $count, $source, $cols, $min);
        wp_send_json_success(['html' => $html, 'shortcode' => $shortcode]);
    }

    public function testimonials_save_settings() {
        $this->v();
        if (isset($_POST['google_places_key'])) update_option('sseo_google_places_key', sanitize_text_field($_POST['google_places_key']));
        if (isset($_POST['google_place_id'])) update_option('sseo_google_place_id', sanitize_text_field($_POST['google_place_id']));
        wp_send_json_success('Saved.');
    }

    private function inject_testimonials( $content, $post_data ) {
        $style = sanitize_text_field($post_data['tm_style'] ?? 'cards');
        $count = (int)($post_data['tm_count'] ?? 3);
        $shortcode = '[sseo_testimonials style="' . $style . '" count="' . $count . '" source="all" columns="2" min_rating="4"]';

        $width = get_option('sseo_content_width', '1140');
        if (!$width) $width = '1140';

        $section = "\n" . '<div style="margin:44px auto;padding:0 20px;max-width:' . (int)$width . 'px">' . "\n";
        $section .= '<h2 style="font-size:26px;font-weight:700;margin:0 0 20px;padding-bottom:12px;color:#0f172a">What Our Customers Say</h2>' . "\n";
        $section .= $shortcode . "\n";
        $section .= '</div>' . "\n";

        // Search for the full-width CTA wrapper divs first, then fall back to inner CTA
        $cta_markers = ['class="sp-cta-wrap"', 'class="lp-cta-wrap"', 'class="au-cta-wrap"', 'class="fq-cta-wrap"',
                        'class="sp-cta"', 'class="lp-cta"', 'class="au-cta"', 'class="fq-cta"', 'class="bp-cta"'];
        $insert_pos = false;
        foreach ($cta_markers as $marker) {
            $pos = strrpos($content, $marker);
            if ($pos !== false) {
                // Find the opening <div that contains this class
                $search_back = substr($content, max(0, $pos - 50), 50);
                $div_pos = strrpos($search_back, '<div');
                if ($div_pos !== false) {
                    $insert_pos = max(0, $pos - 50) + $div_pos;
                } else {
                    $insert_pos = $pos;
                }
                break;
            }
        }

        if ($insert_pos !== false) {
            $content = substr($content, 0, $insert_pos) . $section . "\n" . substr($content, $insert_pos);
        } else {
            $last_div = strrpos($content, '</div>');
            if ($last_div !== false) {
                $content = substr($content, 0, $last_div) . $section . substr($content, $last_div);
            } else {
                $content .= $section;
            }
        }
        return $content;
    }
}
