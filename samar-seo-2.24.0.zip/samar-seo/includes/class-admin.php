<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Admin {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'menus' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'assets' ] );
        add_filter( 'plugin_action_links_' . SSEO_BASENAME, [ $this, 'links' ] );
        add_action( 'admin_init', [ $this, 'check_plugin_lock' ] );
        add_action( 'wp_ajax_sseo_unlock', [ $this, 'ajax_unlock' ] );

    }

    /**
     * Plugin-level password lock
     * Cookie-based: per browser, per device, resets on plugin update
     */
    public function check_plugin_lock() {
        $page = $_GET['page'] ?? '';
        if ( strpos($page, 'sseo') !== 0 ) return;

        // Stealth gate — the agency operator can unlock this browser with ?sseo_op=<connect secret>.
        // Otherwise, when stealth is on and the site is paired, a client typing a plugin URL is bounced
        // to the dashboard: no tool pages, no list of what the plugin does. REST (agency) is unaffected.
        if ( function_exists( 'sseo_stealth' ) ) {
            sseo_stealth_maybe_set_operator();
            if ( sseo_stealth() && function_exists( 'sseo_is_connected' ) && sseo_is_connected() && ! sseo_stealth_operator() ) {
                wp_safe_redirect( admin_url() );
                exit;
            }
        }

        // Gate 1 — not connected to an agency yet: show ONLY the pairing screen, nothing else.
        if ( function_exists('sseo_is_connected') && ! sseo_is_connected() ) {
            $this->render_pair_screen();
            exit;
        }

        // Gate 2 — connected + the agency enabled the lock: require the agency access password.
        $lock_enabled = get_option('sseo_lock_enabled', 0);
        if ( ! $lock_enabled ) return;

        // Build auth token: hash of (user_id + plugin_version + stored_password_hash)
        // This means: different browser = no cookie = locked
        // Plugin update = version changes = old cookie invalid = locked
        // Password change = stored hash changes = old cookie invalid = locked
        $stored_hash = get_option('sseo_plugin_password', '');
        if ( $stored_hash === '' ) return;
        $valid_token = $this->make_auth_token( $stored_hash );

        // Check cookie
        $cookie_name = 'sseo_auth';
        if ( isset($_COOKIE[$cookie_name]) && $_COOKIE[$cookie_name] === $valid_token ) {
            return; // Authenticated in this browser
        }

        // Handle unlock form submission
        if ( isset($_POST['sseo_plugin_unlock']) && wp_verify_nonce($_POST['_sseo_lock_nonce']??'','sseo_lock') ) {
            $input = $_POST['sseo_lock_pass'] ?? '';
            if ( wp_check_password($input, $stored_hash) ) {
                // Set cookie: 12 hours, this browser only, admin path
                setcookie( $cookie_name, $valid_token, time() + 12 * HOUR_IN_SECONDS, ADMIN_COOKIE_PATH, COOKIE_DOMAIN, is_ssl(), true );
                wp_redirect( admin_url('admin.php?page='.$page) );
                exit;
            }
            $this->render_lock_screen( true );
            exit;
        }

        $this->render_lock_screen( false );
        exit;
    }

    /**
     * Generate auth token tied to user + version + password
     * Any change to version or password invalidates all existing sessions
     */
    private function make_auth_token( $stored_hash ) {
        return wp_hash( get_current_user_id() . '|' . SSEO_VERSION . '|' . $stored_hash . '|sseo_lock_salt' );
    }

    private function render_lock_screen( $error = false ) {
        ?>
        <style>
        .sseo-lock-wrap{display:flex;align-items:center;justify-content:center;min-height:70vh}
        .sseo-lock{background:#fff;border-radius:20px;padding:48px;max-width:420px;width:100%;text-align:center;box-shadow:0 4px 24px rgba(0,0,0,.08);border:1px solid #e2e8f0}
        .sseo-lock-logo{width:64px;height:64px;border-radius:16px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:30px;font-weight:900;display:flex;align-items:center;justify-content:center;margin:0 auto 20px}
        .sseo-lock h2{font-size:22px;font-weight:700;color:#1e293b;margin-bottom:6px}
        .sseo-lock p{font-size:14px;color:#64748b;margin-bottom:24px}
        .sseo-lock input[type=password]{width:100%;padding:14px 16px;border:2px solid #e2e8f0;border-radius:10px;font-size:16px;text-align:center;letter-spacing:2px;margin-bottom:12px;outline:none;box-sizing:border-box}
        .sseo-lock input:focus{border-color:#6366f1;box-shadow:0 0 0 3px rgba(99,102,241,.15)}
        .sseo-lock button{width:100%;padding:14px;border:none;border-radius:10px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:15px;font-weight:600;cursor:pointer}
        .sseo-lock button:hover{opacity:.9}
        .sseo-lock-err{background:#fef2f2;border:1px solid #fca5a5;color:#dc2626;padding:10px;border-radius:8px;font-size:13px;margin-bottom:16px}
        .sseo-lock-footer{margin-top:20px;font-size:11px;color:#94a3b8}
        .sseo-lock-ver{font-size:10px;color:#cbd5e1;margin-top:6px}
        </style>
        <div class="sseo-lock-wrap">
            <div class="sseo-lock">
                <div class="sseo-lock-logo"><?php echo esc_html( mb_strtoupper( mb_substr( sseo_product_name(), 0, 1 ) ) ); ?></div>
                <h2><?php echo esc_html( sseo_product_name() ); ?> — Locked</h2>
                <p>Enter the plugin password to continue.<br><span style="font-size:12px;color:#94a3b8">Password is required per browser and after each plugin update.</span></p>
                <?php if($error): ?><div class="sseo-lock-err">Incorrect password. Please try again.</div><?php endif; ?>
                <form method="post">
                    <?php wp_nonce_field('sseo_lock','_sseo_lock_nonce'); ?>
                    <input type="hidden" name="sseo_plugin_unlock" value="1">
                    <input type="password" name="sseo_lock_pass" placeholder="Enter plugin password" autofocus required>
                    <button type="submit">🔓 Unlock <?php echo esc_html( sseo_product_name() ); ?></button>
                </form>
                <div class="sseo-lock-footer">Powered by <?php echo esc_html( sseo_product_name() ); ?></div>
                <div class="sseo-lock-ver">v<?php echo SSEO_VERSION; ?></div>
            </div>
        </div>
        <?php
        exit;
    }

    private function render_pair_screen() {
        $ajax  = admin_url('admin-ajax.php');
        $nonce = wp_create_nonce('sseo_nonce');
        $name  = sseo_product_name();
        ?>
        <style>
        .sseo-lock-wrap{display:flex;align-items:center;justify-content:center;min-height:70vh}
        .sseo-lock{background:#fff;border-radius:20px;padding:48px;max-width:440px;width:100%;text-align:center;box-shadow:0 4px 24px rgba(0,0,0,.08);border:1px solid #e2e8f0}
        .sseo-lock-logo{width:64px;height:64px;border-radius:16px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:30px;font-weight:900;display:flex;align-items:center;justify-content:center;margin:0 auto 20px}
        .sseo-lock h2{font-size:22px;font-weight:700;color:#1e293b;margin-bottom:6px}
        .sseo-lock p{font-size:14px;color:#64748b;margin-bottom:24px}
        .sseo-lock input[type=text]{width:100%;padding:14px 16px;border:2px solid #e2e8f0;border-radius:10px;font-size:15px;text-align:center;margin-bottom:12px;outline:none;box-sizing:border-box}
        .sseo-lock input:focus{border-color:#6366f1;box-shadow:0 0 0 3px rgba(99,102,241,.15)}
        .sseo-lock button{width:100%;padding:14px;border:none;border-radius:10px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:15px;font-weight:600;cursor:pointer}
        .sseo-lock button:disabled{opacity:.6;cursor:default}
        .sseo-lock-err{background:#fef2f2;border:1px solid #fca5a5;color:#dc2626;padding:10px;border-radius:8px;font-size:13px;margin-bottom:16px}
        .sseo-lock-footer{margin-top:20px;font-size:11px;color:#94a3b8}
        .sseo-lock-ver{font-size:10px;color:#cbd5e1;margin-top:6px}
        .sseo-key-link{display:inline-block;margin-top:16px;font-size:13px;color:#6366f1;text-decoration:underline;cursor:pointer}
        .sseo-key-panel{margin-top:14px;text-align:left;border-top:1px solid #e2e8f0;padding-top:16px}
        .sseo-key-help,.sseo-key-note{font-size:12.5px!important;color:#64748b;margin-bottom:12px!important;line-height:1.5}
        .sseo-lock .sseo-key-btn{background:#fff;color:#4f46e5;border:2px solid #c7d2fe;padding:11px;font-size:14px}
        #sseo-key-text{width:100%;box-sizing:border-box;font:12px/1.4 ui-monospace,Menlo,Consolas,monospace;padding:10px;border:2px solid #e2e8f0;border-radius:10px;margin:12px 0 8px;word-break:break-all;resize:none}
        </style>
        <div class="sseo-lock-wrap">
            <div class="sseo-lock">
                <div class="sseo-lock-logo"><?php echo esc_html( mb_strtoupper( mb_substr( $name, 0, 1 ) ) ); ?></div>
                <h2>Connect <?php echo esc_html( $name ); ?></h2>
                <p>Enter the connection code from your agency to activate this plugin.</p>
                <div id="sseo-pair-err" class="sseo-lock-err" style="display:none"></div>
                <input type="text" id="sseo-pair-code" placeholder="Paste your connection code" autofocus>
                <button type="button" id="sseo-pair-go">Connect</button>
                <!-- [connection-key v1] fallback when the host blocks outgoing connections -->
                <a href="#" id="sseo-key-open" class="sseo-key-link">Code not working? Use a connection key instead</a>
                <div id="sseo-key-panel" class="sseo-key-panel" style="display:none">
                    <p class="sseo-key-help">Your agency connects to this site instead, so it works even when the hosting blocks outgoing connections. Create a key, copy it, and give it to your agency to paste into their dashboard.</p>
                    <button type="button" id="sseo-key-make" class="sseo-key-btn">Create connection key</button>
                    <div id="sseo-key-out" style="display:none">
                        <textarea id="sseo-key-text" readonly rows="4"></textarea>
                        <button type="button" id="sseo-key-copy" class="sseo-key-btn">Copy key</button>
                        <p class="sseo-key-note">Keep it private: it gives your agency access to manage this site. Creating a new key cancels the previous one. This page switches to connected by itself once your agency adds the key.</p>
                    </div>
                </div>
                <div class="sseo-lock-footer">This plugin is managed by your agency.</div>
                <div class="sseo-lock-ver">v<?php echo SSEO_VERSION; ?></div>
            </div>
        </div>
        <script>
        (function(){
            var btn=document.getElementById('sseo-pair-go'),inp=document.getElementById('sseo-pair-code'),err=document.getElementById('sseo-pair-err');
            function go(){
                var code=(inp.value||'').trim();
                if(!code){err.textContent='Enter your connection code.';err.style.display='block';return;}
                btn.textContent='Connecting...';btn.disabled=true;err.style.display='none';
                var body='action=sseo_connect_pair&nonce=<?php echo esc_js($nonce); ?>&code='+encodeURIComponent(code);
                fetch('<?php echo esc_js($ajax); ?>',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body})
                    .then(function(r){return r.json();})
                    .then(function(j){if(j&&j.success){location.reload();}else{var m=(j&&j.data)||'That code was not accepted.';err.textContent=m;err.style.display='block';btn.textContent='Connect';btn.disabled=false;if(/connection key/i.test(m)){openKey();}}})
                    .catch(function(){err.textContent='Could not reach the server. Try again.';err.style.display='block';btn.textContent='Connect';btn.disabled=false;});
            }
            btn.addEventListener('click',go);
            inp.addEventListener('keydown',function(e){if(e.key==='Enter')go();});
            // [connection-key v1]
            var panel=document.getElementById('sseo-key-panel'),make=document.getElementById('sseo-key-make'),out=document.getElementById('sseo-key-out'),txt=document.getElementById('sseo-key-text'),copy=document.getElementById('sseo-key-copy'),poll=null;
            function post(action){return fetch('<?php echo esc_js($ajax); ?>',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action='+action+'&nonce=<?php echo esc_js($nonce); ?>'}).then(function(r){return r.json();});}
            function openKey(){panel.style.display='block';document.getElementById('sseo-key-open').style.display='none';}
            document.getElementById('sseo-key-open').addEventListener('click',function(e){e.preventDefault();openKey();});
            make.addEventListener('click',function(){
                make.disabled=true;make.textContent='Creating...';
                post('sseo_connect_key').then(function(j){
                    make.disabled=false;make.textContent='Create a new key';
                    if(!j||!j.success){err.textContent=(j&&j.data)||'Could not create a key.';err.style.display='block';return;}
                    txt.value=j.data.key;out.style.display='block';txt.select();
                    if(!poll){poll=setInterval(function(){post('sseo_connect_status').then(function(s){if(s&&s.success&&s.data.connected){clearInterval(poll);location.reload();}}).catch(function(){});},5000);}
                }).catch(function(){make.disabled=false;make.textContent='Create connection key';err.textContent='Could not create a key. Reload the page and try again.';err.style.display='block';});
            });
            copy.addEventListener('click',function(){
                txt.select();
                var done=function(){copy.textContent='Copied';setTimeout(function(){copy.textContent='Copy key';},1500);};
                if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(txt.value).then(done,function(){document.execCommand('copy');done();});}else{document.execCommand('copy');done();}
            });
        })();
        </script>
        <?php
        exit;
    }

    public function ajax_unlock() {
        check_ajax_referer('sseo_nonce','nonce');
        $input = $_POST['password'] ?? '';
        $stored = get_option('sseo_plugin_password','');
        if ( wp_check_password($input, $stored) ) {
            $token = $this->make_auth_token($stored);
            setcookie('sseo_auth', $token, time()+12*HOUR_IN_SECONDS, ADMIN_COOKIE_PATH, COOKIE_DOMAIN, is_ssl(), true);
            wp_send_json_success('Unlocked.');
        }
        wp_send_json_error('Wrong password.');
    }

    public function menus() {
        // Stealth: show no SEO tool menu at all (unless an agency operator has revealed it this browser).
        if ( function_exists( 'sseo_stealth' ) && sseo_stealth() && ! sseo_stealth_operator() ) return;

        add_menu_page( sseo_product_name(), sseo_product_name(), 'manage_options', 'sseo', [ $this, 'page_dashboard' ], 'dashicons-shield', 79 );
        add_submenu_page( 'sseo', 'Dashboard', 'Dashboard', 'manage_options', 'sseo', [ $this, 'page_dashboard' ] );

        // ── AUDIT ──
        add_submenu_page( 'sseo', '', '<span class="sseo-menu-sep">AUDIT</span>', 'manage_options', '#sseo-sep0', '__return_false' );
        add_submenu_page( 'sseo', 'SEO Audit', '&nbsp;&nbsp;🔍 SEO Audit', 'manage_options', 'sseo-audit', [ $this, 'page_audit' ] );
        add_submenu_page( 'sseo', 'Local SEO Audit', '&nbsp;&nbsp;📍 Local SEO', 'manage_options', 'sseo-local-audit', [ $this, 'page_local_audit' ] );
        add_submenu_page( 'sseo', 'AI SEO Audit', '&nbsp;&nbsp;🤖 AI Compatibility', 'manage_options', 'sseo-ai-audit', [ $this, 'page_ai_audit' ] );

        // ── ON-PAGE SEO ──
        add_submenu_page( 'sseo', '', '<span class="sseo-menu-sep">ON-PAGE SEO</span>', 'manage_options', '#sseo-sep1', '__return_false' );
        add_submenu_page( 'sseo', 'Meta Descriptions', '&nbsp;&nbsp;Meta Descriptions', 'manage_options', 'sseo-meta', [ $this, 'page_meta' ] );
        add_submenu_page( 'sseo', 'Title Optimizer', '&nbsp;&nbsp;Title Optimizer', 'manage_options', 'sseo-titles', [ $this, 'page_titles' ] );
        add_submenu_page( 'sseo', 'H1 Checker', '&nbsp;&nbsp;H1 Checker', 'manage_options', 'sseo-h1', [ $this, 'page_h1' ] );
        add_submenu_page( 'sseo', 'Anchor Text', '&nbsp;&nbsp;Anchor Text', 'manage_options', 'sseo-anchors', [ $this, 'page_anchors' ] );
        add_submenu_page( 'sseo', 'Smart Internal Linker', '&nbsp;&nbsp;🔗 Smart Linker', 'manage_options', 'sseo-linker', [ $this, 'page_linker' ] );

        // ── IMAGES ──
        add_submenu_page( 'sseo', '', '<span class="sseo-menu-sep">IMAGES</span>', 'manage_options', '#sseo-sep2', '__return_false' );
        add_submenu_page( 'sseo', 'Image ALT Tags', '&nbsp;&nbsp;ALT Tags', 'manage_options', 'sseo-alts', [ $this, 'page_alts' ] );
        add_submenu_page( 'sseo', 'Image Titles', '&nbsp;&nbsp;Image Titles', 'manage_options', 'sseo-imgtitles', [ $this, 'page_imgtitles' ] );
        add_submenu_page( 'sseo', 'Image Optimizer', '&nbsp;&nbsp;Image Optimizer', 'manage_options', 'sseo-imgopt', [ $this, 'page_imgopt' ] );

        // ── TECHNICAL SEO ──
        add_submenu_page( 'sseo', '', '<span class="sseo-menu-sep">TECHNICAL SEO</span>', 'manage_options', '#sseo-sep3', '__return_false' );
        add_submenu_page( 'sseo', 'Broken Links', '&nbsp;&nbsp;Broken Links', 'manage_options', 'sseo-broken', [ $this, 'page_broken' ] );
        add_submenu_page( 'sseo', 'Redirects', '&nbsp;&nbsp;Redirects', 'manage_options', 'sseo-redirects', [ $this, 'page_redirects' ] );
        add_submenu_page( 'sseo', 'Redirect Chains', '&nbsp;&nbsp;Redirect Chains', 'manage_options', 'sseo-chains', [ $this, 'page_chains' ] );
        add_submenu_page( 'sseo', 'Orphan Pages', '&nbsp;&nbsp;Orphan Pages', 'manage_options', 'sseo-orphans', [ $this, 'page_orphans' ] );
        add_submenu_page( 'sseo', 'Crawl Depth', '&nbsp;&nbsp;Crawl Depth', 'manage_options', 'sseo-crawl', [ $this, 'page_crawl' ] );
        add_submenu_page( 'sseo', 'robots.txt', '&nbsp;&nbsp;robots.txt', 'manage_options', 'sseo-robots', [ $this, 'page_robots' ] );

        // ── CONTENT & AI ──
        add_submenu_page( 'sseo', '', '<span class="sseo-menu-sep">CONTENT & AI</span>', 'manage_options', '#sseo-sep4', '__return_false' );
        add_submenu_page( 'sseo', 'Content Generator', '&nbsp;&nbsp;Content Generator', 'manage_options', 'sseo-content', [ $this, 'page_content' ] );
        add_submenu_page( 'sseo', 'Page Templates', '&nbsp;&nbsp;Page Templates', 'manage_options', 'sseo-templates', [ $this, 'page_templates' ] );
        add_submenu_page( 'sseo', 'Thin Content', '&nbsp;&nbsp;Thin Content', 'manage_options', 'sseo-thin', [ $this, 'page_thin' ] );

        // ── MARKUP & SOCIAL ──
        add_submenu_page( 'sseo', '', '<span class="sseo-menu-sep">MARKUP & SOCIAL</span>', 'manage_options', '#sseo-sep5', '__return_false' );
        add_submenu_page( 'sseo', 'Schema & OG', '&nbsp;&nbsp;Schema & OG', 'manage_options', 'sseo-schema', [ $this, 'page_schema' ] );
        add_submenu_page( 'sseo', 'Testimonials', '&nbsp;&nbsp;⭐ Testimonials', 'manage_options', 'sseo-testimonials', [ $this, 'page_testimonials' ] );
        add_submenu_page( 'sseo', 'llms.txt', '&nbsp;&nbsp;llms.txt', 'manage_options', 'sseo-llms', [ $this, 'page_llms' ] );

        // ── TOOLS ──
        add_submenu_page( 'sseo', '', '<span class="sseo-menu-sep">TOOLS</span>', 'manage_options', '#sseo-sep6', '__return_false' );
        add_submenu_page( 'sseo', 'Reports', '&nbsp;&nbsp;Reports', 'manage_options', 'sseo-reports', [ $this, 'page_reports' ] );
        add_submenu_page( 'sseo', 'Activity Log', '&nbsp;&nbsp;Activity Log', 'manage_options', 'sseo-log', [ $this, 'page_log' ] );
        add_submenu_page( 'sseo', 'Settings', '&nbsp;&nbsp;⚙️ Settings', 'manage_options', 'sseo-settings', [ $this, 'page_settings' ] );
    }

    public function assets( $hook ) {
        if ( strpos($hook,'sseo') === false ) return;
        $ver = SSEO_VERSION . '.' . filemtime( SSEO_DIR . 'admin/js/admin.js' );
        wp_enqueue_style( 'sseo-admin', SSEO_URL.'admin/css/admin.css', [], $ver );
        wp_enqueue_script( 'sseo-admin', SSEO_URL.'admin/js/admin.js', ['jquery'], $ver, true );

        // Build available models list (only ones with API keys configured)
        $providers = [
            'openai'     => ['label'=>'OpenAI','model'=>get_option('sseo_openai_model','gpt-4o-mini'),'has_key'=>!empty(get_option('sseo_openai_api_key','')),'tier'=>'premium'],
            'anthropic'  => ['label'=>'Claude','model'=>get_option('sseo_anthropic_model','claude-sonnet-4-20250514'),'has_key'=>!empty(get_option('sseo_anthropic_api_key','')),'tier'=>'premium'],
            'azure'      => ['label'=>'Azure','model'=>get_option('sseo_azure_deployment',''),'has_key'=>!empty(get_option('sseo_azure_api_key','')),'tier'=>'premium'],
            'deepseek'   => ['label'=>'DeepSeek','model'=>get_option('sseo_deepseek_model','deepseek-chat'),'has_key'=>!empty(get_option('sseo_deepseek_api_key','')),'tier'=>'budget'],
            'groq'       => ['label'=>'Groq','model'=>get_option('sseo_groq_model','llama-3.3-70b-versatile'),'has_key'=>!empty(get_option('sseo_groq_api_key','')),'tier'=>'free'],
            'gemini'     => ['label'=>'Gemini','model'=>get_option('sseo_gemini_model','gemini-2.0-flash'),'has_key'=>!empty(get_option('sseo_gemini_api_key','')),'tier'=>'free'],
            'openrouter' => ['label'=>'OpenRouter','model'=>get_option('sseo_openrouter_model','meta-llama/llama-3.3-70b-instruct:free'),'has_key'=>!empty(get_option('sseo_openrouter_api_key','')),'tier'=>'free'],
            'platform'   => ['label'=>'Platform AI (agency)','model'=>'agency default','has_key'=>(function_exists('sseo_is_connected') && sseo_is_connected()),'tier'=>'platform'],
        ];

        wp_localize_script( 'sseo-admin', 'sseo', [
            'ajax_url'  => admin_url('admin-ajax.php'),
            'nonce'     => wp_create_nonce('sseo_nonce'),
            'provider'  => get_option('sseo_provider','openai'),
            'providers' => $providers,
        ]);
    }

    public function links( $links ) {
        array_unshift( $links, '<a href="'.admin_url('admin.php?page=sseo-settings').'">Settings</a>' );
        return $links;
    }

    // ─── Helper: get audit stats ──────────────────
    private function get_audit_data() {
        $seo     = new SSEO_SEO_Integration();
        $alt_gen = new SSEO_Alt_Generator();
        $types   = get_option('sseo_post_types',['post','page']);

        $total_posts = 0; $meta_missing = 0;
        foreach ( $types as $pt ) {
            $ids = get_posts(['post_type'=>$pt,'post_status'=>'publish','numberposts'=>-1,'fields'=>'ids']);
            $total_posts += count($ids);
            foreach ( $ids as $pid ) { if ( empty(trim($seo->get_meta($pid))) ) $meta_missing++; }
        }

        $alt_missing = $alt_gen->count_missing();
        $title_opt = new SSEO_Title_Optimizer();
        $title_issues = count( $title_opt->scan() );
        $h1_chk = new SSEO_H1_Checker();
        $h1_issues = count( $h1_chk->scan() );
        $redir = new SSEO_Redirect_Manager();
        $redirect_count = $redir->count();
        $schema_on = get_option('sseo_schema_enabled',1);
        $og_on = get_option('sseo_og_enabled',1);
        $llms = get_option('sseo_llms_txt_content','');
        $thin = new SSEO_Thin_Content();
        $thin_stats = $thin->get_stats();

        // Calculate SEO score (0-100)
        $score = 100;
        $deductions = [];
        if ( $meta_missing > 0 ) { $d = min(30, $meta_missing * 0.5); $score -= $d; $deductions[] = "Meta: -{$d}"; }
        if ( $alt_missing > 0 )  { $d = min(15, $alt_missing * 0.3); $score -= $d; $deductions[] = "ALT: -{$d}"; }
        if ( $title_issues > 0 ) { $d = min(10, $title_issues * 1); $score -= $d; }
        if ( $h1_issues > 0 )    { $d = min(10, $h1_issues * 1.5); $score -= $d; }
        if ( ! $schema_on )      { $score -= 5; }
        if ( ! $og_on )          { $score -= 3; }
        if ( empty($llms) )      { $score -= 5; }
        if ( $thin_stats['thin'] > 0 ) { $d = min(15, $thin_stats['thin'] * 0.5); $score -= $d; }
        $score = max( 0, round($score) );

        return compact('total_posts','meta_missing','alt_missing','title_issues','h1_issues','redirect_count','schema_on','og_on','llms','thin_stats','score');
    }

    // ─── Pages ────────────────────────────────────

    public function page_dashboard() {
        $d = $this->get_audit_data();
        $api = new SSEO_API_Handler();
        $seo = new SSEO_SEO_Integration();
        $sc = $d['score'];
        $grade = $sc >= 90 ? 'A' : ($sc >= 75 ? 'B' : ($sc >= 60 ? 'C' : ($sc >= 40 ? 'D' : 'F')));
        $gc = $sc >= 75 ? 'green' : ($sc >= 50 ? 'orange' : 'red');
        ?>
        <div class="wrap sseo-wrap">
        <div class="sseo-brand"><span class="sseo-logo"><?php echo esc_html( mb_strtoupper( mb_substr( sseo_product_name(), 0, 1 ) ) ); ?></span><h1><?php echo esc_html( sseo_product_name() ); ?></h1><span class="sseo-version">v<?php echo SSEO_VERSION; ?></span></div>
        <p class="sseo-sub">AI-Powered SEO Toolkit · <?php echo esc_html($api->get_provider_name().' / '.$api->get_model_name()); ?> · SEO Plugin: <?php echo esc_html($seo->get_name()); ?></p>

        <div class="sseo-score-row">
            <div class="sseo-score-ring <?php echo $gc; ?>">
                <div class="sseo-score-val"><?php echo $sc; ?></div>
                <div class="sseo-score-grade"><?php echo $grade; ?></div>
            </div>
            <div class="sseo-score-detail">
                <h2>Site SEO Health Score</h2>
                <p>This score updates in real-time as you fix issues. <?php echo $sc >= 75 ? 'Great job — keep optimizing!' : 'Fix the critical items below to improve your score.'; ?></p>
            </div>
        </div>

        <div class="sseo-grid-6">
            <div class="sseo-card sseo-card-stat <?php echo $d['meta_missing']?'red':'green'; ?>">
                <div class="sseo-card-num"><?php echo $d['meta_missing']; ?></div>
                <div class="sseo-card-label">Missing Meta Descriptions</div>
                <?php if($d['meta_missing']): ?><a href="<?php echo admin_url('admin.php?page=sseo-meta'); ?>" class="sseo-fix-link">Fix Now →</a><?php else: ?><span class="sseo-fixed">✓ All Done</span><?php endif; ?>
            </div>
            <div class="sseo-card sseo-card-stat <?php echo $d['alt_missing']?'red':'green'; ?>">
                <div class="sseo-card-num"><?php echo $d['alt_missing']; ?></div>
                <div class="sseo-card-label">Images Missing ALT Tags</div>
                <?php if($d['alt_missing']): ?><a href="<?php echo admin_url('admin.php?page=sseo-alts'); ?>" class="sseo-fix-link">Fix Now →</a><?php else: ?><span class="sseo-fixed">✓ All Done</span><?php endif; ?>
            </div>
            <div class="sseo-card sseo-card-stat <?php echo $d['title_issues']?'orange':'green'; ?>">
                <div class="sseo-card-num"><?php echo $d['title_issues']; ?></div>
                <div class="sseo-card-label">Title Tag Issues</div>
                <?php if($d['title_issues']): ?><a href="<?php echo admin_url('admin.php?page=sseo-titles'); ?>" class="sseo-fix-link">Fix Now →</a><?php else: ?><span class="sseo-fixed">✓ All Done</span><?php endif; ?>
            </div>
            <div class="sseo-card sseo-card-stat <?php echo $d['h1_issues']?'orange':'green'; ?>">
                <div class="sseo-card-num"><?php echo $d['h1_issues']; ?></div>
                <div class="sseo-card-label">H1 Tag Issues</div>
                <?php if($d['h1_issues']): ?><a href="<?php echo admin_url('admin.php?page=sseo-h1'); ?>" class="sseo-fix-link">Fix Now →</a><?php else: ?><span class="sseo-fixed">✓ All Done</span><?php endif; ?>
            </div>
            <div class="sseo-card sseo-card-stat <?php echo $d['thin_stats']['thin']?'orange':'green'; ?>">
                <div class="sseo-card-num"><?php echo $d['thin_stats']['thin']; ?></div>
                <div class="sseo-card-label">Thin Content Pages</div>
                <?php if($d['thin_stats']['thin']): ?><a href="<?php echo admin_url('admin.php?page=sseo-thin'); ?>" class="sseo-fix-link">Review →</a><?php else: ?><span class="sseo-fixed">✓ All Strong</span><?php endif; ?>
            </div>
            <div class="sseo-card sseo-card-stat">
                <div class="sseo-card-num"><?php echo $d['redirect_count']; ?></div>
                <div class="sseo-card-label">Active Redirects</div>
                <a href="<?php echo admin_url('admin.php?page=sseo-redirects'); ?>" class="sseo-fix-link">Manage →</a>
            </div>
        </div>

        <div class="sseo-grid-3">
            <div class="sseo-card">
                <h3>Schema Markup</h3>
                <p class="sseo-status-<?php echo $d['schema_on']?'on':'off'; ?>"><?php echo $d['schema_on']?'✓ Active':'✗ Disabled'; ?></p>
                <p class="sseo-muted">LocalBusiness · Article · FAQ · Breadcrumb</p>
                <a href="<?php echo admin_url('admin.php?page=sseo-schema'); ?>">Configure →</a>
            </div>
            <div class="sseo-card">
                <h3>Open Graph Tags</h3>
                <p class="sseo-status-<?php echo $d['og_on']?'on':'off'; ?>"><?php echo $d['og_on']?'✓ Active':'✗ Disabled'; ?></p>
                <p class="sseo-muted">OG Title · Description · Image · Twitter Card</p>
                <a href="<?php echo admin_url('admin.php?page=sseo-schema'); ?>">Configure →</a>
            </div>
            <div class="sseo-card">
                <h3>llms.txt</h3>
                <p class="sseo-status-<?php echo !empty($d['llms'])?'on':'off'; ?>"><?php echo !empty($d['llms'])?'✓ Published':'✗ Not Created'; ?></p>
                <p class="sseo-muted">AI model compatibility file</p>
                <a href="<?php echo admin_url('admin.php?page=sseo-llms'); ?>">Configure →</a>
            </div>
        </div>

        <div class="sseo-card">
            <h3>Audit Issues From Your SEO Report — Fixable By This Plugin</h3>
            <table class="sseo-table"><thead><tr><th>Issue</th><th>Count</th><th>Status</th><th>Tool</th></tr></thead><tbody>
            <tr><td>Missing meta descriptions</td><td><?php echo $d['meta_missing']; ?></td><td><?php echo $d['meta_missing']?'<span class="sseo-tag red">OPEN</span>':'<span class="sseo-tag green">FIXED</span>'; ?></td><td><a href="<?php echo admin_url('admin.php?page=sseo-meta'); ?>">Meta Descriptions</a></td></tr>
            <tr><td>Images missing ALT text</td><td><?php echo $d['alt_missing']; ?></td><td><?php echo $d['alt_missing']?'<span class="sseo-tag red">OPEN</span>':'<span class="sseo-tag green">FIXED</span>'; ?></td><td><a href="<?php echo admin_url('admin.php?page=sseo-alts'); ?>">Image ALT Tags</a></td></tr>
            <tr><td>Title tags too long/short</td><td><?php echo $d['title_issues']; ?></td><td><?php echo $d['title_issues']?'<span class="sseo-tag orange">OPEN</span>':'<span class="sseo-tag green">FIXED</span>'; ?></td><td><a href="<?php echo admin_url('admin.php?page=sseo-titles'); ?>">Title Optimizer</a></td></tr>
            <tr><td>Missing H1 tags</td><td><?php echo $d['h1_issues']; ?></td><td><?php echo $d['h1_issues']?'<span class="sseo-tag orange">OPEN</span>':'<span class="sseo-tag green">FIXED</span>'; ?></td><td><a href="<?php echo admin_url('admin.php?page=sseo-h1'); ?>">H1 Checker</a></td></tr>
            <tr><td>Broken internal links / 404s</td><td>—</td><td><span class="sseo-tag blue">SCAN</span></td><td><a href="<?php echo admin_url('admin.php?page=sseo-broken'); ?>">Broken Links</a></td></tr>
            <tr><td>No schema markup</td><td>—</td><td><?php echo $d['schema_on']?'<span class="sseo-tag green">ACTIVE</span>':'<span class="sseo-tag orange">OFF</span>'; ?></td><td><a href="<?php echo admin_url('admin.php?page=sseo-schema'); ?>">Schema & OG</a></td></tr>
            <tr><td>llms.txt returning 404</td><td>1</td><td><?php echo !empty($d['llms'])?'<span class="sseo-tag green">FIXED</span>':'<span class="sseo-tag red">OPEN</span>'; ?></td><td><a href="<?php echo admin_url('admin.php?page=sseo-llms'); ?>">llms.txt</a></td></tr>
            <tr><td>Thin content pages (&lt;300 words)</td><td><?php echo $d['thin_stats']['thin']; ?></td><td><?php echo $d['thin_stats']['thin']?'<span class="sseo-tag orange">REVIEW</span>':'<span class="sseo-tag green">GOOD</span>'; ?></td><td><a href="<?php echo admin_url('admin.php?page=sseo-thin'); ?>">Thin Content</a></td></tr>
            <tr><td>301 Redirects for broken URLs</td><td><?php echo $d['redirect_count']; ?> active</td><td><span class="sseo-tag blue">MANAGE</span></td><td><a href="<?php echo admin_url('admin.php?page=sseo-redirects'); ?>">Redirects</a></td></tr>
            </tbody></table>
        </div>
        </div>
        <?php
    }

    // ─── Subpages (shared template pattern) ──────

    public function page_meta() { $this->render_tool_page('meta','Meta Descriptions','Generate and apply AI-powered meta descriptions in bulk','edit-page'); }
    public function page_alts() { $this->render_tool_page('alts','Image ALT Tags','Find and fix images missing ALT text','format-image'); }
    public function page_imgtitles() { $this->render_tool_page('imgtitles','Image Titles','Fix generic image titles (IMG_4521, DSC_0034) with AI-generated descriptive titles','images-alt2'); }
    public function page_titles() { $this->render_tool_page('titles','Title Optimizer','Fix title tags that are too long, too short, or missing','editor-textcolor'); }
    public function page_h1() { $this->render_tool_page('h1','H1 Checker','Detect missing or duplicate H1 headings','heading'); }
    public function page_broken() { $this->render_tool_page('broken','Broken Link Scanner','Find dead internal links across your site','admin-links'); }
    public function page_audit() { $this->render_tool_page('audit','Full SEO Audit','Crawl every page, score 30+ technical factors — Semrush-level analysis','search'); }
    public function page_local_audit() { $this->render_tool_page('local_audit','Local SEO Audit','NAP consistency, GBP alignment, local keywords, citation scan','location-alt'); }
    public function page_ai_audit() { $this->render_tool_page('ai_audit','AI Compatibility Audit','Check if your site can be found, cited, and recommended by ChatGPT, Claude, Perplexity, and Gemini','superhero-alt'); }
    public function page_imgopt() { $this->render_tool_page('imgopt','Image Optimizer','WebP conversion, dimensions, lazy loading, LCP preload & PageSpeed check','performance'); }
    public function page_content() { $this->render_tool_page('content','Content Generator','AI-powered SEO content research, generation & enhancement with media library','edit-large'); }
    public function page_templates() { $this->render_tool_page('templates','Page Templates','Pre-built SEO page templates for Local & National businesses — works with any editor','layout'); }
    public function page_anchors() { $this->render_tool_page('anchors','Anchor Text Fixer','Find generic "click here" anchors and AI-rewrite with keyword-rich text','admin-links'); }
    public function page_linker() { $this->render_tool_page('linker','Smart Internal Linker','AI-powered multi-word phrase matching — finds and inserts relevant internal links across all pages','admin-links'); }
    public function page_orphans() { $this->render_tool_page('orphans','Orphan Pages','Find pages with few inbound links and auto-inject internal links','networking'); }
    public function page_crawl() { $this->render_tool_page('crawl','Crawl Depth Analyzer','Map click-depth from homepage, flatten deep pages','chart-area'); }
    public function page_chains() { $this->render_tool_page('chains','Redirect Chains','Detect A→B→C chains and flatten to A→C','randomize'); }
    public function page_robots() { $this->render_tool_page('robots','robots.txt Editor','Edit robots.txt, scan for blocked resources, generate optimal rules','shield-alt'); }
    public function page_reports() { $this->render_tool_page('reports','SEO Reports','Generate password-protected before/after reports for clients','analytics'); }
    public function page_thin() { $this->render_tool_page('thin','Thin Content Detector','Identify pages with low word count','media-text'); }
    public function page_redirects() { $this->render_tool_page('redirects','301 Redirect Manager','Manage URL redirects for broken links and 404s','randomize'); }
    public function page_schema() { $this->render_tool_page('schema','Schema & Open Graph','Manage structured data and social meta tags','admin-generic'); }
    public function page_testimonials() { $this->render_tool_page('testimonials_mgr','Testimonials Manager','Google reviews + manual reviews · 3 widget styles · embed anywhere','star-filled'); }
    public function page_llms() { $this->render_tool_page('llms','llms.txt Generator','Create and manage your AI compatibility file','media-document'); }
    public function page_log() { $this->render_tool_page('log','Activity Log','Track all AI-generated SEO changes','backup'); }
    public function page_settings() { $this->render_tool_page('settings','Settings','Configure AI provider, models, and preferences','admin-generic'); }

    private function render_tool_page( $slug, $title, $desc, $icon ) {
        ?>
        <div class="wrap sseo-wrap">
        <div class="sseo-brand"><span class="sseo-logo"><?php echo esc_html( mb_strtoupper( mb_substr( sseo_product_name(), 0, 1 ) ) ); ?></span><h1><?php echo esc_html( sseo_product_name() ); ?></h1></div>
        <div class="sseo-model-bar" id="sseo-model-bar"></div>
        <div class="sseo-page-header">
            <span class="dashicons dashicons-<?php echo $icon; ?>"></span>
            <div><h2><?php echo esc_html($title); ?></h2><p><?php echo esc_html($desc); ?></p></div>
        </div>
        <div id="sseo-tool-<?php echo $slug; ?>" class="sseo-tool-container" data-tool="<?php echo $slug; ?>">
            <div class="sseo-loading">Loading...</div>
        </div>
        </div>
        <?php
    }
}
