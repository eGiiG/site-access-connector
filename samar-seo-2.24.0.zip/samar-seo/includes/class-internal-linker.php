<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Smart Internal Linker — finds multi-word phrase opportunities
 * and inserts contextual internal links across all posts/pages
 */
class SSEO_Internal_Linker {

    /**
     * Scan all pages and find linking opportunities
     */
    public function scan() {
        $types = get_option('sseo_post_types', ['post','page']);
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>-1]);

        // Build a "link target" map: each page's title + key phrases
        $targets = [];
        foreach ($posts as $p) {
            $url   = get_permalink($p->ID);
            $title = $p->post_title;
            $text  = wp_strip_all_tags($p->post_content);

            // Extract H2/H3 headings as topic phrases
            $headings = [];
            if (preg_match_all('/<h[23][^>]*>(.*?)<\/h[23]>/is', $p->post_content, $hm)) {
                foreach ($hm[1] as $h) {
                    $clean = trim(wp_strip_all_tags($h));
                    if (strlen($clean) > 5 && strlen($clean) < 80) $headings[] = $clean;
                }
            }

            // Generate matching phrases from title (2-5 word combos)
            $title_phrases = $this->extract_phrases($title);

            $targets[$p->ID] = [
                'id'       => $p->ID,
                'title'    => $title,
                'url'      => $url,
                'path'     => wp_parse_url($url, PHP_URL_PATH),
                'type'     => $p->post_type,
                'headings' => $headings,
                'phrases'  => $title_phrases,
                'words'    => str_word_count($text),
            ];
        }

        // Scan each page's content for opportunities to link to OTHER pages
        $opportunities = [];
        foreach ($posts as $p) {
            $content = $p->post_content;
            $text    = wp_strip_all_tags($content);
            $text_lower = strtolower($text);

            // Get existing internal links to avoid duplicates
            $existing_links = $this->get_existing_links($content);

            foreach ($targets as $tid => $target) {
                if ($tid === $p->ID) continue; // Don't link to self
                if (in_array($target['url'], $existing_links)) continue; // Already linked

                // Check if this page's content mentions the target's phrases
                $best_match = null;
                $best_score = 0;

                // Check title phrases (2+ words)
                foreach ($target['phrases'] as $phrase) {
                    if (strlen($phrase) < 6) continue; // Skip very short
                    $phrase_lower = strtolower($phrase);
                    $pos = strpos($text_lower, $phrase_lower);
                    if ($pos !== false) {
                        $word_count = str_word_count($phrase);
                        $score = $word_count * 3; // More words = better match
                        if ($score > $best_score) {
                            $best_score = $score;
                            // Find the exact case from original text
                            $exact = substr($text, $pos, strlen($phrase));
                            $best_match = ['phrase'=>$exact,'score'=>$score,'words'=>$word_count,'source'=>'title'];
                        }
                    }
                }

                // Check heading phrases
                foreach ($target['headings'] as $heading) {
                    $heading_phrases = $this->extract_phrases($heading);
                    foreach ($heading_phrases as $phrase) {
                        if (strlen($phrase) < 6) continue;
                        $phrase_lower = strtolower($phrase);
                        $pos = strpos($text_lower, $phrase_lower);
                        if ($pos !== false) {
                            $word_count = str_word_count($phrase);
                            $score = $word_count * 2;
                            if ($score > $best_score) {
                                $best_score = $score;
                                $exact = substr($text, $pos, strlen($phrase));
                                $best_match = ['phrase'=>$exact,'score'=>$score,'words'=>$word_count,'source'=>'heading'];
                            }
                        }
                    }
                }

                if ($best_match && $best_score >= 4) { // At least 2-word match
                    $opportunities[] = [
                        'source_id'    => $p->ID,
                        'source_title' => $p->post_title,
                        'target_id'    => $tid,
                        'target_title' => $target['title'],
                        'target_url'   => $target['url'],
                        'anchor'       => $best_match['phrase'],
                        'score'        => $best_match['score'],
                        'word_count'   => $best_match['words'],
                        'match_source' => $best_match['source'],
                    ];
                }
            }
        }

        // Sort by score descending
        usort($opportunities, function($a, $b) { return $b['score'] - $a['score']; });

        // Deduplicate: max 3 links per source page, max 1 link to each target per source
        $filtered = [];
        $source_counts = [];
        $source_target_pairs = [];
        foreach ($opportunities as $opp) {
            $sk = $opp['source_id'];
            $pair = $sk . '->' . $opp['target_id'];
            if (isset($source_target_pairs[$pair])) continue;
            if (($source_counts[$sk] ?? 0) >= 5) continue;

            $filtered[] = $opp;
            $source_counts[$sk] = ($source_counts[$sk] ?? 0) + 1;
            $source_target_pairs[$pair] = true;
        }

        // Stats
        $pages_with_opps = count(array_unique(array_column($filtered, 'source_id')));

        return [
            'opportunities' => array_slice($filtered, 0, 100),
            'total'         => count($filtered),
            'pages_scanned' => count($posts),
            'pages_with_opportunities' => $pages_with_opps,
        ];
    }

    /**
     * AI-enhanced scan — uses AI to find semantic matches beyond exact phrases
     */
    public function ai_scan($limit = 20) {
        $types = get_option('sseo_post_types', ['post','page']);
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>-1]);

        // Build page list
        $page_list = '';
        foreach ($posts as $p) {
            $url = get_permalink($p->ID);
            $words = str_word_count(wp_strip_all_tags($p->post_content));
            $page_list .= "ID:{$p->ID} | {$p->post_title} | {$url} | {$words}w\n";
        }

        // Pick pages that need links (fewest internal links first)
        $needs_links = [];
        foreach ($posts as $p) {
            $existing = count($this->get_existing_links($p->post_content));
            $words = str_word_count(wp_strip_all_tags($p->post_content));
            if ($words > 100) {
                $needs_links[] = ['id'=>$p->ID,'title'=>$p->post_title,'existing_links'=>$existing,'words'=>$words,'content_preview'=>substr(wp_strip_all_tags($p->post_content),0,300)];
            }
        }
        usort($needs_links, function($a,$b){ return $a['existing_links'] - $b['existing_links']; });
        $needs_links = array_slice($needs_links, 0, $limit);

        $source_info = '';
        foreach ($needs_links as $nl) {
            $source_info .= "\n---\nSOURCE ID:{$nl['id']} \"{$nl['title']}\" ({$nl['existing_links']} existing links, {$nl['words']}w)\nContent preview: {$nl['content_preview']}\n";
        }

        $api = new SSEO_API_Handler();
        $prompt = "You are an SEO internal linking expert. Analyze these pages and suggest the best internal links.

ALL PAGES ON THE SITE:
{$page_list}

PAGES THAT NEED MORE INTERNAL LINKS:
{$source_info}

For each source page, suggest 2-4 internal links to other pages on the site.

CRITICAL RULES FOR ANCHOR TEXT:
- Use 2-5 word phrases that exist naturally in the source content
- NEVER use single words like \"floor\" or \"tips\" or \"here\"
- GOOD anchors: \"floor remodeling tips\", \"kitchen renovation cost\", \"bathroom design ideas\"
- BAD anchors: \"click here\", \"read more\", \"floor\", \"tips\", \"remodeling\"
- The anchor text MUST be a phrase that actually appears in the source page's content
- Choose the most descriptive, topic-relevant phrase

Return ONLY JSON (no markdown, no fences):
[
  {
    \"source_id\": 123,
    \"target_id\": 456,
    \"anchor\": \"multi-word phrase from source content\",
    \"reason\": \"brief explanation of relevance\"
  }
]";

        $r = $api->complete($prompt, 0.3);
        if (is_wp_error($r)) return $r;

        $parsed = SSEO_API_Handler::parse_json($r['content']);
        if (is_wp_error($parsed)) return $parsed;

        // Enrich with titles and URLs
        $post_map = [];
        foreach ($posts as $p) $post_map[$p->ID] = ['title'=>$p->post_title,'url'=>get_permalink($p->ID)];

        $results = [];
        foreach ($parsed as $suggestion) {
            $sid = (int)($suggestion['source_id'] ?? 0);
            $tid = (int)($suggestion['target_id'] ?? 0);
            if (!$sid || !$tid || !isset($post_map[$sid]) || !isset($post_map[$tid])) continue;

            $results[] = [
                'source_id'    => $sid,
                'source_title' => $post_map[$sid]['title'],
                'target_id'    => $tid,
                'target_title' => $post_map[$tid]['title'],
                'target_url'   => $post_map[$tid]['url'],
                'anchor'       => sanitize_text_field($suggestion['anchor'] ?? ''),
                'reason'       => sanitize_text_field($suggestion['reason'] ?? ''),
                'ai_suggested' => true,
            ];
        }

        return ['suggestions'=>$results,'tokens'=>$r['tokens']];
    }

    /**
     * Apply a single internal link
     */
    public function apply_link($source_id, $anchor, $target_url) {
        $post = get_post($source_id);
        if (!$post) return new WP_Error('no_post','Source page not found.');

        $content = $post->post_content;
        $anchor = trim($anchor);
        if (strlen($anchor) < 3) return new WP_Error('bad_anchor','Anchor text too short.');

        // Check if this exact link already exists
        if (strpos($content, 'href="' . $target_url . '"') !== false) {
            return new WP_Error('exists','This link already exists on this page.');
        }

        // Find the anchor text in content (case-insensitive but preserve original case)
        $pos = stripos(wp_strip_all_tags($content), $anchor);
        if ($pos === false) {
            // Try in HTML content directly
            $pos = stripos($content, $anchor);
        }

        // Replace first occurrence that's NOT already inside an <a> tag
        $link_tag = '<a href="' . esc_url($target_url) . '">' . esc_html($anchor) . '</a>';

        // Use regex to find the phrase NOT inside an existing link
        $pattern = '/(?<!["\'>])(' . preg_quote($anchor, '/') . ')(?![^<]*<\/a>)/i';
        $new_content = preg_replace($pattern, $link_tag, $content, 1, $count);

        if ($count === 0) {
            return new WP_Error('not_found','Could not find "' . $anchor . '" in the page content, or it is already linked.');
        }

        wp_update_post(['ID'=>$source_id,'post_content'=>$new_content]);

        // Log
        global $wpdb;
        $log_table = $wpdb->prefix . 'sseo_log';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$log_table}'") === $log_table) {
            $wpdb->insert($log_table, [
                'post_id'   => $source_id,
                'type'      => 'internal_link',
                'old_value' => $anchor,
                'new_value' => $target_url,
            ]);
        }

        return ['source_id'=>$source_id,'anchor'=>$anchor,'target_url'=>$target_url,'applied'=>true];
    }

    /**
     * Bulk apply multiple links
     */
    public function apply_bulk($links) {
        $results = [];
        foreach ($links as $link) {
            $r = $this->apply_link(
                (int)($link['source_id'] ?? 0),
                $link['anchor'] ?? '',
                $link['target_url'] ?? ''
            );
            $results[] = is_wp_error($r)
                ? ['source_id'=>$link['source_id']??0,'error'=>$r->get_error_message()]
                : $r;
        }
        $applied = count(array_filter($results, function($r){ return !isset($r['error']); }));
        return ['results'=>$results,'applied'=>$applied,'total'=>count($links)];
    }

    // ─── HELPERS ───

    private function extract_phrases($text) {
        // Remove common stop words and extract meaningful 2-5 word phrases
        $stop = ['a','an','the','of','in','on','at','to','for','and','or','with','by','from','is','are','was','were','be','been','this','that','it','its','our','your','we','they','you','how','what','which','why','when','where','who','do','does','did','has','have','had','can','will','would','should','could','may','might','shall','not','no','but','if','so','very','just','also','too','into','than','then','each','every','all','some','any','few','more','most','other','such','only','own','same','about','up','out','off','over','under','after','before','between','through','during','without','along','around','until','upon','within','among','across','behind','above','below','down','new','old','big','small','great','high','low','long','right','left','get','got','make','made','take','look','come','give','us','per','one','two','three','my','me','her','him','his','she','he','them','these','those','here','there','been','being','many','much','said','like','back','still','well','way','even','best','top','first','last','home','house','llc','inc','construction','wall','–','|','&','-'];

        $words = preg_split('/[\s,.\-–|&:;!?()\[\]"\'\/]+/', strtolower($text));
        $words = array_values(array_filter($words, function($w) use ($stop) {
            return strlen($w) > 2 && !in_array($w, $stop) && !is_numeric($w);
        }));

        $phrases = [];

        // Original full title (cleaned)
        $clean_title = trim(preg_replace('/\s*[\-–|]\s*.*$/', '', $text)); // Remove " - Brand Name" suffix
        if (str_word_count($clean_title) >= 2 && str_word_count($clean_title) <= 8) {
            $phrases[] = $clean_title;
        }

        // 2-word combinations
        for ($i = 0; $i < count($words) - 1; $i++) {
            $phrase = $words[$i] . ' ' . $words[$i+1];
            if (strlen($phrase) >= 6) $phrases[] = $phrase;
        }

        // 3-word combinations
        for ($i = 0; $i < count($words) - 2; $i++) {
            $phrase = $words[$i] . ' ' . $words[$i+1] . ' ' . $words[$i+2];
            if (strlen($phrase) >= 10) $phrases[] = $phrase;
        }

        // 4-word combinations
        for ($i = 0; $i < count($words) - 3; $i++) {
            $phrase = $words[$i] . ' ' . $words[$i+1] . ' ' . $words[$i+2] . ' ' . $words[$i+3];
            $phrases[] = $phrase;
        }

        return array_unique($phrases);
    }

    private function get_existing_links($content) {
        $links = [];
        if (preg_match_all('/href=["\']([^"\']+)["\']/i', $content, $m)) {
            $host = wp_parse_url(home_url('/'), PHP_URL_HOST);
            foreach ($m[1] as $href) {
                $h = wp_parse_url($href, PHP_URL_HOST);
                if (empty($h) || $h === $host) $links[] = $href;
            }
        }
        return $links;
    }
}
