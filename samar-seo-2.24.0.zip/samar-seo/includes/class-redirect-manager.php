<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Redirect_Manager {
    public function __construct() {
        add_action( 'template_redirect', [ $this, 'handle_redirect' ], 1 );
    }

    public function handle_redirect() {
        global $wpdb;
        $table = $wpdb->prefix . 'sseo_redirects';
        if ( $wpdb->get_var("SHOW TABLES LIKE '{$table}'") !== $table ) return;

        $path = $_SERVER['REQUEST_URI'] ?? '';
        $row  = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE source_url = %s OR source_url = %s LIMIT 1",
            $path, untrailingslashit( $path )
        ) );

        if ( $row ) {
            $wpdb->update( $table, ['hits' => $row->hits + 1], ['id' => $row->id] );
            wp_redirect( $row->target_url, (int) $row->type );
            exit;
        }
    }

    public function get_all() {
        global $wpdb;
        $table = $wpdb->prefix . 'sseo_redirects';
        return $wpdb->get_results("SELECT * FROM {$table} ORDER BY created_at DESC");
    }

    public function add( $source, $target, $type = 301 ) {
        global $wpdb;
        $source = '/' . ltrim( wp_parse_url($source, PHP_URL_PATH) ?: $source, '/' );
        $result = $wpdb->insert( $wpdb->prefix . 'sseo_redirects', [
            'source_url' => sanitize_text_field( $source ),
            'target_url' => esc_url_raw( $target ),
            'type'       => (int) $type,
        ] );
        return $result ? $wpdb->insert_id : new WP_Error( 'insert', 'Failed. Source may already exist.' );
    }

    public function delete( $id ) {
        global $wpdb;
        return $wpdb->delete( $wpdb->prefix . 'sseo_redirects', [ 'id' => (int) $id ] );
    }

    public function count() {
        global $wpdb;
        $table = $wpdb->prefix . 'sseo_redirects';
        if ( $wpdb->get_var("SHOW TABLES LIKE '{$table}'") !== $table ) return 0;
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
    }
}
