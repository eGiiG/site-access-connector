<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Title_Optimizer {
    private $api;
    public function __construct() { $this->api = new SSEO_API_Handler(); }

    public function scan() {
        $types = get_option( 'sseo_post_types', ['post','page'] );
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>-1,'fields'=>'ids']);
        $ignored = get_option( 'sseo_thin_ignored', [] );
        $issues = [];
        $seo = new SSEO_SEO_Integration();
        foreach ( $posts as $pid ) {
            if ( in_array( $pid, $ignored ) ) continue;
            $seo_title = $seo->get_title( $pid );
            $title = $seo_title ?: get_the_title( $pid );
            $len = mb_strlen( $title );
            $issue = '';
            if ( $len > 60 ) $issue = 'too_long';
            elseif ( $len < 30 && $len > 0 ) $issue = 'too_short';
            elseif ( empty( trim($title) ) ) $issue = 'missing';
            if ( $issue ) {
                $issues[] = [
                    'post_id'    => $pid,
                    'title'      => $title,
                    'seo_title'  => $seo_title,
                    'char_count' => $len,
                    'issue'      => $issue,
                    'permalink'  => get_permalink( $pid ),
                    'post_type'  => get_post_type( $pid ),
                ];
            }
        }
        return $issues;
    }

    public function optimize( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) return new WP_Error( 'no_post', 'Not found.' );
        $seo = new SSEO_SEO_Integration();
        $current = $seo->get_title( $post_id ) ?: $post->post_title;
        $brand = get_option( 'sseo_brand_name', '' );
        $loc   = get_option( 'sseo_target_location', '' );

        $prompt = "Optimize this SEO title tag. Current: \"{$current}\" ({mb_strlen($current)} chars)
Page content summary: " . wp_trim_words( wp_strip_all_tags($post->post_content), 100 ) . "
" . ($brand?"Brand: {$brand}\n":'') . ($loc?"Location: {$loc}\n":'') . "
Rules:
- MUST be 50-60 characters
- Include primary keyword + location if relevant
- Compelling for CTR
- Generate 3 options

Return ONLY JSON: [{\"title\":\"...\",\"charCount\":55,\"approach\":\"keyword-first\"}]
No markdown.";

        $r = $this->api->complete( $prompt );
        if ( is_wp_error($r) ) return $r;
        $p = SSEO_API_Handler::parse_json( $r['content'] );
        if ( is_wp_error($p) ) return $p;
        return [ 'titles'=>$p, 'tokens'=>$r['tokens'], 'post_id'=>$post_id, 'current'=>$current ];
    }

    public function apply( $post_id, $title ) {
        $post = get_post( $post_id );
        if ( ! $post ) return new WP_Error( 'no_post', 'Post not found.' );

        $seo = new SSEO_SEO_Integration();
        $old = $seo->get_title( $post_id ) ?: $post->post_title;

        $title = sanitize_text_field( $title );

        // 1. Update SEO meta title (for Yoast/RankMath/AIOSEO/standalone)
        $seo->set_title( $post_id, $title );

        // 2. Update the actual WP post_title, keeping slug (post_name) intact
        $result = wp_update_post([
            'ID'         => $post_id,
            'post_title' => $title,
            'post_name'  => $post->post_name, // pin slug — prevents WP from regenerating it
        ], true);

        if ( is_wp_error( $result ) ) return $result;

        // 3. Log the change
        global $wpdb;
        $wpdb->insert( $wpdb->prefix.'sseo_log', [
            'post_id'   => $post_id,
            'type'      => 'title',
            'old_value' => $old,
            'new_value' => $title,
        ]);

        return true;
    }
}
