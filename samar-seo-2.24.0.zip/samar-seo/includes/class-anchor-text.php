<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Anchor_Text {

    private $generic_patterns = [
        'click here', 'click this', 'go here', 'here', 'this link',
        'read more', 'read this', 'learn more', 'find out more', 'see more',
        'more info', 'more information', 'more details', 'details',
        'this page', 'this article', 'this post', 'link', 'visit',
        'check it out', 'check this out', 'see here', 'view more',
    ];

    /**
     * Scan all content for generic anchor text
     */
    public function scan() {
        $types = get_option( 'sseo_post_types', ['post','page'] );
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>-1]);
        $issues = [];

        foreach ( $posts as $p ) {
            if ( ! preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', $p->post_content, $matches, PREG_SET_ORDER ) ) {
                continue;
            }
            foreach ( $matches as $m ) {
                $href   = $m[1];
                $anchor = wp_strip_all_tags( $m[2] );
                $clean  = strtolower( trim( $anchor ) );

                if ( $this->is_generic( $clean ) ) {
                    // Try to find what the link points to
                    $target_title = '';
                    $target_id = url_to_postid( $href );
                    if ( $target_id ) $target_title = get_the_title( $target_id );

                    $issues[] = [
                        'post_id'       => $p->ID,
                        'post_title'    => $p->post_title,
                        'permalink'     => get_permalink($p->ID),
                        'anchor_text'   => $anchor,
                        'href'          => $href,
                        'target_title'  => $target_title,
                        'target_id'     => $target_id,
                        'full_tag'      => $m[0],
                    ];
                }
            }
        }

        return [
            'issues' => $issues,
            'total'  => count($issues),
        ];
    }

    /**
     * AI-rewrite a batch of generic anchors
     */
    public function ai_rewrite( $items ) {
        if ( empty($items) ) return new WP_Error('empty','No items.');
        $api   = new SSEO_API_Handler();
        $brand = get_option('sseo_brand_name','');
        $loc   = get_option('sseo_target_location','');

        $list = '';
        foreach ( $items as $i => $item ) {
            $list .= ($i+1) . ". Current anchor: \"{$item['anchor_text']}\" → Links to: \"{$item['href']}\"";
            if ( ! empty($item['target_title']) ) $list .= " (page: \"{$item['target_title']}\")";
            $list .= " — Found on page: \"{$item['post_title']}\"\n";
        }

        $prompt = "You are an SEO expert. Rewrite these generic anchor texts to be keyword-rich and descriptive.

{$list}

" . ($brand?"Brand: {$brand}\n":'') . ($loc?"Location: {$loc}\n":'') . "

Rules:
- Each new anchor must describe what the linked page is about
- Use relevant keywords naturally (service name, location, topic)
- Keep anchors 3-8 words, natural reading
- DON'T use generic words like 'click here', 'read more', 'learn more'
- Each anchor should be unique

Return ONLY JSON array:
[{\"index\":0,\"old\":\"click here\",\"new\":\"kitchen remodeling services in Maryland\",\"reason\":\"Descriptive of target page content\"}]
No markdown, no fences.";

        $r = $api->complete($prompt);
        if (is_wp_error($r)) return $r;
        $p = SSEO_API_Handler::parse_json($r['content']);
        if (is_wp_error($p)) return $p;
        return ['suggestions'=>$p,'tokens'=>$r['tokens']];
    }

    /**
     * Apply a single anchor text replacement
     */
    public function apply( $post_id, $old_anchor, $new_anchor, $href ) {
        $post = get_post($post_id);
        if (!$post) return new WP_Error('no_post','Not found.');

        $old_anchor = wp_strip_all_tags($old_anchor);
        $new_anchor = sanitize_text_field($new_anchor);

        // Build regex to find the specific link
        $pattern = '/(<a\s[^>]*href=["\']' . preg_quote($href,'/') . '["\'][^>]*>)' . preg_quote($old_anchor,'/') . '(<\/a>)/is';
        $replacement = '$1' . esc_html($new_anchor) . '$2';

        $content = preg_replace($pattern, $replacement, $post->post_content, 1, $count);

        if ($count === 0) {
            // Fallback: simpler match
            $old_tag = '>' . $old_anchor . '</a>';
            $new_tag = '>' . esc_html($new_anchor) . '</a>';
            $content = str_replace($old_tag, $new_tag, $post->post_content);
            if ($content === $post->post_content) return new WP_Error('not_found','Anchor not found in content.');
        }

        wp_update_post(['ID'=>$post_id,'post_content'=>$content]);

        global $wpdb;
        $wpdb->insert($wpdb->prefix.'sseo_log',['post_id'=>$post_id,'type'=>'anchor','old_value'=>$old_anchor,'new_value'=>$new_anchor]);

        return ['post_id'=>$post_id,'old'=>$old_anchor,'new'=>$new_anchor];
    }

    private function is_generic( $text ) {
        $text = strtolower(trim($text));
        if (strlen($text) < 2) return false;
        foreach ( $this->generic_patterns as $pat ) {
            if ( $text === $pat || strpos($text, $pat) !== false ) return true;
        }
        // Also flag single-word anchors that aren't proper nouns
        if ( str_word_count($text) === 1 && strlen($text) < 12 && !preg_match('/[A-Z]/', $text) ) {
            if ( in_array($text, ['here','link','this','more','visit','page','site','website','go']) ) return true;
        }
        return false;
    }
}
