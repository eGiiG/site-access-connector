<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Redirect_Chains {

    /**
     * Scan for redirect chains (A→B→C) in our redirect table
     * and also in actual HTTP responses
     */
    public function scan() {
        global $wpdb;
        $table = $wpdb->prefix . 'sseo_redirects';
        if ( $wpdb->get_var("SHOW TABLES LIKE '{$table}'") !== $table ) return ['chains'=>[],'total'=>0];

        $redirects = $wpdb->get_results("SELECT * FROM {$table}", ARRAY_A);
        $chains = [];

        // Build source→target map
        $map = [];
        foreach ( $redirects as $r ) {
            $map[ $r['source_url'] ] = $r;
        }

        // Detect chains: if a target is also a source, that's a chain
        foreach ( $redirects as $r ) {
            $target = $r['target_url'];
            $target_path = wp_parse_url($target, PHP_URL_PATH) ?: $target;

            // Check if target is also a source
            if ( isset($map[$target_path]) || isset($map[$target]) ) {
                $chain = [ $r['source_url'] ];
                $current = $target_path;
                $depth = 0;

                while ( (isset($map[$current]) || isset($map[rtrim($current,'/')])) && $depth < 10 ) {
                    $next = $map[$current] ?? $map[rtrim($current,'/')] ?? null;
                    if (!$next) break;
                    $chain[] = $current;
                    $current = wp_parse_url($next['target_url'], PHP_URL_PATH) ?: $next['target_url'];
                    $depth++;
                }
                $chain[] = $current; // Final destination

                if ( count($chain) > 2 ) {
                    $chains[] = [
                        'id'          => $r['id'],
                        'chain'       => $chain,
                        'chain_length'=> count($chain) - 1,
                        'source'      => $chain[0],
                        'final'       => end($chain),
                        'current_target' => $r['target_url'],
                    ];
                }
            }
        }

        // Also check external redirects via HTTP (common WP redirects)
        $types = get_option('sseo_post_types',['post','page']);
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>100]);
        $http_chains = [];

        foreach ($posts as $p) {
            if (!preg_match_all('/href=["\']([^"\']+)["\']/i', $p->post_content, $matches)) continue;
            $site_host = wp_parse_url(home_url(), PHP_URL_HOST);

            foreach ($matches[1] as $href) {
                $parsed = wp_parse_url($href);
                $host = $parsed['host'] ?? '';
                if (!empty($host) && $host !== $site_host && $host !== 'www.'.$site_host) continue;

                $path = $parsed['path'] ?? $href;
                if (isset($map[$path])) {
                    $target = $map[$path];
                    $target_path2 = wp_parse_url($target['target_url'], PHP_URL_PATH) ?: $target['target_url'];
                    if (isset($map[$target_path2])) {
                        // This is a chain being linked to from content
                        $http_chains[] = [
                            'found_in_post' => $p->ID,
                            'post_title'    => $p->post_title,
                            'linked_url'    => $href,
                            'chain_start'   => $path,
                        ];
                    }
                }
            }
        }

        return [
            'chains'      => $chains,
            'http_refs'   => $http_chains,
            'total'       => count($chains),
            'total_refs'  => count($http_chains),
        ];
    }

    /**
     * Flatten a chain: update the redirect to point directly to final destination
     */
    public function flatten( $redirect_id, $final_url ) {
        global $wpdb;
        $table = $wpdb->prefix . 'sseo_redirects';

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d",$redirect_id), ARRAY_A);
        if (!$row) return new WP_Error('not_found','Redirect not found.');

        $old_target = $row['target_url'];
        $wpdb->update($table, ['target_url' => sanitize_text_field($final_url)], ['id' => $redirect_id]);

        // Log
        $wpdb->insert($wpdb->prefix.'sseo_log',[
            'post_id'   => 0,
            'type'      => 'chain',
            'old_value' => $row['source_url'] . ' → ' . $old_target,
            'new_value' => $row['source_url'] . ' → ' . $final_url,
        ]);

        return ['id'=>$redirect_id,'source'=>$row['source_url'],'old_target'=>$old_target,'new_target'=>$final_url];
    }

    /**
     * Flatten ALL detected chains at once
     */
    public function flatten_all() {
        $scan = $this->scan();
        $fixed = 0;
        foreach ($scan['chains'] as $chain) {
            $r = $this->flatten($chain['id'], $chain['final']);
            if (!is_wp_error($r)) $fixed++;
        }
        return ['total_chains'=>$scan['total'],'fixed'=>$fixed];
    }

    /**
     * Update content links that point to redirect sources → point to final URL instead
     */
    public function fix_content_links() {
        global $wpdb;
        $table = $wpdb->prefix . 'sseo_redirects';
        $redirects = $wpdb->get_results("SELECT source_url, target_url FROM {$table}", ARRAY_A);
        if (empty($redirects)) return ['posts_fixed'=>0,'links_fixed'=>0];

        $types = get_option('sseo_post_types',['post','page']);
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>-1]);
        $posts_fixed = 0;
        $links_fixed = 0;

        foreach ($posts as $p) {
            $content = $p->post_content;
            $changed = false;
            foreach ($redirects as $r) {
                $source_url = home_url($r['source_url']);
                $target_url = $r['target_url'];
                // Make target absolute if relative
                if (strpos($target_url,'http') !== 0) $target_url = home_url($target_url);

                // Replace in href attributes
                if (strpos($content, $r['source_url']) !== false) {
                    $content = str_replace(
                        ['href="'.$r['source_url'].'"', "href='".$r['source_url']."'",
                         'href="'.$source_url.'"', "href='".$source_url."'"],
                        ['href="'.$target_url.'"', "href='".$target_url."'",
                         'href="'.$target_url.'"', "href='".$target_url."'"],
                        $content
                    );
                    $changed = true;
                    $links_fixed++;
                }
            }
            if ($changed) {
                wp_update_post(['ID'=>$p->ID,'post_content'=>$content]);
                $posts_fixed++;
            }
        }
        return ['posts_fixed'=>$posts_fixed,'links_fixed'=>$links_fixed];
    }
}
