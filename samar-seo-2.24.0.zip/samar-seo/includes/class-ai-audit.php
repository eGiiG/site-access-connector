<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * AI Compatibility Audit — checks if the site is optimized to be found,
 * cited, and recommended by AI chatbots (ChatGPT, Claude, Perplexity, Gemini)
 */
class SSEO_AI_Audit {

    private $ai_bots = [
        'GPTBot'       => ['name'=>'ChatGPT/OpenAI','ua'=>'GPTBot','url'=>'https://openai.com/gptbot'],
        'ClaudeBot'    => ['name'=>'Claude/Anthropic','ua'=>'ClaudeBot','url'=>'https://anthropic.com'],
        'PerplexityBot'=> ['name'=>'Perplexity','ua'=>'PerplexityBot','url'=>'https://perplexity.ai'],
        'GoogleOther'  => ['name'=>'Gemini/Google','ua'=>'Google-Extended','url'=>'https://google.com'],
        'Bytespider'   => ['name'=>'TikTok/ByteDance','ua'=>'Bytespider','url'=>''],
        'CCBot'        => ['name'=>'Common Crawl','ua'=>'CCBot','url'=>'https://commoncrawl.org'],
    ];

    public function run() {
        $checks   = [];
        $issues   = [];
        $score    = 0;
        $max      = 0;

        // ═══ 1. llms.txt FILE ═══
        $llms = get_option('sseo_llms_txt_content','');
        $llms_score = 0; $llms_max = 25;
        $max += $llms_max;

        if (!empty($llms)) {
            $llms_score += 10;
            $llms_len = strlen($llms);
            if ($llms_len > 200) $llms_score += 5;
            if ($llms_len > 500) $llms_score += 5;
            if (preg_match('/services|products|about/i', $llms)) $llms_score += 3;
            if (preg_match('/phone|email|address|contact/i', $llms)) $llms_score += 2;
        } else {
            $issues[] = ['cat'=>'llms.txt','sev'=>'critical','msg'=>'No llms.txt file — AI models cannot learn about your business','fix'=>'sseo-llms','fix_label'=>'Generate llms.txt'];
        }
        if (!empty($llms) && strlen($llms) < 200) {
            $issues[] = ['cat'=>'llms.txt','sev'=>'warning','msg'=>'llms.txt is too short ('.strlen($llms).' chars) — add more business details','fix'=>'sseo-llms','fix_label'=>'Improve llms.txt'];
        }
        $score += $llms_score;
        $checks['llms_txt'] = ['score'=>$llms_score,'max'=>$llms_max,'has_file'=>!empty($llms),'length'=>strlen($llms)];

        // ═══ 2. ROBOTS.TXT — AI BOT ACCESS ═══
        $robots_txt = '';
        $robots_file = ABSPATH . 'robots.txt';
        if (file_exists($robots_file)) $robots_txt = file_get_contents($robots_file);
        else $robots_txt = get_option('sseo_robots_txt','');

        $bot_access = [];
        $bot_score = 0; $bot_max = 18;
        $max += $bot_max;

        foreach ($this->ai_bots as $key => $bot) {
            $blocked = false;
            if (preg_match('/User-agent:\s*' . preg_quote($bot['ua']) . '\s*\n\s*Disallow:\s*\//mi', $robots_txt)) {
                $blocked = true;
            }
            // Also check wildcard blocks
            if (preg_match('/User-agent:\s*\*\s*\n(?:.*\n)*?\s*Disallow:\s*\/\s*$/mi', $robots_txt)) {
                $blocked = true;
            }
            $bot_access[$key] = ['name'=>$bot['name'],'allowed'=>!$blocked];
            if (!$blocked) $bot_score += 3;
            else $issues[] = ['cat'=>'Bot Access','sev'=>'critical','msg'=>$bot['name'].' is BLOCKED in robots.txt','fix'=>'sseo-robots','fix_label'=>'Fix robots.txt'];
        }
        $score += $bot_score;
        $checks['bot_access'] = ['score'=>$bot_score,'max'=>$bot_max,'bots'=>$bot_access];

        // ═══ 3. STRUCTURED DATA / SCHEMA ═══
        $schema_score = 0; $schema_max = 20;
        $max += $schema_max;

        $schema_on = get_option('sseo_schema_enabled',1);
        $has_brand = !empty(get_option('sseo_brand_name',''));
        $has_phone = !empty(get_option('sseo_business_phone',''));
        $has_addr  = !empty(get_option('sseo_business_address',''));
        $has_services = !empty(get_option('sseo_business_services',''));
        $has_hours = !empty(get_option('sseo_business_hours',''));
        $has_rating = !empty(get_option('sseo_review_count',''));
        $has_geo = !empty(get_option('sseo_business_lat',''));

        $schema_items = [
            ['Schema enabled',$schema_on,4],['Business name',$has_brand,3],['Phone number',$has_phone,2],
            ['Address',$has_addr,2],['Services listed',$has_services,3],['Opening hours',$has_hours,2],
            ['Reviews/rating',$has_rating,2],['Geo-coordinates',$has_geo,2],
        ];
        foreach ($schema_items as $si) {
            if ($si[1]) $schema_score += $si[2];
            else $issues[] = ['cat'=>'Schema','sev'=>$si[2]>=3?'warning':'info','msg'=>$si[0].' not configured — AI models use this for citations','fix'=>'sseo-settings','fix_label'=>'Settings'];
        }
        $score += $schema_score;
        $checks['schema'] = ['score'=>$schema_score,'max'=>$schema_max,'items'=>$schema_items];

        // ═══ 4. CONTENT STRUCTURE & CLARITY ═══
        $types = get_option('sseo_post_types',['post','page']);
        $all = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>-1]);
        $content_score = 0; $content_max = 20;
        $max += $content_max;

        $faq_pages = 0; $well_structured = 0; $has_definitions = 0;
        $total_pages = count($all);

        foreach ($all as $p) {
            $c = $p->post_content;
            // FAQ-style content (Q&A that AI can extract)
            if (preg_match_all('/<h[23][^>]*>[^<]*\?<\/h[23]>/i', $c, $qm)) {
                if (count($qm[0]) >= 2) $faq_pages++;
            }
            // Well-structured (has H2s + paragraphs)
            if (preg_match_all('/<h2/i', $c, $h2m) && count($h2m[0]) >= 2) $well_structured++;
            // Definition-style content ("X is...", "X means...")
            if (preg_match('/\b(?:is a|means|refers to|defined as|is the process of)\b/i', $c)) $has_definitions++;
        }

        $struct_pct = $total_pages > 0 ? $well_structured / $total_pages : 0;
        $content_score += min(8, round($struct_pct * 8));
        $content_score += min(6, $faq_pages * 2);
        $content_score += min(6, $has_definitions * 1);

        if ($faq_pages === 0) $issues[] = ['cat'=>'Content','sev'=>'warning','msg'=>'No FAQ-style content found — AI models prefer Q&A format for citations','fix'=>'sseo-content','fix_label'=>'Create FAQ Content'];
        if ($struct_pct < 0.5) $issues[] = ['cat'=>'Content','sev'=>'warning','msg'=>'Only '.round($struct_pct*100).'% of pages have proper heading structure (H2s)','fix'=>'sseo-thin','fix_label'=>'Improve Content'];

        $score += $content_score;
        $checks['content'] = ['score'=>$content_score,'max'=>$content_max,'faq_pages'=>$faq_pages,'well_structured'=>$well_structured,'has_definitions'=>$has_definitions,'total'=>$total_pages];

        // ═══ 5. ENTITY CLARITY ═══
        $entity_score = 0; $entity_max = 12;
        $max += $entity_max;

        $brand = get_option('sseo_brand_name','');
        $loc = get_option('sseo_target_location','');
        $services_str = get_option('sseo_business_services','');
        $brand_mentions = 0; $loc_mentions = 0;

        if ($brand) {
            foreach ($all as $p) {
                if (stripos($p->post_content, $brand) !== false) $brand_mentions++;
            }
        }
        if ($loc) {
            $areas = array_map('trim', explode(',', $loc));
            foreach ($all as $p) {
                $txt = strtolower($p->post_content . ' ' . $p->post_title);
                foreach ($areas as $a) {
                    if (stripos($txt, strtolower($a)) !== false) { $loc_mentions++; break; }
                }
            }
        }

        $entity_score += $brand_mentions >= $total_pages * 0.3 ? 4 : ($brand_mentions > 0 ? 2 : 0);
        $entity_score += $loc_mentions >= $total_pages * 0.3 ? 4 : ($loc_mentions > 0 ? 2 : 0);
        $entity_score += !empty($services_str) ? 4 : 0;

        if ($brand_mentions === 0 && !empty($brand)) $issues[] = ['cat'=>'Entity','sev'=>'warning','msg'=>'Brand name "'.$brand.'" not mentioned on any page','fix'=>'sseo-content','fix_label'=>'Add to Content'];
        if ($loc_mentions < 3 && !empty($loc)) $issues[] = ['cat'=>'Entity','sev'=>'warning','msg'=>'Location keywords only on '.$loc_mentions.' pages — AI needs geographic signals','fix'=>'sseo-thin','fix_label'=>'Enhance Content'];

        $score += $entity_score;
        $checks['entity'] = ['score'=>$entity_score,'max'=>$entity_max,'brand_mentions'=>$brand_mentions,'location_mentions'=>$loc_mentions];

        // ═══ 6. FRESHNESS & AUTHORITY ═══
        $fresh_score = 0; $fresh_max = 5;
        $max += $fresh_max;

        $recent_posts = get_posts(['post_type'=>'post','post_status'=>'publish','numberposts'=>5,'orderby'=>'date','order'=>'DESC']);
        $has_recent = false;
        if ($recent_posts) {
            $latest = strtotime($recent_posts[0]->post_date);
            $days_ago = (time() - $latest) / 86400;
            if ($days_ago < 30) { $fresh_score += 3; $has_recent = true; }
            elseif ($days_ago < 90) { $fresh_score += 1; }
            else { $issues[] = ['cat'=>'Freshness','sev'=>'info','msg'=>'No content published in '.round($days_ago).' days — fresh content improves AI citation likelihood','fix'=>'sseo-content','fix_label'=>'Create Content']; }
        }
        $sitemap_exists = false;
        foreach (['/wp-sitemap.xml','/sitemap.xml','/sitemap_index.xml'] as $sp) {
            $sr = wp_remote_head(home_url($sp), ['timeout'=>5,'sslverify'=>false]);
            if (!is_wp_error($sr) && wp_remote_retrieve_response_code($sr) === 200) { $sitemap_exists = true; break; }
        }
        if ($sitemap_exists) $fresh_score += 2;
        else $issues[] = ['cat'=>'Freshness','sev'=>'warning','msg'=>'No XML sitemap found — AI crawlers use sitemaps','fix'=>'sseo-robots','fix_label'=>'Add Sitemap'];

        $score += $fresh_score;
        $checks['freshness'] = ['score'=>$fresh_score,'max'=>$fresh_max,'has_recent'=>$has_recent,'sitemap'=>$sitemap_exists];

        // ═══ OVERALL ═══
        $pct = $max > 0 ? round($score / $max * 100) : 0;

        // Grade
        $grade = 'F';
        if ($pct >= 90) $grade = 'A';
        elseif ($pct >= 75) $grade = 'B';
        elseif ($pct >= 55) $grade = 'C';
        elseif ($pct >= 35) $grade = 'D';

        $critical = count(array_filter($issues, function($i){ return $i['sev']==='critical'; }));
        $warnings = count(array_filter($issues, function($i){ return $i['sev']==='warning'; }));

        return [
            'score'    => $pct,
            'grade'    => $grade,
            'points'   => $score,
            'max'      => $max,
            'critical' => $critical,
            'warnings' => $warnings,
            'total_issues' => count($issues),
            'issues'   => $issues,
            'checks'   => $checks,
            'ai_bots'  => $bot_access,
            'date'     => current_time('mysql'),
            'site_url' => home_url('/'),
        ];
    }

    /**
     * Run AI-powered deep analysis of citability
     */
    public function run_ai_deep( $audit_data ) {
        $api = new SSEO_API_Handler();
        $brand = get_option('sseo_brand_name', get_bloginfo('name'));
        $services = get_option('sseo_business_services','');
        $loc = get_option('sseo_target_location','');

        $bots_allowed = 0;
        foreach ($audit_data['ai_bots'] as $b) { if ($b['allowed']) $bots_allowed++; }
        $llms_status = ($audit_data['checks']['llms_txt']['has_file']) ? 'EXISTS ('.$audit_data['checks']['llms_txt']['length'].' chars)' : 'MISSING';

        $prompt = "You are an AI SEO specialist analyzing whether a website is optimized to be CITED and RECOMMENDED by AI chatbots (ChatGPT, Claude, Perplexity, Gemini).

Website: " . home_url('/') . "
Business: {$brand}
Services: {$services}
Location: {$loc}
Current AI Compatibility Score: {$audit_data['score']}%

Audit findings:
- llms.txt: {$llms_status}
- Bot access: {$bots_allowed}/6 AI bots allowed
- Schema: {$audit_data['checks']['schema']['score']}/{$audit_data['checks']['schema']['max']} points
- FAQ pages: {$audit_data['checks']['content']['faq_pages']}
- Structured pages: {$audit_data['checks']['content']['well_structured']}/{$audit_data['checks']['content']['total']}
- Brand mentions: {$audit_data['checks']['entity']['brand_mentions']} pages
- Location mentions: {$audit_data['checks']['entity']['location_mentions']} pages

Return ONLY JSON (no markdown):
{
  \"summary\": \"2-3 sentence assessment of AI citability\",
  \"ai_visibility_tips\": [
    {\"tip\": \"specific actionable tip\", \"priority\": \"high/medium/low\", \"tool\": \"sseo tool slug or empty\"}
  ],
  \"content_suggestions\": [
    {\"topic\": \"content topic AI would cite\", \"format\": \"FAQ/How-to/Guide/List\", \"reason\": \"why AI would cite this\"}
  ],
  \"llms_txt_improvements\": \"specific suggestions to improve llms.txt or empty\",
  \"competitor_citation_keywords\": [\"keyword AI users would ask about\"]
}";

        $r = $api->complete($prompt, 0.3);
        if (is_wp_error($r)) return $r;
        $parsed = SSEO_API_Handler::parse_json($r['content']);
        if (is_wp_error($parsed)) return $parsed;
        return $parsed;
    }

    public function get_history() { return get_option('sseo_ai_audit_history', []); }

    public function save_to_history($result) {
        $history = $this->get_history();
        array_unshift($history, [
            'date'   => current_time('mysql'),
            'score'  => $result['score'],
            'grade'  => $result['grade'],
            'issues' => $result['total_issues'],
            'critical' => $result['critical'],
            'data'   => $result,
        ]);
        // Keep last 20 runs
        $history = array_slice($history, 0, 20);
        update_option('sseo_ai_audit_history', $history);
    }
}
