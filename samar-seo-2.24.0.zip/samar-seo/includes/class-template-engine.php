<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Template Engine — pre-built HTML/CSS templates filled by AI
 * AI only generates TEXT content as JSON, never HTML/CSS
 */
class SSEO_Template_Engine {

    private static $templates = [
        'service_page'  => ['file'=>'service-page.html','name'=>'Service Page','icon'=>'🔧'],
        'what_we_do'    => ['file'=>'what-we-do.html','name'=>'What We Do (Gallery Showcase)','icon'=>'🖼️'],
        'local_landing' => ['file'=>'local-landing.html','name'=>'Local Landing Page','icon'=>'📍'],
        'about_us'      => ['file'=>'about-us.html','name'=>'About Us','icon'=>'🏢'],
        'faq_page'      => ['file'=>'faq-page.html','name'=>'FAQ Page','icon'=>'❓'],
        'landing_page'  => ['file'=>'landing-page.html','name'=>'Landing Page','icon'=>'🎯'],
        'blog_post'     => ['file'=>'blog-post.html','name'=>'Blog Post','icon'=>'📝'],
    ];

    public static function get_available() { return self::$templates; }

    /**
     * Generate content using a template
     */
    public function generate( $template_key, $topic, $keywords = '', $scope = 'local', $word_count = 1200, $custom = '' ) {
        $tmpl = self::$templates[$template_key] ?? null;
        if (!$tmpl) return new WP_Error('invalid','Unknown template: '.$template_key);

        $file = SSEO_DIR . 'templates/' . $tmpl['file'];
        if (!file_exists($file)) return new WP_Error('missing','Template file not found: '.$tmpl['file']);

        $html_template = file_get_contents($file);

        // Inject brand colors and width from settings
        $color1 = get_option('sseo_brand_color_1', '');
        $color2 = get_option('sseo_brand_color_2', '');
        $hero_bg = get_option('sseo_hero_bg_color', '');
        $width  = get_option('sseo_content_width', '');

        if ($color1 || $color2 || $hero_bg || $width) {
            $overrides = '';

            if ($color1) {
                $light1 = $this->lighten_color($color1, 0.92);
                $light2 = $this->lighten_color($color1, 0.85);
                $light3 = $this->lighten_color($color1, 0.6);
                $light4 = $this->lighten_color($color1, 0.5);
                $text_on_accent = $this->is_light_color($color1) ? '#1e293b' : '#ffffff';
                $overrides .= "
.sp-wrap,.lp-wrap,.au-wrap,.fq-wrap,.bp{--accent:{$color1};--accent2:{$color1}}
.sp-btn-primary,.lp-btn-primary{background:{$color1}!important;color:{$text_on_accent}!important}
.sp-cta .sp-btn,.lp-cta .lp-btn{background:var(--dark)!important;color:#fff!important}
.au-btn,.fq-btn,.bp-btn{color:{$color1}!important}
.sp-cta-wrap,.lp-cta-wrap,.au-cta-wrap,.fq-cta-wrap{background:linear-gradient(135deg,{$color1},{$color1})!important}
.sp-cta h2,.sp-cta p,.lp-cta h2,.lp-cta p,.au-cta h2,.au-cta p,.fq-cta h2,.fq-cta p{color:#fff!important}
.sp-stat-num,.lp-bcard-icon{color:{$color1}}
.sp h2,.lp h2,.au h2,.fq h2,.bp h2{border-bottom-color:{$color1}}
.sp-benefit{border-left-color:{$color1}}
.sp-faq-q::after,.lp-faq-q::after,.bp-faq-q::after{color:{$color1}}
.fq-arrow{color:{$color1}}
.fq-item.open .fq-arrow{background:{$color1}}
.sp-step-num,.lp-pstep-num{background:{$color1}}
.sp-label{color:{$light3}}
.sp-area,.au-area{background:{$light1};border-color:{$light4}}
.sp-inc-item{background:{$light1}}
.sp a,.lp a,.au a,.fq a,.bp a{color:{$color1}}
.bp-cat{color:{$color1};background:{$light1};border-color:{$light4}}
.bp-hook{border-left-color:{$color1}}
.bp-progress{background:{$color1}}
.bp-tk-check{background:{$color1}}
";
            }
            if ($color2) {
                $text_on_dark = $this->is_light_color($color2) ? '#1e293b' : '#ffffff';
                $sub_text = $this->is_light_color($color2) ? '#475569' : '#cbd5e1';
                $overrides .= "
.sp-wrap,.lp-wrap,.au-wrap,.fq-wrap,.bp{--dark:{$color2}}
.sp-btn-outline{color:{$text_on_dark}!important;border-color:rgba(" . ($this->is_light_color($color2) ? '0,0,0' : '255,255,255') . ",.3)!important}
";
            }

            // Hero background — separate control for the full-width hero section
            $hero_color = $hero_bg ?: ($color2 ?: '');
            if ($hero_color) {
                $hero_text = $this->is_light_color($hero_color) ? '#1e293b' : '#ffffff';
                $hero_sub = $this->is_light_color($hero_color) ? '#475569' : 'rgba(255,255,255,.75)';
                $overrides .= "
.sp-hero-wrap,.lp-hero-wrap,.au-hero-wrap,.fq-hero-wrap{background:{$hero_color}!important}
.sp-hero h1,.lp-hero h1,.au-hero h1,.fq-hero h1{color:{$hero_text}!important}
.sp-hero p,.lp-hero p,.au-hero p,.fq-hero p{color:{$hero_sub}!important}
.sp-label,.au-label{color:" . ($this->is_light_color($hero_color) ? '#475569' : 'rgba(255,255,255,.7)') . "!important}
";
            }
            if ($width && (int)$width !== 1140) {
                $w = (int)$width;
                $overrides .= ".sp,.lp,.au,.fq,.bp,.sp-hero,.lp-hero,.au-hero,.fq-hero,.sp-cta,.lp-cta,.au-cta,.fq-cta{max-width:{$w}px}\n";
            }

            if ($overrides) {
                // Inject after the first </style> tag
                $html_template = preg_replace('/<\/style>/', '</style><style>' . $overrides . '</style>', $html_template, 1);
            }
        }

        // Get business data
        $biz = $this->get_business_data();

        // Build the JSON schema prompt for this template
        $json_schema = $this->get_json_schema($template_key);
        $local_ctx = ($scope === 'local') ? $this->get_local_prompt($biz) : '';
        $links_ctx = $this->get_links_prompt();

        $api = new SSEO_API_Handler();
        $prompt = "You are an SEO content writer. Generate ONLY the text content (no HTML) for a {$tmpl['name']}.

TOPIC: {$topic}
KEYWORDS: {$keywords}
WORD COUNT: You MUST write {$word_count}+ words total. This is a MINIMUM — more is better. Each text field has a word count target in parentheses — these are MINIMUMS not maximums. The content_sections array is your primary volume driver: write 6-10 detailed sub-service sections, each 80-120 words. Every benefit_desc, step_desc, and FAQ answer must be 60-100 words with specific details. Do NOT write short, generic answers. If the total is under {$word_count}, you have failed.
BUSINESS: {$biz['brand']}
{$local_ctx}{$links_ctx}
" . ($custom ? "ADDITIONAL: {$custom}\n" : '') . "

Return ONLY a JSON object with these exact keys (no markdown, no fences, no explanation, no text before or after the JSON, start with { and end with }):
{$json_schema}

RULES:
- Write {$word_count}+ words TOTAL across all text fields
- CRITICAL PARAGRAPH RULE: Write in short, scannable paragraphs of 2-3 sentences each. Never write a single paragraph longer than 4 sentences. Readers skim — dense walls of text hurt engagement and SEO.
- Every text field should be substantial but broken into digestible chunks
- CRITICAL JSON RULES: Do NOT use double quotes inside string values — use single quotes or rephrase instead. Do NOT use literal newlines inside strings. Do NOT add trailing commas. Your output MUST be valid JSON.

LOCAL SEO RULES (CRITICAL):
- Mention the city name ({$biz['city']}) at least 6-8 times naturally across different sections
- Include full NAP (Name, Address, Phone) in intro and CTA sections
- Use \"[Service] in [City], [State]\" format in titles and headings
- Mention nearby cities and neighborhoods from the service areas
- Include county name and state in content naturally
- Reference local landmarks, highways, or well-known areas when relevant
- Use phrases like \"serving [City] and surrounding areas\" or \"[City]'s trusted [service] contractor\"

AI SEO RULES (for ChatGPT/Claude/Perplexity citation):
- Start each section with a clear, definitive statement that AI can quote
- Structure FAQ answers as complete, self-contained responses (not \"we\" focused but factual)
- Include specific numbers: costs, timelines, square footage ranges, year founded
- Write in entity-rich language: use proper nouns, specific service names, brand name
- Each paragraph should answer a searchable question implicitly
- Use \"According to\" or \"Based on\" phrasing for statistics
- Include the brand name + city + service in the first 100 words

INTERNAL LINKING (CRITICAL - must provide 6-10 links):
- For internal_links: provide 6-10 objects with anchor (2-4 word phrase) and url
- Each anchor MUST be a multi-word phrase like \"bathroom renovation services\" not single words
- Pick the MOST relevant pages from the site list — related services, about page, contact, gallery
- IMPORTANT: You MUST use each anchor phrase naturally somewhere in your text content (intro, benefits, steps, FAQ answers)
- Example: if anchor is \"bathroom renovation\", write a sentence containing \"bathroom renovation\" in one of the text fields
- This ensures the links get placed inline in the actual content, not appended artificially

SEARCH ENGINE RULES:
- Include primary keyword in first paragraph and last paragraph
- Use semantic variations of the keyword throughout
- Write content that answers \"People Also Ask\" questions
- Structure for featured snippet eligibility: clear definitions, numbered lists, direct answers";

        // Template-specific overrides
        if ($template_key === 'local_landing') {
            $prompt .= "\n\nLOCAL LANDING PAGE RULES (CRITICAL — this is a GEO page, NOT a service page):
- This page is about the LOCATION, not the services. Pillar service pages already cover service details.
- Focus on: why this city/area is special, local building codes, county permits, neighborhoods served
- The services_in_area array should have SHORT descriptions (1-2 sentences) with slugs linking to the full service pages
- DO NOT duplicate detailed service descriptions — just summarize and link to the pillar page
- Include real neighborhood names, county-specific permit info, local landmarks/highways
- local_expertise reasons should be specific to this location: local team, fast response time, familiarity with area codes
- The meta_description must include the city name and primary keyword
- URL slug should be: service-areas/{city-slug}-{state}/ (e.g. service-areas/catonsville-md/)";
        }

        if ($template_key === 'what_we_do') {
            $prompt .= "\n\nWHAT WE DO / GALLERY SHOWCASE RULES (CRITICAL — this is a VISUAL page, NOT a detailed service page):
- This page showcases COMPLETED PROJECTS with photos. The detailed /services/ page covers process, materials, FAQ.
- DO NOT include: process steps, materials lists, pricing, FAQ, detailed explanations of how the service works.
- DO include: visual descriptions of project types, specialties/tags, stats about completed projects, brief overview of what you can do.
- HEADING RULE: The hero_title must be portfolio-style like 'Our Kitchen Remodeling Projects' or 'Kitchen Remodeling Portfolio' — NEVER include a city name or location in the hero_title. Local pages already use '[Service] in [City]' format. This page is about the WORK, not the location.
- The hero_subtitle can mention service areas generally (e.g. 'Award-winning transformations across Maryland').
- The about_p1 and about_p2 should be SHORT (2-3 sentences each).
- The service_url MUST point to the corresponding /services/ page.
- Image search terms should be SPECIFIC and VARIED — each targeting a different aspect.
- BEFORE/AFTER IMAGES: The ba_1 through ba_4 search terms MUST include the words 'before after' or 'before and after' to find composite comparison photos. Example: 'kitchen before and after', 'home addition before after'.
- Keep total word count under 400 — this is a visual page, not a content page.";
        }

        // Local landing pages need more tokens due to complex schema
        $max_tokens = ($template_key === 'local_landing') ? 32000 : 16384;
        $r = $api->complete($prompt, 0.6, $max_tokens);
        if (is_wp_error($r)) return $r;

        $data = SSEO_API_Handler::parse_json($r['content']);
        if (is_wp_error($data)) return $data;

        // Flatten nested objects (e.g., local_expertise.heading → local_expertise_heading)
        $flat = [];
        foreach ($data as $k => $v) {
            if (is_array($v) && !isset($v[0])) {
                // Associative array (object) — flatten
                foreach ($v as $sk => $sv) {
                    $flat[$k . '_' . $sk] = $sv;
                }
            }
        }
        $data = array_merge($data, $flat);

        // Merge business data
        $data = array_merge($data, [
            'brand'       => $biz['brand'],
            'phone'       => $biz['phone'],
            'phone_raw'   => preg_replace('/[^0-9+]/','',$biz['phone']),
            'email'       => $biz['email'],
            'address'     => $biz['full_address'],
            'contact_url' => $this->get_contact_url(),
        ]);

        // Fill areas from settings if AI didn't provide them
        if (empty($data['areas']) && !empty($biz['location'])) {
            $data['areas'] = array_map(function($a){ return ['area'=>trim($a)]; }, explode(',', $biz['location']));
        }

        // Build areas text for schema
        $areas_text = '';
        if (!empty($data['areas'])) {
            $areas_text = implode(', ', array_map(function($a){ return is_array($a) ? ($a['area']??'') : $a; }, $data['areas']));
        }
        $data['areas_text'] = $areas_text;

        // Render template
        $html = $this->render($html_template, $data);

        // Split long paragraphs into readable 2-3 sentence chunks
        $html = $this->split_long_paragraphs($html);

        // Inject internal links from AI response
        if (!empty($data['internal_links'])) {
            $html = $this->inject_links($html, $data['internal_links']);
        }

        // Fallback: if AI didn't provide enough links, use content generator's injector
        $link_count = substr_count($html, '<a href');
        if ($link_count < 3) {
            $gen2 = new SSEO_Content_Generator();
            $html = $gen2->inject_real_links_public($html);
        }

        // Auto-match images — use AI's specific search terms if available
        $img_keywords = trim($keywords ?: $topic);
        $ai_img_terms = [];
        if (!empty($data['image_1_search'])) $ai_img_terms[] = $data['image_1_search'];
        if (!empty($data['image_2_search'])) $ai_img_terms[] = $data['image_2_search'];
        if (!empty($data['image_3_search'])) $ai_img_terms[] = $data['image_3_search'];
        if ($ai_img_terms) $img_keywords = implode(', ', $ai_img_terms);

        $gen = new SSEO_Content_Generator();
        $img_result = $gen->auto_match_images($html, $img_keywords);
        $html = $img_result['content'];

        // Inject FAQPage schema (critical for AI SEO — ChatGPT/Perplexity/Google)
        $faqs = $data['faqs'] ?? [];
        if (!empty($faqs) && is_array($faqs)) {
            $faq_items = [];
            foreach ($faqs as $faq) {
                $q = $faq['question'] ?? '';
                $a = $faq['answer'] ?? '';
                if ($q && $a) {
                    $faq_items[] = [
                        '@type' => 'Question',
                        'name' => $q,
                        'acceptedAnswer' => ['@type' => 'Answer', 'text' => $a],
                    ];
                }
            }
            // Also check faq_sections (FAQ page template uses nested structure)
            $faq_sections = $data['faq_sections'] ?? [];
            if (!empty($faq_sections) && is_array($faq_sections)) {
                foreach ($faq_sections as $section) {
                    foreach (($section['questions'] ?? []) as $faq) {
                        $q = $faq['question'] ?? '';
                        $a = $faq['answer'] ?? '';
                        if ($q && $a) {
                            $faq_items[] = [
                                '@type' => 'Question',
                                'name' => $q,
                                'acceptedAnswer' => ['@type' => 'Answer', 'text' => $a],
                            ];
                        }
                    }
                }
            }
            if (!empty($faq_items)) {
                $faq_schema = wp_json_encode([
                    '@context' => 'https://schema.org',
                    '@type' => 'FAQPage',
                    'mainEntity' => $faq_items,
                ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                $html .= "\n" . '<script type="application/ld+json">' . $faq_schema . '</script>';
            }
        }

        // Inject GeoCoordinates if available (Local SEO boost)
        $lat = get_option('sseo_business_lat', '');
        $lng = get_option('sseo_business_lng', '');
        if ($lat && $lng) {
            $geo_schema = wp_json_encode([
                '@context' => 'https://schema.org',
                '@type' => 'LocalBusiness',
                'name' => $biz['brand'],
                'telephone' => $biz['phone'],
                'address' => [
                    '@type' => 'PostalAddress',
                    'streetAddress' => $biz['address'],
                    'addressLocality' => $biz['city'],
                    'addressRegion' => $biz['state'],
                    'postalCode' => $biz['zip'],
                ],
                'geo' => [
                    '@type' => 'GeoCoordinates',
                    'latitude' => $lat,
                    'longitude' => $lng,
                ],
                'areaServed' => $areas_text,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $html .= "\n" . '<script type="application/ld+json">' . $geo_schema . '</script>';
        }

        // Extract title
        $title = $data['title'] ?? $topic;

        return [
            'html'             => $html,
            'title'            => $title,
            'template'         => $template_key,
            'word_count'       => str_word_count(wp_strip_all_tags($html)),
            'tokens'           => $r['tokens'],
            'images_matched'   => $img_result['matched'],
            'images_remaining' => $img_result['remaining'],
            'data'             => $data,
        ];
    }

    /**
     * Simple Mustache-like template renderer
     */
    private function render($template, $data) {
        $html = $template;

        // Handle loops: {{#key}}...{{/key}}
        $html = preg_replace_callback('/\{\{#(\w+)\}\}(.*?)\{\{\/\1\}\}/s', function($m) use ($data) {
            $key = $m[1];
            $inner = $m[2];
            $items = $data[$key] ?? [];
            if (!is_array($items)) return '';
            $out = '';
            foreach ($items as $i => $item) {
                $row = $inner;
                if (is_array($item)) {
                    foreach ($item as $k => $v) {
                        if (is_string($v) || is_numeric($v)) {
                            $row = str_replace('{{'.$k.'}}', esc_html((string)$v), $row);
                        }
                    }
                } elseif (is_string($item)) {
                    $row = str_replace('{{.}}', esc_html($item), $row);
                }
                // Handle step numbering
                $row = str_replace('{{step_num}}', (string)($i+1), $row);
                $out .= $row;
            }
            return $out;
        }, $html);

        // Handle simple vars: {{key}}
        foreach ($data as $k => $v) {
            if (is_string($v) || is_numeric($v)) {
                $html = str_replace('{{'.$k.'}}', esc_html((string)$v), $html);
            }
        }

        // Clean leftover placeholders
        $html = preg_replace('/\{\{[a-z_]+\}\}/', '', $html);

        return $html;
    }

    /**
     * Inject internal links into rendered HTML
     */
    private function inject_links($html, $links) {
        if (empty($links) || !is_array($links)) return $html;

        $brand = strtolower(get_option('sseo_brand_name', ''));
        $brand_words = array_filter(preg_split('/\s+/', $brand), function($w){ return strlen($w) > 2; });
        $placed_urls = [];

        // Generic/bad anchors to skip
        $blacklist = ['click here','learn more','read more','contact us','get started','find out','our team','our company','see more','view more','this page','here','more info','home page','main page'];

        foreach ($links as $link) {
            $anchor = trim($link['anchor'] ?? '');
            $url = trim($link['url'] ?? '');
            if (strlen($anchor) < 6 || empty($url)) continue;
            if (str_word_count($anchor) < 2) continue;
            if (isset($placed_urls[$url])) continue;
            if (in_array(strtolower($anchor), $blacklist)) continue;

            // Skip if ANY brand word appears in the anchor (prevents "Wall to", "to Wall" etc)
            $anchor_lower = strtolower($anchor);
            $has_brand_word = false;
            foreach ($brand_words as $bw) {
                if (strpos($anchor_lower, $bw) !== false) { $has_brand_word = true; break; }
            }
            if ($has_brand_word) continue;

            // Use word boundaries, only match in <p> or <li> or <div> text content (not in headings, buttons, etc)
            $link_tag = '<a href="' . esc_url($url) . '">' . esc_html($anchor) . '</a>';
            $pattern = '/(?<=[\s>])(' . preg_quote($anchor, '/') . ')(?=[\s<.,;:!?)])/i';

            if (preg_match($pattern, $html)) {
                // Verify we're not inside an existing <a> tag
                $test_pos = strpos(strtolower($html), strtolower($anchor));
                if ($test_pos !== false) {
                    $before = substr($html, max(0, $test_pos - 200), 200);
                    // Don't link if we're inside an <a> tag
                    if (preg_match('/<a\s[^>]*>[^<]*$/i', $before)) continue;
                    // Don't link if we're inside <h1>-<h6>
                    if (preg_match('/<h[1-6][^>]*>[^<]*$/i', $before)) continue;
                    // Don't link if inside a button
                    if (preg_match('/<button[^>]*>[^<]*$/i', $before)) continue;
                }
                $html = preg_replace($pattern, $link_tag, $html, 1);
                $placed_urls[$url] = true;
            }
        }
        return $html;
    }

    private function get_contact_url() {
        // Try common contact page slugs
        $slugs = ['contact', 'contact-us', 'get-in-touch', 'request-a-quote', 'free-estimate'];
        foreach ($slugs as $slug) {
            $page = get_page_by_path($slug);
            if ($page && $page->post_status === 'publish') {
                return get_permalink($page->ID);
            }
        }
        // Fallback: search by title
        $pages = get_posts(['post_type'=>'page','post_status'=>'publish','s'=>'contact','numberposts'=>1]);
        if (!empty($pages)) return get_permalink($pages[0]->ID);
        // Last resort: homepage
        return home_url('/contact/');
    }

    private function get_business_data() {
        return [
            'brand'        => get_option('sseo_brand_name', get_bloginfo('name')),
            'phone'        => get_option('sseo_business_phone', ''),
            'email'        => get_option('sseo_business_email', ''),
            'address'      => get_option('sseo_business_address', ''),
            'city'         => get_option('sseo_business_city', ''),
            'state'        => get_option('sseo_business_state', ''),
            'zip'          => get_option('sseo_business_zip', ''),
            'full_address' => trim(get_option('sseo_business_address','') . ', ' . get_option('sseo_business_city','') . ', ' . get_option('sseo_business_state','') . ' ' . get_option('sseo_business_zip',''), ', '),
            'location'     => get_option('sseo_target_location', ''),
            'services'     => get_option('sseo_business_services', ''),
            'hours'        => get_option('sseo_business_hours', ''),
            'founded'      => get_option('sseo_business_founded', ''),
            'license'      => get_option('sseo_business_license', ''),
        ];
    }

    private function get_local_prompt($biz) {
        if (empty($biz['city'])) return '';
        return "
LOCAL SEO: Mention {$biz['city']} and service areas ({$biz['location']}) 4-8 times naturally.
ADDRESS: {$biz['full_address']}
PHONE: {$biz['phone']}
SERVICES: {$biz['services']}
";
    }

    private function get_links_prompt() {
        $types = get_option('sseo_post_types', ['post','page']);
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>30]);
        if (empty($posts)) return '';
        $list = "\nSITE PAGES — YOU MUST USE 4-8 OF THESE FOR internal_links (CRITICAL):\n";
        foreach ($posts as $p) {
            $list .= '- "' . $p->post_title . '" → ' . get_permalink($p->ID) . "\n";
        }
        $list .= "\nFor each internal_links entry: {\"anchor\":\"2-4 word relevant phrase\",\"url\":\"full URL from list above\"}\n";
        $list .= "REQUIRED: Include links to About page, Contact page, and 2-3 related service pages.\n";
        $list .= "CRITICAL: Each anchor phrase MUST appear naturally in your text content so links can be placed inline.\n";
        return $list;
    }

    private function get_json_schema($key) {
        $schemas = [
            'service_page' => '{
  "title": "H1 page title with service + city",
  "service_label": "short label like PROFESSIONAL KITCHEN REMODELING",
  "subtitle": "one sentence value proposition",
  "intro_p1": "First paragraph 80-100 words: what the service is + city + brand name + why it matters. Include primary keyword in first sentence.",
  "intro_p2": "Second paragraph 80-100 words: expertise, years experience, areas served, specific details",
  "intro_p3": "Third paragraph 80-100 words: what sets the company apart, materials used, approach. End with call-to-action mentioning phone number.",
  "image_1_search": "EXACT 2-3 word search matching image ALT text in media library, e.g. kitchen remodeling (must match the page topic)",
  "image_2_search": "DIFFERENT 2-3 word search for a DIFFERENT aspect, e.g. kitchen cabinets or kitchen countertop (MUST differ from image_1)",
  "image_3_search": "ANOTHER DIFFERENT 2-3 word search, e.g. kitchen renovation completed or modern kitchen (MUST differ from image_1 and image_2)",
  "image_4_search": "2-3 word search for fourth image e.g. kitchen design or custom kitchen (MUST differ from all above)",
  "stat_1_number": "e.g. 20+", "stat_1_label": "Years Experience",
  "stat_2_number": "e.g. 500+", "stat_2_label": "Projects Completed",
  "stat_3_number": "e.g. 4.9", "stat_3_label": "Google Rating",
  "services_title": "Our Comprehensive [Service Category] Services in [City]",
  "content_sections": [
    {"section_title": "Sub-Service 1 Title (e.g. Custom Kitchen Cabinets)", "section_content": "Detailed 80-120 word paragraph about this sub-service. Include specific details, materials, benefits, and a natural mention of a related internal link anchor phrase. Write like an expert explaining what they do and why it matters to the homeowner."},
    {"section_title": "Sub-Service 2 Title", "section_content": "80-120 words. Different sub-service or aspect. Include local city mentions naturally."},
    {"section_title": "Sub-Service 3 Title", "section_content": "80-120 words. Another sub-service or related offering."},
    {"section_title": "Sub-Service 4 Title", "section_content": "80-120 words. Continue covering all aspects of the service category."},
    {"section_title": "Sub-Service 5 Title", "section_content": "80-120 words. Be thorough — cover every service the business offers in this category."},
    {"section_title": "Sub-Service 6 Title", "section_content": "80-120 words. Include relevant keywords and geographic modifiers."},
    {"section_title": "Sub-Service 7 Title (if applicable)", "section_content": "80-120 words. Add more if the service category warrants it."},
    {"section_title": "Sub-Service 8 Title (if applicable)", "section_content": "80-120 words. Better to have too many than too few."}
  ],
  "why_title": "Why Choose [Brand] for [Service] in [City]",
  "benefits": [
    {"benefit_title": "title", "benefit_desc": "3-4 sentence description (60-80 words) with specific details, not generic claims"},
    {"benefit_title": "title", "benefit_desc": "3-4 sentence description (60-80 words)"},
    {"benefit_title": "title", "benefit_desc": "3-4 sentence description (60-80 words)"},
    {"benefit_title": "title", "benefit_desc": "3-4 sentence description (60-80 words)"},
    {"benefit_title": "title", "benefit_desc": "3-4 sentence description (60-80 words)"},
    {"benefit_title": "title", "benefit_desc": "3-4 sentence description (60-80 words)"}
  ],
  "process_title": "Our [Service] Process in [City]",
  "steps": [
    {"step_title": "Consultation & Design", "step_desc": "3-4 sentences (60-80 words)"},
    {"step_title": "Detailed Proposal & Planning", "step_desc": "3-4 sentences (60-80 words)"},
    {"step_title": "Construction & Project Management", "step_desc": "3-4 sentences (60-80 words)"},
    {"step_title": "Final Walkthrough & Satisfaction Guarantee", "step_desc": "3-4 sentences (60-80 words)"}
  ],
  "included_title": "What Is Included in Our [Service]",
  "included_items": [{"item":"item 1"},{"item":"item 2"},{"item":"item 3"},{"item":"item 4"},{"item":"item 5"},{"item":"item 6"},{"item":"item 7"},{"item":"item 8"},{"item":"item 9"},{"item":"item 10"}],
  "cost_title": "[Service] Cost in [City], [State]",
  "cost_p1": "First paragraph about average costs, price ranges, and what homeowners can expect to budget (80-100 words)",
  "cost_p2": "Second paragraph about factors that affect pricing — size, materials, complexity, permits (80-100 words)",
  "cost_p3": "Third paragraph about financing options, ROI, and value of professional work vs DIY (60-80 words)",
  "faqs": [
    {"question": "How much does [service] cost in [city]?", "answer": "5-6 sentence detailed answer with specific ranges (80-100 words)"},
    {"question": "How long does [service] take in [city]?", "answer": "5-6 sentence answer with realistic timelines (80-100 words)"},
    {"question": "Are you licensed for [service] in [state]?", "answer": "5-6 sentence answer mentioning license numbers (80-100 words)"},
    {"question": "What is included in your [service]?", "answer": "5-6 sentence answer listing specifics (80-100 words)"},
    {"question": "Do you offer free estimates for [service]?", "answer": "5-6 sentence answer about the consultation process (80-100 words)"},
    {"question": "What areas do you serve for [service]?", "answer": "5-6 sentence answer listing cities and counties (80-100 words)"},
    {"question": "What materials do you use for [service]?", "answer": "5-6 sentence answer with brand names and material types (80-100 words)"},
    {"question": "Can I see examples of your [service] work?", "answer": "5-6 sentence answer referencing gallery and portfolio (80-100 words)"}
  ],
  "areas": [{"area":"City 1"},{"area":"City 2"},{"area":"City 3"},{"area":"City 4"},{"area":"City 5"},{"area":"City 6"},{"area":"City 7"},{"area":"City 8"}],
  "cta_title": "Ready to Start Your [Service] in [City]?",
  "cta_text": "Two sentences — urgency + value proposition with phone number",
  "cta_button": "Call [phone] for Free Estimate",
  "internal_links": [{"anchor":"2-4 word descriptive phrase","url":"full page URL from site list"},{"anchor":"phrase","url":"URL"},{"anchor":"phrase","url":"URL"},{"anchor":"phrase","url":"URL"},{"anchor":"phrase","url":"URL"},{"anchor":"phrase","url":"URL"},{"anchor":"phrase","url":"URL"},{"anchor":"phrase","url":"URL"}]
}',

            'about_us' => '{
  "title": "About [Brand Name]",
  "subtitle": "one line tagline",
  "intro": "2-3 paragraphs about the company (150 words)",
  "story_title": "Our Story",
  "story_content": "3-4 paragraphs company history (200-300 words)",
  "mission_title": "Our Mission & Values",
  "mission_content": "2-3 paragraphs (150-200 words)",
  "differentiators_title": "What Sets Us Apart",
  "differentiators": [
    {"diff_title": "title", "diff_desc": "2-3 sentences"},
    {"diff_title": "title", "diff_desc": "2-3 sentences"},
    {"diff_title": "title", "diff_desc": "2-3 sentences"},
    {"diff_title": "title", "diff_desc": "2-3 sentences"}
  ],
  "credentials_title": "Credentials & Certifications",
  "credentials_content": "2 paragraphs (100-150 words)",
  "areas": [{"area":"City 1"},{"area":"City 2"}],
  "cta_title": "Ready to Work With Us?",
  "cta_text": "contact line",
  "cta_button": "Call Us Today",
  "internal_links": [{"anchor":"phrase","url":"URL"}]
}',

            'faq_page' => '{
  "title": "Frequently Asked Questions",
  "subtitle": "subtitle about your services",
  "intro": "1-2 paragraph intro (100 words)",
  "faq_sections": [
    {
      "section_title": "General Questions",
      "questions": [
        {"question": "ends with?", "answer": "3-5 sentence answer"},
        {"question": "ends with?", "answer": "answer"},
        {"question": "ends with?", "answer": "answer"},
        {"question": "ends with?", "answer": "answer"}
      ]
    },
    {
      "section_title": "Pricing & Costs",
      "questions": [
        {"question": "ends with?", "answer": "answer"},
        {"question": "ends with?", "answer": "answer"},
        {"question": "ends with?", "answer": "answer"}
      ]
    },
    {
      "section_title": "Process & Timeline",
      "questions": [
        {"question": "ends with?", "answer": "answer"},
        {"question": "ends with?", "answer": "answer"},
        {"question": "ends with?", "answer": "answer"}
      ]
    }
  ],
  "cta_title": "Still Have Questions?",
  "cta_text": "contact line",
  "cta_button": "Call Us",
  "internal_links": [{"anchor":"phrase","url":"URL"}]
}',

            'landing_page' => '{
  "title": "compelling headline with service + city",
  "subtitle": "value proposition subtitle",
  "cta_button": "Get Your Free Estimate",
  "trust_line": "✓ Licensed ✓ Insured ✓ Free Estimates",
  "intro": "2-3 paragraphs (150-200 words)",
  "benefits_title": "Why Homeowners Choose Us",
  "benefits": [
    {"benefit_title": "title", "benefit_desc": "1-2 sentences"},
    {"benefit_title": "title", "benefit_desc": "1-2 sentences"},
    {"benefit_title": "title", "benefit_desc": "1-2 sentences"},
    {"benefit_title": "title", "benefit_desc": "1-2 sentences"}
  ],
  "process_title": "How It Works",
  "steps": [
    {"step_title": "Step 1", "step_desc": "description"},
    {"step_title": "Step 2", "step_desc": "description"},
    {"step_title": "Step 3", "step_desc": "description"}
  ],
  "testimonials": [
    {"testimonial_text": "review text", "testimonial_author": "Name — City"},
    {"testimonial_text": "review text", "testimonial_author": "Name — City"}
  ],
  "faqs": [
    {"question": "question?", "answer": "answer"},
    {"question": "question?", "answer": "answer"},
    {"question": "question?", "answer": "answer"}
  ],
  "cta_title": "Ready to Transform Your Home?",
  "cta_text": "line about urgency",
  "cta_button_final": "Call Now: [phone]",
  "internal_links": [{"anchor":"phrase","url":"URL"}]
}',

            'what_we_do' => '{
  "hero_title": "Our Kitchen Remodeling Projects",
  "hero_subtitle": "Award-winning kitchen transformations across Baltimore County and Howard County",
  "specialties": ["Specialty 1", "Specialty 2", "Specialty 3", "Specialty 4", "Specialty 5"],
  "stats": [
    {"value": "45+", "label": "Projects completed"},
    {"value": "4.9", "label": "Google rating"},
    {"value": "6-8 wk", "label": "Typical timeline"}
  ],
  "intro_p1": "2-3 sentences overview of what visitors will see on this page — the gallery of completed projects. Mention the brand and service areas.",
  "intro_p2": "2-3 sentences about the design-build approach and that every project shown was handled in-house.",
  "image_featured": "3-4 word search for the best hero image e.g. modern kitchen remodel",
  "image_2": "different angle e.g. kitchen island countertop",
  "image_3": "another aspect e.g. custom kitchen cabinets",
  "image_4": "another aspect e.g. kitchen lighting fixtures",
  "image_5": "another aspect e.g. kitchen tile backsplash",
  "image_6": "another aspect e.g. kitchen sink faucet",
  "image_7": "another aspect e.g. open concept kitchen",
  "ba_1": "before and after kitchen remodel",
  "ba_2": "before after kitchen renovation",
  "ba_3": "before and after kitchen upgrade",
  "ba_4": "before after kitchen makeover",
  "about_heading": "What we can do for your [service type]",
  "about_p1": "2-3 sentences about the RANGE of work — from small updates to full renovations. Do NOT describe the process or materials (that is on the detailed service page).",
  "about_p2": "2-3 sentences encouraging visitors to view the full service details and request an estimate. Mention phone number.",
  "service_url": "/services/kitchens/",
  "cta_title": "Ready to transform your kitchen?",
  "cta_text": "Call [phone] or request a free in-home consultation in [service areas].",
  "cta_button": "Get a Free Estimate",
  "meta_description": "155 chars SEO meta description focusing on visual showcase and gallery"
}',
            'local_landing' => '{
  "city": "City Name",
  "county": "County Name",
  "state_abbr": "MD",
  "hero_title": "[Brand] in [City], [State] — Trusted [Industry] Contractor",
  "hero_subtitle": "Serving [City] and [County] homeowners since [year]",
  "stats": [
    {"value": "20+", "label": "Years Serving [City]"},
    {"value": "150+", "label": "Projects Completed"},
    {"value": "4.9", "label": "Google Rating"},
    {"value": "100%", "label": "Licensed & Insured"}
  ],
  "intro_p1": "3-4 sentences about why [City] homeowners choose [Brand]. Mention specific neighborhoods and streets.",
  "intro_p2": "3-4 sentences about local expertise, county permits, building codes, and what makes this area unique.",
  "intro_p3": "2-3 sentences about the types of projects popular in [City] and an invitation to explore services below.",
  "services_in_area": [
    {"name": "Service Name", "slug": "/what-we-do/service-slug/", "description": "2-3 sentences about this service specifically in [City]. Local angle."},
    {"name": "Service Name", "slug": "/what-we-do/service-slug/", "description": "2-3 sentences."},
    {"name": "Service Name", "slug": "/what-we-do/service-slug/", "description": "2-3 sentences."},
    {"name": "Service Name", "slug": "/what-we-do/service-slug/", "description": "2-3 sentences."},
    {"name": "Service Name", "slug": "/what-we-do/service-slug/", "description": "2-3 sentences."},
    {"name": "Service Name", "slug": "/what-we-do/service-slug/", "description": "2-3 sentences."}
  ],
  "projects": [
    {"type": "Service Type", "title": "Project title in [City]", "description": "2-3 sentences about this completed project: scope, timeline, results."},
    {"type": "Service Type", "title": "Project title", "description": "2-3 sentences."},
    {"type": "Service Type", "title": "Project title", "description": "2-3 sentences."}
  ],
  "local_expertise": {
    "heading": "Why [City] Homeowners Trust [Brand]",
    "reasons": [
      {"title": "reason title", "text": "3-4 sentences with specific local details about why this matters in [City]"},
      {"title": "reason title", "text": "3-4 sentences"},
      {"title": "reason title", "text": "3-4 sentences"},
      {"title": "reason title", "text": "3-4 sentences"}
    ]
  },
  "neighborhoods_intro": "2-3 sentences about the range of neighborhoods in [City] and the types of homes in each area.",
  "neighborhoods": ["Neighborhood 1", "Neighborhood 2", "Neighborhood 3", "Neighborhood 4", "Neighborhood 5", "Neighborhood 6", "Neighborhood 7", "Neighborhood 8"],
  "nearby_areas": [
    {"name": "Nearby City 1", "url": "/service-areas/nearby-city-state/", "distance": "X miles from [City]"},
    {"name": "Nearby City 2", "url": "/service-areas/nearby-city-state/", "distance": "X miles from [City]"},
    {"name": "Nearby City 3", "url": "/service-areas/nearby-city-state/", "distance": "X miles from [City]"}
  ],
  "faqs": [
    {"question": "Location-specific question about permits, costs in [City]?", "answer": "80-100 word answer with specific local details"},
    {"question": "question?", "answer": "80-100 word answer"},
    {"question": "question?", "answer": "80-100 word answer"},
    {"question": "question?", "answer": "80-100 word answer"},
    {"question": "question?", "answer": "80-100 word answer"},
    {"question": "question?", "answer": "80-100 word answer"}
  ],
  "cta_title": "Ready to Start Your [City] Home Project?",
  "cta_text": "Contact [Brand] for a free in-home consultation in [City] and [County]. Call [phone] or visit our office.",
  "cta_button": "Get a Free Estimate",
  "meta_description": "155 chars max SEO meta description with [City] and primary keyword",
  "internal_links": [{"anchor":"service phrase","url":"/what-we-do/slug/"},{"anchor":"phrase","url":"URL"},{"anchor":"phrase","url":"URL"},{"anchor":"phrase","url":"URL"},{"anchor":"phrase","url":"URL"},{"anchor":"phrase","url":"URL"}]
}',
            'blog_post' => '{
  "title": "SEO-optimized article title",
  "category": "HOME IMPROVEMENT",
  "author": "brand name or author",
  "read_time": "number",
  "hook": "compelling opening hook paragraph (2-3 sentences)",
  "image_1_search": "2-3 word search for hero image matching the article topic, e.g. kitchen remodeling",
  "image_2_search": "2-3 word search for mid-article image, DIFFERENT aspect of the topic",
  "image_3_search": "2-3 word search for bottom image, ANOTHER DIFFERENT angle",
  "sections": [
    {"heading": "H2 heading", "content": "3-5 paragraphs (200-300 words)"},
    {"heading": "H2 heading", "content": "3-5 paragraphs (200-300 words)"},
    {"heading": "H2 heading", "content": "3-5 paragraphs (200-300 words)"},
    {"heading": "H2 heading", "content": "2-3 paragraphs (150-200 words)"}
  ],
  "takeaways": [
    {"takeaway": "key point 1"},
    {"takeaway": "key point 2"},
    {"takeaway": "key point 3"},
    {"takeaway": "key point 4"}
  ],
  "faqs": [
    {"question": "question?", "answer": "answer"},
    {"question": "question?", "answer": "answer"},
    {"question": "question?", "answer": "answer"}
  ],
  "cta_title": "Need Help With [Topic]?",
  "cta_text": "contact line",
  "cta_button": "Get a Free Estimate",
  "internal_links": [{"anchor":"phrase","url":"URL"},{"anchor":"phrase","url":"URL"},{"anchor":"phrase","url":"URL"},{"anchor":"phrase","url":"URL"}]
}',
        ];

        return $schemas[$key] ?? '{}';
    }

    /**
     * Split long paragraphs into readable 2-3 sentence chunks
     */
    private function split_long_paragraphs($html) {
        // Split long <p> tags (over 250 chars) into multiple <p> tags
        $html = preg_replace_callback('/<p([^>]*)>(.*?)<\/p>/s', function($m) {
            $attrs = $m[1];
            $text = $m[2];
            if (strlen(strip_tags($text)) < 250) return $m[0]; // Short enough, leave it

            $sentences = preg_split('/(?<=[.!?])\s+/', $text, -1, PREG_SPLIT_NO_EMPTY);
            if (count($sentences) <= 3) return $m[0]; // Already short enough

            $paragraphs = [];
            $chunk = [];
            foreach ($sentences as $s) {
                $chunk[] = $s;
                if (count($chunk) >= 3) {
                    $paragraphs[] = '<p' . $attrs . '>' . implode(' ', $chunk) . '</p>';
                    $chunk = [];
                }
            }
            if (!empty($chunk)) {
                $paragraphs[] = '<p' . $attrs . '>' . implode(' ', $chunk) . '</p>';
            }
            return implode("\n", $paragraphs);
        }, $html);

        // Split long <div class="sp-detail-text"> content into <p> tags
        $html = preg_replace_callback('/<div class="sp-detail-text"([^>]*)>(.*?)<\/div>/s', function($m) {
            $attrs = $m[1];
            $text = $m[2];
            if (strlen(strip_tags($text)) < 200) {
                return '<div class="sp-detail-text"' . $attrs . '><p>' . $text . '</p></div>';
            }

            $sentences = preg_split('/(?<=[.!?])\s+/', trim($text), -1, PREG_SPLIT_NO_EMPTY);
            $paragraphs = [];
            $chunk = [];
            foreach ($sentences as $s) {
                $chunk[] = $s;
                if (count($chunk) >= 2) {
                    $paragraphs[] = '<p>' . implode(' ', $chunk) . '</p>';
                    $chunk = [];
                }
            }
            if (!empty($chunk)) {
                $paragraphs[] = '<p>' . implode(' ', $chunk) . '</p>';
            }
            return '<div class="sp-detail-text"' . $attrs . '>' . implode("\n", $paragraphs) . '</div>';
        }, $html);

        return $html;
    }

    /**
     * Lighten/tint a hex color
     */
    private function lighten_color($hex, $factor) {
        $hex = ltrim($hex, '#');
        if (strlen($hex) !== 6) return '#' . $hex;
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        $r = round($r + (255 - $r) * $factor);
        $g = round($g + (255 - $g) * $factor);
        $b = round($b + (255 - $b) * $factor);
        return '#' . str_pad(dechex(min(255, $r)), 2, '0', STR_PAD_LEFT)
                    . str_pad(dechex(min(255, $g)), 2, '0', STR_PAD_LEFT)
                    . str_pad(dechex(min(255, $b)), 2, '0', STR_PAD_LEFT);
    }

    private function is_light_color($hex) {
        $hex = ltrim($hex, '#');
        if (strlen($hex) !== 6) return false;
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        // Perceived luminance (ITU-R BT.709)
        $lum = (0.2126 * $r + 0.7152 * $g + 0.0722 * $b) / 255;
        return $lum > 0.5;
    }
}
