<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Crawl_Depth {

    /**
     * Analyze crawl depth of all pages from homepage
     * Uses BFS from homepage following internal links
     */
    public function analyze() {
        $types     = get_option( 'sseo_post_types', ['post','page'] );
        $all       = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>-1]);
        $site_host = wp_parse_url( home_url(), PHP_URL_HOST );
        $home_path = wp_parse_url( home_url('/'), PHP_URL_PATH ) ?: '/';

        // Build page data: path → ID and adjacency list
        $path_to_id = [];
        $id_to_path = [];
        $id_to_post = [];
        foreach ( $all as $p ) {
            $url  = get_permalink( $p->ID );
            $path = rtrim( wp_parse_url( $url, PHP_URL_PATH ) ?: '', '/' ) ?: '/';
            $path_to_id[ $path ] = $p->ID;
            $id_to_path[ $p->ID ] = $path;
            $id_to_post[ $p->ID ] = $p;
        }

        // Build adjacency: which pages link to which
        $links_from = []; // ID => [target IDs]
        foreach ( $all as $p ) {
            $links_from[ $p->ID ] = [];
            if ( preg_match_all( '/href=["\']([^"\'#]+)["\']/i', $p->post_content, $matches ) ) {
                foreach ( $matches[1] as $href ) {
                    $parsed = wp_parse_url( $href );
                    $host   = $parsed['host'] ?? '';
                    $is_internal = empty($host) || $host === $site_host || $host === 'www.'.$site_host;
                    if ( ! $is_internal ) continue;

                    $target_path = rtrim( $parsed['path'] ?? $href, '/' ) ?: '/';
                    if ( isset( $path_to_id[$target_path] ) ) {
                        $tid = $path_to_id[$target_path];
                        if ( $tid !== $p->ID ) $links_from[$p->ID][] = $tid;
                    }
                }
            }
        }

        // Also add menu links as depth-1 connections from homepage
        $menus = get_nav_menu_locations();
        $menu_items_ids = [];
        foreach ( $menus as $location => $menu_id ) {
            $items = wp_get_nav_menu_items( $menu_id );
            if ( ! $items ) continue;
            foreach ( $items as $item ) {
                if ( $item->object_id && isset($id_to_path[(int)$item->object_id]) ) {
                    $menu_items_ids[] = (int)$item->object_id;
                }
            }
        }

        // BFS from homepage
        $home_id = null;
        $front_page = get_option('page_on_front');
        if ( $front_page && isset($id_to_path[$front_page]) ) {
            $home_id = $front_page;
        } elseif ( isset($path_to_id['/']) ) {
            $home_id = $path_to_id['/'];
        }

        $depth    = []; // ID => click depth
        $visited  = [];
        $queue    = [];

        // Seed: homepage at depth 0
        if ( $home_id ) {
            $depth[$home_id] = 0;
            $visited[$home_id] = true;
            $queue[] = $home_id;
        }

        // Seed: all menu items at depth 1
        foreach ( $menu_items_ids as $mid ) {
            if ( ! isset($visited[$mid]) ) {
                $depth[$mid] = 1;
                $visited[$mid] = true;
                $queue[] = $mid;
            }
        }

        // BFS
        while ( ! empty($queue) ) {
            $current = array_shift($queue);
            $cd = $depth[$current];
            foreach ( ($links_from[$current] ?? []) as $neighbor ) {
                if ( ! isset($visited[$neighbor]) ) {
                    $depth[$neighbor] = $cd + 1;
                    $visited[$neighbor] = true;
                    $queue[] = $neighbor;
                }
            }
        }

        // Any page not reached = infinite depth (truly orphaned from nav)
        foreach ( $all as $p ) {
            if ( ! isset($depth[$p->ID]) ) {
                $depth[$p->ID] = 999; // unreachable
            }
        }

        // Build results
        $pages = [];
        $depth_dist = [0=>0,1=>0,2=>0,3=>0,4=>0,'5+'=>0,'unreachable'=>0];
        foreach ( $all as $p ) {
            $d = $depth[$p->ID];
            if ( $d === 999 ) {
                $depth_dist['unreachable']++;
            } elseif ( $d >= 5 ) {
                $depth_dist['5+']++;
            } else {
                $depth_dist[$d]++;
            }

            $pages[] = [
                'post_id'       => $p->ID,
                'title'         => $p->post_title,
                'permalink'     => get_permalink($p->ID),
                'post_type'     => $p->post_type,
                'depth'         => $d === 999 ? 'unreachable' : $d,
                'outbound_links'=> count($links_from[$p->ID] ?? []),
                'in_menu'       => in_array($p->ID, $menu_items_ids),
            ];
        }

        // Sort deepest first
        usort($pages, function($a,$b){
            $da = $a['depth']==='unreachable'?999:$a['depth'];
            $db = $b['depth']==='unreachable'?999:$b['depth'];
            return $db - $da;
        });

        return [
            'pages'         => $pages,
            'distribution'  => $depth_dist,
            'total'         => count($all),
            'deep_pages'    => count(array_filter($pages, function($p){ return $p['depth']==='unreachable'||$p['depth']>=5; })),
            'avg_depth'     => $this->avg_depth($depth),
        ];
    }

    private function avg_depth( $depths ) {
        $valid = array_filter($depths, function($d){ return $d < 999; });
        return empty($valid) ? 0 : round( array_sum($valid) / count($valid), 1 );
    }

    /**
     * Add "Related Posts" section to a post to flatten its depth
     */
    public function add_related_section( $post_id, $count = 3 ) {
        $post = get_post($post_id);
        if (!$post) return new WP_Error('no_post','Not found.');

        $types = get_option('sseo_post_types', ['post','page']);
        $cats  = wp_get_post_categories($post_id, ['fields'=>'ids']);
        $tags  = wp_get_post_tags($post_id, ['fields'=>'ids']);

        $args = ['post_type'=>$types,'post_status'=>'publish','numberposts'=>$count,'exclude'=>[$post_id]];
        if ($cats) $args['category__in'] = $cats;

        $related = get_posts($args);
        if (empty($related)) {
            $related = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>$count,'exclude'=>[$post_id],'orderby'=>'rand']);
        }
        if (empty($related)) return new WP_Error('no_related','No related posts found.');

        $html = "\n\n<h3>Related Articles</h3>\n<ul>\n";
        foreach ($related as $r) {
            $html .= '<li><a href="' . get_permalink($r->ID) . '">' . esc_html($r->post_title) . '</a></li>' . "\n";
        }
        $html .= "</ul>";

        // Check if already has related section
        if (strpos($post->post_content, 'Related Articles</h3>') !== false) {
            return new WP_Error('exists','Related section already exists.');
        }

        $content = $post->post_content . $html;
        wp_update_post(['ID'=>$post_id,'post_content'=>$content]);

        global $wpdb;
        $wpdb->insert($wpdb->prefix.'sseo_log',['post_id'=>$post_id,'type'=>'crawl','old_value'=>'added related section','new_value'=>count($related).' links']);

        return ['post_id'=>$post_id,'links_added'=>count($related)];
    }
}
