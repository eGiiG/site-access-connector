<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Thin_Content {

    public function scan( $min_words = 300 ) {
        $types = get_option( 'sseo_post_types', ['post','page'] );
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>-1]);
        $ignored = get_option( 'sseo_thin_ignored', [] );
        $thin = [];

        foreach ( $posts as $p ) {
            if ( in_array( $p->ID, $ignored ) ) continue;
            $text = wp_strip_all_tags( $p->post_content );
            $wc   = str_word_count( $text );
            $target = ( $p->post_type === 'page' ) ? 500 : 300;

            if ( $wc < $min_words ) {
                // Determine severity
                $severity = 'notice';
                if ( $wc < 100 )     $severity = 'critical';
                elseif ( $wc < 200 ) $severity = 'warning';

                // Check text-to-HTML ratio
                $html_len = mb_strlen( $p->post_content );
                $text_len = mb_strlen( $text );
                $ratio = $html_len > 0 ? round( ($text_len / $html_len) * 100, 1 ) : 0;

                $posts_page = (int) get_option('page_for_posts');
                $is_archive = ($p->ID === $posts_page);

                $thin[] = [
                    'post_id'    => $p->ID,
                    'title'      => $p->post_title,
                    'word_count' => $wc,
                    'target'     => $target,
                    'ratio'      => $ratio,
                    'severity'   => $severity,
                    'permalink'  => get_permalink( $p->ID ),
                    'post_type'  => $is_archive ? 'archive' : $p->post_type,
                    'is_archive' => $is_archive,
                ];
            }
        }

        // Sort by severity
        usort( $thin, function($a,$b) {
            $order = ['critical'=>0,'warning'=>1,'notice'=>2];
            return ($order[$a['severity']]??3) - ($order[$b['severity']]??3);
        });

        return $thin;
    }

    public function get_stats() {
        $types = get_option( 'sseo_post_types', ['post','page'] );
        $posts = get_posts(['post_type'=>$types,'post_status'=>'publish','numberposts'=>-1]);
        $ignored = get_option( 'sseo_thin_ignored', [] );
        $total = count($posts);
        $thin = 0; $ok = 0; $strong = 0;

        foreach ( $posts as $p ) {
            if ( in_array( $p->ID, $ignored ) ) { $total--; continue; }
            $wc = str_word_count( wp_strip_all_tags($p->post_content) );
            if ( $wc < 300 ) $thin++;
            elseif ( $wc >= 800 ) $strong++;
            else $ok++;
        }

        return compact( 'total', 'thin', 'ok', 'strong' );
    }
}
