<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Password-free reporting connection. The agency mints a pairing code on their platform; the site
 * owner pastes it here; this exchanges it for a per-site secret the platform then uses (as ?token=)
 * to pull the SEO snapshot — no WordPress user or Application Password involved.
 *
 * Override the platform URL in wp-config.php for white-label domains:
 *     define( 'SSEO_API_URL', 'https://apps.youragency.com' );
 */
if ( ! defined( 'SSEO_API_DEFAULT' ) ) define( 'SSEO_API_DEFAULT', 'https://api.egiig.com' );

if ( ! function_exists( 'sseo_api_base' ) ) {
    function sseo_api_base() {
        return defined( 'SSEO_API_URL' ) ? SSEO_API_URL : ( get_option( 'sseo_connect_api' ) ?: SSEO_API_DEFAULT );
    }
}

if ( ! function_exists( 'sseo_connect_secret' ) ) {
    function sseo_connect_secret() { return (string) get_option( 'sseo_connect_secret', '' ); }
}

if ( ! function_exists( 'sseo_is_connected' ) ) {
    function sseo_is_connected() { return (bool) get_option( 'sseo_connect_paired' ) && sseo_connect_secret() !== ''; }
}

/** True when a REST request carries the paired reporting token (constant-time compare). */
if ( ! function_exists( 'sseo_rest_token_ok' ) ) {
    function sseo_rest_token_ok( $req ) {
        $s = sseo_connect_secret();
        if ( $s === '' ) return false;
        $t = is_object( $req ) ? (string) $req->get_param( 'token' ) : '';
        return $t !== '' && hash_equals( $s, $t );
    }
}

/** Exchange a pairing code for a per-site reporting secret with the platform. Returns true or WP_Error. */
if ( ! function_exists( 'sseo_do_connect' ) ) {
    function sseo_do_connect( $code ) {
        $code = strtoupper( trim( (string) $code ) );
        if ( $code === '' ) return new WP_Error( 'sseo_empty', 'Please enter your connection code.' );

        $secret = wp_generate_password( 48, false, false );
        $resp = wp_remote_post( trailingslashit( sseo_api_base() ) . 'api/wp-plugin/seo-pair', [
            'timeout' => 20,
            'headers' => [ 'Content-Type' => 'application/json', 'Accept' => 'application/json' ],
            'body'    => wp_json_encode( [
                'pair_code' => $code,
                'site_url'  => home_url(),
                'site_name' => get_bloginfo( 'name' ),
                'secret'    => $secret,
            ] ),
        ] );
        if ( is_wp_error( $resp ) ) {
            $m = $resp->get_error_message();
            // [connection-key v1] Hosting that blocks outgoing connections: point to the connection key,
            // where the agency connects to the site and nothing has to leave this server.
            if ( preg_match( '/cURL error (6|7|28|35)\b|timed out|could not resolve|failed to connect/i', $m ) ) {
                return new WP_Error( 'sseo_net_blocked', 'This site could not reach ' . wp_parse_url( sseo_api_base(), PHP_URL_HOST ) . '. The hosting is blocking outgoing connections. Use a connection key instead (below): your agency connects to this site, so nothing has to leave this server.' );
            }
            return new WP_Error( 'sseo_net', 'Connection failed: ' . $m );
        }
        $status = wp_remote_retrieve_response_code( $resp );
        $body   = json_decode( wp_remote_retrieve_body( $resp ), true );
        if ( $status !== 200 || empty( $body['ok'] ) ) {
            return new WP_Error( 'sseo_pair', ! empty( $body['message'] ) ? $body['message'] : 'That connection code was not accepted. Ask your agency for a fresh code.' );
        }

        update_option( 'sseo_connect_secret', $secret );
        update_option( 'sseo_connect_paired', 1 );
        update_option( 'sseo_provider', 'platform' );   // paired -> use the agency's platform AI, no per-site key
        if ( ! empty( $body['brand'] ) ) update_option( 'sseo_whitelabel_name', sanitize_text_field( $body['brand'] ) );

        // Stealth: the agency can ask, at connect time, that this site hide the SEO tool menu from the
        // client while the platform keeps driving the work over REST. Only sets it when the key is present.
        if ( array_key_exists( 'stealth', $body ) ) update_option( 'sseo_stealth', $body['stealth'] ? 1 : 0 );

        // Lock the plugin admin to the agency: store the agency-wide access password (hashed) and turn the
        // lock on, so the client cannot open the plugin. The agency is the one pairing, so the plaintext is
        // returned once for the connect UI to display.
        $lock = isset( $body['lock_password'] ) ? (string) $body['lock_password'] : '';
        if ( $lock !== '' ) {
            update_option( 'sseo_plugin_password', wp_hash_password( $lock ) );
            update_option( 'sseo_lock_enabled', 1 );
        }
        do_action( 'sseo_connected', $body ); // [site-manager v1] Site Manager registers its signing key
        return [ 'lock_password' => $lock ];
    }
}

if ( ! function_exists( 'sseo_do_disconnect' ) ) {
    function sseo_do_disconnect() {
        delete_option( 'sseo_connect_secret' );
        delete_option( 'sseo_connect_paired' );
        do_action( 'sseo_disconnected' ); // [site-manager v1]
    }
}
