<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SEO Page Templates — generates full page content as WordPress drafts
 * Compatible with Gutenberg, Elementor, Divi, Thrive, or any editor
 * Local mode weaves in geo-keywords + schema throughout
 */
class SSEO_Page_Templates {

    private static $templates = [
        'service_page' => [
            'name'  => 'Service Page',
            'desc'  => 'Individual service page with benefits, process, FAQ, CTA',
            'scope' => 'local',
            'icon'  => '🔧',
        ],
        'about_us' => [
            'name'  => 'About Us',
            'desc'  => 'Company story, team, values, credentials, service area',
            'scope' => 'local',
            'icon'  => '🏢',
        ],
        'contact' => [
            'name'  => 'Contact Page',
            'desc'  => 'Full NAP, form placeholder, map embed, hours, service areas',
            'scope' => 'local',
            'icon'  => '📞',
        ],
        'faq_page' => [
            'name'  => 'FAQ Page',
            'desc'  => 'Question/answer format with FAQ schema auto-detected',
            'scope' => 'both',
            'icon'  => '❓',
        ],
        'service_area' => [
            'name'  => 'Service Area Page',
            'desc'  => 'Styled local landing page: service cards linking to pillar pages, stats, projects, testimonials, neighborhoods, nearby areas, FAQ',
            'scope' => 'local',
            'icon'  => '📍',
        ],
        'local_landing' => [
            'name'  => 'Local Landing Page',
            'desc'  => 'Same as Service Area — dedicated geo page with full design: stats bar, service cards, projects, testimonials, neighborhoods, FAQ',
            'scope' => 'local',
            'icon'  => '🗺️',
        ],
        'what_we_do' => [
            'name'  => 'What We Do (Gallery)',
            'desc'  => 'Visual showcase: project gallery, before/after, stats, testimonials — links to detailed /services/ page. No process or FAQ.',
            'scope' => 'local',
            'icon'  => '🖼️',
        ],
        'landing_page' => [
            'name'  => 'Landing Page',
            'desc'  => 'Conversion-focused with hero, benefits, testimonials, CTA',
            'scope' => 'both',
            'icon'  => '🎯',
        ],
        'blog_post' => [
            'name'  => 'Blog Post',
            'desc'  => 'SEO-optimized article with proper heading structure',
            'scope' => 'both',
            'icon'  => '📝',
        ],
        'testimonials' => [
            'name'  => 'Testimonials Page',
            'desc'  => 'Customer reviews with Review schema markup',
            'scope' => 'local',
            'icon'  => '⭐',
        ],
        'gallery' => [
            'name'  => 'Portfolio / Gallery',
            'desc'  => 'Project showcase with descriptions, before/after',
            'scope' => 'local',
            'icon'  => '🖼️',
        ],
        'privacy_policy' => [
            'name'  => 'Privacy Policy',
            'desc'  => 'GDPR/CCPA-ready privacy policy based on your business data',
            'scope' => 'both',
            'icon'  => '🔒',
        ],
        'terms_of_service' => [
            'name'  => 'Terms of Service',
            'desc'  => 'Legal terms covering your services, liability, payments',
            'scope' => 'both',
            'icon'  => '📜',
        ],
        'pricing' => [
            'name'  => 'Pricing / Services List',
            'desc'  => 'Service packages with descriptions and CTAs',
            'scope' => 'both',
            'icon'  => '💰',
        ],
    ];

    public static function get_templates() {
        return self::$templates;
    }

    /**
     * Generate page content using AI
     */
    public function generate( $template_key, $params = [] ) {
        // Service Area pages use the styled Local Landing template from Template Engine
        if ( $template_key === 'service_area' || $template_key === 'local_landing' || $template_key === 'what_we_do' ) {
            $engine = new SSEO_Template_Engine();
            $topic = $params['topic'] ?? 'Service Area';
            $city = $params['city'] ?? get_option('sseo_business_city', '');
            if ($city && $template_key !== 'what_we_do' && stripos($topic, $city) === false) {
                $topic = $topic . ' in ' . $city;
            }

            // Map template key to engine template
            $engine_key = ($template_key === 'what_we_do') ? 'what_we_do' : 'local_landing';

            $r = $engine->generate(
                $engine_key,
                $topic,
                $params['keywords'] ?? '',
                'local',
                (int)($params['word_count'] ?? 1200),
                $params['custom_prompt'] ?? ''
            );

            // If Template Engine succeeds, return styled result
            if (!is_wp_error($r) && !empty($r['html'])) {
                return [
                    'html'     => $r['html'],
                    'title'    => $r['title'] ?? $topic,
                    'meta'     => $r['data']['meta_description'] ?? '',
                    'template' => 'service_area',
                    'tokens'   => $r['tokens'] ?? 0,
                    'type'     => 'page',
                    'engine'   => 'local_landing_v2',
                ];
            }

            // If Template Engine fails, fall through to the old prompt-based generation below
            // so the user at least gets SOME content
            error_log('[Samar SEO] Local landing template failed for "' . $topic . '": ' . (is_wp_error($r) ? $r->get_error_message() : 'empty HTML'));
        }

        $api   = new SSEO_API_Handler();
        $tmpl  = self::$templates[$template_key] ?? null;
        if ( ! $tmpl ) return new WP_Error('invalid','Unknown template.');

        $brand    = get_option('sseo_brand_name', get_bloginfo('name'));
        $phone    = get_option('sseo_business_phone','');
        $address  = get_option('sseo_business_address','');
        $city     = get_option('sseo_business_city','');
        $state    = get_option('sseo_business_state','');
        $zip      = get_option('sseo_business_zip','');
        $email    = get_option('sseo_business_email','');
        $loc      = get_option('sseo_target_location','');
        $services = get_option('sseo_business_services','');
        $hours    = get_option('sseo_business_hours','');
        $btype    = get_option('sseo_business_type','LocalBusiness');

        $scope    = $params['scope'] ?? 'local';
        $topic    = $params['topic'] ?? $tmpl['name'];
        $keywords = $params['keywords'] ?? '';
        $city_target = $params['city'] ?? $city;
        $custom_prompt = $params['custom_prompt'] ?? '';
        $word_count = (int)($params['word_count'] ?? 800);

        // Build context
        $local_context = '';
        if ( $scope === 'local' ) {
            $local_context = "
LOCAL SEO REQUIREMENTS (this is a LOCAL business page):
- Brand: {$brand}
- Phone: {$phone}
- Address: {$address}, {$city}, {$state} {$zip}
- Target City: {$city_target}
- Service Areas: {$loc}
- Services: {$services}
- Business Hours: {$hours}
- Business Type: {$btype}

CRITICAL LOCAL RULES:
- Mention '{$city_target}' and service areas naturally 3-5 times throughout
- Include the full address and phone number in the content
- Use geo-modified keywords (e.g. 'kitchen remodeling {$city_target}' not just 'kitchen remodeling')
- Add a 'Service Area' section listing cities served
- Include phrases like 'serving {$loc}' or 'your trusted {$city_target} contractor'
- Write a CTA with phone number: 'Call {$brand} at {$phone}'
";
        }

        $template_instructions = $this->get_template_prompt($template_key, $topic, $scope);

        $prompt = "You are an expert SEO content writer. Generate a complete, publish-ready page using clean HTML.

TEMPLATE TYPE: {$tmpl['name']}
TOPIC/SERVICE: {$topic}
" . ($keywords ? "TARGET KEYWORDS: {$keywords}\n" : '') . "
SCOPE: " . strtoupper($scope) . "
WORD COUNT: approximately {$word_count} words
{$local_context}
{$template_instructions}
" . ($custom_prompt ? "\nADDITIONAL INSTRUCTIONS: {$custom_prompt}\n" : '') . "

FORMAT RULES:
- Output ONLY valid semantic HTML — no markdown, no code fences
- Use: h1, h2, h3, p, ul, ol, strong, em, blockquote, a
- No html/head/body/style/script tags. No inline styles. No CSS classes.
- Start with ONE h1 tag
- Add [IMAGE: description] placeholders where images should go
- For FAQ sections use H3 ending with ? for schema detection
- Insert 3-8 internal <a href> links with 2-4 word anchor text
- Write engaging, authoritative, conversion-focused content
- Include at least one clear CTA section with phone number

Return ONLY the HTML content.";

        $r = $api->complete($prompt, 0.7);
        if (is_wp_error($r)) return $r;

        $html = $r['content'];
        $html = preg_replace('/^```(?:html)?\s*/i','',trim($html));
        $html = preg_replace('/\s*```$/i','',$html);

        // Extract H1 for title
        $page_title = $topic;
        if (preg_match('/<h1[^>]*>(.*?)<\/h1>/is', $html, $h1m)) {
            $page_title = wp_strip_all_tags($h1m[1]);
        }

        // Generate meta description
        $meta_prompt = "Write a 150-160 character SEO meta description for this page. Topic: {$topic}. Business: {$brand}." . ($scope==='local'?" Location: {$city_target}.":'') . " Return ONLY the meta description text, nothing else.";
        $meta_r = $api->complete($meta_prompt, 0.5);
        $meta_desc = is_wp_error($meta_r) ? '' : trim($meta_r['content']);
        $meta_desc = preg_replace('/^["\']+|["\']+$/','',$meta_desc);

        // Auto-match images from media library
        $gen = new SSEO_Content_Generator();
        $match_result = $gen->auto_match_images($html, $keywords ?: $topic);
        $html = $match_result['content'];

        return [
            'html'       => $html,
            'title'      => $page_title,
            'meta'       => $meta_desc,
            'template'   => $template_key,
            'scope'      => $scope,
            'topic'      => $topic,
            'keywords'   => $keywords,
            'word_count' => str_word_count(wp_strip_all_tags($html)),
            'tokens'     => $r['tokens'] + ($meta_r['tokens'] ?? 0),
            'images_matched'   => $match_result['matched'],
            'images_remaining' => $match_result['remaining'],
        ];
    }

    /**
     * Save generated content as WordPress draft
     */
    public function save_as_draft( $data ) {
        $post_type = in_array($data['template'], ['blog_post']) ? 'post' : 'page';
        $seo = new SSEO_SEO_Integration();

        // Strip AI template artifacts before publishing
        $data['html'] = SSEO_Content_Generator::clean_for_publish($data['html']);

        // Admins can save full HTML including <style>/<script> from templates
        $safe_content = current_user_can('unfiltered_html') ? $data['html'] : wp_kses_post($data['html']);

        $post_id = wp_insert_post([
            'post_title'   => sanitize_text_field($data['title']),
            'post_content' => $safe_content,
            'post_status'  => 'publish',
            'post_type'    => $post_type,
        ]);

        if (is_wp_error($post_id)) return $post_id;

        // Auto-set featured image from first image in content
        (new SSEO_Content_Generator())->set_featured_from_content($post_id, $data['html']);

        // Apply meta description
        if (!empty($data['meta'])) {
            $seo->set_meta($post_id, sanitize_text_field($data['meta']));
        }

        // Mark service pages for schema
        if (in_array($data['template'], ['service_page','service_area','pricing','local_landing'])) {
            update_post_meta($post_id, '_sseo_is_service_page', 1);
        }

        // Local landing pages also get LocalBusiness schema
        if ($data['template'] === 'local_landing') {
            update_post_meta($post_id, '_sseo_local_schema', 1);
        }

        // Log
        global $wpdb;
        $log_table = $wpdb->prefix . 'sseo_log';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$log_table}'") === $log_table) {
            $wpdb->insert($log_table, [
                'post_id'   => $post_id,
                'type'      => 'template',
                'old_value' => $data['template'] . ' (' . $data['scope'] . ')',
                'new_value' => $data['title'],
            ]);
        }

        return [
            'post_id'  => $post_id,
            'edit_url' => get_edit_post_link($post_id, 'raw'),
            'title'    => $data['title'],
            'type'     => $post_type,
        ];
    }

    private function get_template_prompt($key, $topic, $scope) {
        $prompts = [
            'service_page' => "Create a SERVICE PAGE for: {$topic}
Structure: H1 title → intro paragraph → H2 'Why Choose Us' with 3-4 bullet benefits → H2 'Our Process' with numbered steps → H2 'What's Included' → H2 'Frequently Asked Questions' with 4-5 H3 questions ending in ? → H2 'Ready to Get Started?' CTA with phone",

            'about_us' => "Create an ABOUT US page.
Structure: H1 → intro paragraph about the company → H2 'Our Story' → H2 'Our Mission & Values' → H2 'Why Choose Us' with 4 differentiators → H2 'Our Service Area' listing cities → H2 'Credentials & Certifications' → H2 'Contact Us Today' CTA",

            'contact' => "Create a CONTACT PAGE.
Structure: H1 'Contact Us' → intro → H2 'Get In Touch' with full address, phone, email displayed prominently → paragraph saying 'Fill out the form below' (placeholder for form) → H2 'Business Hours' → H2 'Our Service Area' → H2 'Visit Our Location' with [MAP PLACEHOLDER]",

            'faq_page' => "Create a FAQ PAGE about: {$topic}
Structure: H1 → intro paragraph → 8-12 H3 questions (MUST end with ?) each followed by a <p> answer. Questions should be real things customers ask. Include a mix of service, pricing, process, and area questions. End with H2 CTA.",

            'service_area' => "Create a SERVICE AREA page for the target city.
Structure: H1 '{$topic} Services in [City]' → intro about serving that area → H2 'Services We Offer in [City]' → H2 'Why [City] Residents Choose Us' → H2 'Recent Projects in [City]' (placeholder) → H2 'Neighborhoods We Serve' listing specific areas → FAQ section → CTA",

            'landing_page' => "Create a high-conversion LANDING PAGE for: {$topic}
Structure: H1 headline with value prop → strong intro paragraph → H2 'Benefits' with 4-5 bullet points → H2 'How It Works' 3 steps → H2 'What Our Customers Say' (testimonial placeholders) → H2 'Frequently Asked Questions' 3-4 FAQ → H2 CTA with urgency",

            'blog_post' => "Create an SEO blog post about: {$topic}
Structure: H1 title → intro paragraph with hook → 4-6 H2 sections with detailed content → use H3 for subsections where needed → include at least one list → conclude with H2 summary and CTA. Write informatively, not salesy.",

            'testimonials' => "Create a TESTIMONIALS page.
Structure: H1 'What Our Customers Say' → intro → 6-8 testimonial blocks, each with: customer name (fictional), location, star rating, and quote text in blockquote. End with H2 'Ready to Join Our Happy Customers?' CTA",

            'gallery' => "Create a PORTFOLIO / GALLERY page for: {$topic}
Structure: H1 → intro about showcasing work → 6-8 project entries, each with H3 project title, description paragraph, [IMAGE: before/after placeholder], and details like scope/timeline. End with H2 CTA",

            'privacy_policy' => "Create a comprehensive PRIVACY POLICY page for: {$topic}
Structure: H1 'Privacy Policy' → H2 'Information We Collect' (what data: forms, cookies, analytics) → H2 'How We Use Your Information' (purpose: service delivery, communication, improvement) → H2 'Information Sharing' (third parties, legal requirements) → H2 'Data Security' → H2 'Cookies & Tracking' → H2 'Your Rights' (access, deletion, opt-out) → H2 'Children\'s Privacy' → H2 'Changes to This Policy' → H2 'Contact Us' with full business info.
IMPORTANT: Analyze the business type and services to make this SPECIFIC to what data this business actually collects. A construction company collects different data than an e-commerce store. Include the business name, address, phone, and email throughout. Reference actual services offered. Last updated date: today. This must read like a real legal document, not generic boilerplate.",

            'terms_of_service' => "Create comprehensive TERMS OF SERVICE for: {$topic}
Structure: H1 'Terms of Service' → H2 'Acceptance of Terms' → H2 'Services Description' (describe actual services offered) → H2 'Estimates & Pricing' (how quotes work, validity period) → H2 'Payment Terms' (deposits, schedules, methods) → H2 'Project Timeline & Delays' → H2 'Warranties & Guarantees' → H2 'Limitation of Liability' → H2 'Cancellation Policy' → H2 'Intellectual Property' → H2 'Dispute Resolution' → H2 'Governing Law' (state-specific) → H2 'Changes to Terms' → H2 'Contact Information' with full business details.
IMPORTANT: Tailor these terms to the SPECIFIC business type and services. A construction/remodeling company needs different terms than a consulting firm. Reference actual services, location, and licensing. Include the business name, address, phone, email. Last updated date: today. Write in clear, professional legal language.",

            'pricing' => "Create a PRICING / SERVICES page for: {$topic}
Structure: H1 → intro → 3-5 service tiers/packages, each with H2 name, description, what's included list, and a 'Get a Quote' CTA. End with H2 'Custom Solutions' and contact CTA. Don't include specific dollar amounts — say 'Contact for pricing'",
        ];

        return $prompts[$key] ?? "Create a professional page about: {$topic}";
    }
}
