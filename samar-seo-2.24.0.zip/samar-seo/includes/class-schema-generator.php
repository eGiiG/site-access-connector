<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Enhanced Schema Markup Generator
 * LocalBusiness (NAP, geo-coords, hours, service area, aggregate rating)
 * Service schema for /services/ and /what-we-do/ pages
 * BreadcrumbList sitewide
 * Article for blog posts
 * FAQPage auto-detected
 */
class SSEO_Schema_Generator {

    public function __construct() {
        if ( get_option('sseo_schema_enabled', 1) ) {
            add_action( 'wp_head', [ $this, 'output_schema' ], 1 );
        }
    }

    public function output_schema() {
        if ( is_front_page() || is_page('contact') || is_page('about') ) {
            $this->local_business();
        }
        // Per-page LocalBusiness schema toggle
        if ( is_singular() && get_post_meta( get_the_ID(), '_sseo_local_schema', true ) ) {
            $this->local_business();
        }
        if ( is_singular() ) {
            $this->breadcrumb();
            $this->service_schema();
            $this->article();
            $this->faq_schema();
        }
    }

    // ════════════════════════════════════════════
    // LocalBusiness — full NAP, geo, hours, rating
    // ════════════════════════════════════════════
    private function local_business() {
        $name    = get_option( 'sseo_brand_name', get_bloginfo('name') );
        $phone   = get_option( 'sseo_business_phone', '' );
        $address = get_option( 'sseo_business_address', '' );
        $city    = get_option( 'sseo_business_city', '' );
        $state   = get_option( 'sseo_business_state', '' );
        $zip     = get_option( 'sseo_business_zip', '' );
        $country = get_option( 'sseo_business_country', 'US' );
        $type    = get_option( 'sseo_business_type', 'LocalBusiness' );
        $loc     = get_option( 'sseo_target_location', '' );
        $lat     = get_option( 'sseo_business_lat', '' );
        $lng     = get_option( 'sseo_business_lng', '' );
        $email   = get_option( 'sseo_business_email', '' );
        $hours   = get_option( 'sseo_business_hours', '' );
        $founded = get_option( 'sseo_business_founded', '' );
        $license = get_option( 'sseo_business_license', '' );
        $services_list = get_option( 'sseo_business_services', '' );

        if ( ! $name ) return;

        $schema = [
            '@context' => 'https://schema.org',
            '@type'    => $type ?: 'LocalBusiness',
            '@id'      => home_url('/#localbusiness'),
            'name'     => $name,
            'url'      => home_url('/'),
        ];

        // Image/Logo
        $logo = get_site_icon_url();
        $custom_logo_id = get_theme_mod('custom_logo');
        if ( $custom_logo_id ) {
            $logo_url = wp_get_attachment_url( $custom_logo_id );
            if ( $logo_url ) $logo = $logo_url;
        }
        if ( $logo ) {
            $schema['image'] = $logo;
            $schema['logo']  = $logo;
        }

        // Contact
        if ( $phone ) $schema['telephone'] = $phone;
        if ( $email ) $schema['email'] = $email;

        // Full address
        if ( $address || $city ) {
            $addr = [ '@type' => 'PostalAddress' ];
            if ( $address ) $addr['streetAddress']   = $address;
            if ( $city )    $addr['addressLocality']  = $city;
            if ( $state )   $addr['addressRegion']    = $state;
            if ( $zip )     $addr['postalCode']       = $zip;
            if ( $country ) $addr['addressCountry']   = $country;
            $schema['address'] = $addr;
        }

        // Geo coordinates
        if ( $lat && $lng ) {
            $schema['geo'] = [
                '@type'     => 'GeoCoordinates',
                'latitude'  => (float) $lat,
                'longitude' => (float) $lng,
            ];
            $schema['hasMap'] = "https://www.google.com/maps?q={$lat},{$lng}";
        }

        // Service area
        if ( $loc ) {
            $areas = array_map( 'trim', explode( ',', $loc ) );
            if ( count($areas) === 1 ) {
                $schema['areaServed'] = $areas[0];
            } else {
                $schema['areaServed'] = array_map( function($a) {
                    return [ '@type' => 'City', 'name' => $a ];
                }, $areas );
            }
        }

        // Opening hours
        if ( $hours ) {
            // Format: "Mo-Fr 08:00-17:00, Sa 09:00-14:00"
            $specs = array_map( 'trim', explode( ',', $hours ) );
            $schema['openingHoursSpecification'] = [];
            foreach ( $specs as $spec ) {
                if ( preg_match( '/^(\S+)\s+(\d{2}:\d{2})-(\d{2}:\d{2})$/', $spec, $hm ) ) {
                    $days = $this->parse_days( $hm[1] );
                    $schema['openingHoursSpecification'][] = [
                        '@type'     => 'OpeningHoursSpecification',
                        'dayOfWeek' => $days,
                        'opens'     => $hm[2],
                        'closes'    => $hm[3],
                    ];
                }
            }
            if ( empty($schema['openingHoursSpecification']) ) unset($schema['openingHoursSpecification']);
        }

        // Aggregate rating
        $reviews = get_option('sseo_review_count','');
        $rating  = get_option('sseo_avg_rating','');
        if ( $reviews && $rating ) {
            $schema['aggregateRating'] = [
                '@type'       => 'AggregateRating',
                'ratingValue' => $rating,
                'reviewCount' => $reviews,
                'bestRating'  => '5',
                'worstRating' => '1',
            ];
        }

        // Founded
        if ( $founded ) $schema['foundingDate'] = $founded;

        // License
        if ( $license ) $schema['hasCredential'] = $license;

        // Services offered
        if ( $services_list ) {
            $svcs = array_map( 'trim', explode( ',', $services_list ) );
            $schema['hasOfferCatalog'] = [
                '@type'            => 'OfferCatalog',
                'name'             => $name . ' Services',
                'itemListElement'  => array_map( function($s) {
                    return [ '@type'=>'Offer', 'itemOffered'=>['@type'=>'Service','name'=>$s] ];
                }, $svcs ),
            ];
        }

        // Social profiles
        $social = get_option('sseo_social_profiles','');
        if ( $social ) {
            $schema['sameAs'] = array_filter( array_map('trim', explode("\n", $social)) );
        }

        $this->output_json_ld( $schema );
    }

    // ════════════════════════════════════════════
    // Service Schema — for /services/ and /what-we-do/ pages
    // ════════════════════════════════════════════
    private function service_schema() {
        global $post;
        if ( ! $post || $post->post_type !== 'page' ) return;

        $url = get_permalink( $post->ID );
        $path = wp_parse_url( $url, PHP_URL_PATH ) ?: '';

        // Detect service pages by URL pattern or custom meta
        $is_service = (
            strpos($path, '/services/') !== false ||
            strpos($path, '/what-we-do/') !== false ||
            strpos($path, '/service/') !== false ||
            get_post_meta($post->ID, '_sseo_is_service_page', true)
        );

        if ( ! $is_service ) return;

        $name    = get_option('sseo_brand_name', get_bloginfo('name'));
        $loc     = get_option('sseo_target_location', '');
        $phone   = get_option('sseo_business_phone', '');

        $schema = [
            '@context'    => 'https://schema.org',
            '@type'       => 'Service',
            'name'        => $post->post_title,
            'description' => wp_trim_words( wp_strip_all_tags($post->post_content), 50 ),
            'url'         => $url,
            'provider'    => [
                '@type' => get_option('sseo_business_type','LocalBusiness'),
                'name'  => $name,
                'url'   => home_url('/'),
            ],
        ];

        if ( $loc )   $schema['areaServed'] = $loc;
        if ( $phone ) $schema['provider']['telephone'] = $phone;

        $thumb = get_the_post_thumbnail_url( $post->ID, 'full' );
        if ( $thumb ) $schema['image'] = $thumb;

        // SEO meta as description
        $seo = new SSEO_SEO_Integration();
        $desc = $seo->get_meta( $post->ID );
        if ( $desc ) $schema['description'] = $desc;

        $this->output_json_ld( $schema );
    }

    // ════════════════════════════════════════════
    // BreadcrumbList — sitewide
    // ════════════════════════════════════════════
    private function breadcrumb() {
        global $post;
        if ( ! $post ) return;
        if ( is_front_page() ) return; // No breadcrumb on homepage

        $items = [[ '@type'=>'ListItem', 'position'=>1, 'name'=>'Home', 'item'=>home_url('/') ]];
        $pos = 2;

        // Parent page hierarchy
        if ( $post->post_parent ) {
            $ancestors = array_reverse( get_post_ancestors( $post->ID ) );
            foreach ( $ancestors as $anc_id ) {
                $items[] = [ '@type'=>'ListItem', 'position'=>$pos++, 'name'=>get_the_title($anc_id), 'item'=>get_permalink($anc_id) ];
            }
        } elseif ( is_single() ) {
            $cats = get_the_category( $post->ID );
            if ( $cats ) {
                $items[] = [ '@type'=>'ListItem', 'position'=>$pos++, 'name'=>$cats[0]->name, 'item'=>get_category_link($cats[0]->term_id) ];
            }
        }

        $items[] = [ '@type'=>'ListItem', 'position'=>$pos, 'name'=>get_the_title(), 'item'=>get_permalink() ];

        $this->output_json_ld([ '@context'=>'https://schema.org', '@type'=>'BreadcrumbList', 'itemListElement'=>$items ]);
    }

    // ════════════════════════════════════════════
    // Article — blog posts
    // ════════════════════════════════════════════
    private function article() {
        global $post;
        if ( ! $post || $post->post_type !== 'post' ) return;

        $schema = [
            '@context'         => 'https://schema.org',
            '@type'            => 'Article',
            'headline'         => get_the_title(),
            'datePublished'    => get_the_date('c'),
            'dateModified'     => get_the_modified_date('c'),
            'author'           => [ '@type'=>'Person', 'name'=>get_the_author() ],
            'publisher'        => [ '@type'=>'Organization', 'name'=>get_bloginfo('name'), 'url'=>home_url('/') ],
            'mainEntityOfPage' => get_permalink(),
            'wordCount'        => str_word_count( wp_strip_all_tags($post->post_content) ),
        ];

        $thumb = get_the_post_thumbnail_url( $post->ID, 'full' );
        if ( $thumb ) $schema['image'] = $thumb;

        $logo = get_site_icon_url();
        if ( $logo ) $schema['publisher']['logo'] = [ '@type'=>'ImageObject', 'url'=>$logo ];

        $seo = new SSEO_SEO_Integration();
        $desc = $seo->get_meta( $post->ID );
        if ( $desc ) $schema['description'] = $desc;

        $this->output_json_ld( $schema );
    }

    // ════════════════════════════════════════════
    // FAQPage — auto-detected from content
    // ════════════════════════════════════════════
    private function faq_schema() {
        global $post;
        if ( ! $post ) return;

        if ( preg_match_all( '/<h[23][^>]*>([^<]*\?)<\/h[23]>\s*<p>([^<]+)<\/p>/i', $post->post_content, $m, PREG_SET_ORDER ) ) {
            if ( count($m) < 2 ) return;
            $faqs = [];
            foreach ( $m as $faq ) {
                $faqs[] = [
                    '@type'          => 'Question',
                    'name'           => wp_strip_all_tags($faq[1]),
                    'acceptedAnswer' => [ '@type'=>'Answer', 'text'=>wp_strip_all_tags($faq[2]) ],
                ];
            }
            $this->output_json_ld([ '@context'=>'https://schema.org', '@type'=>'FAQPage', 'mainEntity'=>$faqs ]);
        }
    }

    // ════════════════════════════════════════════
    // Validate — check which schemas are present
    // ════════════════════════════════════════════
    public function validate_site() {
        $checks = [];

        // LocalBusiness
        $name = get_option('sseo_brand_name','');
        $checks['local_business'] = [
            'label'  => 'LocalBusiness Schema',
            'status' => !empty($name) && !empty(get_option('sseo_business_phone','')),
            'pages'  => 'Homepage, Contact, About',
            'fields' => [
                'name'    => !empty($name),
                'phone'   => !empty(get_option('sseo_business_phone','')),
                'address' => !empty(get_option('sseo_business_address','')),
                'city'    => !empty(get_option('sseo_business_city','')),
                'geo'     => !empty(get_option('sseo_business_lat','')) && !empty(get_option('sseo_business_lng','')),
                'hours'   => !empty(get_option('sseo_business_hours','')),
                'rating'  => !empty(get_option('sseo_review_count','')) && !empty(get_option('sseo_avg_rating','')),
                'services'=> !empty(get_option('sseo_business_services','')),
            ],
        ];

        // Service
        $service_pages = get_posts(['post_type'=>'page','post_status'=>'publish','numberposts'=>50]);
        $svc_count = 0;
        foreach ($service_pages as $p) {
            $path = wp_parse_url(get_permalink($p->ID), PHP_URL_PATH) ?: '';
            if (strpos($path,'/services/')!==false || strpos($path,'/what-we-do/')!==false || strpos($path,'/service/')!==false) $svc_count++;
        }
        $checks['service'] = [
            'label'  => 'Service Schema',
            'status' => $svc_count > 0,
            'pages'  => $svc_count . ' service pages detected',
        ];

        // Breadcrumb
        $checks['breadcrumb'] = [
            'label'  => 'BreadcrumbList Schema',
            'status' => true,
            'pages'  => 'All pages (except homepage)',
        ];

        // Article
        $post_count = wp_count_posts('post');
        $checks['article'] = [
            'label'  => 'Article Schema',
            'status' => $post_count->publish > 0,
            'pages'  => $post_count->publish . ' blog posts',
        ];

        // FAQ
        $checks['faq'] = [
            'label'  => 'FAQPage Schema',
            'status' => true,
            'pages'  => 'Auto-detected on pages with H2/H3 questions',
        ];

        $checks['google_test_url'] = 'https://search.google.com/test/rich-results?url=' . urlencode(home_url('/'));

        return $checks;
    }

    private function parse_days( $str ) {
        $day_map = ['Mo'=>'Monday','Tu'=>'Tuesday','We'=>'Wednesday','Th'=>'Thursday','Fr'=>'Friday','Sa'=>'Saturday','Su'=>'Sunday'];
        if ( strpos($str,'-') !== false ) {
            list($start,$end) = explode('-', $str);
            $keys = array_keys($day_map);
            $si = array_search($start,$keys);
            $ei = array_search($end,$keys);
            if ($si!==false && $ei!==false) {
                $result = [];
                for ($i=$si;$i<=$ei;$i++) $result[] = $day_map[$keys[$i]];
                return $result;
            }
        }
        return isset($day_map[$str]) ? [$day_map[$str]] : [$str];
    }

    private function output_json_ld( $data ) {
        // Protect email from anti-spam plugins (CleanTalk etc.) that corrupt JSON-LD
        // Strategy: replace email with placeholder, encode JSON, then swap in unicode-encoded email
        $original_email = '';
        array_walk_recursive($data, function(&$val, $key) use (&$original_email) {
            if ($key === 'email' && is_string($val) && strpos($val, '@') !== false) {
                $original_email = $val;
                $val = '___SSEO_EMAIL_PLACEHOLDER___';
            }
        });
        $json = wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT );
        if ($original_email) {
            $unicode_email = '';
            for ($i = 0; $i < strlen($original_email); $i++) {
                $unicode_email .= sprintf('\\u%04x', ord($original_email[$i]));
            }
            $json = str_replace('"___SSEO_EMAIL_PLACEHOLDER___"', '"' . $unicode_email . '"', $json);
        }
        echo '<script type="application/ld+json">' . $json . '</script>' . "\n";
    }

    public function is_enabled() {
        return (bool) get_option( 'sseo_schema_enabled', 1 );
    }


    /**
     * Toggle Service schema on/off for any page
     */
    public static function toggle_service_schema( $post_id, $enable = true ) {
        if ( $enable ) {
            update_post_meta( $post_id, '_sseo_is_service_page', 1 );
        } else {
            delete_post_meta( $post_id, '_sseo_is_service_page' );
        }
        // Also inject into AIOSEO if active
        self::sync_schema_to_seo_plugin( $post_id );
        return [ 'post_id' => $post_id, 'service_schema' => $enable ];
    }

    /**
     * Toggle LocalBusiness schema on/off for any page
     */
    public static function toggle_local_schema( $post_id, $enable = true ) {
        if ( $enable ) {
            update_post_meta( $post_id, '_sseo_local_schema', 1 );
        } else {
            delete_post_meta( $post_id, '_sseo_local_schema' );
        }
        self::sync_schema_to_seo_plugin( $post_id );
        return [ 'post_id' => $post_id, 'local_schema' => $enable ];
    }

    /**
     * Get schema status for a page
     */
    public static function get_page_schema( $post_id ) {
        return [
            'post_id'        => $post_id,
            'service_schema' => (bool) get_post_meta( $post_id, '_sseo_is_service_page', true ),
            'local_schema'   => (bool) get_post_meta( $post_id, '_sseo_local_schema', true ),
        ];
    }

    /**
     * Sync our schema flags to AIOSEO / Yoast / RankMath
     * This writes a custom JSON-LD graph into their schema system
     */
    private static function sync_schema_to_seo_plugin( $post_id ) {
        if ( ! defined('AIOSEO_VERSION') ) return;

        global $wpdb;
        $table = $wpdb->prefix . 'aioseo_posts';
        if ( $wpdb->get_var("SHOW TABLES LIKE '{$table}'") !== $table ) return;

        $is_service = get_post_meta( $post_id, '_sseo_is_service_page', true );
        $is_local   = get_post_meta( $post_id, '_sseo_local_schema', true );

        // Read current AIOSEO schema
        $row = $wpdb->get_row( $wpdb->prepare("SELECT id, schema FROM {$table} WHERE post_id=%d", $post_id) );
        $schema_data = [];
        if ( $row && ! empty($row->schema) ) {
            $schema_data = json_decode( $row->schema, true ) ?: [];
        }

        // Ensure customGraphs array exists
        if ( ! isset($schema_data['customGraphs']) ) $schema_data['customGraphs'] = [];

        // Remove any existing Samar SEO custom graphs
        $schema_data['customGraphs'] = array_filter( $schema_data['customGraphs'], function($g) {
            return ( $g['id'] ?? '' ) !== 'samar-seo-service' && ( $g['id'] ?? '' ) !== 'samar-seo-local';
        });
        $schema_data['customGraphs'] = array_values( $schema_data['customGraphs'] );

        // Add Service schema custom graph
        if ( $is_service ) {
            $post = get_post($post_id);
            $brand = get_option('sseo_brand_name', get_bloginfo('name'));
            $schema_data['customGraphs'][] = [
                'id'        => 'samar-seo-service',
                'graphName' => 'Service (' . sseo_product_name() . ')',
                'schema'    => json_encode([
                    '@context' => 'https://schema.org',
                    '@type'    => 'Service',
                    'name'     => $post ? $post->post_title : '',
                    'provider' => ['@type' => get_option('sseo_business_type','LocalBusiness'), 'name' => $brand],
                    'areaServed' => get_option('sseo_target_location',''),
                ]),
            ];
        }

        // Add LocalBusiness schema custom graph
        if ( $is_local ) {
            $brand = get_option('sseo_brand_name', get_bloginfo('name'));
            $schema_data['customGraphs'][] = [
                'id'        => 'samar-seo-local',
                'graphName' => 'LocalBusiness (' . sseo_product_name() . ')',
                'schema'    => json_encode([
                    '@context'  => 'https://schema.org',
                    '@type'     => get_option('sseo_business_type','LocalBusiness'),
                    'name'      => $brand,
                    'telephone' => get_option('sseo_business_phone',''),
                    'url'       => home_url('/'),
                ]),
            ];
        }

        $schema_json = wp_json_encode( $schema_data );

        if ( $row ) {
            $wpdb->update( $table, ['schema' => $schema_json], ['post_id' => $post_id] );
        } else {
            $wpdb->insert( $table, ['post_id' => $post_id, 'schema' => $schema_json] );
        }
    }

}
