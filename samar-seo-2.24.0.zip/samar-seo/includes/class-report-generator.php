<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Report_Generator {

    public function __construct() {
        // No more public URL endpoints — reports are downloaded, not served
        add_action('wp_ajax_sseo_download_report', [$this, 'download_report']);
    }

    /**
     * Serve report as downloadable HTML file — no public URL, no indexing
     */
    public function download_report() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        $id = sanitize_text_field($_GET['report_id'] ?? '');
        $report = get_option('sseo_report_' . $id);
        if (!$report) wp_die('Report not found.');

        $filename = 'SEO-Report-' . sanitize_file_name($report['client'] ?? 'site') . '-' . date('Y-m-d') . '.html';

        header('Content-Type: text/html; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('X-Robots-Tag: noindex, nofollow');
        header('Cache-Control: no-store, no-cache');
        echo $report['html'];
        exit;
    }

    // ════════════════════════════════════════════════════
    // FULL SNAPSHOT — every fix category with per-page data
    // ════════════════════════════════════════════════════
    public function take_snapshot( $label = 'before' ) {
        $seo   = new SSEO_SEO_Integration();
        $types = get_option( 'sseo_post_types', [ 'post', 'page' ] );

        // ── Meta descriptions ──
        $meta_data = []; $meta_missing = 0; $meta_total = 0;
        foreach ( $types as $pt ) {
            foreach ( get_posts(['post_type'=>$pt,'post_status'=>'publish','numberposts'=>-1]) as $p ) {
                $m = $seo->get_meta($p->ID); $has = !empty(trim($m));
                if(!$has) $meta_missing++;
                $meta_total++;
                $meta_data[] = ['id'=>$p->ID,'title'=>$p->post_title,'type'=>$p->post_type,'meta'=>$m,'has_meta'=>$has,'chars'=>mb_strlen($m)];
            }
        }

        // ── Title tags ──
        $title_data = []; $title_issues_count = 0;
        $ignored = get_option( 'sseo_thin_ignored', [] );
        foreach ( $types as $pt ) {
            foreach ( get_posts(['post_type'=>$pt,'post_status'=>'publish','numberposts'=>-1]) as $p ) {
                if ( in_array( $p->ID, $ignored ) ) continue;
                $st = $seo->get_title($p->ID); $t = $st ?: $p->post_title; $len = mb_strlen($t);
                $issue = ''; if($len>60) $issue='too_long'; elseif($len<30&&$len>0) $issue='too_short'; elseif(empty(trim($t))) $issue='missing';
                if($issue) $title_issues_count++;
                $title_data[] = ['id'=>$p->ID,'title'=>$t,'seo_title'=>$st,'chars'=>$len,'issue'=>$issue,'type'=>$p->post_type];
            }
        }

        // ── H1 tags ──
        $h1_data = []; $h1_issues_count = 0;
        foreach ( $types as $pt ) {
            foreach ( get_posts(['post_type'=>$pt,'post_status'=>'publish','numberposts'=>-1]) as $p ) {
                if ( in_array( $p->ID, $ignored ) ) continue;
                preg_match_all('/<h1[^>]*>(.*?)<\/h1>/is', $p->post_content, $matches);
                $h1s = array_map('wp_strip_all_tags', $matches[1]??[]);
                $cnt = count($h1s); $issue = '';
                if($cnt===0) $issue='missing'; elseif($cnt>1) $issue='multiple';
                if($issue) $h1_issues_count++;
                $h1_data[] = ['id'=>$p->ID,'title'=>$p->post_title,'h1_count'=>$cnt,'h1_tags'=>$h1s,'issue'=>$issue,'type'=>$p->post_type];
            }
        }

        // ── ALT tags ──
        $alt_gen = new SSEO_Alt_Generator();
        $alt_missing = $alt_gen->count_missing();
        $alt_samples = $alt_gen->get_missing(50,0);

        // ── Image titles (generic) ──
        $imgtitle_generic = $alt_gen->count_generic_titles();

        // ── ALT & Title change log (from activity log) ──
        global $wpdb;
        $log_table = $wpdb->prefix . 'sseo_log';
        $alt_changes = [];
        $imgtitle_changes = [];
        if ( $wpdb->get_var("SHOW TABLES LIKE '{$log_table}'") === $log_table ) {
            $alt_changes = $wpdb->get_results("SELECT l.*, p.post_title as image_name FROM {$log_table} l LEFT JOIN {$wpdb->posts} p ON l.post_id=p.ID WHERE l.type='alt' ORDER BY l.created_at DESC LIMIT 100", ARRAY_A);
            $imgtitle_changes = $wpdb->get_results("SELECT l.*, p.post_title as image_name FROM {$log_table} l LEFT JOIN {$wpdb->posts} p ON l.post_id=p.ID WHERE l.type='img_title' ORDER BY l.created_at DESC LIMIT 100", ARRAY_A);
        }

        // ── Thin content ──
        $thin_obj = new SSEO_Thin_Content();
        $thin_stats = $thin_obj->get_stats();
        $thin_pages = $thin_obj->scan(300);

        // ── ALL page word counts (for content tracking) ──
        $all_pages = [];
        foreach ( $types as $pt ) {
            foreach ( get_posts(['post_type'=>$pt,'post_status'=>'publish','numberposts'=>-1]) as $p ) {
                $wc = str_word_count(wp_strip_all_tags($p->post_content));
                $all_pages[$p->ID] = [
                    'id'        => $p->ID,
                    'title'     => $p->post_title,
                    'type'      => $p->post_type,
                    'words'     => $wc,
                    'permalink' => get_permalink($p->ID),
                    'date'      => $p->post_date,
                ];
            }
        }

        // ── Redirects ──
        $redir = new SSEO_Redirect_Manager();
        $redirect_count = $redir->count();
        $redirects_list = $redir->get_all();

        // ── Internal links per page ──
        $host = wp_parse_url(home_url('/'), PHP_URL_HOST);
        $internal_links_data = [];
        $total_internal_links = 0;
        $pages_no_links = 0;
        foreach ( $types as $pt ) {
            foreach ( get_posts(['post_type'=>$pt,'post_status'=>'publish','numberposts'=>-1]) as $p ) {
                $link_count = 0;
                if (preg_match_all('/href=["\']([^"\']+)["\']/i', $p->post_content, $hm)) {
                    foreach ($hm[1] as $href) {
                        $h = wp_parse_url($href, PHP_URL_HOST);
                        if (empty($h) || $h === $host) $link_count++;
                    }
                }
                $total_internal_links += $link_count;
                if ($link_count === 0) $pages_no_links++;
                $internal_links_data[$p->ID] = [
                    'id' => $p->ID, 'title' => $p->post_title, 'type' => $p->post_type,
                    'links' => $link_count, 'permalink' => get_permalink($p->ID),
                ];
            }
        }

        // ── Broken links ──
        $broken_links = (new SSEO_Broken_Links())->scan(50);

        // ── Schema / OG / llms.txt ──
        $schema_on = (bool) get_option('sseo_schema_enabled',1);
        $og_on     = (bool) get_option('sseo_og_enabled',1);
        $llms      = get_option('sseo_llms_txt_content','');

        // ── Full activity log ──
        $enhance_log = [];
        $linker_log = [];
        if ( $wpdb->get_var("SHOW TABLES LIKE '{$log_table}'") === $log_table ) {
            $enhance_log = $wpdb->get_results("SELECT * FROM {$log_table} WHERE type = 'enhance' ORDER BY created_at DESC LIMIT 500", ARRAY_A);
            $linker_log = $wpdb->get_results("SELECT * FROM {$log_table} WHERE type = 'internal_link' ORDER BY created_at DESC LIMIT 500", ARRAY_A);
        }

        // ── Score ──
        $score = 100;
        if ($meta_missing>0)          $score -= min(30, $meta_missing*0.5);
        if ($alt_missing>0)           $score -= min(15, $alt_missing*0.3);
        if ($imgtitle_generic>0)      $score -= min(5, $imgtitle_generic*0.1);
        if ($title_issues_count>0)    $score -= min(10, $title_issues_count);
        if ($h1_issues_count>0)       $score -= min(10, $h1_issues_count*1.5);
        if (!$schema_on)              $score -= 5;
        if (!$og_on)                  $score -= 3;
        if (empty($llms))            $score -= 5;
        if ($thin_stats['thin']>0)   $score -= min(15, $thin_stats['thin']*0.5);
        if (count($broken_links)>0)  $score -= min(7, count($broken_links)*0.5);
        $score = max(0,round($score));

        return [
            'label'=>$label,'date'=>current_time('mysql'),'score'=>$score,
            'meta_total'=>$meta_total,'meta_missing'=>$meta_missing,'meta_data'=>$meta_data,
            'title_issues_count'=>$title_issues_count,'title_data'=>$title_data,
            'h1_issues_count'=>$h1_issues_count,'h1_data'=>$h1_data,
            'alt_missing'=>$alt_missing,'alt_samples'=>$alt_samples,
            'imgtitle_generic'=>$imgtitle_generic,
            'alt_changes'=>$alt_changes,'imgtitle_changes'=>$imgtitle_changes,
            'thin_stats'=>$thin_stats,'thin_pages'=>array_slice($thin_pages,0,30),
            'all_pages'=>$all_pages,
            'redirect_count'=>$redirect_count,'redirects_list'=>array_slice((array)$redirects_list,0,30),
            'internal_links_data'=>$internal_links_data,'total_internal_links'=>$total_internal_links,'pages_no_links'=>$pages_no_links,
            'broken_links'=>$broken_links,
            'schema_on'=>$schema_on,'og_on'=>$og_on,'llms_exists'=>!empty($llms),
            'enhance_log'=>$enhance_log,
            'linker_log'=>$linker_log,
            'site_name'=>get_bloginfo('name'),'site_url'=>home_url('/'),
            'brand'=>get_option('sseo_brand_name',''),'location'=>get_option('sseo_target_location',''),
        ];
    }

    public function generate_report( $before, $after, $client_name = '' ) {
        $report_id = wp_generate_password(12,false);
        $client = $client_name ?: ($after['site_name'] ?? get_bloginfo('name'));
        $date = current_time('F j, Y');

        ob_start();
        include SSEO_DIR . 'includes/report-template.php';
        $html = ob_get_clean();

        update_option('sseo_report_'.$report_id, ['html'=>$html,'created_at'=>current_time('mysql'),'client'=>$client,'before_score'=>$before['score'],'after_score'=>$after['score'],'before_data'=>$before], false);
        $list = get_option('sseo_reports_list',[]);
        $list[] = ['id'=>$report_id,'client'=>$client,'site'=>$after['site_url']??home_url('/'),'date'=>current_time('mysql'),'before_score'=>$before['score'],'after_score'=>$after['score']];
        update_option('sseo_reports_list',$list);

        // Return download URL instead of public URL
        return ['report_id'=>$report_id,'download_url'=>admin_url('admin-ajax.php?action=sseo_download_report&report_id='.$report_id),'before'=>$before['score'],'after'=>$after['score']];
    }

    public function get_reports_list() { return get_option('sseo_reports_list',[]); }
    public function delete_report($id) {
        delete_option('sseo_report_'.$id);
        $list=get_option('sseo_reports_list',[]);
        update_option('sseo_reports_list',array_values(array_filter($list,function($r)use($id){return $r['id']!==$id;})));
    }
}
