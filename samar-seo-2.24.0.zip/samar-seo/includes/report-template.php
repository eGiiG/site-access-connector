<?php
// Report template — $before, $after, $client, $date, $report_id must be in scope
if ( ! defined( 'ABSPATH' ) ) exit;
$b = $before; $a = $after;
$bg = $b['score']>=90?['A','#16a34a']:($b['score']>=75?['B','#2563eb']:($b['score']>=60?['C','#d97706']:($b['score']>=40?['D','#ea580c']:['F','#dc2626'])));
$ag = $a['score']>=90?['A','#16a34a']:($a['score']>=75?['B','#2563eb']:($a['score']>=60?['C','#d97706']:($a['score']>=40?['D','#ea580c']:['F','#dc2626'])));
$ds = $a['score'] - $b['score'];
function _d($bv,$av){return $bv-$av;}
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SEO Report — <?php echo esc_html($client); ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Inter',sans-serif;color:#1e293b;background:#fff;line-height:1.6;font-size:15px;-webkit-font-smoothing:antialiased}.cnt{max-width:940px;margin:0 auto;padding:0 32px}
.cov{background:linear-gradient(135deg,#0f172a,#1e293b 60%,#312e81);color:#fff;padding:80px 0 60px;position:relative;overflow:hidden}.cov::before{content:'';position:absolute;top:-40%;right:-15%;width:500px;height:500px;background:radial-gradient(circle,rgba(99,102,241,.2),transparent 70%);pointer-events:none}.cbdg{display:inline-block;background:rgba(99,102,241,.2);border:1px solid rgba(99,102,241,.3);color:#a5b4fc;font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;padding:6px 16px;border-radius:99px;margin-bottom:20px}.cov h1{font-size:42px;font-weight:900;line-height:1.15}.cov h1 span{background:linear-gradient(90deg,#818cf8,#c084fc);-webkit-background-clip:text;-webkit-text-fill-color:transparent}.csite{font-size:20px;color:#a5b4fc;font-weight:600;margin:12px 0 24px}.cmeta{display:flex;gap:24px;flex-wrap:wrap;font-size:13px;color:#94a3b8;padding-top:20px;border-top:1px solid rgba(255,255,255,.08)}
.scmp{display:grid;grid-template-columns:1fr 80px 1fr;gap:24px;align-items:center;margin:48px 0;padding:40px;background:#f8fafc;border-radius:20px;border:1px solid #e2e8f0}.sbox{text-align:center;padding:24px;border-radius:16px;background:#fff;border:1px solid #e2e8f0}.sbox.bf{border-color:#fca5a5}.sbox.af{border-color:#86efac;box-shadow:0 4px 20px rgba(34,197,94,.1)}.slbl{font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#94a3b8;margin-bottom:8px}.snum{font-size:56px;font-weight:900;line-height:1}.sgrd{font-size:18px;font-weight:700;margin-top:4px}.sarr{text-align:center;font-size:32px;color:#6366f1}.sdlt{text-align:center;margin-top:12px}.dbb{display:inline-block;padding:6px 16px;border-radius:99px;font-size:14px;font-weight:700}.dbu{background:#dcfce7;color:#16a34a}.dbd{background:#fef2f2;color:#dc2626}
.sec{margin:48px 0}.sh{display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:12px;border-bottom:2px solid #6366f1}.sic{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0}.sec h2{font-size:22px;font-weight:800;color:#0f172a}.sec h3{font-size:16px;font-weight:700;margin:20px 0 10px;color:#334155}
.mg{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:14px;margin:20px 0}.mc{background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:18px 14px;text-align:center}.ml{font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#94a3b8;margin-bottom:4px}.mr{display:flex;align-items:center;justify-content:center;gap:8px}.mo{font-size:18px;font-weight:800;color:#dc2626;text-decoration:line-through;opacity:.5}.mn{font-size:26px;font-weight:900}.ma{color:#6366f1;font-size:14px}.grn{color:#16a34a}.red{color:#dc2626}.org{color:#d97706}.blu{color:#2563eb}
table{width:100%;border-collapse:collapse;font-size:13px;margin:16px 0}thead th{background:#0f172a;color:#fff;padding:10px 14px;text-align:left;font-weight:600;font-size:11px;text-transform:uppercase;letter-spacing:.5px}thead.tr th{background:#dc2626}thead.tg th{background:#16a34a}thead.tb th{background:#2563eb}thead.to th{background:#d97706}tbody td{padding:9px 14px;border-bottom:1px solid #f1f5f9;vertical-align:top}tbody tr:nth-child(even){background:#f8fafc}.t{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600}.t-g{background:#dcfce7;color:#16a34a}.t-r{background:#fef2f2;color:#dc2626}.t-o{background:#fef3c7;color:#d97706}.t-b{background:#dbeafe;color:#2563eb}
.cl{margin:16px 0}.cli{display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid #f1f5f9;font-size:14px}.clk{width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0}.clp{background:#dcfce7;color:#16a34a}.clf{background:#fef2f2;color:#dc2626}
.summ{background:linear-gradient(135deg,#ecfdf5,#f0fdf4);border:2px solid #86efac;border-radius:16px;padding:32px;margin:40px 0;text-align:center}.summ h3{font-size:20px;font-weight:800;color:#16a34a;margin-bottom:16px}.sg{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:16px}.sv .v{font-size:32px;font-weight:900;color:#16a34a}.sv .l{font-size:12px;color:#64748b}
.ftr{background:#0f172a;color:#94a3b8;text-align:center;padding:24px;font-size:12px;margin-top:60px}.ftr strong{color:#fff}
.tgl-btn{display:inline-flex;align-items:center;gap:6px;padding:8px 18px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;font-size:13px;font-weight:600;color:#6366f1;cursor:pointer;margin-top:10px;transition:all .2s}.tgl-btn:hover{background:#eff6ff;border-color:#6366f1}
.tgl-rows tr.extra{display:none}.tgl-rows.expanded tr.extra{display:table-row}
.tgl-items .extra-item{display:none}.tgl-items.expanded .extra-item{display:flex}
@media print{.cov{padding:40px 0}.cov h1{font-size:28px}.snum{font-size:36px}.cnt{max-width:100%;padding:0 16px}table,thead th,.scmp,.sbox,.mc,.t,.clk,.summ{-webkit-print-color-adjust:exact;print-color-adjust:exact}body{font-size:11px}.tgl-btn{display:none}.tgl-rows tr.extra,.tgl-items .extra-item{display:table-row!important}}
@media(max-width:768px){.scmp{grid-template-columns:1fr;gap:16px}.sarr{transform:rotate(90deg)}.mg{grid-template-columns:repeat(2,1fr)}.sg{grid-template-columns:1fr}}
</style>
<script>function toggleSection(btn){var p=btn.parentElement;var t=p.querySelector('.tgl-rows,.tgl-items');if(!t)return;t.classList.toggle('expanded');var exp=t.classList.contains('expanded');btn.innerHTML=exp?'Show Less ↑':'Show All ('+btn.dataset.total+') ↓';}</script>
</head><body>

<!-- ═══ COVER ═══ -->
<div class="cov"><div class="cnt">
<div class="cbdg">Complete SEO Optimization Report</div>
<h1>SEO Audit <span>Before &amp; After</span> Report</h1>
<div class="csite"><?php echo esc_html($a['site_url']); ?></div>
<div class="cmeta"><span>📋 <?php echo esc_html($client); ?></span><span>📅 <?php echo esc_html($date); ?></span><span>🔧 <?php echo esc_html( sseo_product_name() ); ?></span><?php if($a['brand']): ?><span>🏢 <?php echo esc_html($a['brand']); ?></span><?php endif; ?></div>
</div></div>

<div class="cnt">

<!-- ═══ SCORE COMPARISON ═══ -->
<div class="scmp">
<div class="sbox bf"><div class="slbl">Before</div><div class="snum" style="color:<?php echo $bg[1]; ?>"><?php echo $b['score']; ?></div><div class="sgrd" style="color:<?php echo $bg[1]; ?>">Grade: <?php echo $bg[0]; ?></div><div style="font-size:12px;color:#94a3b8;margin-top:4px"><?php echo esc_html($b['date']); ?></div></div>
<div class="sarr">→</div>
<div class="sbox af"><div class="slbl">After</div><div class="snum" style="color:<?php echo $ag[1]; ?>"><?php echo $a['score']; ?></div><div class="sgrd" style="color:<?php echo $ag[1]; ?>">Grade: <?php echo $ag[0]; ?></div><div style="font-size:12px;color:#94a3b8;margin-top:4px"><?php echo esc_html($a['date']); ?></div></div>
</div>
<div class="sdlt"><?php if($ds>0): ?><span class="dbb dbu">↑ +<?php echo $ds; ?> points improvement</span><?php elseif($ds<0): ?><span class="dbb dbd">↓ <?php echo $ds; ?></span><?php else: ?><span class="dbb" style="background:#f1f5f9;color:#64748b">No change</span><?php endif; ?></div>

<!-- ═══ 1. ALL ISSUES AT A GLANCE ═══ -->
<div class="sec"><div class="sh"><div class="sic">📊</div><h2>All Issues — Before vs After</h2></div>
<div class="mg">
<?php
$metrics = [
    ['Meta Descriptions', $b['meta_missing'], $a['meta_missing']],
    ['Image ALT Tags', $b['alt_missing'], $a['alt_missing']],
    ['Generic Image Titles', $b['imgtitle_generic']??0, $a['imgtitle_generic']??0],
    ['Title Tag Issues', $b['title_issues_count'], $a['title_issues_count']],
    ['H1 Tag Issues', $b['h1_issues_count'], $a['h1_issues_count']],
    ['Thin Content', $b['thin_stats']['thin'], $a['thin_stats']['thin']],
    ['Pages with No Links', $b['pages_no_links']??0, $a['pages_no_links']??0],
    ['Broken Links', count($b['broken_links']), count($a['broken_links'])],
];
foreach($metrics as $m): $fixed = $m[1] - $m[2]; ?>
<div class="mc"><div class="ml"><?php echo $m[0]; ?></div><div class="mr"><span class="mo"><?php echo $m[1]; ?></span><span class="ma">→</span><span class="mn <?php echo $m[2]==0?'grn':($m[2]<$m[1]?'org':'red'); ?>"><?php echo $m[2]; ?></span></div><div style="font-size:11px;color:#94a3b8;margin-top:4px"><?php echo $fixed>0?$fixed.' fixed':'no change'; ?></div></div>
<?php endforeach; ?>
</div></div>

<!-- ═══ 2. FULL CHECKLIST ═══ -->
<div class="sec"><div class="sh"><div class="sic">✅</div><h2>Technical SEO Checklist</h2></div>
<div class="cl">
<?php
$checks = [
    ['Meta descriptions on all pages', $a['meta_missing']===0, $b['meta_missing'].' → '.$a['meta_missing'].' missing'],
    ['Image ALT tags on all images', $a['alt_missing']===0, $b['alt_missing'].' → '.$a['alt_missing'].' missing'],
    ['Descriptive image titles (no IMG_/DSC_)', ($a['imgtitle_generic']??0)===0, ($b['imgtitle_generic']??0).' → '.($a['imgtitle_generic']??0).' generic'],
    ['Title tags 50-60 chars', $a['title_issues_count']===0, $b['title_issues_count'].' → '.$a['title_issues_count'].' issues'],
    ['H1 on every page', $a['h1_issues_count']===0, $b['h1_issues_count'].' → '.$a['h1_issues_count'].' issues'],
    ['No broken internal links', count($a['broken_links'])===0, count($b['broken_links']).' → '.count($a['broken_links']).' broken'],
    ['No thin content (<300 words)', $a['thin_stats']['thin']===0, $b['thin_stats']['thin'].' → '.$a['thin_stats']['thin'].' thin'],
    ['301 Redirects configured', $a['redirect_count']>0||count($b['broken_links'])===0, $a['redirect_count'].' active'],
    ['Schema markup enabled', $a['schema_on'], ($b['schema_on']?'ON':'OFF').' → '.($a['schema_on']?'ON':'OFF')],
    ['Open Graph tags enabled', $a['og_on'], ($b['og_on']?'ON':'OFF').' → '.($a['og_on']?'ON':'OFF')],
    ['llms.txt published', $a['llms_exists'], ($b['llms_exists']?'Existed':'404').' → '.($a['llms_exists']?'Published':'Missing')],
    ['Internal links on all pages', ($a['pages_no_links']??0)===0, ($b['pages_no_links']??0).' → '.($a['pages_no_links']??0).' pages with 0 links'],
];
foreach($checks as $c): $p=$c[1]; ?>
<div class="cli"><div class="clk <?php echo $p?'clp':'clf'; ?>"><?php echo $p?'✓':'✗'; ?></div><span><?php echo esc_html($c[0]); ?></span><span style="margin-left:auto;font-size:12px;color:#94a3b8"><?php echo esc_html($c[2]); ?></span><span class="t <?php echo $p?'t-g':'t-r'; ?>" style="margin-left:8px"><?php echo $p?'PASS':'OPEN'; ?></span></div>
<?php endforeach; ?>
</div></div>

<!-- ═══ 3. META DESCRIPTION CHANGES ═══ -->
<?php $bm=[]; foreach(($b['meta_data']??[]) as $m) $bm[$m['id']]=$m;
$mrows=[]; foreach(($a['meta_data']??[]) as $m){ $old=$bm[$m['id']]??null; $om=$old?$old['meta']:''; if($om===$m['meta']&&$m['has_meta']) continue; $mrows[]=['t'=>$m['title'],'tp'=>$m['type'],'o'=>$om,'n'=>$m['meta'],'h'=>$m['has_meta'],'c'=>$om!==$m['meta']]; }
if(!empty($mrows)): ?>
<div class="sec"><div class="sh"><div class="sic">📝</div><h2>Meta Description Changes (<?php echo count($mrows); ?>)</h2></div>
<table><thead><tr><th>Page</th><th>Before</th><th>After</th><th>Status</th></tr></thead><tbody class="tgl-rows">
<?php foreach($mrows as $ri => $r): ?>
<tr<?php echo $ri>=10?' class="extra"':''; ?>><td><strong><?php echo esc_html(mb_substr($r['t'],0,30)); ?></strong></td><td style="max-width:200px;font-size:12px;color:#94a3b8"><?php echo $r['o']?esc_html(mb_substr($r['o'],0,65)).'…':'<span class="t t-r">MISSING</span>'; ?></td><td style="max-width:200px;font-size:12px"><?php echo $r['n']?esc_html(mb_substr($r['n'],0,65)).'…':'<span class="t t-r">MISSING</span>'; ?></td><td><?php echo $r['h']&&$r['c']?'<span class="t t-g">FIXED</span>':($r['h']?'<span class="t t-b">OK</span>':'<span class="t t-o">PENDING</span>'); ?></td></tr>
<?php endforeach; ?></tbody></table>
<?php if(count($mrows)>10): ?><button class="tgl-btn" data-total="<?php echo count($mrows); ?>" onclick="toggleSection(this)">Show All (<?php echo count($mrows); ?>) ↓</button><?php endif; ?>
</div>
<?php endif; ?>

<!-- ═══ 4. TITLE TAG CHANGES ═══ -->
<?php $bt=[]; foreach(($b['title_data']??[]) as $t) $bt[$t['id']]=$t;
$trows=[]; foreach(($a['title_data']??[]) as $t){ $old=$bt[$t['id']]??null; $oi=$old?$old['issue']:''; $ch=$old?($old['title']!==$t['title']):false; if(!$oi&&!$t['issue']&&!$ch) continue; $trows[]=['t'=>$t['title'],'ot'=>$old?$old['title']:'','c'=>$t['chars'],'oc'=>$old?$old['chars']:0,'i'=>$t['issue'],'oi'=>$oi,'ch'=>$ch]; }
if(!empty($trows)): ?>
<div class="sec"><div class="sh"><div class="sic">🏷️</div><h2>Title Tag Changes (<?php echo count($trows); ?>)</h2></div>
<table><thead class="tb"><tr><th>Page</th><th>Before</th><th>After</th><th>Status</th></tr></thead><tbody class="tgl-rows">
<?php foreach($trows as $ri => $r): ?>
<tr<?php echo $ri>=10?' class="extra"':''; ?>><td><strong><?php echo esc_html(mb_substr($r['ot']?:$r['t'],0,28)); ?></strong></td><td style="font-size:12px"><?php echo esc_html(mb_substr($r['ot'],0,45)); ?> <span style="color:<?php echo $r['oi']?'#dc2626':'#94a3b8'; ?>">(<?php echo $r['oc']; ?>ch<?php echo $r['oi']?' · '.str_replace('_',' ',$r['oi']):''; ?>)</span></td><td style="font-size:12px"><?php echo esc_html(mb_substr($r['t'],0,45)); ?> <span style="color:<?php echo $r['i']?'#d97706':'#16a34a'; ?>">(<?php echo $r['c']; ?>ch)</span></td><td><?php echo !$r['i']&&$r['oi']?'<span class="t t-g">FIXED</span>':($r['ch']?'<span class="t t-b">UPDATED</span>':($r['i']?'<span class="t t-o">OPEN</span>':'<span class="t t-g">OK</span>')); ?></td></tr>
<?php endforeach; ?></tbody></table>
<?php if(count($trows)>10): ?><button class="tgl-btn" data-total="<?php echo count($trows); ?>" onclick="toggleSection(this)">Show All (<?php echo count($trows); ?>) ↓</button><?php endif; ?>
</div>
<?php endif; ?>

<!-- ═══ 5. H1 TAG CHANGES ═══ -->
<?php $bh=[]; foreach(($b['h1_data']??[]) as $h) $bh[$h['id']]=$h;
$hrows=[]; foreach(($a['h1_data']??[]) as $h){ $old=$bh[$h['id']]??null; $oi=$old?$old['issue']:''; if(!$oi&&!$h['issue']) continue; $hrows[]=['t'=>$h['title'],'h'=>$h['h1_tags'],'oh'=>$old?$old['h1_tags']:[],'i'=>$h['issue'],'oi'=>$oi]; }
if(!empty($hrows)): ?>
<div class="sec"><div class="sh"><div class="sic">🔤</div><h2>H1 Tag Changes (<?php echo count($hrows); ?>)</h2></div>
<table><thead class="to"><tr><th>Page</th><th>Before</th><th>After</th><th>Status</th></tr></thead><tbody class="tgl-rows">
<?php foreach($hrows as $ri => $r): ?>
<tr<?php echo $ri>=10?' class="extra"':''; ?>><td><strong><?php echo esc_html(mb_substr($r['t'],0,28)); ?></strong></td><td style="font-size:12px"><?php echo $r['oh']?esc_html(implode(', ',$r['oh'])):'<span class="t t-r">MISSING</span>'; ?></td><td style="font-size:12px"><?php echo $r['h']?esc_html(implode(', ',$r['h'])):'<span class="t t-r">MISSING</span>'; ?></td><td><?php echo !$r['i']&&$r['oi']?'<span class="t t-g">FIXED</span>':($r['i']?'<span class="t t-o">OPEN</span>':'<span class="t t-g">OK</span>'); ?></td></tr>
<?php endforeach; ?></tbody></table>
<?php if(count($hrows)>10): ?><button class="tgl-btn" data-total="<?php echo count($hrows); ?>" onclick="toggleSection(this)">Show All (<?php echo count($hrows); ?>) ↓</button><?php endif; ?>
</div>
<?php endif; ?>

<!-- ═══ 6. IMAGE ALT TAGS ═══ -->
<?php if($b['alt_missing']>0 || $a['alt_missing']>0): ?>
<div class="sec"><div class="sh"><div class="sic">🖼️</div><h2>Image ALT Tag Fixes</h2></div>
<div class="mg" style="grid-template-columns:1fr 1fr 1fr">
<div class="mc"><div class="ml">Before: Missing ALTs</div><div class="mn red"><?php echo $b['alt_missing']; ?></div></div>
<div class="mc"><div class="ml">After: Missing ALTs</div><div class="mn <?php echo $a['alt_missing']?'org':'grn'; ?>"><?php echo $a['alt_missing']; ?></div></div>
<div class="mc"><div class="ml">Images Fixed</div><div class="mn grn"><?php echo _d($b['alt_missing'],$a['alt_missing']); ?></div></div>
</div>
<?php if(!empty($b['alt_samples'])): ?>
<p style="font-size:13px;color:#64748b;margin:8px 0">Sample images that were missing ALT text:</p>
<table><thead class="tr"><tr><th>Filename</th><th>Used On Page</th><th>Status After</th></tr></thead><tbody>
<?php foreach(array_slice($b['alt_samples'],0,20) as $img):
    $still_missing = false; foreach(($a['alt_samples']??[]) as $ai){ if($ai['attachment_id']===$img['attachment_id']){$still_missing=true;break;} }
?>
<tr><td><code style="font-size:12px"><?php echo esc_html($img['filename']); ?></code></td><td><?php echo $img['parent_title']?esc_html($img['parent_title']):'—'; ?></td><td><?php echo $still_missing?'<span class="t t-o">PENDING</span>':'<span class="t t-g">ALT ADDED</span>'; ?></td></tr>
<?php endforeach; ?></tbody></table>
<?php endif; ?>

<?php if(!empty($a['alt_changes'])): $alt_ch = $a['alt_changes']; ?>
<h3 style="margin-top:16px">ALT Tag Changes Made</h3>
<table><thead class="tr"><tr><th>Image</th><th>Before</th><th>After</th></tr></thead><tbody class="tgl-rows">
<?php foreach($alt_ch as $ri => $ch): ?>
<tr<?php echo $ri>=10?' class="extra"':''; ?>><td><code style="font-size:11px"><?php echo esc_html($ch['image_name']??'#'.$ch['post_id']); ?></code></td><td style="font-size:11px;color:#dc2626"><?php echo $ch['old_value']?esc_html(substr($ch['old_value'],0,60)):'<em>empty</em>'; ?></td><td style="font-size:11px;color:#16a34a"><?php echo esc_html(substr($ch['new_value'],0,60)); ?></td></tr>
<?php endforeach; ?></tbody></table>
<?php if(count($alt_ch)>10): ?><button class="tgl-btn" data-total="<?php echo count($alt_ch); ?>" onclick="toggleSection(this)">Show All (<?php echo count($alt_ch); ?>) ↓</button><?php endif; ?>
<?php endif; ?>
</div>
<?php endif; ?>

<!-- ═══ 6b. IMAGE TITLE FIXES ═══ -->
<?php if(($b['imgtitle_generic']??0)>0 || !empty($a['imgtitle_changes'])): ?>
<div class="sec"><div class="sh"><div class="sic">📛</div><h2>Image Title Fixes</h2></div>
<div class="mg" style="grid-template-columns:1fr 1fr 1fr">
<div class="mc"><div class="ml">Before: Generic Titles</div><div class="mn red"><?php echo $b['imgtitle_generic']??0; ?></div></div>
<div class="mc"><div class="ml">After: Generic Titles</div><div class="mn <?php echo ($a['imgtitle_generic']??0)?'org':'grn'; ?>"><?php echo $a['imgtitle_generic']??0; ?></div></div>
<div class="mc"><div class="ml">Titles Renamed</div><div class="mn grn"><?php echo count($a['imgtitle_changes']??[]); ?></div></div>
</div>
<?php if(!empty($a['imgtitle_changes'])): $itc = $a['imgtitle_changes']; ?>
<h3 style="margin-top:12px">Image Title Changes Made</h3>
<table><thead class="tr"><tr><th>Image</th><th>Before (Generic)</th><th>After (SEO Title)</th></tr></thead><tbody class="tgl-rows">
<?php foreach($itc as $ri => $ch): ?>
<tr<?php echo $ri>=10?' class="extra"':''; ?>><td><code style="font-size:11px"><?php echo esc_html($ch['image_name']??'#'.$ch['post_id']); ?></code></td><td style="font-size:11px;color:#dc2626"><code><?php echo esc_html(substr($ch['old_value'],0,40)); ?></code></td><td style="font-size:11px;color:#16a34a"><?php echo esc_html(substr($ch['new_value'],0,60)); ?></td></tr>
<?php endforeach; ?></tbody></table>
<?php if(count($itc)>10): ?><button class="tgl-btn" data-total="<?php echo count($itc); ?>" onclick="toggleSection(this)">Show All (<?php echo count($itc); ?>) ↓</button><?php endif; ?>
<?php endif; ?>
</div>
<?php endif; ?>

<!-- ═══ 7. BROKEN LINKS & REDIRECTS ═══ -->
<?php if(!empty($b['broken_links']) || $a['redirect_count']>0): ?>
<div class="sec"><div class="sh"><div class="sic">🔗</div><h2>Broken Links & Redirects</h2></div>
<?php if(!empty($b['broken_links'])): ?>
<h3 style="color:#dc2626">Broken Links (Before: <?php echo count($b['broken_links']); ?> → After: <?php echo count($a['broken_links']); ?>)</h3>
<table><thead class="tr"><tr><th>Source Page</th><th>Broken URL</th><th>After Status</th></tr></thead><tbody>
<?php foreach(array_slice($b['broken_links'],0,25) as $bl):
    $still=false; foreach($a['broken_links'] as $ab){ if($ab['broken_url']===$bl['broken_url']){$still=true;break;} } ?>
<tr><td><?php echo esc_html($bl['source_title']); ?></td><td><code style="font-size:12px"><?php echo esc_html($bl['broken_url']); ?></code></td><td><?php echo $still?'<span class="t t-r">STILL BROKEN</span>':'<span class="t t-g">FIXED</span>'; ?></td></tr>
<?php endforeach; ?></tbody></table>
<?php endif; ?>
<?php if(!empty($a['redirects_list'])): ?>
<h3 style="color:#2563eb">Active Redirects (<?php echo count($a['redirects_list']); ?>)</h3>
<table><thead class="tb"><tr><th>From</th><th>To</th><th>Type</th><th>Hits</th></tr></thead><tbody>
<?php foreach(array_slice($a['redirects_list'],0,20) as $rd): $rd=(array)$rd; ?>
<tr><td><code style="font-size:12px"><?php echo esc_html($rd['source_url']); ?></code></td><td><code style="font-size:12px"><?php echo esc_html($rd['target_url']); ?></code></td><td><span class="t t-b"><?php echo $rd['type']; ?></span></td><td><?php echo $rd['hits']; ?></td></tr>
<?php endforeach; ?></tbody></table>
<?php endif; ?></div>
<?php endif; ?>

<!-- ═══ 7b. INTERNAL LINKING ═══ -->
<?php
$b_il = $b['internal_links_data'] ?? [];
$a_il = $a['internal_links_data'] ?? [];
// Intelligent: if baseline has no link data (old baseline), treat all pages as having 0 links initially
$b_total_il = $b['total_internal_links'] ?? 0;
$a_total_il = $a['total_internal_links'] ?? 0;
$b_no_links = $b['pages_no_links'] ?? count($a_il); // If no baseline data, assume all had 0 links
$a_no_links = $a['pages_no_links'] ?? 0;
$il_added = $a_total_il - $b_total_il;
?>
<div class="sec"><div class="sh"><div class="sic">🔗</div><h2>Internal Linking</h2></div>
<?php $linker_entries = $a['linker_log'] ?? []; $linker_count = count($linker_entries); ?>
<div class="mg" style="grid-template-columns:repeat(4,1fr)">
<div class="mc"><div class="ml">Total Internal Links</div><div class="mr"><span class="mo"><?php echo $b_total_il; ?></span><span class="ma">→</span><span class="mn <?php echo $a_total_il>$b_total_il?'grn':'org'; ?>"><?php echo $a_total_il; ?></span></div></div>
<div class="mc"><div class="ml">Links Added</div><div class="mn <?php echo $il_added>0?'grn':'red'; ?>"><?php echo $il_added>0?'+'.$il_added:$il_added; ?></div></div>
<div class="mc"><div class="ml">Pages with 0 Links</div><div class="mr"><span class="mo"><?php echo $b_no_links; ?></span><span class="ma">→</span><span class="mn <?php echo $a_no_links===0?'grn':($a_no_links<$b_no_links?'org':'red'); ?>"><?php echo $a_no_links; ?></span></div></div>
<div class="mc"><div class="ml">Smart Linker Actions</div><div class="mn <?php echo $linker_count>0?'grn':'org'; ?>"><?php echo $linker_count; ?></div></div>
</div>

<?php if ($linker_count > 0): ?>
<h3 style="margin-top:20px;color:#2563eb">🔗 Links Added via Smart Linker (<?php echo $linker_count; ?>)</h3>
<table><thead class="tb"><tr><th>Source Page</th><th>Anchor Text</th><th>Links To</th></tr></thead><tbody class="tgl-rows">
<?php foreach(array_slice($linker_entries, 0, 20) as $ri => $le): ?>
<tr<?php echo $ri>=10?' class="extra"':''; ?>>
<td><?php $lp=get_post($le['post_id']); echo $lp ? '<a href="'.get_permalink($lp).'" target="_blank" style="color:#2563eb">'.esc_html(mb_substr($lp->post_title,0,35)).'</a>' : '#'.$le['post_id']; ?></td>
<td><strong><?php echo esc_html($le['old_value']); ?></strong></td>
<td><a href="<?php echo esc_url($le['new_value']); ?>" target="_blank" style="color:#64748b;font-size:12px"><?php echo esc_html(mb_substr($le['new_value'],0,40)); ?></a></td>
</tr>
<?php endforeach; ?></tbody></table>
<?php if($linker_count>10): ?><button class="tgl-btn" data-total="<?php echo min($linker_count,20); ?>" onclick="toggleSection(this)">Show All ↓</button><?php endif; ?>
<?php endif; ?>

<?php
// Show pages with link changes (exclude ignored pages)
$il_rows = [];
$il_ignored = get_option( 'sseo_thin_ignored', [] );
foreach ($a_il as $pid => $ap) {
    if ( in_array( (int) $pid, $il_ignored ) ) continue;
    $bp = $b_il[$pid] ?? null;
    $before_links = $bp ? $bp['links'] : 0;
    $after_links = $ap['links'];
    $diff = $after_links - $before_links;
    if ($diff !== 0 || $after_links === 0) {
        $il_rows[] = ['title'=>$ap['title'],'type'=>$ap['type'],'before'=>$before_links,'after'=>$after_links,'diff'=>$diff,'url'=>$ap['permalink']];
    }
}
// Sort: most links added first, then pages with 0 links
usort($il_rows, function($a,$b){ if($a['after']===0 && $b['after']!==0) return -1; if($b['after']===0 && $a['after']!==0) return 1; return $b['diff']-$a['diff']; });
if (!empty($il_rows)):
?>
<table><thead class="tb"><tr><th>Page</th><th>Before</th><th>After</th><th>Change</th><th>Status</th></tr></thead><tbody class="tgl-rows">
<?php foreach($il_rows as $ri => $r): ?>
<tr<?php echo $ri>=10?' class="extra"':''; ?>>
<td><a href="<?php echo esc_url($r['url']); ?>" target="_blank" style="color:#2563eb;text-decoration:underline;font-weight:600"><?php echo esc_html(mb_substr($r['title'],0,35)); ?></a><br><span style="font-size:11px;color:#94a3b8"><?php echo esc_html($r['type']); ?></span></td>
<td><strong><?php echo $r['before']; ?></strong> links</td>
<td><strong class="<?php echo $r['after']>=3?'grn':($r['after']>0?'org':'red'); ?>"><?php echo $r['after']; ?></strong> links</td>
<td><?php if($r['diff']>0): ?><span style="color:#16a34a;font-weight:700">+<?php echo $r['diff']; ?></span><?php elseif($r['diff']===0): ?><span style="color:#94a3b8">—</span><?php else: ?><span style="color:#dc2626"><?php echo $r['diff']; ?></span><?php endif; ?></td>
<td><?php echo $r['after']>=3?'<span class="t t-g">GOOD</span>':($r['after']>0?'<span class="t t-o">LOW</span>':'<span class="t t-r">NONE</span>'); ?></td>
</tr>
<?php endforeach; ?></tbody></table>
<?php if(count($il_rows)>10): ?><button class="tgl-btn" data-total="<?php echo count($il_rows); ?>" onclick="toggleSection(this)">Show All (<?php echo count($il_rows); ?>) ↓</button><?php endif; ?>
<?php endif; ?>
<div style="margin-top:12px;font-size:13px;color:#64748b;padding:12px;background:#f8fafc;border-radius:8px">
<strong>Recommendation:</strong> Each page should have 3-8 internal links to related content. Pages with 0 links are orphaned and harder to discover by search engines and AI chatbots.
</div>
</div>
<?php if($b['thin_stats']['thin']>0 || $a['thin_stats']['thin']>0): ?>
<div class="sec"><div class="sh"><div class="sic">📄</div><h2>Thin Content Enhancement</h2></div>
<div class="mg" style="grid-template-columns:repeat(4,1fr)">
<div class="mc"><div class="ml">Total Pages</div><div class="mn blu"><?php echo $a['thin_stats']['total']; ?></div></div>
<div class="mc"><div class="ml">Thin (<300w)</div><div class="mr"><span class="mo"><?php echo $b['thin_stats']['thin']; ?></span><span class="ma">→</span><span class="mn <?php echo $a['thin_stats']['thin']?'red':'grn'; ?>"><?php echo $a['thin_stats']['thin']; ?></span></div></div>
<div class="mc"><div class="ml">Adequate</div><div class="mn org"><?php echo $a['thin_stats']['ok']; ?></div></div>
<div class="mc"><div class="ml">Strong (800+)</div><div class="mr"><span class="mo"><?php echo $b['thin_stats']['strong']; ?></span><span class="ma">→</span><span class="mn grn"><?php echo $a['thin_stats']['strong']; ?></span></div></div>
</div>
<?php
// Build list of pages that were enhanced from thin content (from enhance log)
$thin_enhanced = [];
$el = $a['enhance_log'] ?? [];
foreach ($el as $le) {
    $lpid = (int)($le['post_id'] ?? 0);
    if (!$lpid) continue;
    $old_wc = (int) preg_replace('/[^0-9]/', '', $le['old_value'] ?? '0');
    $new_wc = (int) preg_replace('/[^0-9]/', '', $le['new_value'] ?? '0');
    $diff = $new_wc - $old_wc;
    if ($diff <= 0) continue;
    // Keep only the best (most recent) enhancement per page
    if (!isset($thin_enhanced[$lpid]) || $diff > $thin_enhanced[$lpid]['added']) {
        $p = get_post($lpid);
        $thin_enhanced[$lpid] = [
            'title' => $p ? $p->post_title : 'Page #'.$lpid,
            'type' => $p ? $p->post_type : 'page',
            'before' => $old_wc,
            'after' => $new_wc,
            'added' => $diff,
            'url' => $p ? get_permalink($lpid) : '#',
            'date' => $le['created_at'] ?? '',
        ];
    }
}
usort($thin_enhanced, function($x, $y) { return $y['added'] - $x['added']; });
$thin_enhanced = array_values($thin_enhanced);
if (!empty($thin_enhanced)):
?>
<h3 style="margin-top:20px;color:#16a34a">📈 Pages Enhanced (<?php echo count($thin_enhanced); ?>)</h3>
<table><thead class="tg"><tr><th>Page</th><th>Before</th><th>After</th><th>Words Added</th><th>Link</th></tr></thead><tbody class="tgl-rows">
<?php foreach($thin_enhanced as $ri => $te): ?>
<tr<?php echo $ri>=10?' class="extra"':''; ?>>
<td><strong><?php echo esc_html(mb_substr($te['title'],0,40)); ?></strong><br><span style="font-size:11px;color:#94a3b8"><?php echo $te['type']; ?><?php echo $te['date'] ? ' · '.date('M j', strtotime($te['date'])) : ''; ?></span></td>
<td><strong class="red"><?php echo number_format($te['before']); ?></strong> words</td>
<td><strong class="grn"><?php echo number_format($te['after']); ?></strong> words</td>
<td><span style="color:#16a34a;font-weight:700">+<?php echo number_format($te['added']); ?></span></td>
<td><a href="<?php echo esc_url($te['url']); ?>" target="_blank" style="color:#2563eb;font-size:12px">View Live ↗</a></td>
</tr>
<?php endforeach; ?></tbody></table>
<?php if(count($thin_enhanced)>10): ?><button class="tgl-btn" data-total="<?php echo count($thin_enhanced); ?>" onclick="toggleSection(this)">Show All (<?php echo count($thin_enhanced); ?>) ↓</button><?php endif; ?>
<?php endif; ?>
</div>
<?php endif; ?>

<!-- ═══ 8b. CONTENT CHANGES & NEW PAGES ═══ -->
<?php
$b_all = $b['all_pages'] ?? [];
$a_all = $a['all_pages'] ?? [];
$baseline_date = $b['date'] ?? '';
$new_pages = []; $enhanced_pages = []; $total_words_added = 0;

// Intelligent baseline: if old baseline has no all_pages, build from thin_pages data
if (empty($b_all) && !empty($b['thin_pages'])) {
    foreach ($b['thin_pages'] as $tp) {
        $b_all[$tp['post_id']] = ['id'=>$tp['post_id'],'title'=>$tp['title'],'type'=>$tp['post_type'],'words'=>$tp['word_count'],'permalink'=>$tp['permalink']??'','date'=>''];
    }
}

// Build enhance log lookup: post_id => earliest old_value word count from sseo_log
// This captures the ORIGINAL word count before any enhancements were applied via the plugin
$enhance_log_before = [];
foreach (($a['enhance_log'] ?? $b['enhance_log'] ?? []) as $log_entry) {
    if (($log_entry['type'] ?? '') !== 'enhance') continue;
    $lpid = (int)($log_entry['post_id'] ?? 0);
    if (!$lpid) continue;
    // Extract word count from "X words" format
    $old_wc = (int) preg_replace('/[^0-9]/', '', $log_entry['old_value'] ?? '0');
    // Keep the LOWEST (earliest/original) before word count per page
    if (!isset($enhance_log_before[$lpid]) || $old_wc < $enhance_log_before[$lpid]) {
        $enhance_log_before[$lpid] = $old_wc;
    }
}

// Track which pages we've processed
$processed_pids = [];

// FIRST: Always include pages from enhance log — these are confirmed enhancements
foreach ($enhance_log_before as $pid => $log_bwc) {
    if (isset($a_all[$pid])) {
        $ap = $a_all[$pid];
        $awc = $ap['words'];
        $diff = $awc - $log_bwc;
        if ($diff > 50) {
            $enhanced_pages[] = array_merge($ap, ['before_words' => $log_bwc, 'added' => $diff]);
            $total_words_added += $diff;
            $processed_pids[$pid] = true;
        }
    }
}

// THEN: Check remaining pages for word count changes between snapshots
foreach ($a_all as $pid => $ap) {
    if (isset($processed_pids[$pid])) continue;
    $processed_pids[$pid] = true;

    if (!isset($b_all[$pid])) {
        // Page not in baseline snapshot
        // ONLY include if there's proof it was actually modified via the plugin
        if (isset($enhance_log_before[$pid])) {
            // Page was enhanced via plugin — use log's original word count as "before"
            $bwc = $enhance_log_before[$pid];
            $awc = $ap['words'];
            $diff = $awc - $bwc;
            if ($diff > 0) {
                $enhanced_pages[] = array_merge($ap, ['before_words' => $bwc, 'added' => $diff]);
                $total_words_added += $diff;
            }
        } elseif ($baseline_date && !empty($ap['date']) && strtotime($ap['date']) > strtotime($baseline_date)) {
            // Genuinely new page published after baseline
            $new_pages[] = array_merge($ap, ['before_words' => 0]);
            $total_words_added += $ap['words'];
        }
        // Pages not in baseline AND not in enhance log = pre-existing, never touched — SKIP
    } else {
        // Page in both snapshots — compare word counts
        $bwc = $b_all[$pid]['words'];
        $awc = $ap['words'];
        // Also check enhance log — use the lower of snapshot vs log as true "before"
        if (isset($enhance_log_before[$pid]) && $enhance_log_before[$pid] < $bwc) {
            $bwc = $enhance_log_before[$pid];
        }
        $diff = $awc - $bwc;
        if ($diff > 50) {
            $enhanced_pages[] = array_merge($ap, ['before_words' => $bwc, 'added' => $diff]);
            $total_words_added += $diff;
        }
    }
}

// Sort enhanced pages by words added (most first)
usort($enhanced_pages, function($x, $y) { return $y['added'] - $x['added']; });

if (!empty($new_pages) || !empty($enhanced_pages)):
?>
<div class="sec"><div class="sh"><div class="sic">📝</div><h2>Content Created & Enhanced</h2></div>
<div class="mg" style="grid-template-columns:repeat(3,1fr)">
<div class="mc"><div class="ml">New Pages Created</div><div class="mn grn"><?php echo count($new_pages); ?></div></div>
<div class="mc"><div class="ml">Pages Enhanced</div><div class="mn blu"><?php echo count($enhanced_pages); ?></div></div>
<div class="mc"><div class="ml">Total Words Added</div><div class="mn grn"><?php echo number_format($total_words_added); ?></div></div>
</div>

<?php if (!empty($new_pages)): ?>
<h3 style="margin-top:20px;color:#16a34a">🆕 New Pages & Posts Created (<?php echo count($new_pages); ?>)</h3>
<table><thead class="tg"><tr><th>Page Title</th><th>Type</th><th>Before</th><th>After</th><th>Published</th><th>Link</th></tr></thead><tbody class="tgl-rows">
<?php foreach($new_pages as $ri => $np): ?>
<tr<?php echo $ri>=10?' class="extra"':''; ?>>
<td><strong><?php echo esc_html(mb_substr($np['title'],0,40)); ?></strong></td>
<td><span class="t t-b"><?php echo strtoupper($np['type']); ?></span></td>
<td><strong class="red"><?php echo number_format($np['before_words']); ?></strong> words</td>
<td><strong class="grn"><?php echo number_format($np['words']); ?></strong> words</td>
<td style="font-size:12px;color:#94a3b8"><?php echo esc_html(date('M j, Y', strtotime($np['date']))); ?></td>
<td><a href="<?php echo esc_url($np['permalink']); ?>" target="_blank" style="color:#2563eb;font-size:12px">View Live ↗</a></td>
</tr>
<?php endforeach; ?></tbody></table>
<?php if(count($new_pages)>10): ?><button class="tgl-btn" data-total="<?php echo count($new_pages); ?>" onclick="toggleSection(this)">Show All (<?php echo count($new_pages); ?>) ↓</button><?php endif; ?>
<?php endif; ?>

<?php if (!empty($enhanced_pages)): ?>
<h3 style="margin-top:20px;color:#2563eb">📈 Existing Pages Enhanced (<?php echo count($enhanced_pages); ?>)</h3>
<table><thead class="tb"><tr><th>Page Title</th><th>Before</th><th>After</th><th>Words Added</th><th>Link</th></tr></thead><tbody class="tgl-rows">
<?php foreach($enhanced_pages as $ri => $ep): ?>
<tr<?php echo $ri>=10?' class="extra"':''; ?>>
<td><strong><?php echo esc_html(mb_substr($ep['title'],0,35)); ?></strong><br><span style="font-size:11px;color:#94a3b8"><?php echo $ep['type']; ?></span></td>
<td><strong class="red"><?php echo number_format($ep['before_words']); ?></strong> words</td>
<td><strong class="grn"><?php echo number_format($ep['words']); ?></strong> words</td>
<td><span style="color:#16a34a;font-weight:700">+<?php echo number_format($ep['added']); ?></span></td>
<td><a href="<?php echo esc_url($ep['permalink']); ?>" target="_blank" style="color:#2563eb;font-size:12px">View Live ↗</a></td>
</tr>
<?php endforeach; ?></tbody></table>
<?php if(count($enhanced_pages)>10): ?><button class="tgl-btn" data-total="<?php echo count($enhanced_pages); ?>" onclick="toggleSection(this)">Show All (<?php echo count($enhanced_pages); ?>) ↓</button><?php endif; ?>
<?php endif; ?>
</div>
<?php endif; ?>

<!-- ═══ 9. TECHNICAL CONFIG ═══ -->
<div class="sec"><div class="sh"><div class="sic">⚙️</div><h2>Technical Configuration</h2></div>
<table><thead><tr><th>Feature</th><th>Before</th><th>After</th><th>Change</th></tr></thead><tbody>
<tr><td><strong>Schema Markup</strong><br><span style="font-size:11px;color:#94a3b8">LocalBusiness · Article · FAQ · Breadcrumb</span></td><td><?php echo $b['schema_on']?'<span class="t t-g">ON</span>':'<span class="t t-r">OFF</span>'; ?></td><td><?php echo $a['schema_on']?'<span class="t t-g">ON</span>':'<span class="t t-r">OFF</span>'; ?></td><td><?php echo $a['schema_on']&&!$b['schema_on']?'<span class="t t-g">ENABLED</span>':'<span class="t t-b">—</span>'; ?></td></tr>
<tr><td><strong>Open Graph & Twitter Cards</strong></td><td><?php echo $b['og_on']?'<span class="t t-g">ON</span>':'<span class="t t-r">OFF</span>'; ?></td><td><?php echo $a['og_on']?'<span class="t t-g">ON</span>':'<span class="t t-r">OFF</span>'; ?></td><td><?php echo $a['og_on']&&!$b['og_on']?'<span class="t t-g">ENABLED</span>':'<span class="t t-b">—</span>'; ?></td></tr>
<tr><td><strong>llms.txt</strong> (AI compatibility)</td><td><?php echo $b['llms_exists']?'<span class="t t-g">EXISTS</span>':'<span class="t t-r">404</span>'; ?></td><td><?php echo $a['llms_exists']?'<span class="t t-g">PUBLISHED</span>':'<span class="t t-r">MISSING</span>'; ?></td><td><?php echo $a['llms_exists']&&!$b['llms_exists']?'<span class="t t-g">CREATED</span>':'<span class="t t-b">—</span>'; ?></td></tr>
<tr><td><strong>301 Redirects</strong></td><td><?php echo $b['redirect_count']; ?> active</td><td><?php echo $a['redirect_count']; ?> active</td><td><?php $rd=$a['redirect_count']-$b['redirect_count']; echo $rd>0?'<span class="t t-g">+'.$rd.' ADDED</span>':'<span class="t t-b">—</span>'; ?></td></tr>
</tbody></table></div>

<!-- ═══ SUMMARY ═══ -->
<div class="summ">
<h3>✅ Complete Optimization Summary</h3>
<p style="color:#64748b;margin-bottom:16px">Total work accomplished during this SEO engagement.</p>
<div class="sg">
<div class="sv"><div class="v"><?php echo _d($b['meta_missing'],$a['meta_missing']); ?></div><div class="l">Meta Descriptions Fixed</div></div>
<div class="sv"><div class="v"><?php echo _d($b['alt_missing'],$a['alt_missing']); ?></div><div class="l">ALT Tags Fixed</div></div>
<div class="sv"><div class="v"><?php echo _d($b['title_issues_count'],$a['title_issues_count']); ?></div><div class="l">Title Issues Fixed</div></div>
<div class="sv"><div class="v"><?php echo _d($b['h1_issues_count'],$a['h1_issues_count']); ?></div><div class="l">H1 Issues Fixed</div></div>
<div class="sv"><div class="v"><?php echo _d(count($b['broken_links']),count($a['broken_links'])); ?></div><div class="l">Broken Links Fixed</div></div>
<div class="sv"><div class="v"><?php echo _d($b['thin_stats']['thin'],$a['thin_stats']['thin']); ?></div><div class="l">Thin Pages Enhanced</div></div>
<?php
// Reuse variables already calculated in section 8b above
$sum_new = isset($new_pages) ? count($new_pages) : 0;
$sum_enhanced = isset($enhanced_pages) ? count($enhanced_pages) : 0;
$sum_words = isset($total_words_added) ? $total_words_added : 0;
?>
<div class="sv"><div class="v"><?php echo $sum_new; ?></div><div class="l">New Pages Created</div></div>
<div class="sv"><div class="v"><?php echo $sum_enhanced; ?></div><div class="l">Pages Enhanced</div></div>
<div class="sv"><div class="v"><?php echo number_format($sum_words); ?></div><div class="l">Total Words Added</div></div>
<div class="sv"><div class="v"><?php echo max(0, ($a['total_internal_links']??0) - ($b['total_internal_links']??0)); ?></div><div class="l">Internal Links Added</div></div>
<div class="sv"><div class="v">+<?php echo max(0,$ds); ?></div><div class="l">Score Improvement</div></div>
<div class="sv"><div class="v"><?php echo $a['score']; ?>/100</div><div class="l">Final SEO Score</div></div>
</div></div>

</div>

<div class="ftr">
<p>Confidential · Prepared for <strong><?php echo esc_html($client); ?></strong> · <?php echo esc_html($date); ?></p>
<p style="margin-top:6px;opacity:.6">Powered by <strong><?php echo esc_html( sseo_product_name() ); ?></strong></p>
</div>
</body></html>
