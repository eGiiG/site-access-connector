<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Testimonials {

    public function __construct() {
        add_shortcode( 'sseo_testimonials', [ $this, 'render_shortcode' ] );
        // CSS is now inline with shortcode output (get_inline_css) - no wp_head hook needed
    }

    // ═══ GOOGLE PLACES API ═══

    public function fetch_google_reviews() {
        $api_key  = get_option('sseo_google_places_key', '');
        $place_id = get_option('sseo_google_place_id', '');
        if ( empty($api_key) || empty($place_id) ) {
            return new WP_Error('config', 'Google Places API key and Place ID are required.');
        }

        // Fetch with reviews sorted by newest
        $url = 'https://maps.googleapis.com/maps/api/place/details/json?' . http_build_query([
            'place_id'    => $place_id,
            'fields'      => 'name,rating,user_ratings_total,reviews,url,formatted_phone_number,formatted_address',
            'reviews_sort'=> 'newest',
            'key'         => $api_key,
        ]);

        $response = wp_remote_get($url, ['timeout' => 15]);
        if ( is_wp_error($response) ) return $response;

        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ( ($body['status'] ?? '') !== 'OK' ) {
            return new WP_Error('api', 'Google: ' . ($body['status'] ?? 'unknown') . ' — ' . ($body['error_message'] ?? 'Check your API key and Place ID'));
        }

        $result  = $body['result'] ?? [];
        $reviews = $result['reviews'] ?? [];

        // Also fetch "most relevant" reviews (separate call)
        $url2 = 'https://maps.googleapis.com/maps/api/place/details/json?' . http_build_query([
            'place_id'    => $place_id,
            'fields'      => 'reviews',
            'reviews_sort'=> 'most_relevant',
            'key'         => $api_key,
        ]);
        $response2 = wp_remote_get($url2, ['timeout' => 15]);
        if (!is_wp_error($response2)) {
            $body2 = json_decode(wp_remote_retrieve_body($response2), true);
            if (($body2['status'] ?? '') === 'OK') {
                $reviews2 = $body2['result']['reviews'] ?? [];
                // Merge, deduplicate by author + time
                $seen = [];
                foreach ($reviews as $r) $seen[$r['author_name'] . ($r['time'] ?? '')] = true;
                foreach ($reviews2 as $r) {
                    $key = $r['author_name'] . ($r['time'] ?? '');
                    if (!isset($seen[$key])) {
                        $reviews[] = $r;
                        $seen[$key] = true;
                    }
                }
            }
        }

        $stored = [];
        foreach ( $reviews as $r ) {
            $stored[] = [
                'source'  => 'google',
                'author'  => $r['author_name'] ?? 'Customer',
                'rating'  => (int)($r['rating'] ?? 5),
                'text'    => $r['text'] ?? '',
                'date'    => $r['relative_time_description'] ?? '',
                'photo'   => $r['profile_photo_url'] ?? '',
                'time'    => $r['time'] ?? 0,
            ];
        }

        // Sort by rating desc then time desc
        usort($stored, function($a, $b) {
            if ($b['rating'] !== $a['rating']) return $b['rating'] - $a['rating'];
            return ($b['time'] ?? 0) - ($a['time'] ?? 0);
        });

        update_option('sseo_google_reviews', $stored);
        update_option('sseo_google_rating', $result['rating'] ?? '');
        update_option('sseo_google_review_count', $result['user_ratings_total'] ?? '');
        update_option('sseo_google_business_name', $result['name'] ?? '');
        update_option('sseo_google_business_url', $result['url'] ?? '');
        update_option('sseo_google_business_address', $result['formatted_address'] ?? '');
        update_option('sseo_google_reviews_fetched', current_time('mysql'));

        return [
            'reviews'       => $stored,
            'rating'        => $result['rating'] ?? 0,
            'total_reviews' => $result['user_ratings_total'] ?? 0,
            'business_name' => $result['name'] ?? '',
            'google_url'    => $result['url'] ?? '',
            'fetched_count' => count($stored),
        ];
    }

    // ═══ MANUAL REVIEWS ═══

    public function get_manual_reviews() { return get_option('sseo_manual_reviews', []); }

    public function save_manual_review( $data ) {
        $reviews = $this->get_manual_reviews();
        $reviews[] = [
            'source'  => 'manual',
            'author'  => sanitize_text_field($data['author'] ?? 'Customer'),
            'rating'  => max(1, min(5, (int)($data['rating'] ?? 5))),
            'text'    => sanitize_textarea_field($data['text'] ?? ''),
            'location'=> sanitize_text_field($data['location'] ?? ''),
            'project' => sanitize_text_field($data['project'] ?? ''),
            'date'    => sanitize_text_field($data['date'] ?? current_time('F Y')),
        ];
        update_option('sseo_manual_reviews', $reviews);
        return count($reviews);
    }

    public function delete_manual_review( $index ) {
        $reviews = $this->get_manual_reviews();
        if ( isset($reviews[$index]) ) {
            array_splice($reviews, $index, 1);
            update_option('sseo_manual_reviews', $reviews);
        }
        return $reviews;
    }

    // ═══ GET ALL REVIEWS ═══

    public function get_all_reviews( $count = 10, $source = 'all', $min_rating = 1 ) {
        $all = [];
        if ( $source === 'all' || $source === 'google' ) {
            foreach ( get_option('sseo_google_reviews', []) as $r ) {
                if ( $r['rating'] >= $min_rating ) $all[] = $r;
            }
        }
        if ( $source === 'all' || $source === 'manual' ) {
            foreach ( $this->get_manual_reviews() as $r ) {
                if ( $r['rating'] >= $min_rating ) $all[] = $r;
            }
        }
        usort($all, function($a, $b) {
            if ($b['rating'] !== $a['rating']) return $b['rating'] - $a['rating'];
            return ($b['time'] ?? 0) - ($a['time'] ?? 0);
        });
        return array_slice($all, 0, $count);
    }

    // ═══ SHORTCODE ═══

    public function render_shortcode( $atts ) {
        $atts = shortcode_atts([
            'count'      => 6,
            'style'      => 'cards',
            'source'     => 'all',
            'min_rating' => 4,
            'columns'    => 2,
            'show_rating'=> 'true',
            'show_photo' => 'true',
        ], $atts);

        $reviews = $this->get_all_reviews((int)$atts['count'], $atts['source'], (int)$atts['min_rating']);
        if ( empty($reviews) ) return '<p style="text-align:center;color:#64748b;">No reviews yet.</p>';

        $biz_name  = get_option('sseo_google_business_name', get_option('sseo_brand_name', get_bloginfo('name')));
        $rating    = get_option('sseo_google_rating', get_option('sseo_avg_rating', ''));
        $total     = get_option('sseo_google_review_count', get_option('sseo_review_count', ''));
        $google_url= get_option('sseo_google_business_url', '');

        // Include CSS inline (once per page) so it works in admin, AJAX, frontend, everywhere
        $css = '';
        if ( ! self::$css_rendered ) {
            self::$css_rendered = true;
            $css = $this->get_inline_css();
        }

        $method = 'render_' . $atts['style'];
        if ( method_exists($this, $method) ) {
            return $css . $this->$method($reviews, $atts, $biz_name, $rating, $total, $google_url);
        }
        return $css . $this->render_cards($reviews, $atts, $biz_name, $rating, $total, $google_url);
    }

    private static $css_rendered = false;

    private function get_inline_css() {
        return '<style>
.sseo-rw{margin:32px 0;font-family:system-ui,-apple-system,BlinkMacSystemFont,sans-serif}
.sseo-rw-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:12px}
.sseo-rw-biz{display:flex;align-items:center;gap:12px}
.sseo-rw-glogo{flex-shrink:0;display:flex}
.sseo-rw-bizname{font-size:18px;font-weight:700;color:#1e293b}
.sseo-rw-summary{font-size:13px;color:#64748b;margin-top:2px}
.sseo-rw-glink{font-size:13px;font-weight:600;color:#4285F4;text-decoration:none;padding:8px 16px;border:1px solid #4285F4;border-radius:8px;white-space:nowrap;transition:all .2s}
.sseo-rw-glink:hover{background:#4285F4;color:#fff}
.sseo-rw-st{letter-spacing:1px;font-size:16px}
.sseo-rw-sf{color:#f59e0b}
.sseo-rw-se{color:#d1d5db}
.sseo-rw-grid{display:grid!important;gap:16px!important}
.sseo-rw-grid-1{grid-template-columns:1fr!important}
.sseo-rw-grid-2{grid-template-columns:repeat(2,1fr)!important}
.sseo-rw-grid-3{grid-template-columns:repeat(3,1fr)!important}
.sseo-rw-grid-4{grid-template-columns:repeat(4,1fr)!important}
.sseo-rw-card{background:#fff!important;border:1px solid #e2e8f0!important;border-radius:14px!important;padding:24px!important;display:flex!important;flex-direction:column!important;transition:box-shadow .2s;min-height:220px}
.sseo-rw-card:hover{box-shadow:0 8px 24px rgba(0,0,0,.07)}
.sseo-rw-card-top{display:flex!important;align-items:center!important;gap:12px!important}
.sseo-rw-av{width:44px!important;height:44px!important;border-radius:50%!important;object-fit:cover;flex-shrink:0}
.sseo-rw-init{color:#fff;display:flex!important;align-items:center!important;justify-content:center!important;font-weight:700;font-size:18px}
.sseo-rw-who{flex:1;min-width:0}
.sseo-rw-name{font-weight:600;font-size:14px;color:#1e293b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sseo-rw-meta{font-size:12px;color:#94a3b8;margin-top:1px}
.sseo-rw-src{flex-shrink:0;opacity:.7}
.sseo-rw-stars{margin:10px 0 4px}
.sseo-rw-text{font-size:14px;line-height:1.7;color:#475569;margin:8px 0 0;flex:1}
.sseo-rw-more{background:none;border:none;color:#6366f1;font-size:13px;font-weight:600;cursor:pointer;padding:4px 0;margin-top:4px;display:block}
.sseo-rw-more:hover{text-decoration:underline}
.sseo-rw-proj{font-size:12px;color:#6366f1;font-weight:500;margin-top:10px;padding-top:10px;border-top:1px solid #f1f5f9}
.sseo-sl-wrap{position:relative}
.sseo-sl-track{display:flex;gap:16px;overflow-x:auto;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;padding:4px 0 16px;scrollbar-width:thin}
.sseo-sl-track::-webkit-scrollbar{height:6px}
.sseo-sl-track::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:3px}
.sseo-sl-card{min-width:320px;max-width:360px;scroll-snap-align:start;background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:24px;flex-shrink:0;display:flex;flex-direction:column}
.sseo-sl-nav{display:flex;gap:8px}
.sseo-sl-btn{width:36px;height:36px;border-radius:50%;border:1px solid #e2e8f0;background:#fff;cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center;transition:all .2s;color:#475569}
.sseo-sl-btn:hover{background:#f1f5f9;border-color:#94a3b8}
.sseo-rw-minitem{padding:20px 0;border-bottom:1px solid #f1f5f9}
.sseo-rw-minitem:last-child{border-bottom:none}
@media(max-width:768px){.sseo-rw-grid{grid-template-columns:1fr!important}.sseo-sl-card{min-width:280px}.sseo-rw-head{flex-direction:column;align-items:flex-start}}
</style>';
    }

    // ─── STYLE 1: CARDS ───

    private function render_cards( $reviews, $atts, $biz_name, $rating, $total, $google_url ) {
        $cols = max(1, min(4, (int)$atts['columns']));
        $html = '<div class="sseo-rw">';

        // Header with business name and Google branding
        $html .= '<div class="sseo-rw-head">';
        $html .= '<div class="sseo-rw-biz">';
        $html .= '<div class="sseo-rw-glogo"><svg viewBox="0 0 24 24" width="28" height="28"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg></div>';
        $html .= '<div>';
        $html .= '<div class="sseo-rw-bizname">' . esc_html($biz_name) . '</div>';
        if ( $rating && $total ) {
            $html .= '<div class="sseo-rw-summary">' . $this->stars_html((float)$rating) . ' <strong>' . esc_html($rating) . '</strong>/5 based on ' . esc_html($total) . ' reviews</div>';
        }
        $html .= '</div></div>';
        if ( $google_url ) {
            $html .= '<a href="' . esc_url($google_url) . '" target="_blank" rel="noopener" class="sseo-rw-glink">Write a review</a>';
        }
        $html .= '</div>';

        $html .= '<div class="sseo-rw-grid sseo-rw-grid-' . $cols . '">';
        foreach ( $reviews as $r ) {
            $html .= '<div class="sseo-rw-card">';
            $html .= '<div class="sseo-rw-card-top">';
            if ( $atts['show_photo'] === 'true' && !empty($r['photo']) ) {
                $html .= '<img src="' . esc_url($r['photo']) . '" class="sseo-rw-av" alt="">';
            } else {
                $initial = mb_strtoupper(mb_substr($r['author'], 0, 1));
                $colors = ['#6366f1','#0ea5e9','#f59e0b','#10b981','#ec4899','#8b5cf6','#14b8a6'];
                $ci = crc32($r['author']) % count($colors);
                $html .= '<div class="sseo-rw-av sseo-rw-init" style="background:' . $colors[$ci] . '">' . esc_html($initial) . '</div>';
            }
            $html .= '<div class="sseo-rw-who"><div class="sseo-rw-name">' . esc_html($r['author']) . '</div>';
            $meta_parts = [];
            if ( !empty($r['location']) ) $meta_parts[] = esc_html($r['location']);
            if ( !empty($r['date']) ) $meta_parts[] = esc_html($r['date']);
            if ( $meta_parts ) $html .= '<div class="sseo-rw-meta">' . implode(' · ', $meta_parts) . '</div>';
            $html .= '</div>';
            // Source icon
            if ( ($r['source'] ?? '') === 'google' ) {
                $html .= '<div class="sseo-rw-src"><svg viewBox="0 0 24 24" width="18" height="18"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg></div>';
            }
            $html .= '</div>';
            if ( $atts['show_rating'] === 'true' ) $html .= '<div class="sseo-rw-stars">' . $this->stars_html($r['rating']) . '</div>';
            $text = esc_html($r['text']);
            $max_chars = 180;
            if ( mb_strlen($text) > $max_chars ) {
                $short = mb_substr($text, 0, $max_chars) . '...';
                $html .= '<p class="sseo-rw-text"><span class="sseo-rw-short">' . $short . '</span><span class="sseo-rw-full" style="display:none">' . $text . '</span></p>';
                $html .= '<button class="sseo-rw-more" onclick="var p=this.previousElementSibling;var s=p.querySelector(\'.sseo-rw-short\');var f=p.querySelector(\'.sseo-rw-full\');if(s.style.display!==\'none\'){s.style.display=\'none\';f.style.display=\'inline\';this.textContent=\'See less\';}else{s.style.display=\'inline\';f.style.display=\'none\';this.textContent=\'See more\';}">See more</button>';
            } else {
                $html .= '<p class="sseo-rw-text">' . $text . '</p>';
            }
            if ( !empty($r['project']) ) $html .= '<div class="sseo-rw-proj">' . esc_html($r['project']) . '</div>';
            $html .= '</div>';
        }
        $html .= '</div></div>';
        return $html;
    }

    // ─── STYLE 2: SLIDER ───

    private function render_slider( $reviews, $atts, $biz_name, $rating, $total, $google_url ) {
        $uid = 'sseo-sl-' . wp_rand(1000, 9999);
        $html = '<div class="sseo-rw">';

        $html .= '<div class="sseo-rw-head">';
        $html .= '<div class="sseo-rw-biz">';
        $html .= '<div class="sseo-rw-glogo"><svg viewBox="0 0 24 24" width="28" height="28"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg></div>';
        $html .= '<div><div class="sseo-rw-bizname">' . esc_html($biz_name) . '</div>';
        if ( $rating && $total ) $html .= '<div class="sseo-rw-summary">' . $this->stars_html((float)$rating) . ' <strong>' . esc_html($rating) . '</strong>/5 · ' . esc_html($total) . ' reviews</div>';
        $html .= '</div></div>';
        $html .= '<div class="sseo-sl-nav">';
        $html .= '<button class="sseo-sl-btn" onclick="document.querySelector(\'#' . $uid . ' .sseo-sl-track\').scrollBy({left:-340,behavior:\'smooth\'})">&#8592;</button>';
        $html .= '<button class="sseo-sl-btn" onclick="document.querySelector(\'#' . $uid . ' .sseo-sl-track\').scrollBy({left:340,behavior:\'smooth\'})">&#8594;</button>';
        $html .= '</div></div>';

        $html .= '<div class="sseo-sl-wrap" id="' . $uid . '"><div class="sseo-sl-track">';
        foreach ( $reviews as $r ) {
            $initial = mb_strtoupper(mb_substr($r['author'], 0, 1));
            $colors = ['#6366f1','#0ea5e9','#f59e0b','#10b981','#ec4899','#8b5cf6','#14b8a6'];
            $ci = crc32($r['author']) % count($colors);
            $html .= '<div class="sseo-sl-card">';
            $html .= '<div class="sseo-rw-stars">' . $this->stars_html($r['rating']) . '</div>';
            $text = esc_html($r['text']);
            $max_chars = 180;
            if ( mb_strlen($text) > $max_chars ) {
                $short = mb_substr($text, 0, $max_chars) . '...';
                $html .= '<p class="sseo-rw-text"><span class="sseo-rw-short">"' . $short . '"</span><span class="sseo-rw-full" style="display:none">"' . $text . '"</span></p>';
                $html .= '<button class="sseo-rw-more" onclick="var p=this.previousElementSibling;var s=p.querySelector(\'.sseo-rw-short\');var f=p.querySelector(\'.sseo-rw-full\');if(s.style.display!==\'none\'){s.style.display=\'none\';f.style.display=\'inline\';this.textContent=\'See less\';}else{s.style.display=\'inline\';f.style.display=\'none\';this.textContent=\'See more\';}">See more</button>';
            } else {
                $html .= '<p class="sseo-rw-text">"' . $text . '"</p>';
            }
            $html .= '<div class="sseo-rw-card-top" style="margin-top:auto">';
            if ( !empty($r['photo']) ) {
                $html .= '<img src="' . esc_url($r['photo']) . '" class="sseo-rw-av" alt="">';
            } else {
                $html .= '<div class="sseo-rw-av sseo-rw-init" style="background:' . $colors[$ci] . '">' . esc_html($initial) . '</div>';
            }
            $html .= '<div class="sseo-rw-who"><div class="sseo-rw-name">' . esc_html($r['author']) . '</div>';
            if ( !empty($r['date']) ) $html .= '<div class="sseo-rw-meta">' . esc_html($r['date']) . '</div>';
            $html .= '</div></div></div>';
        }
        $html .= '</div></div></div>';
        return $html;
    }

    // ─── STYLE 3: MINIMAL ───

    private function render_minimal( $reviews, $atts, $biz_name, $rating, $total, $google_url ) {
        $html = '<div class="sseo-rw sseo-rw-min">';

        $html .= '<div class="sseo-rw-head" style="border-bottom:1px solid #e2e8f0;padding-bottom:16px;margin-bottom:0">';
        $html .= '<div class="sseo-rw-biz">';
        $html .= '<div class="sseo-rw-glogo"><svg viewBox="0 0 24 24" width="24" height="24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg></div>';
        $html .= '<div><div class="sseo-rw-bizname" style="font-size:16px">' . esc_html($biz_name) . '</div>';
        if ( $rating && $total ) $html .= '<div class="sseo-rw-summary">' . $this->stars_html((float)$rating) . ' ' . esc_html($rating) . '/5 · ' . esc_html($total) . ' reviews</div>';
        $html .= '</div></div></div>';

        foreach ( $reviews as $r ) {
            $html .= '<div class="sseo-rw-minitem">';
            $html .= '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><div class="sseo-rw-stars">' . $this->stars_html($r['rating']) . '</div>';
            if ( !empty($r['date']) ) $html .= '<span style="font-size:12px;color:#94a3b8">' . esc_html($r['date']) . '</span>';
            $html .= '</div>';
            $html .= '<blockquote class="sseo-rw-quote">"' . esc_html($r['text']) . '"</blockquote>';
            $html .= '<div class="sseo-rw-cite"><strong>' . esc_html($r['author']) . '</strong>';
            if ( !empty($r['location']) ) $html .= ' · ' . esc_html($r['location']);
            if ( !empty($r['project']) ) $html .= ' · ' . esc_html($r['project']);
            $html .= '</div></div>';
        }
        $html .= '</div>';
        return $html;
    }

    private function stars_html( $rating ) {
        $full  = floor($rating);
        $half  = ($rating - $full) >= 0.3 ? 1 : 0;
        $empty = 5 - $full - $half;
        $html  = '<span class="sseo-rw-st">';
        for ($i = 0; $i < $full; $i++) $html .= '<span class="sseo-rw-sf">&#9733;</span>';
        if ($half) $html .= '<span class="sseo-rw-sf">&#9733;</span>';
        for ($i = 0; $i < $empty; $i++) $html .= '<span class="sseo-rw-se">&#9733;</span>';
        $html .= '</span>';
        return $html;
    }

    public function get_shortcode( $style = 'cards', $count = 6, $source = 'all', $columns = 2, $min_rating = 4 ) {
        return '[sseo_testimonials style="' . $style . '" count="' . $count . '" source="' . $source . '" columns="' . $columns . '" min_rating="' . $min_rating . '"]';
    }

    public function generate_widget_html( $style = 'cards', $count = 6, $source = 'all', $columns = 2, $min_rating = 4 ) {
        return $this->render_shortcode(['style'=>$style,'count'=>$count,'source'=>$source,'columns'=>$columns,'min_rating'=>$min_rating]);
    }

    public function inject_styles() {
        // Load on singular pages OR the blog/archive page
        if ( ! is_singular() && ! is_home() ) return;

        // Check post_content AND archive intro meta for the shortcode
        $has_shortcode = false;
        if ( is_singular() ) {
            global $post;
            if ( $post && strpos($post->post_content, 'sseo_testimonials') !== false ) {
                $has_shortcode = true;
            }
        }
        if ( is_home() ) {
            $page_id = (int) get_option('page_for_posts');
            if ( $page_id ) {
                $intro = get_post_meta($page_id, '_sseo_archive_intro', true);
                if ( $intro && strpos($intro, 'sseo_testimonials') !== false ) {
                    $has_shortcode = true;
                }
            }
        }
        if ( ! $has_shortcode ) return;

        echo '<style>
.sseo-rw{margin:32px 0;font-family:system-ui,-apple-system,BlinkMacSystemFont,sans-serif}
.sseo-rw-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:12px}
.sseo-rw-biz{display:flex;align-items:center;gap:12px}
.sseo-rw-glogo{flex-shrink:0;display:flex}
.sseo-rw-bizname{font-size:18px;font-weight:700;color:#1e293b}
.sseo-rw-summary{font-size:13px;color:#64748b;margin-top:2px}
.sseo-rw-glink{font-size:13px;font-weight:600;color:#4285F4;text-decoration:none;padding:8px 16px;border:1px solid #4285F4;border-radius:8px;white-space:nowrap;transition:all .2s}
.sseo-rw-glink:hover{background:#4285F4;color:#fff}
.sseo-rw-st{letter-spacing:1px;font-size:16px}
.sseo-rw-sf{color:#f59e0b}
.sseo-rw-se{color:#d1d5db}
.sseo-rw-grid{display:grid!important;gap:16px}
.sseo-rw-grid-1{grid-template-columns:1fr!important}
.sseo-rw-grid-2{grid-template-columns:repeat(2,1fr)!important}
.sseo-rw-grid-3{grid-template-columns:repeat(3,1fr)!important}
.sseo-rw-grid-4{grid-template-columns:repeat(4,1fr)!important}
.sseo-rw-card{background:#fff!important;border:1px solid #e2e8f0!important;border-radius:14px!important;padding:24px!important;display:flex!important;flex-direction:column!important;transition:box-shadow .2s;min-height:220px}
.sseo-rw-card:hover{box-shadow:0 8px 24px rgba(0,0,0,.07)}
.sseo-rw-card-top{display:flex;align-items:center;gap:12px}
.sseo-rw-av{width:44px;height:44px;border-radius:50%;object-fit:cover;flex-shrink:0}
.sseo-rw-init{color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px}
.sseo-rw-who{flex:1;min-width:0}
.sseo-rw-name{font-weight:600;font-size:14px;color:#1e293b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sseo-rw-meta{font-size:12px;color:#94a3b8;margin-top:1px}
.sseo-rw-src{flex-shrink:0;opacity:.7}
.sseo-rw-stars{margin:10px 0 4px}
.sseo-rw-text{font-size:14px;line-height:1.7;color:#475569;margin:8px 0 0;flex:1}
.sseo-rw-more{background:none;border:none;color:#6366f1;font-size:13px;font-weight:600;cursor:pointer;padding:4px 0;margin-top:4px;display:block}
.sseo-rw-more:hover{text-decoration:underline}
.sseo-rw-proj{font-size:12px;color:#6366f1;font-weight:500;margin-top:10px;padding-top:10px;border-top:1px solid #f1f5f9}
.sseo-sl-wrap{position:relative}
.sseo-sl-track{display:flex;gap:16px;overflow-x:auto;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;padding:4px 0 16px;scrollbar-width:thin}
.sseo-sl-track::-webkit-scrollbar{height:6px}
.sseo-sl-track::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:3px}
.sseo-sl-card{min-width:320px;max-width:360px;scroll-snap-align:start;background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:24px;flex-shrink:0;display:flex;flex-direction:column}
.sseo-sl-nav{display:flex;gap:8px}
.sseo-sl-btn{width:36px;height:36px;border-radius:50%;border:1px solid #e2e8f0;background:#fff;cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center;transition:all .2s;color:#475569}
.sseo-sl-btn:hover{background:#f1f5f9;border-color:#94a3b8}
.sseo-rw-minitem{padding:20px 0;border-bottom:1px solid #f1f5f9}
.sseo-rw-minitem:last-child{border:none}
.sseo-rw-quote{font-style:italic;font-size:15px;line-height:1.7;color:#334155;margin:0 0 8px;padding:0;border:none}
.sseo-rw-cite{font-size:13px;color:#64748b}
@media(max-width:768px){.sseo-rw-grid{grid-template-columns:1fr!important}.sseo-sl-card{min-width:280px}.sseo-rw-head{flex-direction:column;align-items:flex-start}}
</style>' . "\n";
    }


    /**
     * Generate direct Google Review link from Place ID
     * Returns the shortened link customers can click to leave a review
     */
    public static function get_review_link() {
        $place_id = get_option('sseo_google_place_id', '');
        if ( empty($place_id) ) {
            return new WP_Error('no_place_id', 'Google Place ID is required. Set it in Settings.');
        }
        return [
            'review_url'  => 'https://search.google.com/local/writereview?placeid=' . urlencode($place_id),
            'short_url'   => 'https://g.page/r/' . urlencode($place_id) . '/review',
            'place_id'    => $place_id,
            'embed_html'  => '<a href="https://search.google.com/local/writereview?placeid=' . esc_attr($place_id) . '" target="_blank" rel="noopener" style="display:inline-block;padding:12px 24px;background:#4285f4;color:#fff;border-radius:8px;text-decoration:none;font-weight:600">⭐ Leave Us a Google Review</a>',
            'qr_url'      => 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' . urlencode('https://search.google.com/local/writereview?placeid=' . $place_id),
        ];
    }

}
