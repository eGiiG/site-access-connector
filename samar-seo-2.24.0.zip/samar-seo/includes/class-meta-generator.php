<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SSEO_Meta_Generator {
    private $api;

    public function __construct() { $this->api = new SSEO_API_Handler(); }

    public function generate( $post_id, $count = 3, $tone = '' ) {
        $post = get_post( $post_id );
        if ( ! $post ) return new WP_Error( 'no_post', 'Post not found.' );

        $content = wp_trim_words( wp_strip_all_tags( $post->post_content ), 300, '...' );
        $kw = $this->get_keywords( $post );
        $brand = get_option( 'sseo_brand_name', '' );
        $loc   = get_option( 'sseo_target_location', '' );
        if ( ! $tone ) $tone = get_option( 'sseo_default_tone', 'professional' );

        $prompt = "You are an expert SEO copywriter. Generate {$count} unique meta descriptions.

Page Title: {$post->post_title}
Content: {$content}
Keywords: {$kw}
Tone: {$tone}" . ($brand ? "\nBrand: {$brand}" : '') . ($loc ? "\nLocation: {$loc}" : '') . "

Rules:
- MUST be 150-160 characters each
- Include keywords naturally
- Include CTA or value prop
- Each distinct approach (benefit, urgency, question, social-proof)

Return ONLY JSON array: [{\"description\":\"...\",\"charCount\":155,\"approach\":\"benefit-focused\"}]
No markdown, no fences.";

        $r = $this->api->complete( $prompt, 0.7, 4000 );
        if ( is_wp_error( $r ) ) return $r;

        $raw = $r['content'];
        $p = SSEO_API_Handler::parse_json( $raw );

        // If JSON parsing fails, extract descriptions from raw text
        if ( is_wp_error( $p ) || !is_array( $p ) ) {
            $descriptions = [];
            // Try to find quoted strings that look like meta descriptions (100-170 chars)
            if ( preg_match_all( '/"description"\s*:\s*"([^"]{80,200})"/', $raw, $matches ) ) {
                foreach ( $matches[1] as $i => $desc ) {
                    $descriptions[] = [
                        'description' => $desc,
                        'charCount'   => strlen( $desc ),
                        'approach'    => 'extracted-' . ($i + 1),
                    ];
                }
            }
            // Fallback: extract any sentence-like strings 100-170 chars
            if ( empty( $descriptions ) && preg_match_all( '/([A-Z][^"]{99,169}[.!?])/', $raw, $matches ) ) {
                foreach ( array_slice( $matches[1], 0, $count ) as $i => $desc ) {
                    $descriptions[] = [
                        'description' => trim( $desc ),
                        'charCount'   => strlen( trim( $desc ) ),
                        'approach'    => 'fallback-' . ($i + 1),
                    ];
                }
            }
            // Last resort: auto-generate from title + keywords
            if ( empty( $descriptions ) ) {
                $auto = substr( $post->post_title . ' - ' . $content, 0, 155 ) . '...';
                $descriptions[] = [
                    'description' => $auto,
                    'charCount'   => strlen( $auto ),
                    'approach'    => 'auto-generated',
                ];
            }
            $p = $descriptions;
        }

        return [ 'descriptions' => $p, 'tokens' => $r['tokens'], 'post_id' => $post_id, 'post_title' => $post->post_title ];
    }

    public function apply( $post_id, $desc ) {
        $seo = new SSEO_SEO_Integration();
        $old = $seo->get_meta( $post_id );
        $seo->set_meta( $post_id, $desc );
        $this->log( $post_id, 'meta', $old, $desc );
        return true;
    }

    private function get_keywords( $post ) {
        $kw = [];
        $seo = new SSEO_SEO_Integration();
        $fk = $seo->get_focus_keyword( $post->ID );
        if ( $fk ) $kw[] = $fk;
        $cats = get_the_category( $post->ID );
        if ( $cats ) foreach ( array_slice($cats,0,3) as $c ) $kw[] = $c->name;
        $tags = get_the_tags( $post->ID );
        if ( $tags ) foreach ( array_slice($tags,0,5) as $t ) $kw[] = $t->name;
        return implode( ', ', array_unique( $kw ) );
    }

    private function log( $pid, $type, $old, $new, $tok = 0 ) {
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'sseo_log', [ 'post_id'=>$pid, 'type'=>$type, 'old_value'=>$old, 'new_value'=>$new, 'tokens_used'=>$tok ] );
    }
}
